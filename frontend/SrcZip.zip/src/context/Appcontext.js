import React, { createContext } from 'react';

export const ApplicationContext = createContext();
export const AuthContext = createContext();
export const UserRoleAccessContext = createContext();
export const DataContext = createContext();