// // apiClient.js
// import axios from '../../../axiosInstance';
// import cancelTokenManager from "./CancelTokenManager";

// export const axiosWithCancel = async (url, options = {}) => {
//   const cancelTokenSource = axios.CancelToken.source();
//   cancelTokenManager.addCancelToken(cancelTokenSource.cancel);

//   try {
//     const response = await axios({
//       url,
//       ...options,
//       cancelToken: cancelTokenSource.token,
//     });

//     return response.data;
//   } catch (error) {
//     if (axios.isCancel(error)) {
//       console.log("Request canceled:", error.message);
//     } else {
//       throw error;
//     }
//   }
// };

// apiClient.js
// apiClient.js
// import axios from '../../../axiosInstance';
import axios from '../../../axiosInstance';
import cancelTokenManager from './CancelTokenManager';

export const axiosWithCancel = async (url, options = {}) => {
  const cancelSource = axios.CancelToken.source();
  cancelTokenManager.addCancelToken(cancelSource.cancel); // Register cancel function

  console.log(`[axiosWithCancel] Starting request to: ${url}`);

  try {
    const response = await axios({
      url,
      ...options,
      cancelToken: cancelSource.token,
    });

    console.log(`[axiosWithCancel] Success: ${url}`);
    return response.data;
  } catch (error) {
    if (axios.isCancel(error)) {
      console.warn(`[axiosWithCancel] Cancelled: ${url}`, error.message);
    } else {
      console.error(`[axiosWithCancel] Error: ${url}`, error);
    }
  }
};
