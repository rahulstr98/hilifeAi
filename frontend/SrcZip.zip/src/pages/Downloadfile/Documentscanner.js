import React, { useState, useRef, useEffect } from 'react';
import {
    Box, Button, Card, Grid, CardContent, Container, IconButton,
    CircularProgress, Slider, Select, MenuItem, FormControl, InputLabel,
    Paper, Dialog, DialogActions, DialogContent, DialogTitle, Tooltip,
    Typography, TextField, FormControlLabel, Switch, Badge, DialogContentText,
    useMediaQuery, useTheme, Snackbar, Alert, LinearProgress, List, ListItem,
    ListItemAvatar, Avatar, ListItemText, ListItemSecondaryAction, Divider
} from '@mui/material';
import { jsPDF } from 'jspdf';
import { Cropper } from 'react-cropper';
import 'cropperjs/dist/cropper.css';
import { saveAs } from 'file-saver';
import debounce from 'lodash.debounce';
import { DragDropContext, Droppable, Draggable } from 'react-beautiful-dnd';

// Import icons
import {
    CameraAlt as CameraAltIcon,
    Close as CloseIcon,
    Download as DownloadIcon,
    Adjust as AdjustIcon,
    FilterBAndW as FilterBAndWIcon,
    Image as ImageIcon,
    RotateRight as RotateIcon,
    Crop as CropIcon,
    Flip as FlipIcon,
    PhotoCamera as PhotoCameraIcon,
    InsertDriveFile as InsertDriveFileIcon,
    PictureAsPdf as PdfIcon,
    Image as JpgIcon,
    Collections as PngIcon,
    AutoFixHigh as MagicIcon,
    FlashOn as FlashOnIcon,
    FlashOff as FlashOffIcon,
    Check as CheckIcon,
    CloudUpload as UploadIcon,
    FlipCameraAndroid as FlipCameraIcon,
    ChevronLeft as ChevronLeftIcon,
    ChevronRight as ChevronRightIcon,
    Collections as GalleryIcon,
    Delete as DeleteIcon,
    Reorder as ReorderIcon,
    AddPhotoAlternate as AddPhotoIcon,
    GridOn as GridIcon
} from '@mui/icons-material';

const DocumentScanner = () => {
    const theme = useTheme();
    const isMobile = useMediaQuery(theme.breakpoints.down('sm'));

    // State variables
    const [images, setImages] = useState([]);
    const [processedImages, setProcessedImages] = useState([]);
    const [imageSettings, setImageSettings] = useState([]);
    const [currentImageIndex, setCurrentImageIndex] = useState(0);
    const [isProcessing, setIsProcessing] = useState(false);
    const [openCrop, setOpenCrop] = useState(false);
    const [cameraStream, setCameraStream] = useState(null);
    const [showCamera, setShowCamera] = useState(false);
    const [fileNames, setFileNames] = useState([]);
    const [openSaveDialog, setOpenSaveDialog] = useState(false);
    const [selectedFormat, setSelectedFormat] = useState('pdf');
    const [capturedImages, setCapturedImages] = useState([]);
    const [showGallery, setShowGallery] = useState(false);
    const [cameraFacingMode, setCameraFacingMode] = useState('environment');
    const [mirrorPreview, setMirrorPreview] = useState(false);
    const [flashSupported, setFlashSupported] = useState(false);
    const [flashOn, setFlashOn] = useState(false);
    const [error, setError] = useState(null);
    const [progress, setProgress] = useState(0);
    const [showImageList, setShowImageList] = useState(false);
    const [captureCountdown, setCaptureCountdown] = useState(0);

    // Refs
    const fileInputRef = useRef(null);
    const cameraVideoRef = useRef(null);
    const cropperRef = useRef(null);
    const canvasRef = useRef(null);
    const countdownInterval = useRef(null);

    // Get current values
    const currentImage = images[currentImageIndex] || null;
    const currentProcessedImage = processedImages[currentImageIndex] || null;
    const currentFileName = fileNames[currentImageIndex] || 'document';
    const currentSettings = imageSettings[currentImageIndex] || {
        brightness: 100,
        contrast: 100,
        filter: 'none',
        rotation: 0,
        flipHorizontal: false,
        flipVertical: false,
        edgeDetection: false,
        autoEnhance: false
    };

    // Camera cleanup
    useEffect(() => {
        return () => {
            if (cameraStream) {
                cameraStream.getTracks().forEach(track => track.stop());
            }
            if (countdownInterval.current) {
                clearInterval(countdownInterval.current);
            }
        };
    }, [cameraStream]);

    // Camera initialization
    useEffect(() => {
        if (!showCamera) return;

        let stream = null;
        const initCamera = async () => {
            try {
                const constraints = {
                    video: {
                        facingMode: cameraFacingMode,
                        width: { ideal: isMobile ? 1280 : 1920 },
                        height: { ideal: isMobile ? 720 : 1080 }
                    }
                };

                stream = await navigator.mediaDevices.getUserMedia(constraints);
                setCameraStream(stream);

                if (cameraVideoRef.current) {
                    cameraVideoRef.current.srcObject = stream;
                }

                // Check flash support
                const track = stream.getVideoTracks()[0];
                const capabilities = track.getCapabilities?.();
                setFlashSupported(!!capabilities?.torch && cameraFacingMode === 'environment');

                setMirrorPreview(cameraFacingMode === 'user');
            } catch (err) {
                console.error("Camera error:", err);
                setError("Camera access failed. Please check permissions.");
                setShowCamera(false);
            }
        };

        initCamera();

        return () => {
            if (stream) {
                stream.getTracks().forEach(track => track.stop());
            }
        };
    }, [showCamera, cameraFacingMode, isMobile]);

    // Toggle flash effect
    useEffect(() => {
        if (!cameraStream || !flashSupported) return;

        const track = cameraStream.getVideoTracks()[0];
        if (track && track.applyConstraints) {
            track.applyConstraints({
                advanced: [{ torch: flashOn }]
            }).catch(err => {
                console.error("Error toggling flash:", err);
                setFlashSupported(false);
            });
        }
    }, [flashOn, cameraStream, flashSupported]);

    const toggleCamera = () => {
        setCameraFacingMode(prev => prev === 'user' ? 'environment' : 'user');
        setFlashOn(false);
    };

    const startCaptureCountdown = () => {
        setCaptureCountdown(3);
        countdownInterval.current = setInterval(() => {
            setCaptureCountdown(prev => {
                if (prev <= 1) {
                    clearInterval(countdownInterval.current);
                    captureImage();
                    return 0;
                }
                return prev - 1;
            });
        }, 1000);
    };

    const captureImage = () => {
        if (!cameraVideoRef.current) return;

        const video = cameraVideoRef.current;
        const canvas = canvasRef.current;
        if (!canvas) return;

        try {
            canvas.width = video.videoWidth;
            canvas.height = video.videoHeight;
            const ctx = canvas.getContext('2d');

            if (cameraFacingMode === 'user') {
                ctx.translate(canvas.width, 0);
                ctx.scale(-1, 1);
            }

            ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
            ctx.setTransform(1, 0, 0, 1, 0, 0);

            const imageData = canvas.toDataURL('image/jpeg', 0.9);
            setCapturedImages(prev => [...prev, imageData]);

            setIsProcessing(true);
            setTimeout(() => setIsProcessing(false), 200);
        } catch (err) {
            console.error("Capture error:", err);
            setError("Failed to capture image");
        }
    };

    const retakePhoto = () => {
        setCapturedImages([]);
        setShowGallery(false);
    };

    const confirmSelection = () => {
        if (capturedImages.length > 0) {
            const initialSettings = capturedImages.map(() => ({
                brightness: 100,
                contrast: 100,
                filter: 'none',
                rotation: 0,
                flipHorizontal: false,
                flipVertical: false,
                edgeDetection: false,
                autoEnhance: false
            }));

            setImages(capturedImages);
            setProcessedImages(capturedImages);
            setImageSettings(initialSettings);
            setFileNames(capturedImages.map((_, i) => `document_${i + 1}`));
            setShowGallery(false);
            setShowCamera(false);
        }
    };

    const handleFileUpload = (e) => {
        const files = Array.from(e.target.files);
        if (files.length === 0) return;

        const newImages = [];
        const newFileNames = [];
        const newSettings = [];

        files.forEach((file, index) => {
            const reader = new FileReader();
            reader.onload = (event) => {
                newImages.push(event.target.result);
                newFileNames.push(file.name.replace(/\.[^/.]+$/, "") || `document_${index + 1}`);
                newSettings.push({
                    brightness: 100,
                    contrast: 100,
                    filter: 'none',
                    rotation: 0,
                    flipHorizontal: false,
                    flipVertical: false,
                    edgeDetection: false,
                    autoEnhance: false
                });

                if (newImages.length === files.length) {
                    setImages(prev => [...prev, ...newImages]);
                    setProcessedImages(prev => [...prev, ...newImages]);
                    setImageSettings(prev => [...prev, ...newSettings]);
                    setFileNames(prev => [...prev, ...newFileNames]);
                    setCurrentImageIndex(0);
                }
            };
            reader.onerror = () => {
                setError("Failed to read file");
            };
            reader.readAsDataURL(file);
        });
    };

    const prepareDownload = (format) => {
        setSelectedFormat(format);
        setOpenSaveDialog(true);
    };

    const handleCrop = () => {
        try {
            if (cropperRef.current) {
                const cropper = cropperRef.current.cropper;
                const newImages = [...images];
                newImages[currentImageIndex] = cropper.getCroppedCanvas().toDataURL();
                setImages(newImages);
                setOpenCrop(false);
                applyFiltersToImage(currentImageIndex, newImages[currentImageIndex]);
            }
        } catch (err) {
            console.error("Crop error:", err);
            setError("Failed to crop image");
        }
    };

    const applyEdgeDetection = (canvas) => {
        try {
            const tempCanvas = document.createElement('canvas');
            tempCanvas.width = canvas.width;
            tempCanvas.height = canvas.height;
            const tempCtx = tempCanvas.getContext('2d');

            tempCtx.drawImage(canvas, 0, 0);
            const imageData = tempCtx.getImageData(0, 0, tempCanvas.width, tempCanvas.height);
            const data = imageData.data;

            // Convert to grayscale
            for (let i = 0; i < data.length; i += 4) {
                const avg = (data[i] + data[i + 1] + data[i + 2]) / 3;
                data[i] = data[i + 1] = data[i + 2] = avg;
            }

            tempCtx.putImageData(imageData, 0, 0);

            // Apply edge enhancement
            const ctx = canvas.getContext('2d');
            ctx.filter = 'brightness(1.2) contrast(1.5)';
            ctx.drawImage(tempCanvas, 0, 0);
        } catch (err) {
            console.error("Edge detection error:", err);
            setError("Failed to apply edge detection");
        }
    };

    const applyFiltersToImage = debounce((index, imgSrc) => {
        if (isProcessing || !images[index]) return;

        setIsProcessing(true);

        const img = new Image();
        img.crossOrigin = 'Anonymous';
        img.src = imgSrc || images[index];

        img.onload = () => {
            requestAnimationFrame(() => {
                try {
                    const canvas = document.createElement('canvas');
                    const ctx = canvas.getContext('2d');
                    const settings = imageSettings[index] || currentSettings;

                    const isRotated = settings.rotation % 180 === 90;
                    canvas.width = isRotated ? img.height : img.width;
                    canvas.height = isRotated ? img.width : img.height;

                    ctx.save();
                    ctx.translate(canvas.width / 2, canvas.height / 2);
                    ctx.rotate(settings.rotation * Math.PI / 180);
                    ctx.scale(
                        settings.flipHorizontal ? -1 : 1,
                        settings.flipVertical ? -1 : 1
                    );

                    const filters = [
                        `brightness(${settings.brightness}%)`,
                        `contrast(${settings.contrast}%)`,
                        settings.filter === 'grayscale' ? 'grayscale(1)' : '',
                        settings.filter === 'blackwhite' ? 'contrast(2) grayscale(1) brightness(1.2)' : '',
                        settings.autoEnhance ? 'contrast(1.2) brightness(1.1) saturate(1.1)' : ''
                    ].filter(Boolean).join(' ');

                    ctx.filter = filters;
                    ctx.drawImage(img, -img.width / 2, -img.height / 2, img.width, img.height);
                    ctx.restore();

                    if (settings.edgeDetection) {
                        applyEdgeDetection(canvas);
                    }

                    setProcessedImages(prev => {
                        const newProcessedImages = [...prev];
                        newProcessedImages[index] = canvas.toDataURL('image/jpeg', 0.9);
                        return newProcessedImages;
                    });

                } catch (err) {
                    console.error("Filter error:", err);
                    setError("Failed to apply filters");
                } finally {
                    setIsProcessing(false);
                }
            });
        };

        img.onerror = () => {
            setIsProcessing(false);
            setError("Failed to load image for processing");
        };
    }, 300);

    const updateImageSetting = (index, key, value) => {
        const newSettings = [...imageSettings];
        if (!newSettings[index]) {
            newSettings[index] = { ...currentSettings };
        }
        newSettings[index][key] = value;
        setImageSettings(newSettings);
        applyFiltersToImage(index);
    };

    const handleDownload = async () => {
        if (processedImages.length === 0) return;

        setIsProcessing(true);
        setProgress(0);

        try {
            if (selectedFormat === 'pdf') {
                const pdf = new jsPDF();
                const totalImages = processedImages.length;

                for (let i = 0; i < totalImages; i++) {
                    try {
                        const img = new Image();
                        img.src = processedImages[i];

                        await new Promise((resolve, reject) => {
                            img.onload = () => {
                                try {
                                    const imgWidth = pdf.internal.pageSize.getWidth() - 20;
                                    const imgHeight = (img.height * imgWidth) / img.width;

                                    pdf.addImage(processedImages[i], 'JPEG', 10, 10, imgWidth, imgHeight);

                                    if (i < totalImages - 1) {
                                        pdf.addPage();
                                    }
                                    resolve();
                                } catch (err) {
                                    reject(err);
                                }
                            };
                            img.onerror = () => reject(new Error("Failed to load image"));
                        });

                        setProgress(Math.round(((i + 1) / totalImages) * 100));
                    } catch (err) {
                        console.error(`Error processing image ${i + 1}:`, err);
                        continue;
                    }
                }

                pdf.save(`${currentFileName || 'document'}.pdf`);
            } else {
                // Download individual images
                for (let i = 0; i < processedImages.length; i++) {
                    try {
                        const fileName = fileNames[i] || `document_${i + 1}`;
                        const link = document.createElement('a');
                        link.href = processedImages[i];
                        link.download = `${fileName}.${selectedFormat}`;
                        document.body.appendChild(link);
                        link.click();
                        document.body.removeChild(link);
                        setProgress(Math.round(((i + 1) / processedImages.length) * 100));
                    } catch (err) {
                        console.error(`Error downloading image ${i + 1}:`, err);
                        continue;
                    }
                }
            }
        } catch (err) {
            console.error("Download error:", err);
            setError("Error during download. Please try again.");
        } finally {
            setIsProcessing(false);
            setProgress(0);
            setOpenSaveDialog(false);
        }
    };

    const handleUpload = async () => {
        if (processedImages.length === 0) return;

        setIsProcessing(true);
        setProgress(0);

        try {
            const formData = new FormData();
            const totalImages = processedImages.length;

            for (let i = 0; i < totalImages; i++) {
                const fileName = fileNames[i] || `document_${i + 1}`;
                const blob = await fetch(processedImages[i]).then(res => res.blob());
                formData.append('images', blob, `${fileName}.jpg`);
                setProgress(Math.round(((i + 1) / totalImages) * 100));
            }

            const response = await fetch('/api/upload', {
                method: 'POST',
                body: formData
            });

            const result = await response.json();

            if (response.ok) {
                alert(`${processedImages.length} file(s) uploaded successfully!`);
            } else {
                throw new Error(result.error || 'Upload failed');
            }
        } catch (err) {
            console.error("Upload error:", err);
            setError(err.message || "Error during upload. Please try again.");
        } finally {
            setIsProcessing(false);
            setProgress(0);
            setOpenSaveDialog(false);
        }
    };

    const navigateImage = (direction) => {
        const newIndex = direction === 'prev'
            ? (currentImageIndex - 1 + images.length) % images.length
            : (currentImageIndex + 1) % images.length;
        setCurrentImageIndex(newIndex);
    };

    const removeImage = (index) => {
        const newImages = [...images];
        const newProcessedImages = [...processedImages];
        const newSettings = [...imageSettings];
        const newFileNames = [...fileNames];

        newImages.splice(index, 1);
        newProcessedImages.splice(index, 1);
        newSettings.splice(index, 1);
        newFileNames.splice(index, 1);

        setImages(newImages);
        setProcessedImages(newProcessedImages);
        setImageSettings(newSettings);
        setFileNames(newFileNames);

        if (currentImageIndex >= newImages.length && newImages.length > 0) {
            setCurrentImageIndex(newImages.length - 1);
        } else if (newImages.length === 0) {
            setCurrentImageIndex(0);
        }
    };

    const applyAutoEnhance = () => {
        updateImageSetting(currentImageIndex, 'autoEnhance', true);
        updateImageSetting(currentImageIndex, 'brightness', 110);
        updateImageSetting(currentImageIndex, 'contrast', 120);
    };

    // Reorder images
    const onDragEnd = (result) => {
        if (!result.destination) return;

        const reorder = (list, startIndex, endIndex) => {
            const result = Array.from(list);
            const [removed] = result.splice(startIndex, 1);
            result.splice(endIndex, 0, removed);
            return result;
        };

        const newImages = reorder(
            images,
            result.source.index,
            result.destination.index
        );

        const newProcessedImages = reorder(
            processedImages,
            result.source.index,
            result.destination.index
        );

        const newSettings = reorder(
            imageSettings,
            result.source.index,
            result.destination.index
        );

        const newFileNames = reorder(
            fileNames,
            result.source.index,
            result.destination.index
        );

        setImages(newImages);
        setProcessedImages(newProcessedImages);
        setImageSettings(newSettings);
        setFileNames(newFileNames);

        // Update current index if needed
        if (currentImageIndex === result.source.index) {
            setCurrentImageIndex(result.destination.index);
        } else if (
            currentImageIndex > result.source.index &&
            currentImageIndex <= result.destination.index
        ) {
            setCurrentImageIndex(currentImageIndex - 1);
        } else if (
            currentImageIndex < result.source.index &&
            currentImageIndex >= result.destination.index
        ) {
            setCurrentImageIndex(currentImageIndex + 1);
        }
    };

    // Apply filters when settings change for current image
    useEffect(() => {
        if (images.length > 0) {
            applyFiltersToImage(currentImageIndex);
        }
    }, [currentImageIndex, currentSettings, images]);

    const handleCloseError = () => {
        setError(null);
    };

    return (
        <Container maxWidth="md" sx={{ mt: 2, mb: 2, p: isMobile ? 1 : 2 }}>
            <Snackbar
                open={!!error}
                autoHideDuration={6000}
                onClose={handleCloseError}
                anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
            >
                <Alert onClose={handleCloseError} severity="error" sx={{ width: '100%' }}>
                    {error}
                </Alert>
            </Snackbar>

            <Card variant="outlined" sx={{
                borderRadius: 3,
                boxShadow: 3,
                background: theme.palette.background.paper
            }}>
                <CardContent sx={{ textAlign: 'center' }}>
                    <Typography variant="h4" gutterBottom sx={{
                        fontWeight: 'bold',
                        color: theme.palette.primary.main,
                        fontSize: isMobile ? '1.8rem' : '2.2rem',
                        mb: 3
                    }}>
                        Document Scanner
                    </Typography>

                    <input
                        type="file"
                        accept="image/*"
                        ref={fileInputRef}
                        onChange={handleFileUpload}
                        style={{ display: 'none' }}
                        multiple
                    />

                    {images.length === 0 && !showCamera && !showGallery ? (
                        <Box sx={{
                            border: '2px dashed',
                            borderColor: theme.palette.divider,
                            borderRadius: '12px',
                            p: isMobile ? 2 : 4,
                            mb: 3,
                            backgroundColor: theme.palette.background.default,
                            transition: 'all 0.3s ease',
                            '&:hover': {
                                borderColor: theme.palette.primary.main,
                                backgroundColor: theme.palette.action.hover
                            }
                        }}>
                            <Box sx={{
                                display: 'flex',
                                flexDirection: isMobile ? 'column' : 'row',
                                gap: 2,
                                justifyContent: 'center'
                            }}>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={() => fileInputRef.current.click()}
                                    startIcon={<InsertDriveFileIcon />}
                                    size={isMobile ? 'medium' : 'large'}
                                    sx={{
                                        minWidth: isMobile ? '100%' : 'auto',
                                        py: isMobile ? 1.5 : undefined
                                    }}
                                >
                                    Upload Document(s)
                                </Button>
                                <Button
                                    variant="contained"
                                    color="secondary"
                                    onClick={() => setShowCamera(true)}
                                    startIcon={<PhotoCameraIcon />}
                                    size={isMobile ? 'medium' : 'large'}
                                    sx={{
                                        minWidth: isMobile ? '100%' : 'auto',
                                        py: isMobile ? 1.5 : undefined
                                    }}
                                >
                                    Scan with Camera
                                </Button>
                            </Box>
                        </Box>
                    ) : showCamera ? (
                        <Box sx={{ mb: 3 }}>
                            <Box sx={{
                                border: '2px solid',
                                borderColor: theme.palette.divider,
                                borderRadius: '8px',
                                overflow: 'hidden',
                                position: 'relative',
                                backgroundColor: '#000',
                                height: isMobile ? '350px' : '500px'
                            }}>
                                <video
                                    ref={cameraVideoRef}
                                    autoPlay
                                    playsInline
                                    muted
                                    style={{
                                        width: '100%',
                                        height: '100%',
                                        objectFit: 'contain',
                                        transform: mirrorPreview ? 'scaleX(-1)' : 'none'
                                    }}
                                />
                                {captureCountdown > 0 && (
                                    <Box sx={{
                                        position: 'absolute',
                                        top: 0,
                                        left: 0,
                                        right: 0,
                                        bottom: 0,
                                        display: 'flex',
                                        alignItems: 'center',
                                        justifyContent: 'center',
                                        backgroundColor: 'rgba(0,0,0,0.5)',
                                        zIndex: 2
                                    }}>
                                        <Typography variant="h1" sx={{
                                            color: 'white',
                                            fontSize: '5rem',
                                            fontWeight: 'bold'
                                        }}>
                                            {captureCountdown}
                                        </Typography>
                                    </Box>
                                )}
                                <Box sx={{
                                    position: 'absolute',
                                    bottom: 16,
                                    left: '50%',
                                    transform: 'translateX(-50%)',
                                    display: 'flex',
                                    gap: 1,
                                    backgroundColor: 'rgba(0,0,0,0.7)',
                                    borderRadius: 4,
                                    p: 1,
                                    alignItems: 'center'
                                }}>
                                    {flashSupported && (
                                        <Tooltip title={flashOn ? "Turn off flash" : "Turn on flash"}>
                                            <IconButton
                                                onClick={() => setFlashOn(!flashOn)}
                                                sx={{
                                                    color: flashOn ? theme.palette.warning.main : 'white'
                                                }}
                                            >
                                                {flashOn ? <FlashOnIcon /> : <FlashOffIcon />}
                                            </IconButton>
                                        </Tooltip>
                                    )}

                                    <IconButton
                                        onClick={startCaptureCountdown}
                                        sx={{
                                            backgroundColor: 'white',
                                            width: 56,
                                            height: 56,
                                            '&:hover': { backgroundColor: '#f5f5f5' }
                                        }}
                                        disabled={isProcessing || captureCountdown > 0}
                                    >
                                        {isProcessing ? (
                                            <CircularProgress size={24} />
                                        ) : (
                                            <CameraAltIcon sx={{ color: 'black' }} />
                                        )}
                                    </IconButton>

                                    <Tooltip title="Switch Camera">
                                        <IconButton
                                            onClick={toggleCamera}
                                            sx={{
                                                color: 'white',
                                                backgroundColor: 'rgba(255,255,255,0.2)'
                                            }}
                                        >
                                            <FlipCameraIcon />
                                        </IconButton>
                                    </Tooltip>

                                    {capturedImages.length > 0 && (
                                        <Tooltip title="View captured images">
                                            <IconButton
                                                onClick={() => setShowGallery(true)}
                                                sx={{
                                                    color: 'white',
                                                    backgroundColor: 'rgba(255,255,255,0.2)'
                                                }}
                                            >
                                                <Badge
                                                    badgeContent={capturedImages.length}
                                                    color="primary"
                                                >
                                                    <GalleryIcon />
                                                </Badge>
                                            </IconButton>
                                        </Tooltip>
                                    )}
                                </Box>
                                <IconButton
                                    onClick={() => setShowCamera(false)}
                                    sx={{
                                        position: 'absolute',
                                        top: 10,
                                        right: 10,
                                        backgroundColor: 'rgba(0,0,0,0.5)',
                                        color: 'white'
                                    }}
                                >
                                    <CloseIcon />
                                </IconButton>
                            </Box>
                            <canvas ref={canvasRef} style={{ display: 'none' }} />
                        </Box>
                    ) : showGallery ? (
                        <Box sx={{ mb: 3 }}>
                            <Typography variant="h6" gutterBottom>
                                Select Scans ({capturedImages.length})
                            </Typography>
                            <Grid container spacing={2} sx={{ maxHeight: '400px', overflow: 'auto', mb: 2 }}>
                                {capturedImages.map((img, index) => (
                                    <Grid item xs={6} md={4} key={index}>
                                        <Box
                                            onClick={() => {
                                                setImages([img]);
                                                setCurrentImageIndex(0);
                                                setShowGallery(false);
                                                setShowCamera(false);
                                            }}
                                            sx={{
                                                border: '2px solid',
                                                borderColor: images[0] === img ? 'primary.main' : 'divider',
                                                borderRadius: 2,
                                                overflow: 'hidden',
                                                position: 'relative',
                                                cursor: 'pointer',
                                                transition: 'border-color 0.2s',
                                                '&:hover': {
                                                    borderColor: 'primary.main',
                                                    boxShadow: 2
                                                }
                                            }}
                                        >
                                            <img
                                                src={img}
                                                alt={`Scan ${index + 1}`}
                                                style={{
                                                    width: '100%',
                                                    height: '150px',
                                                    objectFit: 'cover'
                                                }}
                                                onError={(e) => {
                                                    e.target.onerror = null;
                                                    e.target.src = 'placeholder-image.jpg';
                                                }}
                                            />
                                            <Typography variant="caption" sx={{
                                                position: 'absolute',
                                                bottom: 0,
                                                left: 0,
                                                right: 0,
                                                backgroundColor: 'rgba(0,0,0,0.7)',
                                                color: 'white',
                                                textAlign: 'center',
                                                p: 0.5
                                            }}>
                                                Page {index + 1}
                                            </Typography>
                                        </Box>
                                    </Grid>
                                ))}
                            </Grid>
                            <Box sx={{
                                display: 'flex',
                                justifyContent: 'center',
                                gap: 2,
                                flexWrap: 'wrap'
                            }}>
                                <Button
                                    variant="outlined"
                                    onClick={retakePhoto}
                                    startIcon={<DeleteIcon />}
                                >
                                    Retake All
                                </Button>
                                <Button
                                    variant="contained"
                                    color="primary"
                                    onClick={confirmSelection}
                                    startIcon={<CheckIcon />}
                                >
                                    Use All Scans
                                </Button>
                            </Box>
                        </Box>
                    ) : (
                        <>
                            <Paper elevation={3} sx={{
                                p: isMobile ? 1 : 3,
                                mb: 3,
                                borderRadius: 3,
                                position: 'relative',
                                background: theme.palette.background.default
                            }}>
                                <Box sx={{
                                    display: 'flex',
                                    justifyContent: 'center',
                                    mb: 3,
                                    border: '1px solid',
                                    borderColor: theme.palette.divider,
                                    borderRadius: '8px',
                                    overflow: 'hidden',
                                    position: 'relative',
                                    minHeight: isMobile ? '250px' : '300px',
                                    backgroundColor: theme.palette.grey[100]
                                }}>
                                    {isProcessing && (
                                        <Box sx={{
                                            position: 'absolute',
                                            top: 0,
                                            left: 0,
                                            right: 0,
                                            bottom: 0,
                                            display: 'flex',
                                            alignItems: 'center',
                                            justifyContent: 'center',
                                            // backgroundColor: 'rgba(0,0,0,0.3)',
                                            zIndex: 1
                                        }}>
                                            <CircularProgress color="primary" />
                                        </Box>
                                    )}
                                    <img
                                        src={currentProcessedImage || currentImage}
                                        alt="Processed document"
                                        style={{
                                            maxWidth: '100%',
                                            maxHeight: isMobile ? '350px' : '500px',
                                            objectFit: 'contain'
                                        }}
                                        onError={(e) => {
                                            e.target.onerror = null;
                                            e.target.src = 'placeholder-image.jpg';
                                        }}
                                    />
                                    {images.length > 1 && (
                                        <>
                                            <IconButton
                                                onClick={() => navigateImage('prev')}
                                                sx={{
                                                    position: 'absolute',
                                                    left: 10,
                                                    top: '50%',
                                                    transform: 'translateY(-50%)',
                                                    backgroundColor: 'rgba(0,0,0,0.5)',
                                                    color: 'white',
                                                    '&:hover': {
                                                        backgroundColor: 'rgba(0,0,0,0.7)'
                                                    }
                                                }}
                                            >
                                                <ChevronLeftIcon />
                                            </IconButton>
                                            <IconButton
                                                onClick={() => navigateImage('next')}
                                                sx={{
                                                    position: 'absolute',
                                                    right: 10,
                                                    top: '50%',
                                                    transform: 'translateY(-50%)',
                                                    backgroundColor: 'rgba(0,0,0,0.5)',
                                                    color: 'white',
                                                    '&:hover': {
                                                        backgroundColor: 'rgba(0,0,0,0.7)'
                                                    }
                                                }}
                                            >
                                                <ChevronRightIcon />
                                            </IconButton>
                                            <Typography variant="subtitle2" sx={{
                                                position: 'absolute',
                                                top: 10,
                                                left: '50%',
                                                transform: 'translateX(-50%)',
                                                backgroundColor: 'rgba(0,0,0,0.7)',
                                                color: 'white',
                                                px: 2,
                                                py: 1,
                                                borderRadius: 2
                                            }}>
                                                {currentImageIndex + 1} / {images.length}
                                            </Typography>
                                        </>
                                    )}
                                    <Box sx={{
                                        position: 'absolute',
                                        bottom: 16,
                                        left: '50%',
                                        transform: 'translateX(-50%)',
                                        display: 'flex',
                                        gap: 1,
                                        backgroundColor: 'rgba(0,0,0,0.7)',
                                        borderRadius: 4,
                                        p: 1
                                    }}>
                                        <Tooltip title="Rotate 90°">
                                            <IconButton
                                                onClick={() => updateImageSetting(currentImageIndex, 'rotation', (currentSettings.rotation + 90) % 360)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <RotateIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Crop">
                                            <IconButton
                                                onClick={() => setOpenCrop(true)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <CropIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Flip Horizontal">
                                            <IconButton
                                                onClick={() => updateImageSetting(currentImageIndex, 'flipHorizontal', !currentSettings.flipHorizontal)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <FlipIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Flip Vertical">
                                            <IconButton
                                                onClick={() => updateImageSetting(currentImageIndex, 'flipVertical', !currentSettings.flipVertical)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <FlipIcon sx={{ transform: 'scaleY(-1)' }} />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Auto Enhance">
                                            <IconButton
                                                onClick={applyAutoEnhance}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <MagicIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Reorder Images">
                                            <IconButton
                                                onClick={() => setShowImageList(!showImageList)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <ReorderIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Add More Images">
                                            <IconButton
                                                onClick={() => fileInputRef.current.click()}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <AddPhotoIcon />
                                            </IconButton>
                                        </Tooltip>
                                        <Tooltip title="Open Camera">
                                            <IconButton
                                                onClick={() => setShowCamera(true)}
                                                sx={{
                                                    color: 'white',
                                                    '&:hover': {
                                                        color: theme.palette.primary.light
                                                    }
                                                }}
                                            >
                                                <PhotoCameraIcon />
                                            </IconButton>
                                        </Tooltip>
                                        {images.length > 1 && (
                                            <Tooltip title="Delete this image">
                                                <IconButton
                                                    onClick={() => removeImage(currentImageIndex)}
                                                    sx={{
                                                        color: theme.palette.error.light,
                                                        '&:hover': {
                                                            color: theme.palette.error.main
                                                        }
                                                    }}
                                                >
                                                    <DeleteIcon />
                                                </IconButton>
                                            </Tooltip>
                                        )}
                                    </Box>
                                </Box>

                                {showImageList && (
                                    <Box sx={{ mb: 3 }}>
                                        <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                                            Reorder Documents
                                        </Typography>
                                        <Paper elevation={2} sx={{ maxHeight: 300, overflow: 'auto' }}>
                                            <DragDropContext onDragEnd={onDragEnd}>
                                                <Droppable droppableId="images">
                                                    {(provided) => (
                                                        <List
                                                            ref={provided.innerRef}
                                                            {...provided.droppableProps}
                                                            dense
                                                        >
                                                            {images.map((img, index) => (
                                                                <Draggable key={index} draggableId={`img-${index}`} index={index}>
                                                                    {(provided) => (
                                                                        <ListItem
                                                                            ref={provided.innerRef}
                                                                            {...provided.draggableProps}
                                                                            {...provided.dragHandleProps}
                                                                            button
                                                                            selected={currentImageIndex === index}
                                                                            onClick={() => setCurrentImageIndex(index)}
                                                                            sx={{
                                                                                '&:hover': {
                                                                                    backgroundColor: theme.palette.action.hover
                                                                                },
                                                                                '&.Mui-selected': {
                                                                                    backgroundColor: theme.palette.action.selected
                                                                                }
                                                                            }}
                                                                        >
                                                                            <ListItemAvatar>
                                                                                <Avatar
                                                                                    src={img}
                                                                                    variant="rounded"
                                                                                    sx={{ width: 56, height: 56 }}
                                                                                />
                                                                            </ListItemAvatar>
                                                                            <ListItemText
                                                                                primary={`Document ${index + 1}`}
                                                                                secondary={fileNames[index] || `document_${index + 1}`}
                                                                            />
                                                                            <ListItemSecondaryAction>
                                                                                <IconButton
                                                                                    edge="end"
                                                                                    onClick={(e) => {
                                                                                        e.stopPropagation();
                                                                                        removeImage(index);
                                                                                    }}
                                                                                >
                                                                                    <DeleteIcon />
                                                                                </IconButton>
                                                                            </ListItemSecondaryAction>
                                                                        </ListItem>
                                                                    )}
                                                                </Draggable>
                                                            ))}
                                                            {provided.placeholder}
                                                        </List>
                                                    )}
                                                </Droppable>
                                            </DragDropContext>
                                        </Paper>
                                    </Box>
                                )}

                                <Grid container spacing={isMobile ? 1 : 3}>
                                    <Grid item xs={12} md={6} sm={6}>
                                        <Box sx={{
                                            p: isMobile ? 1 : 2,
                                            border: '1px solid',
                                            borderColor: theme.palette.divider,
                                            borderRadius: 2,
                                            background: theme.palette.background.paper
                                        }}>
                                            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                                                Image Adjustments
                                            </Typography>
                                            <Box sx={{ mb: 2 }}>
                                                <Typography gutterBottom>Brightness: {currentSettings.brightness}%</Typography>
                                                <Slider
                                                    value={currentSettings.brightness}
                                                    onChange={(e, newValue) => updateImageSetting(currentImageIndex, 'brightness', newValue)}
                                                    min={50}
                                                    max={150}
                                                    step={1}
                                                    valueLabelDisplay="auto"
                                                    color="primary"
                                                />
                                            </Box>
                                            <Box sx={{ mb: 2 }}>
                                                <Typography gutterBottom>Contrast: {currentSettings.contrast}%</Typography>
                                                <Slider
                                                    value={currentSettings.contrast}
                                                    onChange={(e, newValue) => updateImageSetting(currentImageIndex, 'contrast', newValue)}
                                                    min={50}
                                                    max={150}
                                                    step={1}
                                                    valueLabelDisplay="auto"
                                                    color="secondary"
                                                />
                                            </Box>
                                            <FormControlLabel
                                                control={
                                                    <Switch
                                                        checked={currentSettings.autoEnhance}
                                                        onChange={(e) => updateImageSetting(currentImageIndex, 'autoEnhance', e.target.checked)}
                                                        color="primary"
                                                    />
                                                }
                                                label="Auto Enhance"
                                            />
                                        </Box>
                                    </Grid>
                                    <Grid item xs={12} md={6}>
                                        <Box sx={{
                                            p: isMobile ? 1 : 2,
                                            border: '1px solid',
                                            borderColor: theme.palette.divider,
                                            borderRadius: 2,
                                            background: theme.palette.background.paper
                                        }}>
                                            <Typography variant="subtitle1" gutterBottom sx={{ fontWeight: 'bold' }}>
                                                Document Mode
                                            </Typography>
                                            <FormControl fullWidth sx={{ mb: 2 }}>
                                                <InputLabel>Document Mode</InputLabel>
                                                <Select
                                                    value={currentSettings.filter}
                                                    onChange={(e) => updateImageSetting(currentImageIndex, 'filter', e.target.value)}
                                                    label="Document Mode"
                                                >
                                                    <MenuItem value="none">
                                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                            <ImageIcon sx={{ mr: 1, color: theme.palette.primary.main }} />
                                                            Original Color
                                                        </Box>
                                                    </MenuItem>
                                                    <MenuItem value="grayscale">
                                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                            <FilterBAndWIcon sx={{ mr: 1, color: theme.palette.grey[600] }} />
                                                            Grayscale
                                                        </Box>
                                                    </MenuItem>
                                                    <MenuItem value="blackwhite">
                                                        <Box sx={{ display: 'flex', alignItems: 'center' }}>
                                                            <AdjustIcon sx={{ mr: 1, color: theme.palette.common.black }} />
                                                            Black & White
                                                        </Box>
                                                    </MenuItem>
                                                </Select>
                                            </FormControl>
                                            <FormControlLabel
                                                control={
                                                    <Switch
                                                        checked={currentSettings.edgeDetection}
                                                        onChange={(e) => updateImageSetting(currentImageIndex, 'edgeDetection', e.target.checked)}
                                                        color="primary"
                                                    />
                                                }
                                                label="Edge Detection"
                                            />
                                        </Box>
                                    </Grid>
                                </Grid>

                                <Box sx={{
                                    display: 'flex',
                                    justifyContent: 'center',
                                    gap: 2,
                                    mt: 3,
                                    flexWrap: isMobile ? 'wrap' : 'nowrap'
                                }}>
                                    <Button
                                        variant="outlined"
                                        color="error"
                                        onClick={() => {
                                            setImages([]);
                                            setCapturedImages([]);
                                        }}
                                        startIcon={<CloseIcon />}
                                        sx={{ flex: isMobile ? '1 1 100%' : 'none' }}
                                    >
                                        Cancel
                                    </Button>
                                    <Button
                                        variant="contained"
                                        color="primary"
                                        onClick={() => prepareDownload('pdf')}
                                        disabled={isProcessing}
                                        startIcon={<PdfIcon />}
                                        sx={{ flex: isMobile ? '1 1 100%' : 'none' }}
                                    >
                                        Save as PDF
                                    </Button>
                                    <Button
                                        variant="contained"
                                        color="secondary"
                                        onClick={() => prepareDownload('jpg')}
                                        disabled={isProcessing}
                                        startIcon={<JpgIcon />}
                                        sx={{ flex: isMobile ? '1 1 100%' : 'none' }}
                                    >
                                        Save as JPG
                                    </Button>
                                    <Button
                                        variant="contained"
                                        onClick={() => prepareDownload('png')}
                                        disabled={isProcessing}
                                        startIcon={<PngIcon />}
                                        sx={{
                                            backgroundColor: '#ff5252',
                                            '&:hover': { backgroundColor: '#ff0000' },
                                            flex: isMobile ? '1 1 100%' : 'none'
                                        }}
                                    >
                                        Save as PNG
                                    </Button>
                                </Box>
                            </Paper>
                        </>
                    )}
                </CardContent>
            </Card>

            {/* Crop Dialog */}
            <Dialog open={openCrop} onClose={() => setOpenCrop(false)} maxWidth="md" fullWidth>
                <DialogTitle>Crop Document</DialogTitle>
                <DialogContent dividers>
                    <Cropper
                        src={currentImage}
                        style={{ height: 400, width: '100%' }}
                        aspectRatio={NaN}
                        guides={true}
                        ref={cropperRef}
                        viewMode={1}
                        autoCropArea={1}
                        background={false}
                    />
                </DialogContent>
                <DialogActions>
                    <Button onClick={() => setOpenCrop(false)}>Cancel</Button>
                    <Button onClick={handleCrop} color="primary">Apply Crop</Button>
                </DialogActions>
            </Dialog>

            {/* Save Dialog */}
            <Dialog open={openSaveDialog} onClose={() => setOpenSaveDialog(false)} fullWidth maxWidth="sm">
                <DialogTitle>Save Document</DialogTitle>
                <DialogContent>
                    <DialogContentText sx={{ mb: 2 }}>
                        Choose options for your {selectedFormat.toUpperCase()} file:
                    </DialogContentText>
                    <TextField
                        autoFocus
                        margin="dense"
                        label="Filename"
                        type="text"
                        fullWidth
                        variant="outlined"
                        value={currentFileName}
                        onChange={(e) => {
                            const newFileNames = [...fileNames];
                            newFileNames[currentImageIndex] = e.target.value;
                            setFileNames(newFileNames);
                        }}
                        sx={{ mb: 2 }}
                    />
                    <Box sx={{
                        display: 'flex',
                        alignItems: 'center',
                        mb: 2,
                        p: 2,
                        backgroundColor: theme.palette.background.default,
                        borderRadius: 1
                    }}>
                        {selectedFormat === 'pdf' && <PdfIcon color="primary" sx={{ mr: 1, fontSize: '2rem' }} />}
                        {selectedFormat === 'jpg' && <JpgIcon color="secondary" sx={{ mr: 1, fontSize: '2rem' }} />}
                        {selectedFormat === 'png' && <PngIcon color="error" sx={{ mr: 1, fontSize: '2rem' }} />}
                        <Typography variant="body2" color="text.secondary">
                            {images.length > 1
                                ? `${images.length} files will be ${selectedFormat === 'pdf' ? 'combined into a single PDF' : 'downloaded individually'}`
                                : `File will be saved as ${currentFileName}.${selectedFormat}`}
                        </Typography>
                    </Box>
                    {isProcessing && (
                        <Box sx={{ width: '100%', mt: 2 }}>
                            <LinearProgress variant="determinate" value={progress} />
                            <Typography variant="body2" color="text.secondary" sx={{ mt: 1, textAlign: 'center' }}>
                                {progress}% complete
                            </Typography>
                        </Box>
                    )}
                </DialogContent>
                <DialogActions sx={{ p: 2 }}>
                    <Button
                        onClick={() => setOpenSaveDialog(false)}
                        variant="outlined"
                        sx={{ mr: 1 }}
                        disabled={isProcessing}
                    >
                        Cancel
                    </Button>
                    <Button
                        onClick={handleDownload}
                        color="primary"
                        variant="contained"
                        startIcon={<DownloadIcon />}
                        disabled={isProcessing}
                    >
                        {isProcessing ? 'Processing...' : 'Download'}
                    </Button>
                    {/* <Button
                        onClick={handleUpload}
                        color="secondary"
                        variant="contained"
                        startIcon={<UploadIcon />}
                        disabled={isProcessing}
                    >
                        Upload
                    </Button> */}
                </DialogActions>
            </Dialog>
        </Container>
    );
};

export default DocumentScanner;