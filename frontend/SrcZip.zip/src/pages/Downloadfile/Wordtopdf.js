import React, { useState, useRef } from 'react';
import {
    Button,
    Container,
    Card,
    CardContent,
    CircularProgress,
    Box,
    Typography,
} from '@mui/material';
import { renderAsync } from 'docx-preview';
import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';

const WordToPDF = () => {
    const [loading, setLoading] = useState(false);
    const [fileName, setFileName] = useState('');
    const previewRef = useRef();

    const handleUpload = async (e) => {
        const file = e.target.files[0];
        if (!file || !file.name.endsWith('.docx')) {
            alert('Please upload a .docx file.');
            return;
        }

        setFileName(file.name.replace('.docx', ''));
        setLoading(true);
        previewRef.current.innerHTML = '';

        try {
            const arrayBuffer = await file.arrayBuffer();

            await renderAsync(arrayBuffer, previewRef.current, undefined, {
                inWrapper: true,
                ignoreWidth: false,
                ignoreHeight: false,
                ignoreFonts: false,
                breakPages: false,
                experimental: true,
            });

            // 🔥 Remove docx-preview wrappers with background
            const wrappers = previewRef.current.querySelectorAll('.docx-wrapper');
            wrappers.forEach((el) => {
                el.style.background = 'transparent'; // Remove gray background
                el.querySelectorAll('header, footer').forEach((hf) => {
                    hf.remove(); // Remove actual header/footer content
                });
            });
        } catch (err) {
            console.error('Render error:', err);
            alert('Failed to render Word file.');
        } finally {
            setLoading(false);
        }
    };

    const handleConvert = async () => {
        if (!previewRef.current) return;

        setLoading(true);
        try {
            const canvas = await html2canvas(previewRef.current, {
                scale: 2,
                useCORS: true,
            });
            const imgData = canvas.toDataURL('image/png');
            const pdf = new jsPDF('p', 'mm', 'a4');
            const pdfWidth = pdf.internal.pageSize.getWidth();
            const pdfHeight = (canvas.height * pdfWidth) / canvas.width;

            let heightLeft = pdfHeight;
            let position = 0;
            pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
            heightLeft -= pdf.internal.pageSize.getHeight();

            while (heightLeft > 0) {
                pdf.addPage();
                position -= pdf.internal.pageSize.getHeight();
                pdf.addImage(imgData, 'PNG', 0, position, pdfWidth, pdfHeight);
                heightLeft -= pdf.internal.pageSize.getHeight();
            }

            pdf.save(`${fileName || 'document'}.pdf`);
        } catch (err) {
            console.error('PDF error:', err);
            alert('Failed to generate PDF.');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container maxWidth="md" sx={{ mt: 5 }}>
            <Card variant="outlined">
                <CardContent>
                    <Typography variant="h5" align="center" gutterBottom>
                        Word → PDF Converter
                    </Typography>

                    <input type="file" accept=".docx" hidden id="docx-upload" onChange={handleUpload} />
                    <Box textAlign="center" mb={2}>
                        <label htmlFor="docx-upload">
                            <Button variant="contained" disabled={loading} component="span">
                                {loading ? <CircularProgress size={24} /> : 'Upload .docx File'}
                            </Button>
                        </label>
                    </Box>

                    <Box
                        ref={previewRef}
                        sx={{
                            border: '1px solid #ccc',
                            minHeight: 300,
                            p: 2,
                            mb: 2,
                            backgroundColor: '#fff',
                        }}
                    />

                    <Box textAlign="center" mb={2}>
                        <Button variant="contained" color="secondary" onClick={handleConvert} disabled={loading || !fileName}>
                            {loading ? 'Processing...' : 'Download PDF'}
                        </Button>
                    </Box>
                </CardContent>
            </Card>
        </Container>
    );
};

export default WordToPDF;