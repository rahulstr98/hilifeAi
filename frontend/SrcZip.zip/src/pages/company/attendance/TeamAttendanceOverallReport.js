import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import { FaFileExcel, FaFileCsv, FaSearch, FaEdit, FaPrint, FaFilePdf } from "react-icons/fa";
import { Box, Typography, Chip, OutlinedInput, TableCell, Select, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Button, Popover, TextField, IconButton, InputAdornment, Tooltip } from "@mui/material";
import { userStyle, colourStyles } from "../../../pageStyle";
import { handleApiError } from "../../../components/Errorhandling";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from 'axios';
import { SERVICE } from "../../../services/Baseservice";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { useReactToPrint } from "react-to-print";
import { UserRoleAccessContext } from "../../../context/Appcontext";
import { AuthContext } from "../../../context/Appcontext";
import Headtitle from "../../../components/Headtitle";
import { ThreeDots } from "react-loader-spinner";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import ImageIcon from "@mui/icons-material/Image";
import { saveAs } from "file-saver";
import Selects from "react-select";
import moment from "moment";
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import domtoimage from 'dom-to-image';
import { MultiSelect } from 'react-multi-select-component';
import { getCurrentServerTime } from '../../../components/getCurrentServerTime';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ExportData from "../../../components/ExportData";
import MessageAlert from "../../../components/MessageAlert";
import PageHeading from "../../../components/PageHeading";
import AlertDialog from "../../../components/Alert";
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from "../../../components/ManageColumn";
import TeamAttOverallReviewAndReport from './TeamAttOverallReviewAndReport.js';
import TeamAttOverallShortAndMonth from "./TeamAttOverallShortAndMonth.js";
import TeamAttOverallSummary from './TeamAttOverallSummary.js'
import TeamAttOverallSummaryHierarchy from './TeamAttOverallSummaryHierarchy.js'
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function TeamAttendanceOverallReportList() {

    // get current month in string name
    const monthstring = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"];
    const [serverTime, setServerTime] = useState(null);
    useEffect(() => {
        const fetchTime = async () => {
            const time = await getCurrentServerTime();
            setServerTime(time);
            setFilterUser({ ...filterUser, fromdate: moment(time).format('YYYY-MM-DD'), todate: moment(time).format('YYYY-MM-DD') });

            const currentYearAttMonth = Number(moment(time).format('YYYY'));
            const currentMonthIndex = Number(moment(time).format('M'));

            const currentMonthObject = { label: monthstring[currentMonthIndex - 1], value: currentMonthIndex };
            const currentYearObject = { label: currentYearAttMonth, value: currentYearAttMonth };
            setIsMonthYear({ ...isMonthyear, ismonth: currentMonthObject, isyear: currentYearObject, isuser: '' });
        };

        fetchTime();
    }, []);

    const { isUserRoleCompare, isUserRoleAccess, listPageAccessMode, pageName, setPageName, buttonStyles, allUsersLimit } = useContext(UserRoleAccessContext);
    const { auth } = useContext(AuthContext);

    const gridRefTableAttTeam = useRef(null);
    const gridRefImageAttTeam = useRef(null);
    const gridRefTableAttDay = useRef(null);
    const gridRefImageAttDay = useRef(null);

    const currentDateAttMonth = new Date(serverTime);
    const currentYearAttMonth = currentDateAttMonth.getFullYear();

    const currentMonthIndex = new Date(serverTime).getMonth();
    const currentMonthObject = { label: monthstring[currentMonthIndex], value: currentMonthIndex + 1 };
    const currentYearObject = { label: currentYearAttMonth, value: currentYearAttMonth };
    const years = Array.from(new Array(10), (val, index) => currentYearAttMonth - index);
    const getyear = years.map((year) => {
        return { value: year, label: year };
    });

    const [hoursOptionconvert, setHoursOptionsConvert] = useState([]);
    const [hoursOptionconvertclockout, setHoursOptionsConvertClockout] = useState([]);

    var today = new Date(serverTime);
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
    var yyyy = today.getFullYear();
    today = yyyy + "-" + mm + "-" + dd;
    var newtoday = dd + "/" + mm + "/" + yyyy;
    const headerStyle = { wrapHeaderText: true, autoHeaderHeight: true, headerClassName: 'bold-header' };

    const [attStatus, setAttStatus] = useState([]);
    const [attModearr, setAttModearr] = useState([]);
    const [userShifts, setUserShifts] = useState([]);
    const [userShiftsAttDay, setUserShiftsAttDay] = useState([]);
    const [userShiftsAttShort, setUserShiftsAttShort] = useState([]);
    const [userShiftsAttMonth, setUserShiftsAttMonth] = useState([]);
    const [userShiftsAttReview, setUserShiftsAttReview] = useState([]);
    const [userShiftsAttReport, setUserShiftsAttReport] = useState([]);
    const [userShiftsUserShiftSummary, setUserShiftsUserShiftSummary] = useState([]);
    const [userShiftsUserShiftSummaryHier, setUserShiftsUserShiftSummaryHier] = useState([]);
    const [items, setItems] = useState([]);
    const [itemsAttDay, setItemsAttDay] = useState([]);
    const [isHeadings, setIsHeadings] = useState([]);
    const [showAlert, setShowAlert] = useState();
    const [loader, setLoader] = useState(true);
    const [attClockInEdit, setAttClockInEdit] = useState({ username: "", empcode: "", date: "", clockin: "", timeperiod: "", });
    const [isReadClockIn, setIsReadClockIn] = useState(false);
    const [getAttIdClockIn, setGetAttIdClockIn] = useState("");
    const [attClockOutEdit, setAttClockOutEdit] = useState({ username: "", empcode: "", date: "", clockout: "", timeperiod: "", });
    const [isReadClockOut, setIsReadClockOut] = useState(false);
    const [getAttIdClockOut, setGetAttIdClockOut] = useState("");
    const [attStatusOption, setAttStatusOption] = useState([]);
    const [isMonthyear, setIsMonthYear] = useState({ ismonth: currentMonthObject, isyear: currentYearObject });

    const [dateOptions, setDateOptions] = useState([]);
    const [hoursOption, setHoursOptions] = useState([]);
    const [allHoursOption, setAallHoursOptions] = useState([]);
    const [removeHide, setRemoveHide] = useState(true);
    const [hoursOptionsNew, setHoursOptionsNew] = useState([]);
    const [minsOptionsNew, setMinsOptionsNew] = useState([]);

    const [hoursOptionsOut, setHoursOptionsOut] = useState([]);
    const [minsOptionsOut, setMinsOptionsOut] = useState([]);

    // State to track advanced filter
    const [advancedFilter, setAdvancedFilter] = useState(null);
    const [gridApi, setGridApi] = useState(null);
    const [columnApi, setColumnApi] = useState(null);
    const [filteredDataItems, setFilteredDataItems] = useState(userShifts);
    const [filteredRowData, setFilteredRowData] = useState([]);

    const [advancedFilterAttDay, setAdvancedFilterAttDay] = useState(null);
    const [gridApiAttDay, setGridApiAttDay] = useState(null);
    const [columnApiAttDay, setColumnApiAttDay] = useState(null);
    const [filteredDataItemsAttDay, setFilteredDataItemsAttDay] = useState(userShiftsAttDay);
    const [filteredRowDataAttDay, setFilteredRowDataAttDay] = useState([]);

    // Datatable
    const [pageAttTeam, setPageAttTeam] = useState(1);
    const [pageSizeAttTeam, setPageSizeAttTeam] = useState(10);
    const [searchQueryAttTeam, setSearchQueryAttTeam] = useState("");
    const [totalPagesAttTeam, setTotalPagesAttTeam] = useState("");

    const [pageAttDay, setPageAttDay] = useState(1);
    const [pageSizeAttDay, setPageSizeAttDay] = useState(10);
    const [searchQueryAttDay, setSearchQueryAttDay] = useState("");
    const [totalPagesAttDay, setTotalPagesAttDay] = useState("");

    const [pageAttShort, setPageAttShort] = useState(1);
    const [pageSizeAttShort, setPageSizeAttShort] = useState(10);
    const [searchQueryAttShort, setSearchQueryAttShort] = useState("");
    const [totalPagesAttShort, setTotalPagesAttShort] = useState("");

    const [pageAttMonth, setPageAttMonth] = useState(1);
    const [pageSizeAttMonth, setPageSizeAttMonth] = useState(10);
    const [searchQueryAttMonth, setSearchQueryAttMonth] = useState("");
    const [totalPagesAttMonth, setTotalPagesAttMonth] = useState("");

    const [pageAttReview, setPageAttReview] = useState(1);
    const [pageSizeAttReview, setPageSizeAttReview] = useState(10);
    const [searchQueryAttReview, setSearchQueryAttReview] = useState('');
    const [totalPagesAttReview, setTotalPagesAttReview] = useState('');

    const [pageAttReport, setPageAttReport] = useState(1);
    const [pageSizeAttReport, setPageSizeAttReport] = useState(10);
    const [searchQueryAttReport, setSearchQueryAttReport] = useState("");
    const [totalPagesAttReport, setTotalPagesAttReport] = useState("");

    const [pageUserShiftSummary, setPageUserShiftSummary] = useState(1);
    const [pageSizeUserShiftSummary, setPageSizeUserShiftSummary] = useState(10);
    const [searchQueryUserShiftSummary, setSearchQueryUserShiftSummary] = useState("");
    const [totalPagesUserShiftSummary, setTotalPagesUserShiftSummary] = useState(1);

    const [pageUserShiftSummaryHier, setPageUserShiftSummaryHier] = useState(1);
    const [pageSizeUserShiftSummaryHier, setPageSizeUserShiftSummaryHier] = useState(10);
    const [searchQueryUserShiftSummaryHier, setSearchQueryUserShiftSummaryHier] = useState("");
    const [totalPagesUserShiftSummaryHier, setTotalPagesUserShiftSummaryHier] = useState(1);

    const [attSeetings, setAttSettings] = useState({});

    // Error Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const handleClickOpenerr = () => { setIsErrorOpen(true); };
    const handleCloseerr = () => { setIsErrorOpen(false); };

    // Exports
    const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [isPdfFilterOpen, setIsPdfFilterOpen] = useState(false);
    // pageAttTeam refersh reload
    const handleCloseFilterMod = () => { setIsFilterOpen(false); };
    const handleClosePdfFilterMod = () => { setIsPdfFilterOpen(false); };

    const [isFilterOpenAttDay, setIsFilterOpenAttDay] = useState(false);
    const [isPdfFilterOpenAttDay, setIsPdfFilterOpenAttDay] = useState(false);
    // pageAttTeam refersh reload
    const handleCloseFilterModAttDay = () => { setIsFilterOpenAttDay(false); };
    const handleClosePdfFilterModAttDay = () => { setIsPdfFilterOpenAttDay(false); };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); }

    // Edit model Clock In
    const [openEditClkIn, setOpenEditClkIn] = useState(false);
    const handleClickOpenEditClkIn = () => { setOpenEditClkIn(true); };
    const handleCloseEditClkIn = () => {
        setOpenEditClkIn(false);
        setAttClockInEdit({
            shiftendtime: "",
            shiftname: "",
            shift: "",
            clinhour: "00",
            clinseconds: "00",
            clinminute: "00",
            username: "",
            empcode: "",
            date: "",
            clockin: "",
            timeperiod: "",
        });
        setIsReadClockIn(false);
        setGetAttIdClockIn("");
    };

    // Edit model Clock Out
    const [openEditClkOut, setOpenEditClkOut] = useState(false);
    const handleClickOpenEditClkOut = () => { setOpenEditClkOut(true); };
    const handleCloseEditClkOut = () => {
        setOpenEditClkOut(false);
        setAttClockOutEdit({
            shiftendtime: "",
            shiftname: "",
            shift: "",
            clouthour: "00",
            cloutseconds: "00",
            cloutminute: "00",
            username: "",
            empcode: "",
            date: "",
            clockout: "",
            timeperiod: "",
        });
        setIsReadClockOut(false);
    };

    //Delete model
    const [removeId, setRemoveId] = useState("");
    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    const handleClickOpen = () => { setIsDeleteOpen(true); };
    const handleCloseMod = () => { setIsDeleteOpen(false); };

    const [isOutDeleteOpen, setIsOutDeleteOpen] = useState(false);
    const handleOutClickOpen = () => { setIsOutDeleteOpen(true); };
    const handleOutCloseMod = () => { setIsOutDeleteOpen(false); };

    let hoursOptions = [];

    //get all months
    const months = [
        { value: 1, label: "January", },
        { value: 2, label: "February", },
        { value: 3, label: "March", },
        { value: 4, label: "April", },
        { value: 5, label: "May", },
        { value: 6, label: "June", },
        { value: 7, label: "July", },
        { value: 8, label: "August", },
        { value: 9, label: "September", },
        { value: 10, label: "October", },
        { value: 11, label: "November", },
        { value: 12, label: "December" },
    ];

    const attModeOptions = [
        { label: "User Shift Roaster", value: "User Shift Roaster" },
        { label: "Attendance Day Shift", value: "Attendance Day Shift" },
        { label: "Attendance Short Time", value: "Attendance Short Time" },
        { label: "Attendance Month Status", value: "Attendance Month Status" },
        { label: "Attendance Review", value: "Attendance Review" },
        { label: "Attendance Report", value: "Attendance Report" },
        { label: "Attendance Summary Report", value: "Attendance Summary Report" },
        { label: "Attendance Summary Report - Hierarchy", value: "Attendance Summary Report - Hierarchy" },
    ]

    const modeDropDowns = [
        { label: "My Hierarchy List", value: "My Hierarchy List" },
        { label: "All Hierarchy List", value: "All Hierarchy List" },
        { label: "My + All Hierarchy List", value: "My + All Hierarchy List" },
    ];
    const sectorDropDowns = [
        { label: "Primary", value: "Primary" },
        { label: "Secondary", value: "Secondary" },
        { label: "Tertiary", value: "Tertiary" },
        { label: "All", value: "all" },
    ];

    const timeoptions = [
        { value: "AM", label: "AM" },
        { value: "PM", label: "PM" },
    ];

    const minutssecOptions = [
        { value: "00", label: "00" },
        { value: "01", label: "01" },
        { value: "02", label: "02" },
        { value: "03", label: "03" },
        { value: "04", label: "04" },
        { value: "05", label: "05" },
        { value: "06", label: "06" },
        { value: "07", label: "07" },
        { value: "08", label: "08" },
        { value: "09", label: "09" },
        { value: "10", label: "10" },
        { value: "11", label: "11" },
        { value: "12", label: "12" },
        { value: "13", label: "13" },
        { value: "14", label: "14" },
        { value: "15", label: "15" },
        { value: "16", label: "16" },
        { value: "17", label: "17" },
        { value: "18", label: "18" },
        { value: "19", label: "19" },
        { value: "20", label: "20" },
        { value: "21", label: "21" },
        { value: "22", label: "22" },
        { value: "23", label: "23" },
        { value: "24", label: "24" },
        { value: "25", label: "25" },
        { value: "26", label: "26" },
        { value: "27", label: "27" },
        { value: "28", label: "28" },
        { value: "29", label: "29" },
        { value: "30", label: "30" },
        { value: "31", label: "31" },
        { value: "32", label: "32" },
        { value: "33", label: "33" },
        { value: "34", label: "34" },
        { value: "35", label: "35" },
        { value: "36", label: "36" },
        { value: "37", label: "37" },
        { value: "38", label: "38" },
        { value: "39", label: "39" },
        { value: "40", label: "40" },
        { value: "41", label: "41" },
        { value: "42", label: "42" },
        { value: "43", label: "43" },
        { value: "44", label: "44" },
        { value: "45", label: "45" },
        { value: "46", label: "46" },
        { value: "47", label: "47" },
        { value: "48", label: "48" },
        { value: "49", label: "49" },
        { value: "50", label: "50" },
        { value: "51", label: "51" },
        { value: "52", label: "52" },
        { value: "53", label: "53" },
        { value: "54", label: "54" },
        { value: "55", label: "55" },
        { value: "56", label: "56" },
        { value: "57", label: "57" },
        { value: "58", label: "58" },
        { value: "59", label: "59" },
    ];

    const hrsOptions = [
        { value: "01", label: "01" },
        { value: "02", label: "02" },
        { value: "03", label: "03" },
        { value: "04", label: "04" },
        { value: "05", label: "05" },
        { value: "06", label: "06" },
        { value: "07", label: "07" },
        { value: "08", label: "08" },
        { value: "09", label: "09" },
        { value: "10", label: "10" },
        { value: "11", label: "11" },
        { value: "12", label: "12" },
    ];

    const [selectedMode, setSelectedMode] = useState("Today");
    const mode = [
        { label: "Today", value: "Today" },
        { label: "Tomorrow", value: "Tomorrow" },
        { label: "Yesterday", value: "Yesterday" },
        { label: "This Week", value: "This Week" },
        { label: "This Month", value: "This Month" },
        { label: "Last Week", value: "Last Week" },
        { label: "Last Month", value: "Last Month" },
        { label: "Custom", value: "Custom" }
    ]

    // pageAttTeam refersh reload
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    // Manage Columns
    const [isManageColumnsOpen, setManageColumnsOpen] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);
    const [searchQueryManage, setSearchQueryManage] = useState("");
    const handleOpenManageColumns = (event) => {
        setAnchorEl(event.currentTarget);
        setManageColumnsOpen(true);
    };
    const handleCloseManageColumns = () => {
        setManageColumnsOpen(false);
        setSearchQueryManage("");
    };
    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttTeam, setAnchorElSearchAttTeam] = React.useState(null);
    const handleClickSearchAttTeam = (event) => {
        setAnchorElSearchAttTeam(event.currentTarget);
    };
    const handleCloseSearchAttTeam = () => {
        setAnchorElSearchAttTeam(null);
        setSearchQueryAttTeam("");
    };

    const openSearchAttTeam = Boolean(anchorElSearchAttTeam);
    const idSearchAttTeam = openSearchAttTeam ? 'simple-popover' : undefined;

    // Manage Columns
    const [isManageColumnsOpenAttDay, setManageColumnsOpenAttDay] = useState(false);
    const [anchorElAttDay, setAnchorElAttDay] = useState(null);
    const [searchQueryManageAttDay, setSearchQueryManageAttDay] = useState("");
    const handleOpenManageColumnsAttDay = (event) => {
        setAnchorElAttDay(event.currentTarget);
        setManageColumnsOpenAttDay(true);
    };
    const handleCloseManageColumnsAttDay = () => {
        setManageColumnsOpenAttDay(false);
        setSearchQueryManageAttDay("");
    };
    const openAttDay = Boolean(anchorElAttDay);
    const idAttDay = openAttDay ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttDay, setAnchorElSearchAttDay] = React.useState(null);
    const handleClickSearchAttDay = (event) => {
        setAnchorElSearchAttDay(event.currentTarget);
    };
    const handleCloseSearchAttDay = () => {
        setAnchorElSearchAttDay(null);
        setSearchQueryAttDay("");
    };

    const openSearchAttDay = Boolean(anchorElSearchAttDay);
    const idSearchAttDay = openSearchAttDay ? 'simple-popover' : undefined;

    let listpageaccessby =
        listPageAccessMode?.find(
            (data) =>
                data.modulename === "Human Resources" &&
                data.submodulename === "HR" &&
                data.mainpagename === "Attendance" &&
                data.subpagename === "Attendance Reports" &&
                data.subsubpagename === "Team Attendance Overall Report"
        )?.listpageaccessmode || "Overall";

    const [filterUser, setFilterUser] = useState({
        company: "Please Select Company",
        branch: "Please Select Branch",
        attmode: "Please Select Attendance Mode",
        mode: "My Hierarchy List",
        level: "Primary",
        fromdate: today,
        todate: today,
        listpageaccessmode: listpageaccessby,
    });

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    }

    const clockInOpt = [
        'Shift Not Started',
        'Early - ClockIn',
        'Not Allotted',
        'Week Off Present',
        'Long Leave LWP Approved',
        'Long Leave DL - LWP Approved',
        'Long Leave DDL - LWP Approved',
        'Long Absent',
        'Long BL - Absent',
        // 'Pending...',
        'BeforeAndAfterWeekOffAbsent',
        'BeforeAndAfterWeekOffLeave',
        'Pending',
        'BL - Absent',
        // 'DDHA - LWP Applied',
        // 'DDHB - LWP Applied',
        // 'DDL - LWP Applied',
        // 'DHA - LWP Applied',
        // 'DHB - LWP Applied',
        // 'HA - LWP Applied',
        // 'HB - LWP Applied',
        // 'DL - LWP Applied',
        'DDHA - LWP Approved',
        'DDHB - LWP Approved',
        'DDL - LWP Approved',
        'DHA - LWP Approved',
        'DHB - LWP Approved',
        'HA - LWP Approved',
        'HB - LWP Approved',
        'DL - LWP Approved',
        // 'DDHA - LWP Rejected',
        // 'DDHB - LWP Rejected',
        // 'DDL - LWP Rejected',
        // 'DHA - LWP Rejected',
        // 'DHB - LWP Rejected',
        // 'HA - LWP Rejected',
        // 'HB - LWP Rejected',
        // 'DL - LWP Rejected',
        // 'LWP Applied',
        'LWP Approved',
        // 'LWP Rejected',
        'On - Present',
        'BeforeWeekOffAbsent',
        'AfterWeekOffAbsent',
        // 'PERAPPR',
        // 'PERAPPL',
        // 'PERREJ',
        'PERAPPR - IN',
        'COMP - PERAPPRIN',
        // 'COMP - PERAPPR',
        // 'COMP - PERAPPL',
        // 'HB Applied',
        'HB Approved',
        // 'HB Rejected',
        // 'HA Applied',
        'HA Approved',
        // 'HA Rejected',
        // 'DL Applied',
        'DL Approved',
        // 'DL Rejected',
        // 'DHB Applied',
        'DHB Approved',
        // 'DHB Rejected',
        // 'DHA Applied',
        'DHA Approved',
        // 'DHA Rejected',
        'HBLOP',
        'FLOP',
        'Grace - ClockIn',
        'Late - ClockIn',
        'Present',
        'Absent',
        'Week Off',
        'Mis - ClockIn',
        'Holiday',
        'Leave',
        'BeforeWeekOffLeave',
        'AfterWeekOffLeave',
    ];

    const clockOutOpt = [
        'Shift Not Started',
        'Early - ClockOut',
        'Over - ClockOut',
        'Long Leave LWP Approved',
        'Long Leave DL - LWP Approved',
        'Long Leave DDL - LWP Approved',
        'Long Absent',
        'Long BL - Absent',
        'Not Allotted',
        // 'LWP Applied',
        'LWP Approved',
        // 'LWP Rejected',
        'BL - Absent',
        // 'Pending...',
        'Week Off Present',
        'BeforeAndAfterWeekOffAbsent',
        'BeforeAndAfterWeekOffLeave',
        'Pending',
        // 'DDHA - LWP Applied',
        // 'DDHB - LWP Applied',
        // 'DDL - LWP Applied',
        // 'DHA - LWP Applied',
        // 'DHB - LWP Applied',
        // 'HA - LWP Applied',
        // 'HB - LWP Applied',
        // 'DL - LWP Applied',
        'DDHA - LWP Approved',
        'DDHB - LWP Approved',
        'DDL - LWP Approved',
        'DHA - LWP Approved',
        'DHB - LWP Approved',
        'HA - LWP Approved',
        'HB - LWP Approved',
        'DL - LWP Approved',
        // 'DDHA - LWP Rejected',
        // 'DDHB - LWP Rejected',
        // 'DDL - LWP Rejected',
        // 'DHA - LWP Rejected',
        // 'DHB - LWP Rejected',
        // 'HA - LWP Rejected',
        // 'HB - LWP Rejected',
        // 'DL - LWP Rejected',
        // 'PERAPPR',
        // 'PERAPPL',
        // 'PERREJ',
        // 'COMP - PERAPPR',
        // 'COMP - PERAPPL',
        'PERAPPR - OUT',
        'COMP - PERAPPROUT',
        // 'HB Applied',
        'HB Approved',
        // 'HB Rejected',
        // 'HA Applied',
        'HA Approved',
        // 'HA Rejected',
        // 'DL Applied',
        'DL Approved',
        // 'DL Rejected',
        // 'DHB Applied',
        'DHB Approved',
        // 'DHB Rejected',
        // 'DHA Applied',
        'DHA Approved',
        // 'DHA Rejected',
        'BeforeWeekOffAbsent',
        'AfterWeekOffAbsent',
        'HALOP',
        'On - ClockOut',
        'Auto Mis - ClockOut',
        'Pending',
        'Present',
        'Absent',
        'Week Off',
        'Mis - ClockOut',
        'Holiday',
        'Leave',
        'FLOP',
        'BeforeWeekOffLeave',
        'AfterWeekOffLeave',
    ];

    // Show All Columns & Manage Columns
    const initialColumnVisibility = {
        serialNumber: true,
        empcode: true,
        username: true,
        mode: true,
        level: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        date: true,
        shiftmode: true,
        shift: true,
        changeshift: true,
        leavestatus: true,
        permissionstatus: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        daystatus: true,
        appliedthrough: true,
        isweekoff: true,
        isholiday: true,
        lopcalculation: true,
        modetarget: true,
        paidpresent: true,
        lopday: true,
        paidpresentday: true,
    };

    const [columnVisibility, setColumnVisibility] = useState(initialColumnVisibility);

    // Show All Columns & Manage Columns
    const initialColumnVisibilityAttDay = {
        serialNumber: true,
        empcode: true,
        prodshift: true,
        prodstartdate: true,
        prodstarttime: true,
        prodenddate: true,
        prodendtime: true,
        nextshift: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        date: true,
        shiftmode: true,
        shift: true,
        leavestatus: true,
        permissionstatus: true,
        shiftworkinghours: true,
        shiftbeforeothours: true,
        shiftafterothours: true,
        totalothours: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        daystatus: true,
        appliedthrough: true,
        lopcalculation: true,
        modetarget: true,
        paidpresent: true,
        lopday: true,
        paidpresentday: true,
    };
    const [columnVisibilityAttDay, setColumnVisibilityAttDay] = useState(initialColumnVisibilityAttDay);

    let startMonthDate = new Date(filterUser.fromdate);
    let endMonthDate = new Date(filterUser.todate);

    const headArr = [];
    while (startMonthDate <= endMonthDate) {
        headArr.push(`${String(startMonthDate.getDate()).padStart(2, '0')}/${String(startMonthDate.getMonth() + 1).padStart(2, '0')}/${startMonthDate.getFullYear()} ${startMonthDate.toLocaleDateString('en-US', { weekday: 'long' })} ${startMonthDate.getDate()}`);

        startMonthDate.setDate(startMonthDate.getDate() + 1);
    }

    const initialColumnVisibilityAttReport = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        ...headArr.reduce((acc, data, index) => {
            acc[data] = true;
            return acc;
        }, {}),
    }
    // Show All Columns & Manage Columns
    const [columnVisibilityAttReport, setColumnVisibilityAttReport] = useState(initialColumnVisibilityAttReport);

    useEffect(() => {
        getapi();
    }, []);

    const getapi = async () => {
        let userchecks = axios.post(`${SERVICE.CREATE_USERCHECKS}`, {
            headers: {
                'Authorization': `Bearer ${auth.APIToken}`,
            },
            empcode: String(isUserRoleAccess?.empcode),
            companyname: String(isUserRoleAccess?.companyname),
            pagename: String("Team Attendance Overall Report"),
            commonid: String(isUserRoleAccess?._id),
            date: String(new Date(serverTime)),
            addedby: [
                {
                    name: String(isUserRoleAccess?.username),
                    // date: String(new Date(serverTime)),
                },
            ],
        });
    }

    const getDateRange = (mode) => {
        const today = new Date(serverTime);
        let fromdate, todate;

        const formatDate = (date) => {
            const day = String(date.getDate()).padStart(2, '0');
            const month = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
            const year = date.getFullYear();
            return `${day}-${month}-${year}`;
        };

        switch (mode) {
            case "Today":
                fromdate = todate = formatDate(today);
                break;
            case "Tomorrow":
                const tomorrow = new Date(today);
                tomorrow.setDate(today.getDate() + 1);
                fromdate = todate = formatDate(tomorrow);
                break;
            case "Yesterday":
                const yesterday = new Date(today);
                yesterday.setDate(today.getDate() - 1);
                fromdate = todate = formatDate(yesterday);
                break;
            case "This Week":
                const startOfThisWeek = new Date(today);
                startOfThisWeek.setDate(today.getDate() - (today.getDay() + 6) % 7); // Monday
                const endOfThisWeek = new Date(startOfThisWeek);
                endOfThisWeek.setDate(startOfThisWeek.getDate() + 6); // Sunday
                fromdate = formatDate(startOfThisWeek);
                todate = formatDate(endOfThisWeek);
                break;
            case "This Month":
                fromdate = formatDate(new Date(today.getFullYear(), today.getMonth(), 1));
                todate = formatDate(new Date(today.getFullYear(), today.getMonth() + 1, 0));
                break;
            case "Last Week":
                const startOfLastWeek = new Date(today);
                startOfLastWeek.setDate(today.getDate() - (today.getDay() + 6) % 7 - 7); // Last Monday
                const endOfLastWeek = new Date(startOfLastWeek);
                endOfLastWeek.setDate(startOfLastWeek.getDate() + 6); // Last Sunday
                fromdate = formatDate(startOfLastWeek);
                todate = formatDate(endOfLastWeek);
                break;
            case "Last Month":
                fromdate = formatDate(new Date(today.getFullYear(), today.getMonth() - 1, 1)); // 1st of last month
                todate = formatDate(new Date(today.getFullYear(), today.getMonth(), 0)); // Last day of last month
                break;
            default:
                fromdate = todate = "";
        }

        return { fromdate, todate };
    };

    const formatDateForInput = (date) => {
        if (isNaN(date.getTime())) {
            return ''; // Return empty if the date is invalid
        }
        return date.toISOString().split("T")[0]; // Converts date to 'yyyy-MM-dd' format
    };

    const [attStatusOptionDropdown, setAttStatusOptionDropdown] = useState([]);
    const [selectedOptionsStatus, setSelectedOptionsStatus] = useState([]);
    let [valueStatusCat, setValueStatusCat] = useState([]);

    const handleStatusChange = (options) => {
        setValueStatusCat(
            options.map((a, index) => {
                return a.value;
            })
        );
        setSelectedOptionsStatus(options);
    };

    const customValueRendererStatus = (valueStatusCat, _categoryname) => {
        return valueStatusCat?.length ? valueStatusCat.map(({ label }) => label)?.join(', ') : 'Please Select Status';
    };

    const handleGetMonth = (e) => {
        const selectedMonthObject = months.find((d) => d.value === e);
        setIsMonthYear({ ...isMonthyear, ismonth: selectedMonthObject });
    }
    const handleGetYear = (e) => {
        const selectedYearObject = getyear.find((d) => d.value === e);
        setIsMonthYear({ ...isMonthyear, isyear: selectedYearObject });
    }

    //get all Sub vendormasters.
    const fetchAttedanceStatus = async () => {
        setPageName(!pageName);
        const rearr = [];
        const perarr = [];
        try {
            let res_vendor = await axios.get(SERVICE.ATTENDANCE_STATUS, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            let res_type = await axios.get(SERVICE.LEAVETYPE, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            const uniqueNamesWithIds = new Map();

            res_vendor?.data?.attendancestatus.forEach((item) => {
                uniqueNamesWithIds.set(item.name, item._id);
            });

            let resdataforclockin = res_vendor?.data?.attendancestatus.map((data, index) => {
                return data.clockinstatus
            })

            let resdataforclockout = res_vendor?.data?.attendancestatus.map((data, index) => {
                return data.clockoutstatus
            })

            const formattedArray = Array.from(uniqueNamesWithIds).map(([name, _id]) => ({
                label: name,
                value: name,
                _id: _id,
            }));

            let resdatawithlwp = [...res_type?.data?.leavetype, { code: "LWP" }]
            let leavestatusarr = ['Approved'];
            let leavestatushp = ['DHA', 'DDL', 'DDHB', 'DDHA', 'DHB', 'HA', 'HB', 'DL'];
            let leavedaystatus = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10', '11', '12', '13', '14',
                '15', '16', '17', '18', '19', '20', '21', '22', '23', '24', '25', '26', '27',
                '28', '29', '30', '31'];
            resdatawithlwp.forEach((data, index) => {
                let resdata = leavestatusarr.map((leavestatus, i) => {
                    rearr.push(data.code + ' ' + leavestatus);
                });
            });
            resdatawithlwp.forEach((data, index) => {
                let resdata = leavestatusarr.map((leavestatus, i) => {

                    let resdaysleave = leavedaystatus.map((dayval, rindex) => {
                        perarr.push(`${dayval}Long ${data.code} ${leavestatus}`);
                    });

                    let resleave = leavestatushp.map((red, rindex) => {
                        perarr.push(`${red} - ${data.code} ${leavestatus}`);

                        let resdaysleave = leavedaystatus.map((dayval, rindex) => {
                            perarr.push(`${dayval}${red} - Long ${data.code} ${leavestatus}`);
                        });
                    });
                });
            });
            let sumresclockin = [...clockInOpt, ...resdataforclockout, ...resdataforclockin];
            let finalresclockin = sumresclockin
                .map((t) => ({
                    ...t,
                    label: t,
                    value: t,
                }))
                .filter((item, index, self) => {
                    return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                });
            let sumresclockout = [...clockOutOpt, ...resdataforclockout, ...resdataforclockin];
            let finalresclockout = sumresclockout
                .map((t) => ({
                    ...t,
                    label: t,
                    value: t,
                }))
                .filter((item, index, self) => {
                    return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                });

            const finalOptions = [...formattedArray, ...finalresclockin, ...finalresclockout];

            // Remove duplicates
            const uniqueFinalOptions = finalOptions.filter((option, index, self) => index === self.findIndex((o) => o.label === option.label && o.value === option.value));

            setAttStatus(res_vendor?.data?.attendancestatus);
            // setAttStatusOptionDropdown(formattedArray);
            setAttStatusOptionDropdown(uniqueFinalOptions);
        } catch (err) {
            handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    useEffect(() => {
        fetchAttedanceStatus();
    }, []);

    const getattendancestatus = (alldata) => {
        let result = attStatus.filter((data, index) => {
            return data?.clockinstatus === alldata?.clockinstatus && data?.clockoutstatus === alldata?.clockoutstatus
        })
        return result[0]?.name
    }

    const getAttModeAppliedThr = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.appliedthrough
    }

    const getAttModeLop = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.lop === true ? 'Yes' : 'No';
    }

    const getAttModeLopType = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.loptype
    }

    const getFinalLop = (rowlop, rowloptype) => {
        return (rowloptype === undefined || rowloptype === "") ? rowlop : (rowlop + ' - ' + rowloptype);
    }

    const getAttModeTarget = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.target === true ? 'Yes' : 'No';
    }

    const getAttModePaidPresent = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.paidleave === true ? 'Yes' : 'No';
    }

    const getAttModePaidPresentType = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus
        })
        return result[0]?.paidleavetype;
    }

    const getFinalPaid = (rowpaid, rowpaidtype) => {
        return (rowpaidtype === undefined || rowpaidtype === "") ? rowpaid : (rowpaid + ' - ' + rowpaidtype);
    }

    const getAssignLeaveDayForLop = (rowlopday) => {
        if (rowlopday === 'Yes - Double Day') {
            return '2'
        } else if (rowlopday === 'Yes - Full Day') {
            return '1';
        } else if (rowlopday === 'Yes - Half Day') {
            return '0.5'
        } else {
            return '0';
        }
    }

    const getAssignLeaveDayForPaid = (rowpaidday) => {
        if (rowpaidday === 'Yes - Double Day') {
            return '2'
        } else if (rowpaidday === 'Yes - Full Day') {
            return '1';
        } else if (rowpaidday === 'Yes - Half Day') {
            return '0.5'
        } else {
            return '0';
        }
    }

    const getCount = (rowlopstatus) => {
        if (rowlopstatus === 'Yes - Double Day') {
            return '2'
        } else if (rowlopstatus === 'Yes - Full Day') {
            return '1';
        } else if (rowlopstatus === 'Yes - Half Day') {
            return '0.5'
        } else {
            return '0';
        }
    }

    const getIsWeekoff = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus;
        })
        return result[0]?.weekoff === true ? 'Yes' : 'No';
    }

    const getIsHoliday = (rowdaystatus) => {
        let result = attModearr.filter((data, index) => {
            return data?.name === rowdaystatus;
        })
        return result[0]?.holiday === true ? 'Yes' : 'No';
    }

    const fetchAttMode = async () => {
        setPageName(!pageName)
        try {
            let res_freq = await axios.get(SERVICE.ATTENDANCE_MODE_STATUS, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setAttModearr(res_freq?.data?.allattmodestatus);
            let result = res_freq?.data?.allattmodestatus.filter((data, index) => {
                return data.appliedthrough != "Auto";
            });

            setAttStatusOption(result.map((d) => d.name));
        } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
    };

    useEffect(() => {
        fetchAttMode();
    }, []);

    function getMonthsInRange(fromdate, todate) {
        const startDate = new Date(fromdate);
        const endDate = new Date(todate);
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        const result = [];

        // Previous month based on `fromdate`
        const prevMonth = startDate.getMonth() === 0 ? 11 : startDate.getMonth() - 1;
        const prevYear = startDate.getMonth() === 0 ? startDate.getFullYear() - 1 : startDate.getFullYear();
        result.push({ month: monthNames[prevMonth], year: prevYear.toString() });

        // Add selected months between `fromdate` and `todate`
        const currentDate = new Date(startDate);
        currentDate.setDate(1); // Normalize to the start of the month
        while (
            currentDate.getFullYear() < endDate.getFullYear() ||
            (currentDate.getFullYear() === endDate.getFullYear() && currentDate.getMonth() <= endDate.getMonth())
        ) {
            result.push({
                month: monthNames[currentDate.getMonth()],
                year: currentDate.getFullYear().toString()
            });
            currentDate.setMonth(currentDate.getMonth() + 1);
        }

        // Next month based on `todate`
        const nextMonth = endDate.getMonth() === 11 ? 0 : endDate.getMonth() + 1;
        const nextYear = endDate.getMonth() === 11 ? endDate.getFullYear() + 1 : endDate.getFullYear();
        result.push({ month: monthNames[nextMonth], year: nextYear.toString() });

        return result;
    }

    function getMonthsInRangeAttMonth(month, year) {
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        const result = [];

        // Previous month
        const prevMonth = month === 0 ? 11 : month - 1;
        const prevYear = month === 0 ? year - 1 : year;
        result.push({ month: monthNames[prevMonth], year: prevYear.toString() });

        // Current month
        result.push({ month: monthNames[month], year: year.toString() });

        // Next month
        const nextMonth = month === 11 ? 0 : month + 1;
        const nextYear = month === 11 ? year + 1 : year;
        result.push({ month: monthNames[nextMonth], year: nextYear.toString() });

        return result;
    }

    // get week for month's start to end
    function getWeekNumberInMonth(date) {
        const firstDayOfMonth = new Date(date.getFullYear(), date.getMonth(), 1);
        const dayOfWeek = firstDayOfMonth.getDay(); // 0 (Sunday) to 6 (Saturday)

        // If the first day of the month is not Monday (1), calculate the adjustment
        const adjustment = dayOfWeek === 0 ? 6 : dayOfWeek - 1;

        // Calculate the day of the month adjusted for the starting day of the week
        const dayOfMonthAdjusted = date.getDate() + adjustment;

        // Calculate the week number based on the adjusted day of the month
        const weekNumber = Math.ceil(dayOfMonthAdjusted / 7);

        return weekNumber;
    }

    const [isDisableModeDropdown, setIsDisableModeDropdown] = useState(false);
    const fetchFilteredUsersStatus = async () => {
        setPageName(!pageName)
        setItems([]);
        setLoader(true);
        setPageAttTeam(1);
        setPageSizeAttTeam(10);

        let startMonthDate = new Date(filterUser.fromdate);

        const currentDate = new Date(filterUser.todate);
        const nextDay = new Date(currentDate);
        nextDay.setDate(currentDate.getDate() + 1);
        let endMonthDate = new Date(nextDay);

        const daysArray = [];
        while (startMonthDate <= endMonthDate) {
            const formattedDate = `${String(startMonthDate.getDate()).padStart(2, '0')}/${String(startMonthDate.getMonth() + 1).padStart(2, '0')}/${startMonthDate.getFullYear()}`;
            const dayName = startMonthDate.toLocaleDateString('en-US', { weekday: 'long' });
            const dayCount = startMonthDate.getDate();
            const shiftMode = 'Main Shift';
            const weekNumberInMonth = (getWeekNumberInMonth(startMonthDate) === 1 ? `${getWeekNumberInMonth(startMonthDate)}st Week` :
                getWeekNumberInMonth(startMonthDate) === 2 ? `${getWeekNumberInMonth(startMonthDate)}nd Week` :
                    getWeekNumberInMonth(startMonthDate) === 3 ? `${getWeekNumberInMonth(startMonthDate)}rd Week` :
                        getWeekNumberInMonth(startMonthDate) > 3 ? `${getWeekNumberInMonth(startMonthDate)}th Week` : '')

            daysArray.push({ formattedDate, dayName, dayCount, shiftMode, weekNumberInMonth });

            // Move to the next day
            startMonthDate.setDate(startMonthDate.getDate() + 1);
        }

        const montharray = getMonthsInRange(filterUser.fromdate, filterUser.todate);
        const montharrayAttMonth = getMonthsInRangeAttMonth((Number(isMonthyear.ismonth.value) - 1), Number(isMonthyear.isyear.value));

        try {

            const filterUserModeValue = filterUser.mode === 'My Hierarchy List' ? 'myhierarchy' : filterUser.mode === 'All Hierarchy List' ? 'allhierarchy' : filterUser.mode === 'My + All Hierarchy List' ? 'myallhierarchy' : '';
            let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_INDVL_HIERARFILTER, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                hierachy: filterUserModeValue,
                sector: filterUser.level,
                username: isUserRoleAccess?.companyname,
                team: isUserRoleAccess.team,
                listpageaccessmode: filterUser?.listpageaccessmode,
                pagename: "menuteamattendanceoverallreport",
                role: isUserRoleAccess.role,
            });

            let res1 = await axios.get(`${SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            let attendanceCriteriaData = res1?.data?.attendancecontrolcriteria[0];

            // if (res?.data?.resultedTeam?.length > 0 && res?.data?.resultAccessFilter?.length < 1 && ["myallhierarchy", "allhierarchy"]?.includes(filterUser?.mode === "My Hierarchy List"
            //     ? "myhierarchy"
            //     : filterUser?.mode === "All Hierarchy List"
            //         ? "allhierarchy"
            //         : "myallhierarchy")) {
            //     alert("Some employees have not been given access to this page.")
            // }


            setIsDisableModeDropdown(res?.data?.isDataAccessMode);
            if (!res?.data?.isDataAccessMode &&
                res?.data?.resultAccessFilterHierarchy > 0 &&
                res?.data?.resultAccessFilter?.length == 0 &&
                ["myallhierarchy", "allhierarchy"]?.includes(filterUserModeValue)
            ) {
                setLoader(true);
                alert("Some employees have not been given access to this page.");
            }

            const resultAccessFilters = res?.data?.resultAccessFilter;
            // console.log(resultAccessFilters, 'resultAccessFilters')

            function splitArray(array, chunkSize) {
                const resultarr = [];
                for (let i = 0; i < array.length; i += chunkSize) {
                    const chunk = array.slice(i, i + chunkSize);
                    resultarr.push({
                        data: chunk,
                    });
                }
                return resultarr;
            }
            let teamFilteredData = allUsersLimit?.filter(data => data.team === isUserRoleAccess.team);

            let employeelistnames = filterUser.attmode === 'Attendance Summary Report' ? (teamFilteredData.length > 0 ? [...new Set(teamFilteredData.map(item => item.companyname))] : []) :
                (resultAccessFilters.length > 0 ? [...new Set(resultAccessFilters.map(item => item))] : [])

            // let employeelistnames = resultAccessFilters.length > 0 ? [...new Set(resultAccessFilters.map(item => item))] : [];
            const resultarr = splitArray(employeelistnames, 10);

            let res_applyleave = await axios.post(SERVICE.APPLYLEAVE_APPROVED, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                employee: [...employeelistnames],
            });

            let leaveresult = res_applyleave?.data?.applyleaves?.filter(data => data.leavetype !== 'Leave Without Pay (LWP)');
            let leaveresultWithoutPay = res_applyleave?.data?.applyleaves?.filter(data => data.leavetype === 'Leave Without Pay (LWP)');

            let res_permission = await axios.post(SERVICE.PERMISSIONS_APPROVED, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                employee: [...employeelistnames],
            });
            let permissionresult = res_permission?.data?.permissions;

            async function sendBatchRequest(batch) {
                try {
                    let res_type = await axios.get(SERVICE.LEAVETYPE, {
                        headers: {
                            Authorization: `Bearer ${auth.APIToken}`,
                        },
                    });

                    let resdatawithlwp = [...res_type?.data?.leavetype, { leavetype: 'Leave Without Pay (LWP)', code: "LWP" }]

                    let leavestatusApproved = [];
                    resdatawithlwp?.map((type) => {
                        res_applyleave?.data?.applyleaves && res_applyleave?.data?.applyleaves?.forEach((d) => {
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Single' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push(type.code + ' ' + d.status)
                            }
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push('DL' + ' - ' + type.code + ' ' + d.status)
                            }
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double Day' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push('DDL' + ' - ' + type.code + ' ' + d.status)
                            }
                        });
                    });

                    const rearr = [...new Set(leavestatusApproved)];

                    if (['User Shift Roaster', 'Attendance Review']?.includes(filterUser.attmode)) {

                        let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FILTER, {
                            employee: batch.data,
                            fromdate: filterUser.fromdate,
                            todate: filterUser.todate,
                            montharray: [...montharray],
                        }, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            }
                        });

                        // console.log(res?.data?.finaluser, 'user shift')
                        const filtered = res?.data?.finaluser?.filter(d => {
                            const formattedDate = new Date(d.finalDate);
                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        });

                        // console.log(filtered, 'filtered')
                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            filtered.forEach((userdata, i) => {
                                if (
                                    // userdata.company === data.company &&
                                    // userdata.branch === data.branch &&
                                    // userdata.unit === data.unit &&
                                    // userdata.empcode === data.empcode &&
                                    // userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);
                        // const finalresult = hierarchyResult.filter((data) => {
                        //     return data.shift != "Week Off" && data.shift != "Not Allotted";
                        // });

                        const findPreviousNonWeekOff = (items, index) => {
                            for (let i = index - 1; i >= 0; i--) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const findNextNonWeekOff = (items, index) => {
                            for (let i = index + 1; i < items.length; i++) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const changedWeekoffResult = hierarchyResult?.map((item, index) => {
                            let updatedClockInStatus = item.clockinstatus;
                            let updatedClockOutStatus = item.clockoutstatus;

                            const itemDate = moment(item.rowformattedDate, "DD/MM/YYYY");

                            // For Week Off status
                            if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
                                const prev = findPreviousNonWeekOff(hierarchyResult, index);
                                const next = findNextNonWeekOff(hierarchyResult, index);

                                const isPrevLeave = leaveresult.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

                                const isNextLeave = leaveresult.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

                                const isPrevLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);

                                if (isPrevLeave && isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
                                } else if (isPrevAbsent && isNextAbsent) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
                                } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
                                } else if (isNextAbsent || isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
                                }
                            }

                            return {
                                ...item,
                                clockinstatus: updatedClockInStatus,
                                clockoutstatus: updatedClockOutStatus,
                            };
                        });

                        const resultBefore = [];

                        const empGrouped = {};

                        changedWeekoffResult.forEach(item => {
                            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
                            empGrouped[item.empcode].push(item);
                        });

                        const leaveStatuses = [
                            ...rearr,
                            "Absent", "BL - Absent",
                        ];

                        // console.log(leaveStatuses, 'leaveStatuses')
                        Object.keys(empGrouped).forEach(empcode => {
                            const records = empGrouped[empcode]
                                .sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                            let streak = [];
                            let counterIn = 1;
                            let counterOut = 1;

                            for (let i = 0; i < records.length; i++) {
                                const current = records[i];
                                const isWeekOff = current.shift === "Week Off";

                                const isLeaveDay =
                                    current.clockin === "00:00:00" &&
                                    current.clockout === "00:00:00" &&
                                    leaveStatuses.includes(current.clockinstatus) &&
                                    !isWeekOff;

                                if (isLeaveDay) {
                                    streak.push(current);
                                } else if (isWeekOff) {
                                    // Push Week Off directly, don’t reset streak
                                    resultBefore.push(current);
                                } else {
                                    // Encountered present day, finalize streak
                                    if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                        streak.forEach(day => {
                                            let clockinstatus = day.clockinstatus;
                                            let clockoutstatus = day.clockoutstatus;

                                            if (clockinstatus === "Absent") {
                                                clockinstatus = `${counterIn++}Long Absent`;
                                            } else if (clockinstatus === "BL - Absent") {
                                                clockinstatus = `${counterIn++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockinstatus)) {
                                                clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                            }

                                            if (clockoutstatus === "Absent") {
                                                clockoutstatus = `${counterOut++}Long Absent`;
                                            } else if (clockoutstatus === "BL - Absent") {
                                                clockoutstatus = `${counterOut++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockoutstatus)) {
                                                clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                            }

                                            resultBefore.push({
                                                ...day,
                                                clockinstatus,
                                                clockoutstatus
                                            });
                                        });
                                    } else {
                                        resultBefore.push(...streak); // push as-is
                                    }

                                    resultBefore.push(current); // current present day
                                    streak = [];
                                    counterIn = 1;
                                    counterOut = 1;
                                }
                            }

                            // Remaining streak at end
                            if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                streak.forEach(day => {
                                    let clockinstatus = day.clockinstatus;
                                    let clockoutstatus = day.clockoutstatus;

                                    if (clockinstatus === "Absent") {
                                        clockinstatus = `${counterIn++}Long Absent`;
                                    } else if (clockinstatus === "BL - Absent") {
                                        clockinstatus = `${counterIn++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockinstatus)) {
                                        clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                    }

                                    if (clockoutstatus === "Absent") {
                                        clockoutstatus = `${counterOut++}Long Absent`;
                                    } else if (clockoutstatus === "BL - Absent") {
                                        clockoutstatus = `${counterOut++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockoutstatus)) {
                                        clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                    }

                                    resultBefore.push({
                                        ...day,
                                        clockinstatus,
                                        clockoutstatus
                                    });
                                });
                            } else {
                                resultBefore.push(...streak);
                            }
                        });
                        resultBefore.sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                        // Group data by empcode
                        let groupedData = {};
                        resultBefore.forEach((item) => {
                            if (!groupedData[item.empcode]) {
                                groupedData[item.empcode] = {
                                    attendanceRecords: [],
                                    departmentDateSet: item.departmentDateSet || [],
                                };
                            }
                            groupedData[item.empcode].attendanceRecords.push(item);
                        });
                        // console.log(groupedData, 'groupedData')
                        let result = [];

                        for (let empcode in groupedData) {
                            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

                            departmentDateSet.forEach((dateRange) => {
                                let { fromdate, todate, department } = dateRange;

                                let countByEmpcodeClockin = {};
                                let countByEmpcodeClockout = {};

                                let recordsInDateRange = attendanceRecords.filter((record) => {
                                    let formattedDate = new Date(record.finalDate);
                                    return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
                                });

                                let processedRecords = recordsInDateRange.map((item) => {
                                    let formattedDate = new Date(item.finalDate);
                                    let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                                    let dojDate = item.doj ? new Date(item.doj) : null;

                                    let updatedClockInStatus = item.clockinstatus;
                                    let updatedClockOutStatus = item.clockoutstatus;

                                    // Check if the date falls within the reasonDate or dojDate
                                    if (reasonDate && formattedDate > reasonDate) {
                                        return null;
                                    }
                                    if (dojDate && formattedDate < dojDate) {
                                        return null;
                                    }

                                    // Handling Late Clock-in and Early Clock-out
                                    if (!countByEmpcodeClockin[item.empcode]) {
                                        countByEmpcodeClockin[item.empcode] = 1;
                                    }
                                    if (!countByEmpcodeClockout[item.empcode]) {
                                        countByEmpcodeClockout[item.empcode] = 1;
                                    }

                                    if (updatedClockInStatus === "Late - ClockIn") {
                                        updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                                        countByEmpcodeClockin[item.empcode]++;
                                    }

                                    if (updatedClockOutStatus === "Early - ClockOut") {
                                        updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                                        countByEmpcodeClockout[item.empcode]++;
                                    }

                                    // console.log(item.rowformattedDate, updatedClockInStatus, updatedClockOutStatus)

                                    return {
                                        ...item,
                                        department,
                                        fromdate,
                                        todate,
                                        clockinstatus: updatedClockInStatus,
                                        clockoutstatus: updatedClockOutStatus,
                                    };
                                });

                                result.push(...processedRecords.filter(Boolean));
                            });
                        }

                        return result;
                    }

                    if (filterUser.attmode === 'Attendance Day Shift') {

                        let res_att_day = await axios.post(SERVICE.USER_PRODUCTION_DAY_SHIFT_ATTENDANCE_FILTER, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            },
                            employee: batch.data,
                            userDates: daysArray,
                        });

                        let res_vendor = await axios.get(SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA_LAST_INDEX, {
                            headers: {
                                'Authorization': `Bearer ${auth.APIToken}`
                            }
                        });
                        let attendancecontrol = res_vendor?.data?.attendancecontrolcriteria;

                        let reasonDateFilteredData = res_att_day?.data?.finaluser.filter(d => {
                            const [day, month, year] = d.rowformattedDate.split("/");
                            const formattedDate = new Date(`${year}-${month}-${day}`);

                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        })

                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            reasonDateFilteredData.forEach((userdata, i) => {
                                if (
                                    // userdata.company === data.company &&
                                    // userdata.branch === data.branch &&
                                    // userdata.unit === data.unit &&
                                    // userdata.empcode === data.empcode &&
                                    // userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });
                        // console.log(reasonDateFilteredData, 'reasonDateFilteredData')

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);
                        // console.log(hierarchyResult, 'hierarchyResult')
                        const currentDate = new Date(filterUser.todate);
                        const currdate = new Date(currentDate);
                        // Add one day
                        currdate.setDate(currdate.getDate() + 1);

                        // Format the new date as DD/MM/YYYY
                        const newDay = String(currdate.getDate()).padStart(2, '0');
                        const newMonth = String(currdate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
                        const newYear = currdate.getFullYear();

                        const nextDateFormatted = `${newDay}/${newMonth}/${newYear}`;
                        // console.log(nextDateFormatted, 'nextDateFormatted')

                        let filtered = hierarchyResult.filter(d => d.rowformattedDate !== nextDateFormatted);
                        // console.log(filtered, 'filtered')

                        function padTime(time) {
                            if (!time) {
                                return '';
                            }
                            let [hours, minutes] = time?.split(':');
                            if (hours.length === 1) {
                                hours = '0' + hours;
                            }
                            return `${hours}:${minutes}`;
                        }

                        // Swap logic
                        const updatedShifts = filtered.reduce((acc, item) => {
                            const key = `${item.empcode}-${item.date}`;
                            if (!acc[key]) acc[key] = [];
                            acc[key].push(item);
                            return acc;
                        }, {});

                        // Process each group
                        const result = Object.values(updatedShifts).flatMap((shifts) => {
                            const mainShift = shifts.find((shift) => shift.shiftMode === 'Main Shift');
                            const secondShift = shifts.find((shift) => shift.shiftMode === 'Second Shift');

                            // Check if the Main Shift starts with PM
                            if (mainShift && secondShift && mainShift.shift.split('to')[0].includes('PM')) {
                                // Swap shift
                                [mainShift.clockin, secondShift.clockin] = [secondShift.clockin, mainShift.clockin];
                                [mainShift.clockout, secondShift.clockout] = [secondShift.clockout, mainShift.clockout];
                                [mainShift.shift, secondShift.shift] = [secondShift.shift, mainShift.shift];
                                [mainShift.shiftworkinghours, secondShift.shiftworkinghours] = [secondShift.shiftworkinghours, mainShift.shiftworkinghours];
                                [mainShift.shiftbeforeothours, secondShift.shiftbeforeothours] = [secondShift.shiftbeforeothours, mainShift.shiftbeforeothours];
                                [mainShift.shiftafterothours, secondShift.shiftafterothours] = [secondShift.shiftafterothours, mainShift.shiftafterothours];
                                [mainShift.totalothours, secondShift.totalothours] = [secondShift.totalothours, mainShift.totalothours];
                            }

                            return shifts;
                        });

                        const itemsWithSerialNumber = filtered?.map((item, index) => {
                            // Parse the date string (DD/MM/YYYY)
                            const [day, month, year] = item.rowformattedDate.split('/').map(Number);
                            const date = new Date(year, month - 1, day); // Month is 0-indexed in JavaScript

                            // Add one day
                            date.setDate(date.getDate() + 1);

                            let userShiftTimingsFrom = { date: item.rowformattedDate, shifttiming: item.shift }

                            let currentShift = userShiftTimingsFrom;
                            // console.log(currentShift, 'curre')

                            // Helper function to parse date and time from shift objects
                            function parseFromDateTimeEnd(shift) {
                                // console.log(shift, '846')
                                const [day, month, year] = shift.date.split('/');
                                // const timeString = shift.shifttiming.split('to')[0].trim();
                                let timeString = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM")?.split('to')[1]?.trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming?.split('to')[1]?.trim() : ("00:00AMto11:59PM")?.split('to')[1]?.trim());
                                let timeStringFrom = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM")?.split('to')[0]?.trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming?.split('to')[0]?.trim() : ("00:00AMto11:59PM")?.split('to')[0]?.trim());

                                // Normalize time separators (replace dots with colons)
                                timeString = timeString.replace('.', ':');
                                timeStringFrom = timeStringFrom.replace('.', ':');

                                // Handle missing leading zeros in hour values
                                timeString = padTime(timeString);
                                timeStringFrom = padTime(timeStringFrom);

                                let [hours, minutes] = timeString.slice(0, -2).split(':');
                                let [hoursFrom, minutesFrom] = timeStringFrom.slice(0, -2).split(':');

                                const period = timeString.slice(-2);
                                const periodFrom = timeStringFrom.slice(-2);

                                if (period === 'PM' && hours !== '12') {
                                    hours = parseInt(hours, 10) + 12;
                                } else if (period === 'AM' && hours === '12') {
                                    hours = '00';
                                }

                                const dateTimeString = new Date(`${year}-${month}-${day}T${hours}:${minutes}:00Z`);
                                // return new Date(dateTimeString);
                                // let newTime = new Date(dateTimeString.getTime() - 4 * 60 * 60 * 1000);

                                if (periodFrom === 'PM' && hoursFrom !== '12') {
                                    dateTimeString.setDate(dateTimeString.getDate() + 1);
                                }

                                //from time
                                let newTime = new Date(dateTimeString.getTime() + Number(attendancecontrol.clockout) * 60 * 60 * 1000);

                                // console.log(newTime.toISOString());
                                return (newTime.toISOString());
                            }

                            // Parse initial date and time from current shift
                            const shiftEndTime = currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? parseFromDateTimeEnd(currentShift) : "";

                            // Helper function to parse date and time from shift objects
                            function parseFromDateTime(shift) {
                                const [day, month, year] = shift.date.split('/');
                                // const timeString = shift.shifttiming.split('to')[0].trim();
                                let timeString = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM").split('to')[0].trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming.split('to')[0].trim() : ("00:00AMto11:59PM").split('to')[0].trim());

                                // Normalize time separators (replace dots with colons)
                                timeString = timeString.replace('.', ':');

                                // Handle missing leading zeros in hour values
                                timeString = padTime(timeString);


                                let [hours, minutes] = timeString.slice(0, -2).split(':');
                                const period = timeString.slice(-2);

                                if (period === 'PM' && hours !== '12') {
                                    hours = parseInt(hours, 10) + 12;
                                } else if (period === 'AM' && hours === '12') {
                                    hours = '00';
                                }

                                const dateTimeString = new Date(`${year}-${month}-${day}T${hours}:${minutes}:00Z`);
                                // return new Date(dateTimeString);
                                // let newTime = new Date(dateTimeString.getTime() - 4 * 60 * 60 * 1000);

                                //from time
                                let newTime = new Date(dateTimeString.getTime() - Number(attendancecontrol.clockin) * 60 * 60 * 1000);

                                // console.log(newTime.toISOString());
                                return (newTime.toISOString());
                            }

                            // Parse initial date and time from current shift
                            const shiftFromTime = currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? parseFromDateTime(currentShift) : "";

                            return {
                                ...item,
                                prodshift: currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? `${shiftFromTime.split(".000Z")[0]}to${shiftEndTime.split(".000Z")[0]}` : ""
                            };
                        });

                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber')
                        return itemsWithSerialNumber;
                    }

                    if (filterUser.attmode === 'Attendance Short Time') {
                        let res_att_day = await axios.post(SERVICE.USER_PRODUCTION_DAY_SHIFT_ATTENDANCE_FILTER, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            },
                            employee: batch.data,
                            userDates: daysArray,
                        });

                        let res_vendor = await axios.get(SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA_LAST_INDEX, {
                            headers: {
                                'Authorization': `Bearer ${auth.APIToken}`
                            }
                        });
                        let attendancecontrol = res_vendor?.data?.attendancecontrolcriteria;

                        // Parse the date string (DD/MM/YYYY)
                        const currentDate = new Date(filterUser.todate);
                        const currdate = new Date(currentDate);
                        // Add one day
                        currdate.setDate(currdate.getDate() + 1);

                        // Format the new date as DD/MM/YYYY
                        const newDay = String(currdate.getDate()).padStart(2, '0');
                        const newMonth = String(currdate.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
                        const newYear = currdate.getFullYear();

                        const nextDateFormatted = `${newDay}/${newMonth}/${newYear}`;

                        let reasonDateFilteredData = res_att_day?.data?.finaluser?.filter(d => {
                            const [day, month, year] = d.rowformattedDate.split("/");
                            const formattedDate = new Date(`${year}-${month}-${day}`);

                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        })

                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            reasonDateFilteredData.forEach((userdata, i) => {
                                if (
                                    // userdata.company === data.company &&
                                    // userdata.branch === data.branch &&
                                    // userdata.unit === data.unit &&
                                    // userdata.empcode === data.empcode &&
                                    // userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });
                        // console.log(reasonDateFilteredData, 'reasonDateFilteredData')

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);

                        let filtered = hierarchyResult.filter(d => d.rowformattedDate !== nextDateFormatted);

                        // Swap logic
                        const updatedShifts = filtered.reduce((acc, item) => {
                            const key = `${item.empcode}-${item.date}`;
                            if (!acc[key]) acc[key] = [];
                            acc[key].push(item);
                            return acc;
                        }, {});

                        // Process each group
                        const result = Object.values(updatedShifts).flatMap((shifts) => {
                            const mainShift = shifts.find((shift) => shift.shiftMode === 'Main Shift');
                            const secondShift = shifts.find((shift) => shift.shiftMode === 'Second Shift');

                            // Check if the Main Shift starts with PM
                            if (mainShift && secondShift && mainShift.shift.split('to')[0].includes('PM')) {
                                // console.log(mainShift.clockin)
                                // Swap shift
                                [mainShift.clockin, secondShift.clockin] = [secondShift.clockin, mainShift.clockin];
                                [mainShift.clockout, secondShift.clockout] = [secondShift.clockout, mainShift.clockout];
                                [mainShift.shift, secondShift.shift] = [secondShift.shift, mainShift.shift];
                                [mainShift.shiftworkinghours, secondShift.shiftworkinghours] = [secondShift.shiftworkinghours, mainShift.shiftworkinghours];
                                [mainShift.shiftbeforeshorthours, secondShift.shiftbeforeshorthours] = [secondShift.shiftbeforeshorthours, mainShift.shiftbeforeshorthours];
                                [mainShift.shiftaftershorthours, secondShift.shiftaftershorthours] = [secondShift.shiftaftershorthours, mainShift.shiftaftershorthours];
                                [mainShift.totalshorthours, secondShift.totalshorthours] = [secondShift.totalshorthours, mainShift.totalshorthours];
                            }

                            return shifts;
                        });

                        const itemsWithSerialNumber = filtered?.map((item, index) => {
                            // Parse the date string (DD/MM/YYYY)
                            const [day, month, year] = item.rowformattedDate.split('/').map(Number);
                            const date = new Date(year, month - 1, day); // Month is 0-indexed in JavaScript

                            // Add one day
                            date.setDate(date.getDate() + 1);

                            // Format the new date as DD/MM/YYYY
                            const newDay = String(date.getDate()).padStart(2, '0');
                            const newMonth = String(date.getMonth() + 1).padStart(2, '0'); // Month is 0-indexed
                            const newYear = date.getFullYear();

                            const nextDateFormatted = `${newDay}/${newMonth}/${newYear}`;

                            let userShiftTimingsFrom = { date: item.rowformattedDate, shifttiming: item.shift }
                            // let userShiftTimingsFromTwo = { date: nextDateFormatted, shifttiming: item.shift }
                            // let userShiftTimingsTo = { date: nextDateFormatted, shifttiming: item.nextshift }
                            // let userShiftTimingsBefore = { date: item.rowformattedDate, shifttiming: item.nextshift }

                            let currentShift = userShiftTimingsFrom;
                            // const currentShiftTwo = userShiftTimingsFromTwo;
                            // const nextShift = userShiftTimingsTo;
                            // const nextShiftBefor = userShiftTimingsBefore;

                            function padTime(time) {
                                let [hours, minutes] = time.split(':');
                                if (hours.length === 1) {
                                    hours = '0' + hours;
                                }
                                return `${hours}:${minutes}`;
                            }

                            // Helper function to parse date and time from shift objects
                            function parseFromDateTimeEnd(shift) {
                                const [day, month, year] = shift.date.split('/');
                                // const timeString = shift.shifttiming.split('to')[0].trim();
                                let timeString = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM").split('to')[1].trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming.split('to')[1].trim() : ("00:00AMto11:59PM").split('to')[1].trim());
                                let timeStringFrom = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM").split('to')[0].trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming.split('to')[0].trim() : ("00:00AMto11:59PM").split('to')[0].trim());

                                // Normalize time separators (replace dots with colons)
                                timeString = timeString.replace('.', ':');
                                timeStringFrom = timeStringFrom.replace('.', ':');

                                // Handle missing leading zeros in hour values
                                timeString = padTime(timeString);
                                timeStringFrom = padTime(timeStringFrom);

                                let [hours, minutes] = timeString.slice(0, -2).split(':');
                                let [hoursFrom, minutesFrom] = timeStringFrom.slice(0, -2).split(':');

                                const period = timeString.slice(-2);
                                const periodFrom = timeStringFrom.slice(-2);

                                if (period === 'PM' && hours !== '12') {
                                    hours = parseInt(hours, 10) + 12;
                                } else if (period === 'AM' && hours === '12') {
                                    hours = '00';
                                }

                                const dateTimeString = new Date(`${year}-${month}-${day}T${hours}:${minutes}:00Z`);
                                // return new Date(dateTimeString);
                                // let newTime = new Date(dateTimeString.getTime() - 4 * 60 * 60 * 1000);

                                if (periodFrom === 'PM' && hoursFrom !== '12') {
                                    dateTimeString.setDate(dateTimeString.getDate() + 1);
                                }

                                //from time
                                let newTime = new Date(dateTimeString.getTime() + Number(attendancecontrol.clockout) * 60 * 60 * 1000);

                                // console.log(newTime.toISOString());
                                return (newTime.toISOString());
                            }

                            // Parse initial date and time from current shift
                            const shiftEndTime = currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? parseFromDateTimeEnd(currentShift) : "";

                            // Helper function to parse date and time from shift objects
                            function parseFromDateTime(shift) {
                                const [day, month, year] = shift.date.split('/');
                                // const timeString = shift.shifttiming.split('to')[0].trim();
                                let timeString = shift.shifttiming && shift.shifttiming != "" && shift.shifttiming == "Week Off" && shift.shifttiming == "Not Allotted" && shift.shifttiming === "Invalid start time" ? ("00:00AMto00:00AM").split('to')[0].trim() : ((shift.shifttiming && shift.shifttiming != "" && shift.shifttiming != "Week Off" && shift.shifttiming != "Not Allotted" && shift.shifttiming !== "Invalid start time") ? shift.shifttiming.split('to')[0].trim() : ("00:00AMto11:59PM").split('to')[0].trim());

                                // Normalize time separators (replace dots with colons)
                                timeString = timeString.replace('.', ':');

                                // Handle missing leading zeros in hour values
                                timeString = padTime(timeString);


                                let [hours, minutes] = timeString.slice(0, -2).split(':');
                                const period = timeString.slice(-2);

                                if (period === 'PM' && hours !== '12') {
                                    hours = parseInt(hours, 10) + 12;
                                } else if (period === 'AM' && hours === '12') {
                                    hours = '00';
                                }

                                const dateTimeString = new Date(`${year}-${month}-${day}T${hours}:${minutes}:00Z`);
                                // return new Date(dateTimeString);
                                // let newTime = new Date(dateTimeString.getTime() - 4 * 60 * 60 * 1000);

                                //from time
                                let newTime = new Date(dateTimeString.getTime() - Number(attendancecontrol.clockin) * 60 * 60 * 1000);

                                // console.log(newTime.toISOString());
                                return (newTime.toISOString());
                            }
                            // Parse initial date and time from current shift
                            const shiftFromTime = currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? parseFromDateTime(currentShift) : "";

                            return {
                                ...item,
                                prodshift: currentShift.shifttiming && currentShift.shifttiming != "" && currentShift.shifttiming !== "Week Off" && currentShift.shifttiming !== "Not Allotted" && currentShift.shifttiming !== 'Invalid start time' ? `${shiftFromTime.split(".000Z")[0]}to${shiftEndTime.split(".000Z")[0]}` : ""
                            };
                        });

                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber')
                        return itemsWithSerialNumber;
                    }

                    if (filterUser.attmode === 'Attendance Month Status') {

                        let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FOR_MONTH_LOP_CAL_FILTER, {
                            employee: batch.data,
                            ismonth: Number(isMonthyear.ismonth.value),
                            isyear: Number(isMonthyear.isyear.value),
                            montharray: [...montharrayAttMonth],
                            department: [],
                        }, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            }
                        })

                        const rearr = [...new Set(leavestatusApproved)];

                        const filtered = res?.data?.finaluser?.filter(d => {
                            const [day, month, year] = d.rowformattedDate.split("/");
                            const formattedDate = new Date(`${year}-${month}-${day}`);
                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        });

                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            filtered.forEach((userdata, i) => {
                                if (
                                    //     userdata.company === data.company &&
                                    //     userdata.branch === data.branch &&
                                    //     userdata.unit === data.unit &&
                                    //     userdata.empcode === data.empcode &&
                                    //     userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);

                        const findPreviousNonWeekOff = (items, index) => {
                            for (let i = index - 1; i >= 0; i--) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const findNextNonWeekOff = (items, index) => {
                            for (let i = index + 1; i < items.length; i++) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const changedWeekoffResult = hierarchyResult?.map((item, index) => {
                            let updatedClockInStatus = item.clockinstatus;
                            let updatedClockOutStatus = item.clockoutstatus;

                            const itemDate = moment(item.rowformattedDate, "DD/MM/YYYY");

                            // For Week Off status
                            if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
                                const prev = findPreviousNonWeekOff(hierarchyResult, index);
                                const next = findNextNonWeekOff(hierarchyResult, index);

                                const isPrevLeave = leaveresult.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

                                const isNextLeave = leaveresult.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

                                const isPrevLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);

                                if (isPrevLeave && isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
                                } else if (isPrevAbsent && isNextAbsent) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
                                } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
                                } else if (isNextAbsent || isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
                                }
                            }

                            return {
                                ...item,
                                clockinstatus: updatedClockInStatus,
                                clockoutstatus: updatedClockOutStatus,
                            };
                        });
                        // console.log(changedWeekoffResult, 'changedWeekoffResult')
                        const resultBefore = [];

                        const empGrouped = {};

                        changedWeekoffResult.forEach(item => {
                            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
                            empGrouped[item.empcode].push(item);
                        });

                        const leaveStatuses = [
                            ...rearr,
                            "Absent", "BL - Absent",
                        ];

                        // console.log(leaveStatuses, 'leaveStatuses')
                        Object.keys(empGrouped).forEach(empcode => {
                            const records = empGrouped[empcode]
                                .sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                            let streak = [];
                            let counterIn = 1;
                            let counterOut = 1;

                            for (let i = 0; i < records.length; i++) {
                                const current = records[i];
                                const isWeekOff = current.shift === "Week Off";

                                const isLeaveDay =
                                    current.clockin === "00:00:00" &&
                                    current.clockout === "00:00:00" &&
                                    leaveStatuses.includes(current.clockinstatus) &&
                                    !isWeekOff;

                                if (isLeaveDay) {
                                    streak.push(current);
                                } else if (isWeekOff) {
                                    // Push Week Off directly, don’t reset streak
                                    resultBefore.push(current);
                                } else {
                                    // Encountered present day, finalize streak
                                    if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                        streak.forEach(day => {
                                            let clockinstatus = day.clockinstatus;
                                            let clockoutstatus = day.clockoutstatus;

                                            if (clockinstatus === "Absent") {
                                                clockinstatus = `${counterIn++}Long Absent`;
                                            } else if (clockinstatus === "BL - Absent") {
                                                clockinstatus = `${counterIn++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockinstatus)) {
                                                clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                            }

                                            if (clockoutstatus === "Absent") {
                                                clockoutstatus = `${counterOut++}Long Absent`;
                                            } else if (clockoutstatus === "BL - Absent") {
                                                clockoutstatus = `${counterOut++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockoutstatus)) {
                                                clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                            }

                                            resultBefore.push({
                                                ...day,
                                                clockinstatus,
                                                clockoutstatus
                                            });
                                        });
                                    } else {
                                        resultBefore.push(...streak); // push as-is
                                    }

                                    resultBefore.push(current); // current present day
                                    streak = [];
                                    counterIn = 1;
                                    counterOut = 1;
                                }
                            }

                            // Remaining streak at end
                            if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                streak.forEach(day => {
                                    let clockinstatus = day.clockinstatus;
                                    let clockoutstatus = day.clockoutstatus;

                                    if (clockinstatus === "Absent") {
                                        clockinstatus = `${counterIn++}Long Absent`;
                                    } else if (clockinstatus === "BL - Absent") {
                                        clockinstatus = `${counterIn++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockinstatus)) {
                                        clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                    }

                                    if (clockoutstatus === "Absent") {
                                        clockoutstatus = `${counterOut++}Long Absent`;
                                    } else if (clockoutstatus === "BL - Absent") {
                                        clockoutstatus = `${counterOut++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockoutstatus)) {
                                        clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                    }

                                    resultBefore.push({
                                        ...day,
                                        clockinstatus,
                                        clockoutstatus
                                    });
                                });
                            } else {
                                resultBefore.push(...streak);
                            }
                        });
                        resultBefore.sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                        // Group data by empcode
                        let groupedData = {};
                        resultBefore.forEach((item) => {
                            if (!groupedData[item.empcode]) {
                                groupedData[item.empcode] = {
                                    attendanceRecords: [],
                                    departmentDateSet: item.departmentDateSet || [],
                                };
                            }
                            groupedData[item.empcode].attendanceRecords.push(item);
                        });
                        // console.log(groupedData, 'groupedData')
                        let result = [];

                        for (let empcode in groupedData) {
                            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

                            departmentDateSet.forEach((dateRange) => {
                                let { fromdate, todate, department, monthname, year } = dateRange;

                                let countByEmpcodeClockin = {};
                                let countByEmpcodeClockout = {};

                                let recordsInDateRange = attendanceRecords.filter((record) => {
                                    let formattedDate = new Date(record.finalDate);
                                    return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
                                });

                                let processedRecords = recordsInDateRange.map((item) => {
                                    let formattedDate = new Date(item.finalDate);
                                    let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                                    let dojDate = item.doj ? new Date(item.doj) : null;

                                    let updatedClockInStatus = item.clockinstatus;
                                    let updatedClockOutStatus = item.clockoutstatus;

                                    // Check if the date falls within the reasonDate or dojDate
                                    if (reasonDate && formattedDate > reasonDate) {
                                        return null;
                                    }
                                    if (dojDate && formattedDate < dojDate) {
                                        return null;
                                    }

                                    // Handling Late Clock-in and Early Clock-out
                                    if (!countByEmpcodeClockin[item.empcode]) {
                                        countByEmpcodeClockin[item.empcode] = 1;
                                    }
                                    if (!countByEmpcodeClockout[item.empcode]) {
                                        countByEmpcodeClockout[item.empcode] = 1;
                                    }

                                    if (updatedClockInStatus === "Late - ClockIn") {
                                        updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                                        countByEmpcodeClockin[item.empcode]++;
                                    }

                                    if (updatedClockOutStatus === "Early - ClockOut") {
                                        updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                                        countByEmpcodeClockout[item.empcode]++;
                                    }

                                    return {
                                        ...item,
                                        department,
                                        fromdate,
                                        todate,
                                        monthname,
                                        year,
                                        clockinstatus: updatedClockInStatus,
                                        clockoutstatus: updatedClockOutStatus,
                                    };
                                });

                                result.push(...processedRecords.filter(Boolean));
                            });
                        }

                        // console.log(result, 'result')
                        const itemsWithSerialNumber = result?.map((item) => (
                            {
                                ...item,
                                totalnumberofdays: item.totalnumberofdays,
                                empshiftdays: item.empshiftdays,
                                totalcounttillcurrendate: item.totalcounttillcurrendate,
                                totalshift: item.totalshift,
                                attendanceauto: getattendancestatus(item),
                                daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                                appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lopcalculation: getFinalLop(
                                    getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                lopcount: getCount(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresent: getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                lopday: getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                paidpresentday: getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            }));

                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber bef')
                        const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                        function getPreviousRelevantEntry(index, array) {
                            for (let i = index - 1; i >= 0; i--) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        function getNextRelevantEntry(index, array) {
                            for (let i = index + 1; i < array.length; i++) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        itemsWithSerialNumber.forEach((item, index, array) => {
                            if (item.shift === 'Week Off') {
                                const previousItem = getPreviousRelevantEntry(index, array);
                                const nextItem = getNextRelevantEntry(index, array);

                                const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                                const isPreviousManualPaidFull =
                                    previousItem &&
                                    previousItem.appliedthrough === 'Manual' &&
                                    previousItem.paidpresent === 'Yes - Full Day';

                                const isNextManualPaidFull =
                                    nextItem &&
                                    nextItem.appliedthrough === 'Manual' &&
                                    nextItem.paidpresent === 'Yes - Full Day';

                                const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                                const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                                if (isPrevLop && isNextLop) {
                                    item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLop) {
                                    item.clockinstatus = 'BeforeWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLop) {
                                    item.clockinstatus = 'AfterWeekOffAbsent';
                                    item.clockoutstatus = 'AfterWeekOffAbsent';
                                }

                                // Recalculate attendance status if needed
                                item.attendanceauto = getattendancestatus(item);
                                item.daystatus = item.attendanceautostatus || getattendancestatus(item);
                                item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                                item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                                item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                                item.lopcalculation = getFinalLop(
                                    getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.lopcount = getCount(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                                item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresent = getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.lopday = getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.paidpresentday = getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                                item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

                            }
                            if (attStatusOption.includes(item.daystatus) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {
                                const previousItem = array[index - 1];
                                const nextItem = array[index + 1];

                                const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

                                if (hasRelevantStatus(previousItem)) {
                                    if (!weekOption.includes(previousItem.clockinstatus)) {
                                        previousItem.clockinstatus = 'Week Off';
                                        previousItem.clockoutstatus = 'Week Off';
                                        previousItem.attendanceauto = getattendancestatus(previousItem);
                                        previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                        previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lopcalculation = getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopcount = getCount(
                                            getFinalLop(
                                                getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    }
                                }
                                if (hasRelevantStatus(nextItem)) {
                                    if (!weekOption.includes(nextItem.clockinstatus)) {
                                        nextItem.clockinstatus = 'Week Off';
                                        nextItem.clockoutstatus = 'Week Off';
                                        nextItem.attendanceauto = getattendancestatus(nextItem);
                                        nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                        nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lopcalculation = getFinalLop(
                                            getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.lopcount = getCount(
                                            getFinalLop(
                                                getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    }
                                }
                            }
                        })

                        let fianlResult = itemsWithSerialNumber.filter((data) => Number(data.year) === Number(isMonthyear.isyear.value) && data.monthname === monthstring[Number(isMonthyear.ismonth.value) - 1])

                        // console.log(fianlResult, 'fianlResult')

                        return fianlResult;

                    }

                    if (filterUser.attmode === 'Attendance Report') {
                        let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FILTER, {
                            employee: batch.data,
                            fromdate: filterUser.fromdate,
                            todate: filterUser.todate,
                            montharray: [...montharray],
                        }, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            }
                        });
                        // console.log(res?.data?.finaluser, 'user shift')
                        const filtered = res?.data?.finaluser?.filter(d => {
                            const formattedDate = new Date(d.finalDate);
                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        });

                        // console.log(filtered, 'filtered')
                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            filtered.forEach((userdata, i) => {
                                if (
                                    // userdata.company === data.company &&
                                    // userdata.branch === data.branch &&
                                    // userdata.unit === data.unit &&
                                    // userdata.empcode === data.empcode &&
                                    // userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);
                        // const finalresult = hierarchyResult.filter((data) => {
                        //     return data.shift != "Week Off" && data.shift != "Not Allotted";
                        // });

                        const result = hierarchyResult?.reduce((acc, {
                            id, userid, company, branch, unit, team, department, username, empcode, shift, shiftMode,
                            //  serialNumber, weekoff, boardingLog, shiftallot,  lateclockincount, earlyclockoutcount,
                            departmentDateSet, date, clockin, clockinstatus, rowformattedDate,
                            clockout, clockoutstatus, attendanceautostatus, finalDate, reasondate, doj, resonablestatus,
                        }) => {

                            if (!acc[empcode]) {
                                acc[empcode] = [];
                            }

                            // Check if the last entry has the same department
                            const lastEntry = acc[empcode][acc[empcode].length - 1];
                            const currentEntry = {
                                id, userid, company, branch, unit, team, department, username, empcode, shift, shiftMode,
                                // serialNumber, weekoff, boardingLog, shiftallot, lateclockincount, earlyclockoutcount,
                                departmentDateSet, alldays: [], clockin, clockinstatus, clockout, clockoutstatus, attendanceautostatus, rowformattedDate, finalDate, reasondate, doj, resonablestatus,
                            };

                            if (lastEntry && lastEntry.department === department) {
                                lastEntry.alldays.push({
                                    date, shift, shiftMode, clockin, clockinstatus,
                                    // weekoff, boardingLog, shiftallot, lateclockincount, earlyclockoutcount,
                                    clockout, clockoutstatus, attendanceautostatus, empcode, rowformattedDate, departmentDateSet, finalDate, department, reasondate, doj, resonablestatus,
                                });
                            } else {
                                // Push a new row if department changes or if it's the first entry
                                currentEntry.alldays.push({
                                    date, shift, shiftMode, clockin, clockinstatus,
                                    // weekoff, boardingLog, shiftallot,  lateclockincount, earlyclockoutcount,
                                    clockout, clockoutstatus, attendanceautostatus, empcode, rowformattedDate, departmentDateSet, finalDate, department, reasondate, doj, resonablestatus,
                                });
                                acc[empcode].push(currentEntry);
                            }

                            return acc;
                        }, {});

                        const rows = Object.values(result).flatMap((userEntries, userIndex) => {
                            return userEntries.map((userData, index) => ({
                                ...userData,
                                // serialNumber: userIndex + 1 + (index > 0 ? 0.1 * index : 0), // Adjust the serial number calculation
                                id: `${userData.empcode}-${userIndex + 1}-${index + 1}`, // Ensure each row has a unique ID
                            }));
                        });
                        // console.log(rows, 'rows')
                        return rows
                    }

                    if (filterUser.attmode === 'Attendance Summary Report') {
                        let res = await axios.post(
                            SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FILTER,
                            {
                                employee: batch.data,
                                fromdate: filterUser.fromdate,
                                todate: filterUser.fromdate,
                                montharray: [...montharray],
                            },
                            {
                                headers: {
                                    Authorization: `Bearer ${auth.APIToken}`,
                                },
                            }
                        );

                        const filtered = res?.data?.finaluser?.filter((d) => {
                            const formattedDate = new Date(d.finalDate);
                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== '') {
                                return formattedDate <= reasonDate;
                            } else if (d.doj && d.doj !== '') {
                                return formattedDate >= dojDate;
                            } else {
                                return d;
                            }
                        });

                        const findPreviousNonWeekOff = (items, index) => {
                            for (let i = index - 1; i >= 0; i--) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const findNextNonWeekOff = (items, index) => {
                            for (let i = index + 1; i < items.length; i++) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const changedWeekoffResult = filtered
                            ?.filter((data) => data.team === isUserRoleAccess.team)
                            ?.map((item, index) => {
                                let updatedClockInStatus = item.clockinstatus;
                                let updatedClockOutStatus = item.clockoutstatus;

                                const itemDate = moment(item.rowformattedDate, 'DD/MM/YYYY');

                                // For Week Off status
                                if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
                                    const prev = findPreviousNonWeekOff(filtered, index);
                                    const next = findNextNonWeekOff(filtered, index);

                                    const isPrevLeave = leaveresult.some((leaveItem) => prev && moment(leaveItem.date, 'DD/MM/YYYY').isSame(moment(prev.rowformattedDate, 'DD/MM/YYYY'), 'day') && leaveItem.empcode === item.empcode);
                                    const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

                                    const isNextLeave = leaveresult.some((leaveItem) => next && moment(leaveItem.date, 'DD/MM/YYYY').isSame(moment(next.rowformattedDate, 'DD/MM/YYYY'), 'day') && leaveItem.empcode === item.empcode);
                                    const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

                                    const isPrevLeaveWithoutPay = leaveresultWithoutPay.some((leaveItem) => prev && moment(leaveItem.date, 'DD/MM/YYYY').isSame(moment(prev.rowformattedDate, 'DD/MM/YYYY'), 'day') && leaveItem.empcode === item.empcode);
                                    const isNextLeaveWithoutPay = leaveresultWithoutPay.some((leaveItem) => next && moment(leaveItem.date, 'DD/MM/YYYY').isSame(moment(next.rowformattedDate, 'DD/MM/YYYY'), 'day') && leaveItem.empcode === item.empcode);

                                    if (isPrevLeave && isNextLeave) {
                                        updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
                                    } else if (isPrevAbsent && isNextAbsent) {
                                        updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                    } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                                        updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                    } else if (isPrevLeave) {
                                        updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
                                    } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                                        updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
                                    } else if (isNextLeave) {
                                        updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
                                    } else if (isNextAbsent || isNextLeaveWithoutPay) {
                                        updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
                                    }
                                }

                                return {
                                    ...item,
                                    clockinstatus: updatedClockInStatus,
                                    clockoutstatus: updatedClockOutStatus,
                                };
                            });

                        const resultBefore = [];

                        const empGrouped = {};

                        changedWeekoffResult.forEach((item) => {
                            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
                            empGrouped[item.empcode].push(item);
                        });

                        const leaveStatuses = [...rearr, 'Absent', 'BL - Absent'];

                        // console.log(leaveStatuses, 'leaveStatuses')
                        Object.keys(empGrouped).forEach((empcode) => {
                            const records = empGrouped[empcode].sort((a, b) => moment(a.rowformattedDate, 'DD/MM/YYYY') - moment(b.rowformattedDate, 'DD/MM/YYYY'));

                            let streak = [];
                            let counterIn = 1;
                            let counterOut = 1;

                            for (let i = 0; i < records.length; i++) {
                                const current = records[i];
                                const isWeekOff = current.shift === 'Week Off';
                                const isShiftNotStarted = current.clockinstatus === 'Shift Not Started' && current.clockoutstatus === 'Shift Not Started';

                                const isLeaveDay = current.clockin === '00:00:00' && current.clockout === '00:00:00' && leaveStatuses.includes(current.clockinstatus) && !isWeekOff && !isShiftNotStarted;

                                if (isLeaveDay) {
                                    streak.push(current);
                                } else if (isWeekOff) {
                                    // Push Week Off directly, don’t reset streak
                                    resultBefore.push(current);
                                } else {
                                    // Encountered present day, finalize streak
                                    if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                        streak.forEach((day) => {
                                            let clockinstatus = day.clockinstatus;
                                            let clockoutstatus = day.clockoutstatus;

                                            if (clockinstatus === 'Absent') {
                                                clockinstatus = `${counterIn++}Long Absent`;
                                            } else if (clockinstatus === 'BL - Absent') {
                                                clockinstatus = `${counterIn++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockinstatus)) {
                                                clockinstatus = `${counterIn++}Long Leave ${rearr?.filter((d) => d === clockinstatus)}`;
                                            }

                                            if (clockoutstatus === 'Absent') {
                                                clockoutstatus = `${counterOut++}Long Absent`;
                                            } else if (clockoutstatus === 'BL - Absent') {
                                                clockoutstatus = `${counterOut++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockoutstatus)) {
                                                clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter((d) => d === clockoutstatus)}`;
                                            }

                                            resultBefore.push({
                                                ...day,
                                                clockinstatus,
                                                clockoutstatus,
                                            });
                                        });
                                    } else {
                                        resultBefore.push(...streak); // push as-is
                                    }

                                    resultBefore.push(current); // current present day
                                    streak = [];
                                    counterIn = 1;
                                    counterOut = 1;
                                }
                            }

                            // Remaining streak at end
                            if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                streak.forEach((day) => {
                                    let clockinstatus = day.clockinstatus;
                                    let clockoutstatus = day.clockoutstatus;

                                    if (clockinstatus === 'Absent') {
                                        clockinstatus = `${counterIn++}Long Absent`;
                                    } else if (clockinstatus === 'BL - Absent') {
                                        clockinstatus = `${counterIn++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockinstatus)) {
                                        clockinstatus = `${counterIn++}Long Leave ${rearr?.filter((d) => d === clockinstatus)}`;
                                    }

                                    if (clockoutstatus === 'Absent') {
                                        clockoutstatus = `${counterOut++}Long Absent`;
                                    } else if (clockoutstatus === 'BL - Absent') {
                                        clockoutstatus = `${counterOut++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockoutstatus)) {
                                        clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter((d) => d === clockoutstatus)}`;
                                    }

                                    resultBefore.push({
                                        ...day,
                                        clockinstatus,
                                        clockoutstatus,
                                    });
                                });
                            } else {
                                resultBefore.push(...streak);
                            }
                        });
                        resultBefore.sort((a, b) => moment(a.rowformattedDate, 'DD/MM/YYYY') - moment(b.rowformattedDate, 'DD/MM/YYYY'));

                        // console.log(resultBefore, 'resultBefore')

                        // Group data by empcode
                        let groupedData = {};
                        resultBefore.forEach((item) => {
                            if (!groupedData[item.empcode]) {
                                groupedData[item.empcode] = {
                                    attendanceRecords: [],
                                    departmentDateSet: item.departmentDateSet || [],
                                };
                            }
                            groupedData[item.empcode].attendanceRecords.push(item);
                        });
                        // console.log(groupedData, 'groupedData')
                        let result = [];

                        for (let empcode in groupedData) {
                            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

                            departmentDateSet.forEach((dateRange) => {
                                let { fromdate, todate, department } = dateRange;

                                let countByEmpcodeClockin = {};
                                let countByEmpcodeClockout = {};

                                let recordsInDateRange = attendanceRecords.filter((record) => {
                                    let formattedDate = new Date(record.finalDate);
                                    return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
                                });

                                let processedRecords = recordsInDateRange.map((item) => {
                                    let formattedDate = new Date(item.finalDate);
                                    let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                                    let dojDate = item.doj ? new Date(item.doj) : null;

                                    let updatedClockInStatus = item.clockinstatus;
                                    let updatedClockOutStatus = item.clockoutstatus;

                                    // Check if the date falls within the reasonDate or dojDate
                                    if (reasonDate && formattedDate > reasonDate) {
                                        return null;
                                    }
                                    if (dojDate && formattedDate < dojDate) {
                                        return null;
                                    }

                                    // Handling Late Clock-in and Early Clock-out
                                    if (!countByEmpcodeClockin[item.empcode]) {
                                        countByEmpcodeClockin[item.empcode] = 1;
                                    }
                                    if (!countByEmpcodeClockout[item.empcode]) {
                                        countByEmpcodeClockout[item.empcode] = 1;
                                    }

                                    if (updatedClockInStatus === 'Late - ClockIn') {
                                        updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                                        countByEmpcodeClockin[item.empcode]++;
                                    }

                                    if (updatedClockOutStatus === 'Early - ClockOut') {
                                        updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                                        countByEmpcodeClockout[item.empcode]++;
                                    }

                                    return {
                                        ...item,
                                        department,
                                        fromdate,
                                        todate,
                                        clockinstatus: updatedClockInStatus,
                                        clockoutstatus: updatedClockOutStatus,
                                    };
                                });

                                result.push(...processedRecords.filter(Boolean));
                            });
                        }

                        // console.log(result, 'result')

                        const itemsWithSerialNumber = result?.map((item) => ({
                            ...item,
                            id: item.id,
                            shiftmode: item.shiftMode,
                            uniqueid: item.id,
                            userid: item.userid,
                            attendanceauto: getattendancestatus(item),
                            daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                            appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lopcalculation: getFinalLop(getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))),
                            lopcount: getCount(getFinalLop(getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)))),
                            modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresent: getFinalPaid(getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)), getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))),
                            lopday: getAssignLeaveDayForLop(getFinalLop(getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)))),
                            paidpresentday: getAssignLeaveDayForPaid(getFinalPaid(getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)), getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)))),
                            isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                        }));

                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber bef')
                        const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                        function getPreviousRelevantEntry(index, array) {
                            for (let i = index - 1; i >= 0; i--) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        function getNextRelevantEntry(index, array) {
                            for (let i = index + 1; i < array.length; i++) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        itemsWithSerialNumber.forEach((item, index, array) => {
                            if (item.shift === 'Week Off') {
                                const previousItem = getPreviousRelevantEntry(index, array);
                                const nextItem = getNextRelevantEntry(index, array);

                                const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                                const isPreviousManualPaidFull = previousItem && previousItem.appliedthrough === 'Manual' && previousItem.paidpresent === 'Yes - Full Day';

                                const isNextManualPaidFull = nextItem && nextItem.appliedthrough === 'Manual' && nextItem.paidpresent === 'Yes - Full Day';

                                const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                                const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                                if (isPrevLop && isNextLop) {
                                    item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLop) {
                                    item.clockinstatus = 'BeforeWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLop) {
                                    item.clockinstatus = 'AfterWeekOffAbsent';
                                    item.clockoutstatus = 'AfterWeekOffAbsent';
                                }

                                // Recalculate attendance status if needed
                                item.attendanceauto = getattendancestatus(item);
                                item.daystatus = item.attendanceautostatus || getattendancestatus(item);
                                item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                                item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                                item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                                item.lopcalculation = getFinalLop(getAttModeLop(item.attendanceautostatus || getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus || getattendancestatus(item)));
                                item.lopcount = getCount(getFinalLop(getAttModeLop(item.attendanceautostatus || getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))));
                                item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                                item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresent = getFinalPaid(getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)), getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item)));
                                item.lopday = getAssignLeaveDayForLop(getFinalLop(getAttModeLop(item.attendanceautostatus || getattendancestatus(item)), getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))));
                                item.paidpresentday = getAssignLeaveDayForPaid(getFinalPaid(getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)), getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))));
                                item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                                item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));
                            }
                            if (attStatusOption.includes(item.daystatus) && item.clockin === '00:00:00' && item.clockout === '00:00:00' && item.appliedthrough === 'Manual' && item.paidpresent === 'Yes - Full Day') {
                                const previousItem = array[index - 1];
                                const nextItem = array[index + 1];

                                const hasRelevantStatus = (entry) => entry && (weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off';

                                if (hasRelevantStatus(previousItem)) {
                                    if (!weekOption.includes(previousItem.clockinstatus)) {
                                        previousItem.clockinstatus = 'Week Off';
                                        previousItem.clockoutstatus = 'Week Off';
                                        previousItem.attendanceauto = getattendancestatus(previousItem);
                                        previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                        previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lopcalculation = getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopcount = getCount(
                                            getFinalLop(getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)), getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)))
                                        );
                                        previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)), getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)))
                                        );
                                        previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)), getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)))
                                        );
                                        previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    }
                                }
                                if (hasRelevantStatus(nextItem)) {
                                    if (!weekOption.includes(nextItem.clockinstatus)) {
                                        nextItem.clockinstatus = 'Week Off';
                                        nextItem.clockoutstatus = 'Week Off';
                                        nextItem.attendanceauto = getattendancestatus(nextItem);
                                        nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                        nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lopcalculation = getFinalLop(getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)), getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)));
                                        nextItem.lopcount = getCount(getFinalLop(getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)), getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))));
                                        nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresent = getFinalPaid(getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)), getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)));
                                        nextItem.lopday = getAssignLeaveDayForLop(getFinalLop(getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)), getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))));
                                        nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)), getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)))
                                        );
                                        nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    }
                                }
                            }
                        });
                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber')
                        let finalResult = itemsWithSerialNumber.filter((data) => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate);
                        // console.log(finalResult, 'finalResult')
                        return finalResult;
                    }

                    if (filterUser.attmode === 'Attendance Summary Report - Hierarchy') {
                        let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FILTER, {
                            employee: batch.data,
                            fromdate: filterUser.fromdate,
                            todate: filterUser.fromdate,
                            montharray: [...montharray],
                        }, {
                            headers: {
                                Authorization: `Bearer ${auth.APIToken}`,
                            }
                        });
                        // console.log(res?.data?.finaluser, 'res?.data?.finaluser')
                        const filtered = res?.data?.finaluser?.filter(d => {
                            const formattedDate = new Date(d.finalDate);
                            const reasonDate = new Date(d.reasondate);
                            const dojDate = new Date(d.doj);

                            if (d.reasondate && d.reasondate !== "") {
                                return (formattedDate <= reasonDate);
                            } else if (d.doj && d.doj !== "") {
                                return (formattedDate >= dojDate);
                            } else {
                                return d;
                            }
                        });

                        const findPreviousNonWeekOff = (items, index) => {
                            for (let i = index - 1; i >= 0; i--) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const findNextNonWeekOff = (items, index) => {
                            for (let i = index + 1; i < items.length; i++) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };
                        // console.log(resultAccessFilters, 'resultAccessFilters')
                        let hierarchyres = [];
                        resultAccessFilters?.forEach((data) => {
                            filtered.forEach((userdata, i) => {
                                if (
                                    // userdata.company === data.company &&
                                    // userdata.branch === data.branch &&
                                    // userdata.unit === data.unit &&
                                    // userdata.empcode === data.empcode &&
                                    // userdata.username === data.companyname
                                    userdata.username === data
                                ) {
                                    const resfinaldata = {
                                        ...userdata,
                                        level: data.level,
                                        control: data.control,
                                    };
                                    hierarchyres.push(resfinaldata);
                                }
                            });
                        });

                        const hierarchyResult = hierarchyres.filter((item) => item !== null);
                        // const finalresult = hierarchyResult.filter((data) => {
                        //     return data.shift != "Week Off" && data.shift != "Not Allotted";
                        // });

                        const changedWeekoffResult = hierarchyResult?.map((item, index) => {
                            let updatedClockInStatus = item.clockinstatus;
                            let updatedClockOutStatus = item.clockoutstatus;

                            const itemDate = moment(item.rowformattedDate, "DD/MM/YYYY");

                            // For Week Off status
                            if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
                                const prev = findPreviousNonWeekOff(hierarchyResult, index);
                                const next = findNextNonWeekOff(hierarchyResult, index);

                                const isPrevLeave = leaveresult.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

                                const isNextLeave = leaveresult.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

                                const isPrevLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);

                                if (isPrevLeave && isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
                                } else if (isPrevAbsent && isNextAbsent) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
                                } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
                                } else if (isNextAbsent || isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
                                }
                            }

                            return {
                                ...item,
                                clockinstatus: updatedClockInStatus,
                                clockoutstatus: updatedClockOutStatus,
                            };
                        });

                        const resultBefore = [];

                        const empGrouped = {};

                        changedWeekoffResult.forEach(item => {
                            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
                            empGrouped[item.empcode].push(item);
                        });

                        const leaveStatuses = [
                            ...rearr,
                            "Absent", "BL - Absent",
                        ];

                        // console.log(leaveStatuses, 'leaveStatuses')
                        Object.keys(empGrouped).forEach(empcode => {
                            const records = empGrouped[empcode]
                                .sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                            let streak = [];
                            let counterIn = 1;
                            let counterOut = 1;

                            for (let i = 0; i < records.length; i++) {
                                const current = records[i];
                                const isWeekOff = current.shift === "Week Off";
                                const isShiftNotStarted = current.clockinstatus === 'Shift Not Started' && current.clockoutstatus === 'Shift Not Started'

                                const isLeaveDay =
                                    current.clockin === "00:00:00" &&
                                    current.clockout === "00:00:00" &&
                                    leaveStatuses.includes(current.clockinstatus) &&
                                    !isWeekOff && !isShiftNotStarted;

                                if (isLeaveDay) {
                                    streak.push(current);
                                } else if (isWeekOff) {
                                    // Push Week Off directly, don’t reset streak
                                    resultBefore.push(current);
                                } else {
                                    // Encountered present day, finalize streak
                                    if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                        streak.forEach(day => {
                                            let clockinstatus = day.clockinstatus;
                                            let clockoutstatus = day.clockoutstatus;

                                            if (clockinstatus === "Absent") {
                                                clockinstatus = `${counterIn++}Long Absent`;
                                            } else if (clockinstatus === "BL - Absent") {
                                                clockinstatus = `${counterIn++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockinstatus)) {
                                                clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                            }

                                            if (clockoutstatus === "Absent") {
                                                clockoutstatus = `${counterOut++}Long Absent`;
                                            } else if (clockoutstatus === "BL - Absent") {
                                                clockoutstatus = `${counterOut++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockoutstatus)) {
                                                clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                            }

                                            resultBefore.push({
                                                ...day,
                                                clockinstatus,
                                                clockoutstatus
                                            });
                                        });
                                    } else {
                                        resultBefore.push(...streak); // push as-is
                                    }

                                    resultBefore.push(current); // current present day
                                    streak = [];
                                    counterIn = 1;
                                    counterOut = 1;
                                }
                            }

                            // Remaining streak at end
                            if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                streak.forEach(day => {
                                    let clockinstatus = day.clockinstatus;
                                    let clockoutstatus = day.clockoutstatus;

                                    if (clockinstatus === "Absent") {
                                        clockinstatus = `${counterIn++}Long Absent`;
                                    } else if (clockinstatus === "BL - Absent") {
                                        clockinstatus = `${counterIn++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockinstatus)) {
                                        clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                    }

                                    if (clockoutstatus === "Absent") {
                                        clockoutstatus = `${counterOut++}Long Absent`;
                                    } else if (clockoutstatus === "BL - Absent") {
                                        clockoutstatus = `${counterOut++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockoutstatus)) {
                                        clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                    }

                                    resultBefore.push({
                                        ...day,
                                        clockinstatus,
                                        clockoutstatus
                                    });
                                });
                            } else {
                                resultBefore.push(...streak);
                            }
                        });
                        resultBefore.sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                        // console.log(resultBefore, 'resultBefore')

                        // Group data by empcode
                        let groupedData = {};
                        resultBefore.forEach((item) => {
                            if (!groupedData[item.empcode]) {
                                groupedData[item.empcode] = {
                                    attendanceRecords: [],
                                    departmentDateSet: item.departmentDateSet || [],
                                };
                            }
                            groupedData[item.empcode].attendanceRecords.push(item);
                        });
                        // console.log(groupedData, 'groupedData')
                        let result = [];

                        for (let empcode in groupedData) {
                            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

                            departmentDateSet.forEach((dateRange) => {
                                let { fromdate, todate, department } = dateRange;

                                let countByEmpcodeClockin = {};
                                let countByEmpcodeClockout = {};

                                let recordsInDateRange = attendanceRecords.filter((record) => {
                                    let formattedDate = new Date(record.finalDate);
                                    return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
                                });

                                let processedRecords = recordsInDateRange.map((item) => {
                                    let formattedDate = new Date(item.finalDate);
                                    let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                                    let dojDate = item.doj ? new Date(item.doj) : null;

                                    let updatedClockInStatus = item.clockinstatus;
                                    let updatedClockOutStatus = item.clockoutstatus;

                                    // Check if the date falls within the reasonDate or dojDate
                                    if (reasonDate && formattedDate > reasonDate) {
                                        return null;
                                    }
                                    if (dojDate && formattedDate < dojDate) {
                                        return null;
                                    }

                                    // Handling Late Clock-in and Early Clock-out
                                    if (!countByEmpcodeClockin[item.empcode]) {
                                        countByEmpcodeClockin[item.empcode] = 1;
                                    }
                                    if (!countByEmpcodeClockout[item.empcode]) {
                                        countByEmpcodeClockout[item.empcode] = 1;
                                    }

                                    if (updatedClockInStatus === "Late - ClockIn") {
                                        updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                                        countByEmpcodeClockin[item.empcode]++;
                                    }

                                    if (updatedClockOutStatus === "Early - ClockOut") {
                                        updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                                        countByEmpcodeClockout[item.empcode]++;
                                    }

                                    return {
                                        ...item,
                                        department,
                                        fromdate,
                                        todate,
                                        clockinstatus: updatedClockInStatus,
                                        clockoutstatus: updatedClockOutStatus,
                                    };
                                });

                                result.push(...processedRecords.filter(Boolean));
                            });
                        }

                        // console.log(result, 'result')

                        const itemsWithSerialNumber = result?.map((item) => (
                            {
                                ...item,
                                id: item.id,
                                shiftmode: item.shiftMode,
                                uniqueid: item.id,
                                userid: item.userid,
                                attendanceauto: getattendancestatus(item),
                                daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                                appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lopcalculation: getFinalLop(
                                    getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                lopcount: getCount(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresent: getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                lopday: getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                paidpresentday: getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            }));

                        // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber bef')
                        const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                        function getPreviousRelevantEntry(index, array) {
                            for (let i = index - 1; i >= 0; i--) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        function getNextRelevantEntry(index, array) {
                            for (let i = index + 1; i < array.length; i++) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        itemsWithSerialNumber.forEach((item, index, array) => {
                            if (item.shift === 'Week Off') {
                                const previousItem = getPreviousRelevantEntry(index, array);
                                const nextItem = getNextRelevantEntry(index, array);

                                const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                                const isPreviousManualPaidFull =
                                    previousItem &&
                                    previousItem.appliedthrough === 'Manual' &&
                                    previousItem.paidpresent === 'Yes - Full Day';

                                const isNextManualPaidFull =
                                    nextItem &&
                                    nextItem.appliedthrough === 'Manual' &&
                                    nextItem.paidpresent === 'Yes - Full Day';

                                const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                                const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                                if (isPrevLop && isNextLop) {
                                    item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLop) {
                                    item.clockinstatus = 'BeforeWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLop) {
                                    item.clockinstatus = 'AfterWeekOffAbsent';
                                    item.clockoutstatus = 'AfterWeekOffAbsent';
                                }

                                // Recalculate attendance status if needed
                                item.attendanceauto = getattendancestatus(item);
                                item.daystatus = item.attendanceautostatus || getattendancestatus(item);
                                item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                                item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                                item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                                item.lopcalculation = getFinalLop(
                                    getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.lopcount = getCount(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                                item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresent = getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.lopday = getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.paidpresentday = getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                                item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

                            }
                            if (attStatusOption.includes(item.daystatus) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {
                                const previousItem = array[index - 1];
                                const nextItem = array[index + 1];

                                const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

                                if (hasRelevantStatus(previousItem)) {
                                    if (!weekOption.includes(previousItem.clockinstatus)) {
                                        previousItem.clockinstatus = 'Week Off';
                                        previousItem.clockoutstatus = 'Week Off';
                                        previousItem.attendanceauto = getattendancestatus(previousItem);
                                        previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                        previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lopcalculation = getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopcount = getCount(
                                            getFinalLop(
                                                getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    }
                                }
                                if (hasRelevantStatus(nextItem)) {
                                    if (!weekOption.includes(nextItem.clockinstatus)) {
                                        nextItem.clockinstatus = 'Week Off';
                                        nextItem.clockoutstatus = 'Week Off';
                                        nextItem.attendanceauto = getattendancestatus(nextItem);
                                        nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                        nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lopcalculation = getFinalLop(
                                            getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.lopcount = getCount(
                                            getFinalLop(
                                                getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    }
                                }
                            }
                        })

                        let finalResult = itemsWithSerialNumber.filter(data => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate);
                        // console.log(finalResult)
                        return finalResult;
                    }

                } catch (err) {
                    console.error("Error in POST request for batch:", batch.data, err);
                }
            }

            async function getAllResults() {
                let allResults = [];
                for (let batch of resultarr) {
                    const finaldata = await sendBatchRequest(batch);
                    allResults = allResults.concat(finaldata);
                }

                return { allResults }; // Return both results as an object
            }
            // console.log(filterUser.attmode, 'results')
            if (filterUser.attmode === 'User Shift Roaster') {
                getAllResults().then(async (results) => {

                    const itemsWithSerialNumber = results.allResults?.map((item) => (
                        {
                            ...item,
                            id: item.id,
                            shiftmode: item.shiftMode,
                            uniqueid: item.id,
                            userid: item.userid,
                            level: item.level == undefined ? filterUser.level : item.level + item.control,
                            attendanceauto: getattendancestatus(item),
                            daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                            appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lopcalculation: getFinalLop(
                                getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                            ),
                            modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresent: getFinalPaid(
                                getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                            ),
                            lopday: getAssignLeaveDayForLop(
                                getFinalLop(
                                    getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                )
                            ),
                            paidpresentday: getAssignLeaveDayForPaid(
                                getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                )
                            ),
                            isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                        }));

                    const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                    function getPreviousRelevantEntry(index, array) {
                        for (let i = index - 1; i >= 0; i--) {
                            if (array[i].shift !== 'Week Off') {
                                return array[i];
                            }
                        }
                        return null;
                    }

                    function getNextRelevantEntry(index, array) {
                        for (let i = index + 1; i < array.length; i++) {
                            if (array[i].shift !== 'Week Off') {
                                return array[i];
                            }
                        }
                        return null;
                    }

                    itemsWithSerialNumber.forEach((item, index, array) => {
                        if (item.shift === 'Week Off') {

                            const previousItem = getPreviousRelevantEntry(index, array);
                            const nextItem = getNextRelevantEntry(index, array);

                            const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                            const isPreviousManualPaidFull =
                                previousItem &&
                                previousItem.appliedthrough === 'Manual' &&
                                previousItem.paidpresent === 'Yes - Full Day';

                            const isNextManualPaidFull =
                                nextItem &&
                                nextItem.appliedthrough === 'Manual' &&
                                nextItem.paidpresent === 'Yes - Full Day';

                            const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                            const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                            if (isPrevLop && isNextLop) {
                                item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                            } else if (isPrevLop) {
                                item.clockinstatus = 'BeforeWeekOffAbsent';
                                item.clockoutstatus = 'BeforeWeekOffAbsent';
                            } else if (isNextLop) {
                                item.clockinstatus = 'AfterWeekOffAbsent';
                                item.clockoutstatus = 'AfterWeekOffAbsent';
                            }

                            // Recalculate attendance status if needed
                            item.attendanceauto = getattendancestatus(item);
                            item.daystatus = item.attendanceautostatus || getattendancestatus(item);
                            item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                            item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                            item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                            item.lopcalculation = getFinalLop(
                                getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                            );
                            item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                            item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                            item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                            item.paidpresent = getFinalPaid(
                                getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                            );
                            item.lopday = getAssignLeaveDayForLop(
                                getFinalLop(
                                    getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                )
                            );
                            item.paidpresentday = getAssignLeaveDayForPaid(
                                getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                )
                            );
                            item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                            item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

                        }
                        if (attStatusOption.includes(item.daystatus) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {

                            const previousItem = array[index - 1];
                            const nextItem = array[index + 1];

                            const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

                            if (hasRelevantStatus(previousItem)) {
                                if (!weekOption.includes(previousItem.clockinstatus)) {
                                    previousItem.clockinstatus = 'Week Off';
                                    previousItem.clockoutstatus = 'Week Off';
                                    previousItem.attendanceauto = getattendancestatus(previousItem);
                                    previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                    previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.lopcalculation = getFinalLop(
                                        getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                        getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                    );
                                    previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidpresent = getFinalPaid(
                                        getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                        getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                    );
                                    previousItem.lopday = getAssignLeaveDayForLop(
                                        getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        )
                                    );
                                    previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                        getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        )
                                    );
                                    previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                }
                            }
                            if (hasRelevantStatus(nextItem)) {
                                if (!weekOption.includes(nextItem.clockinstatus)) {
                                    nextItem.clockinstatus = 'Week Off';
                                    nextItem.clockoutstatus = 'Week Off';
                                    nextItem.attendanceauto = getattendancestatus(nextItem);
                                    nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                    nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.lopcalculation = getFinalLop(
                                        getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                        getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                    );
                                    nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidpresent = getFinalPaid(
                                        getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                        getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                    );
                                    nextItem.lopday = getAssignLeaveDayForLop(
                                        getFinalLop(
                                            getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        )
                                    );
                                    nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                        getFinalPaid(
                                            getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        )
                                    );
                                    nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                }
                            }
                        }
                    })

                    let fianlResult = itemsWithSerialNumber.filter(data => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate)?.map((item, index) => ({ ...item, serialNumber: index + 1, }))
                    // console.log(fianlResult, 'fianlResult usershift');
                    setUserShifts(fianlResult);
                    setFilteredDataItems(fianlResult);
                    setSearchQueryAttTeam("");
                    setLoader(false);
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Day Shift') {
                getAllResults().then(async (results) => {
                    function convertTo12HourFormatWithSeconds(time) {
                        const [hours, minutes, seconds] = time.split(':').map(Number);
                        const isPM = hours >= 12;
                        const convertedHours = hours % 12 || 12; // Convert to 12-hour format
                        const formattedTime = `${convertedHours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
                        return formattedTime;
                    }
                    // console.log(results.allResults, 'results.allResults')
                    const itemsWithSerialNumberFinal = results.allResults.map((item, index) => {

                        const fromtodate = item.prodshift ? item.prodshift.split("to") : "";
                        const fromdate = fromtodate ? fromtodate[0].split("T")[0] : "";
                        const fromtime = fromtodate ? fromtodate[0].split("T")[1] : "";

                        const enddate = fromtodate ? fromtodate[1].split("T")[0] : "";
                        const endtime = fromtodate ? fromtodate[1].split("T")[1] : "";
                        // console.log(item.shiftMode === 'Second Shift' ?  )

                        return {
                            ...item,
                            id: item.id,
                            serialNumber: index + 1,
                            shiftmode: item.shiftMode,
                            prodstartdate: item.prodshift !== "" ? moment(fromdate).format("DD/MM/YYYY") : "",
                            prodstarttime: item.prodshift !== "" ? convertTo12HourFormatWithSeconds(fromtime) : "",
                            prodenddate: item.prodshift !== "" ? moment(enddate).format("DD/MM/YYYY") : "",
                            prodendtime: item.prodshift !== "" ? convertTo12HourFormatWithSeconds(endtime) : "",
                        }
                    });
                    const filteredMainShift = itemsWithSerialNumberFinal?.filter((shift) => shift.shiftMode === "Main Shift");
                    const filteredSecondShift = itemsWithSerialNumberFinal?.filter((shift) => shift.shiftMode === "Second Shift");

                    itemsWithSerialNumberFinal.forEach((data) => {
                        if (data.shiftMode === 'Main Shift') {

                            // Check if this user also has a "Second Shift"
                            const hasSecondShift = filteredSecondShift.some(
                                (shift) =>
                                    shift.empcode === data.empcode &&
                                    shift.rowformattedDate === data.rowformattedDate &&
                                    shift.shiftMode === 'Second Shift'
                            );

                            if (hasSecondShift) {
                                const mainShift = filteredMainShift.find(
                                    (shift) =>
                                        shift.empcode === data.empcode &&
                                        shift.rowformattedDate === data.rowformattedDate &&
                                        shift.shiftMode === 'Main Shift'
                                );

                                if (mainShift) {

                                    const endtime = mainShift.shift?.split('to')[1]?.trim(); // Extract end time

                                    const mainShiftEndTime = moment(endtime, 'h:mm A'); // Convert to moment
                                    const changedMainShiftEndTime = mainShiftEndTime.format('h:mm:ss A');

                                    data.prodendtime = changedMainShiftEndTime; // Update the end time
                                }
                            }
                        }

                        if (data.shiftMode === 'Second Shift') {
                            const mainShift = filteredMainShift.find(
                                (shift) =>
                                    shift.empcode === data.empcode &&
                                    shift.rowformattedDate === data.rowformattedDate &&
                                    shift.shiftMode === 'Main Shift'
                            );

                            if (mainShift) {
                                const endtime = mainShift.clockout !== '00:00:00' ? mainShift.clockout : mainShift.shift?.split('to')[1]?.trim(); // Extract end time
                                // let startTimeWithPM = mainShift.shift?.split('to')[0];

                                const mainShiftEndTime = moment(endtime, 'h:mm:ss A'); // Convert to moment
                                const changedMainShiftEndTime = mainShiftEndTime.add(1, 'second').format('h:mm:ss A'); // Add 1 minute

                                data.prodstarttime = changedMainShiftEndTime; // Set second shift's start time to main shift's end time
                                // if (startTimeWithPM.includes('PM')) {
                                //     data.prodstartdate = mainShift.prodenddate;
                                //     data.prodenddate = mainShift.prodenddate;
                                // }
                            }
                        }
                    });

                    // console.log(itemsWithSerialNumberFinal, 'itemsWithSerialNumberFinal')
                    setUserShiftsAttDay(itemsWithSerialNumberFinal);
                    setFilteredDataItemsAttDay(itemsWithSerialNumberFinal);
                    setLoader(false);
                    setSearchQueryAttDay("");
                    setTotalPagesAttDay(Math.ceil(itemsWithSerialNumberFinal.length / pageSizeAttDay));
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Short Time') {
                getAllResults().then(async (results) => {
                    function convertTo12HourFormatWithSeconds(time) {
                        const [hours, minutes, seconds] = time.split(':').map(Number);
                        const isPM = hours >= 12;
                        const convertedHours = hours % 12 || 12; // Convert to 12-hour format
                        const formattedTime = `${convertedHours}:${String(minutes).padStart(2, '0')}:${String(seconds).padStart(2, '0')} ${isPM ? 'PM' : 'AM'}`;
                        return formattedTime;
                    }
                    // console.log(results.allResults, 'results.allResults')
                    const itemsWithSerialNumberFinal = results.allResults.map((item, index) => {

                        const fromtodate = item.prodshift ? item.prodshift.split("to") : "";
                        const fromdate = fromtodate ? fromtodate[0].split("T")[0] : "";
                        const fromtime = fromtodate ? fromtodate[0].split("T")[1] : "";

                        const enddate = fromtodate ? fromtodate[1].split("T")[0] : "";
                        const endtime = fromtodate ? fromtodate[1].split("T")[1] : "";
                        // console.log(item.shiftMode === 'Second Shift' ?  )

                        return {
                            ...item,
                            id: item.id,
                            serialNumber: index + 1,
                            shiftmode: item.shiftMode,
                            prodstartdate: item.prodshift !== "" ? moment(fromdate).format("DD/MM/YYYY") : "",
                            prodstarttime: item.prodshift !== "" ? convertTo12HourFormatWithSeconds(fromtime) : "",
                            prodenddate: item.prodshift !== "" ? moment(enddate).format("DD/MM/YYYY") : "",
                            prodendtime: item.prodshift !== "" ? convertTo12HourFormatWithSeconds(endtime) : "",
                        }
                    });
                    const filteredMainShift = itemsWithSerialNumberFinal?.filter((shift) => shift.shiftMode === "Main Shift");
                    const filteredSecondShift = itemsWithSerialNumberFinal?.filter((shift) => shift.shiftMode === "Second Shift");

                    itemsWithSerialNumberFinal.forEach((data) => {
                        if (data.shiftMode === 'Main Shift') {

                            // Check if this user also has a "Second Shift"
                            const hasSecondShift = filteredSecondShift.some(
                                (shift) =>
                                    shift.empcode === data.empcode &&
                                    shift.rowformattedDate === data.rowformattedDate &&
                                    shift.shiftMode === 'Second Shift'
                            );

                            if (hasSecondShift) {
                                const mainShift = filteredMainShift.find(
                                    (shift) =>
                                        shift.empcode === data.empcode &&
                                        shift.rowformattedDate === data.rowformattedDate &&
                                        shift.shiftMode === 'Main Shift'
                                );

                                if (mainShift) {

                                    const endtime = mainShift.shift?.split('to')[1]?.trim(); // Extract end time

                                    const mainShiftEndTime = moment(endtime, 'h:mm A'); // Convert to moment
                                    const changedMainShiftEndTime = mainShiftEndTime.format('h:mm:ss A');

                                    data.prodendtime = changedMainShiftEndTime; // Update the end time
                                }
                            }
                        }

                        if (data.shiftMode === 'Second Shift') {
                            const mainShift = filteredMainShift.find(
                                (shift) =>
                                    shift.empcode === data.empcode &&
                                    shift.rowformattedDate === data.rowformattedDate &&
                                    shift.shiftMode === 'Main Shift'
                            );

                            if (mainShift) {
                                const endtime = mainShift.clockout !== '00:00:00' ? mainShift.clockout : mainShift.shift?.split('to')[1]?.trim(); // Extract end time
                                // let startTimeWithPM = mainShift.shift?.split('to')[0];

                                const mainShiftEndTime = moment(endtime, 'h:mm:ss A'); // Convert to moment
                                const changedMainShiftEndTime = mainShiftEndTime.add(1, 'second').format('h:mm:ss A'); // Add 1 minute

                                data.prodstarttime = changedMainShiftEndTime; // Set second shift's start time to main shift's end time
                                // if (startTimeWithPM.includes('PM')) {
                                //     data.prodstartdate = mainShift.prodenddate;
                                //     data.prodenddate = mainShift.prodenddate;
                                // }
                            }
                        }
                    });

                    // console.log(itemsWithSerialNumberFinal, 'itemsWithSerialNumberFinal')
                    setUserShiftsAttShort(itemsWithSerialNumberFinal);
                    setLoader(false);
                    setSearchQueryAttShort("");
                    setTotalPagesAttShort(Math.ceil(itemsWithSerialNumberFinal.length / pageSizeAttDay));
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Month Status') {
                getAllResults().then(async (results) => {
                    const finalresult = [];

                    results.allResults?.forEach(item => {

                        const leaveOnDateApproved = leaveresult.find((d) => d.date === item.rowformattedDate && d.empcode === item.empcode);

                        let weekoffdayscount = 0;
                        if (item.isweekoff === 'Yes') {
                            weekoffdayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                        }

                        let holidaydayscount = 0;
                        if (item.isholiday === 'Yes') {
                            holidaydayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                        }

                        const existingEntryIndex = finalresult.findIndex(entry => entry.empcode === item.empcode);

                        if (existingEntryIndex !== -1) {

                            if (item.shift !== 'Not Allotted') {
                                finalresult[existingEntryIndex].shift++;
                            }

                            if (item.isweekoff === 'Yes') {
                                finalresult[existingEntryIndex].weekoff++;
                            }

                            if (item.isholiday === 'Yes') {
                                finalresult[existingEntryIndex].holidayCount++;
                            }

                            if (leaveOnDateApproved) {
                                finalresult[existingEntryIndex].leaveCount++;
                            }

                            if (item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
                                finalresult[existingEntryIndex].nostatuscount++;
                            }

                            if (item.lopcalculation === 'Yes - Double Day') {
                                finalresult[existingEntryIndex].doublelopcount++;
                            }

                            if (item.lopcalculation === 'Yes - Double Half Day') {
                                finalresult[existingEntryIndex].doublehalflopcount++;
                            }

                            finalresult[existingEntryIndex].lopcount = String(parseFloat(finalresult[existingEntryIndex].lopcount) + parseFloat(item.lopcount));
                            finalresult[existingEntryIndex].paidpresentday = String(parseFloat(finalresult[existingEntryIndex].paidpresentday) + parseFloat(item.paidpresentday));

                        } else {

                            const newItem = {
                                id: item.id,
                                empcode: item.empcode,
                                username: item.username,
                                company: item.company,
                                branch: item.branch,
                                unit: item.unit,
                                team: item.team,
                                department: item.department,
                                totalnumberofdays: item.totalnumberofdays,
                                empshiftdays: item.empshiftdays,
                                shift: item.shift !== 'Not Allotted' ? 1 : 0,
                                // weekoff: (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off' && item.clockin === '00:00:00' && item.clockout === '00:00:00') ? 1 : 0,
                                weekoff: weekoffdayscount,
                                lopcount: item.lopcount,
                                paidpresentday: item.paidpresentday,
                                totalcounttillcurrendate: item.totalcounttillcurrendate,
                                totalshift: item.totalshift,
                                // holidayCount: (item.clockinstatus === 'Holiday' && item.clockoutstatus === 'Holiday') ? 1 : 0,
                                holidayCount: holidaydayscount,
                                leaveCount: leaveOnDateApproved ? 1 : 0,
                                clsl: 0,
                                // holiday: 0,
                                totalpaiddays: 0,
                                nostatus: 0,
                                nostatuscount: (item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.paidpresent === 'No' && item.modetarget === 'No' && item.lopcalculation === 'No') ? 1 : 0,
                                doublelopcount: item.lopcalculation === "Yes - Double Day" ? 1 : 0,
                                doublehalflopcount: item.lopcalculation === "Double Half Day" ? 0.5 : 0,
                            };

                            finalresult.push(newItem);
                        }
                    });

                    let resultdata = finalresult?.map((item, index) => {
                        const finalPaidPresentDays = Number(item.paidpresentday) - (Number(item.weekoff) + Number(item.holidayCount) + Number(item.leaveCount) + Number(item.doublelopcount) + Number(item.doublehalflopcount));

                        return {
                            ...item,
                            serialNumber: index + 1,
                            totalnumberofdays: Number(item.totalnumberofdays),
                            lopcount: Number(item.lopcount),
                            clsl: item.leaveCount,
                            paidpresentday: finalPaidPresentDays,
                            totalpaiddays: Number(item.paidpresentday) > Number(item.shift) ? (Number(item.shift) - Number(item.lopcount)) : (Number(item.paidpresentday) - Number(item.doublelopcount) + Number(item.doublehalflopcount)),
                        }
                    });

                    // console.log(resultdata, 'resultdata')
                    setUserShiftsAttMonth(resultdata);
                    setLoader(false);
                    setSearchQueryAttMonth("");
                    setTotalPagesAttMonth(Math.ceil(resultdata.length / pageSizeAttMonth));
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Review') {
                getAllResults().then(async (results) => {

                    const itemsWithSerialNumber = results.allResults
                        .filter((item) => item !== null)
                        ?.map((item, index) => ({
                            ...item,
                            shift: item.changeshift ? item.changeshift : item.shift,
                            attendanceauto: getattendancestatus(item),
                            bookby: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                            appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            lopcalculation: getFinalLop(
                                getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                            ),
                            modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            paidpresent: getFinalPaid(
                                getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                            ),
                            lopday: getAssignLeaveDayForLop(
                                getFinalLop(
                                    getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                )
                            ),
                            paidpresentday: getAssignLeaveDayForPaid(
                                getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                )
                            ),
                            isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                        }));

                    const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                    function getPreviousRelevantEntry(index, array) {
                        for (let i = index - 1; i >= 0; i--) {
                            if (array[i].shift !== 'Week Off') {
                                return array[i];
                            }
                        }
                        return null;
                    }

                    function getNextRelevantEntry(index, array) {
                        for (let i = index + 1; i < array.length; i++) {
                            if (array[i].shift !== 'Week Off') {
                                return array[i];
                            }
                        }
                        return null;
                    }

                    itemsWithSerialNumber.forEach((item, index, array) => {
                        if (item.shift === 'Week Off') {
                            const previousItem = getPreviousRelevantEntry(index, array);
                            const nextItem = getNextRelevantEntry(index, array);

                            const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                            const isPreviousManualPaidFull =
                                previousItem &&
                                previousItem.appliedthrough === 'Manual' &&
                                previousItem.paidpresent === 'Yes - Full Day';

                            const isNextManualPaidFull =
                                nextItem &&
                                nextItem.appliedthrough === 'Manual' &&
                                nextItem.paidpresent === 'Yes - Full Day';

                            const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                            const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                            if (isPrevLop && isNextLop) {
                                item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                            } else if (isPrevLop) {
                                item.clockinstatus = 'BeforeWeekOffAbsent';
                                item.clockoutstatus = 'BeforeWeekOffAbsent';
                            } else if (isNextLop) {
                                item.clockinstatus = 'AfterWeekOffAbsent';
                                item.clockoutstatus = 'AfterWeekOffAbsent';
                            }

                            // Recalculate attendance status if needed
                            item.attendanceauto = getattendancestatus(item);
                            item.bookby = item.attendanceautostatus || getattendancestatus(item);
                            item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                            item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                            item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                            item.lopcalculation = getFinalLop(
                                getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                            );
                            item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                            item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                            item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                            item.paidpresent = getFinalPaid(
                                getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                            );
                            item.lopday = getAssignLeaveDayForLop(
                                getFinalLop(
                                    getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                )
                            );
                            item.paidpresentday = getAssignLeaveDayForPaid(
                                getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                )
                            );
                            item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                            item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

                        }
                        if (attStatusOption.includes(item.bookby) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {
                            const previousItem = array[index - 1];
                            const nextItem = array[index + 1];

                            const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

                            if (hasRelevantStatus(previousItem)) {
                                if (!weekOption.includes(previousItem.clockinstatus)) {
                                    previousItem.clockinstatus = 'Week Off';
                                    previousItem.clockoutstatus = 'Week Off';
                                    previousItem.attendanceauto = getattendancestatus(previousItem);
                                    previousItem.bookby = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                    previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.lopcalculation = getFinalLop(
                                        getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                        getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                    );
                                    previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.paidpresent = getFinalPaid(
                                        getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                        getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                    );
                                    previousItem.lopday = getAssignLeaveDayForLop(
                                        getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        )
                                    );
                                    previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                        getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        )
                                    );
                                    previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                }
                            }
                            if (hasRelevantStatus(nextItem)) {
                                if (!weekOption.includes(nextItem.clockinstatus)) {
                                    nextItem.clockinstatus = 'Week Off';
                                    nextItem.clockoutstatus = 'Week Off';
                                    nextItem.attendanceauto = getattendancestatus(nextItem);
                                    nextItem.bookby = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                    nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.lopcalculation = getFinalLop(
                                        getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                        getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                    );
                                    nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.paidpresent = getFinalPaid(
                                        getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                        getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                    );
                                    nextItem.lopday = getAssignLeaveDayForLop(
                                        getFinalLop(
                                            getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        )
                                    );
                                    nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                        getFinalPaid(
                                            getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        )
                                    );
                                    nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                }
                            }
                        }
                    })

                    let resultdata = itemsWithSerialNumber
                        ?.filter((data) => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate)
                        ?.filter((item) => {
                            // item.clockin !== "00:00:00" &&
                            const clockoutText = item.clockoutstatus.replace(/^\d+/, '').trim();
                            if (valueStatusCat?.includes(item.bookby)) {
                                return item;
                            } else if (valueStatusCat?.includes(item.clockinstatus)) {
                                return item;
                            } else if (valueStatusCat?.includes(clockoutText)) {
                                return item;
                            }
                        })
                        .map((item, index) => {
                            return {
                                ...item,
                                serialNumber: index + 1,
                                // attendanceauto: getattendancestatus(item) === undefined ? "No Status" : getattendancestatus(item)
                            };
                        });
                    setUserShiftsAttReview(resultdata);
                    setSearchQueryAttReview('');
                    setTotalPagesAttReview(Math.ceil(resultdata.length / pageSizeAttReview));
                    setLoader(false);
                }).catch((error) => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Report') {
                getAllResults().then(async (results) => {

                    const dayarr = daysArray.map((data, index) => {
                        return `${data.formattedDate} ${data.dayName} ${data.dayCount}`;
                    });

                    let res_type = await axios.get(SERVICE.LEAVETYPE, {
                        headers: {
                            Authorization: `Bearer ${auth.APIToken}`,
                        },
                    });

                    let resdatawithlwp = [...res_type?.data?.leavetype, { leavetype: 'Leave Without Pay (LWP)', code: "LWP" }]

                    let leavestatusApproved = [];
                    resdatawithlwp?.map((type) => {
                        res_applyleave?.data?.applyleaves && res_applyleave?.data?.applyleaves?.forEach((d) => {
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Single' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push(type.code + ' ' + d.status)
                            }
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push('DL' + ' - ' + type.code + ' ' + d.status)
                            }
                            if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double Day' && d.leavestatus === 'Shift') {
                                leavestatusApproved.push('DDL' + ' - ' + type.code + ' ' + d.status)
                            }
                        });
                    });

                    const rearr = [...new Set(leavestatusApproved)];

                    const itemsWithSerialNumber = results.allResults?.flatMap((val, index) => {

                        const findPreviousNonWeekOff = (items, index) => {
                            for (let i = index - 1; i >= 0; i--) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const findNextNonWeekOff = (items, index) => {
                            for (let i = index + 1; i < items.length; i++) {
                                if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                                    return items[i];
                                }
                            }
                            return null;
                        };

                        const changedWeekoffResult = val.alldays?.map((item, index) => {
                            let updatedClockInStatus = item.clockinstatus;
                            let updatedClockOutStatus = item.clockoutstatus;

                            const itemDate = moment(item.rowformattedDate, "DD/MM/YYYY");

                            // For Week Off status
                            if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
                                const prev = findPreviousNonWeekOff(val.alldays, index);
                                const next = findNextNonWeekOff(val.alldays, index);

                                const isPrevLeave = leaveresult.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

                                const isNextLeave = leaveresult.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

                                const isPrevLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
                                const isNextLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);

                                if (isPrevLeave && isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
                                } else if (isPrevAbsent && isNextAbsent) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
                                } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLeave) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
                                } else if (isNextAbsent || isNextLeaveWithoutPay) {
                                    updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
                                }
                            }

                            return {
                                ...item,
                                clockinstatus: updatedClockInStatus,
                                clockoutstatus: updatedClockOutStatus,
                            };
                        });

                        const resultBefore = [];

                        const empGrouped = {};

                        changedWeekoffResult.forEach(item => {
                            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
                            empGrouped[item.empcode].push(item);
                        });

                        const leaveStatuses = [
                            ...rearr,
                            "Absent", "BL - Absent",
                        ];

                        // console.log(leaveStatuses, 'leaveStatuses')
                        Object.keys(empGrouped).forEach(empcode => {
                            const records = empGrouped[empcode]
                                .sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                            let streak = [];
                            let counterIn = 1;
                            let counterOut = 1;

                            for (let i = 0; i < records.length; i++) {
                                const current = records[i];
                                const isWeekOff = current.shift === "Week Off";

                                const isLeaveDay =
                                    current.clockin === "00:00:00" &&
                                    current.clockout === "00:00:00" &&
                                    leaveStatuses.includes(current.clockinstatus) &&
                                    !isWeekOff;

                                if (isLeaveDay) {
                                    streak.push(current);
                                } else if (isWeekOff) {
                                    // Push Week Off directly, don’t reset streak
                                    resultBefore.push(current);
                                } else {
                                    // Encountered present day, finalize streak
                                    if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                        streak.forEach(day => {
                                            let clockinstatus = day.clockinstatus;
                                            let clockoutstatus = day.clockoutstatus;

                                            if (clockinstatus === "Absent") {
                                                clockinstatus = `${counterIn++}Long Absent`;
                                            } else if (clockinstatus === "BL - Absent") {
                                                clockinstatus = `${counterIn++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockinstatus)) {
                                                clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                            }

                                            if (clockoutstatus === "Absent") {
                                                clockoutstatus = `${counterOut++}Long Absent`;
                                            } else if (clockoutstatus === "BL - Absent") {
                                                clockoutstatus = `${counterOut++}Long BL - Absent`;
                                            } else if (rearr?.includes(clockoutstatus)) {
                                                clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                            }

                                            resultBefore.push({
                                                ...day,
                                                clockinstatus,
                                                clockoutstatus
                                            });
                                        });
                                    } else {
                                        resultBefore.push(...streak); // push as-is
                                    }

                                    resultBefore.push(current); // current present day
                                    streak = [];
                                    counterIn = 1;
                                    counterOut = 1;
                                }
                            }

                            // Remaining streak at end
                            if (streak.length > attendanceCriteriaData?.longabsentcount) {
                                streak.forEach(day => {
                                    let clockinstatus = day.clockinstatus;
                                    let clockoutstatus = day.clockoutstatus;

                                    if (clockinstatus === "Absent") {
                                        clockinstatus = `${counterIn++}Long Absent`;
                                    } else if (clockinstatus === "BL - Absent") {
                                        clockinstatus = `${counterIn++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockinstatus)) {
                                        clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                                    }

                                    if (clockoutstatus === "Absent") {
                                        clockoutstatus = `${counterOut++}Long Absent`;
                                    } else if (clockoutstatus === "BL - Absent") {
                                        clockoutstatus = `${counterOut++}Long BL - Absent`;
                                    } else if (rearr?.includes(clockoutstatus)) {
                                        clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                                    }

                                    resultBefore.push({
                                        ...day,
                                        clockinstatus,
                                        clockoutstatus
                                    });
                                });
                            } else {
                                resultBefore.push(...streak);
                            }
                        });
                        resultBefore.sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

                        // Group data by empcode
                        let groupedData = {};
                        // val.alldays.forEach((item) => {
                        resultBefore.forEach((item) => {
                            if (!groupedData[item.empcode]) {
                                groupedData[item.empcode] = {
                                    attendanceRecords: [],
                                    departmentDateSet: item.departmentDateSet || [],
                                };
                            }
                            groupedData[item.empcode].attendanceRecords.push(item);
                        });
                        // console.log(groupedData, 'groupedData')

                        let userRows = [];

                        for (let empcode in groupedData) {
                            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

                            departmentDateSet.forEach((dateRange) => {
                                let { fromdate, todate, department } = dateRange;

                                let countByEmpcodeClockin = {};
                                let countByEmpcodeClockout = {};

                                let recordsInDateRange = attendanceRecords.filter((record) => {
                                    let formattedDate = new Date(record.finalDate);
                                    return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
                                });

                                let processedRecords = recordsInDateRange.map((item) => {
                                    let formattedDate = new Date(item.finalDate);
                                    let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                                    let dojDate = item.doj ? new Date(item.doj) : null;

                                    let updatedClockInStatus = item.clockinstatus;
                                    let updatedClockOutStatus = item.clockoutstatus;

                                    // Check if the date falls within the reasonDate or dojDate
                                    if (reasonDate && formattedDate > reasonDate) {
                                        return null;
                                    }
                                    if (dojDate && formattedDate < dojDate) {
                                        return null;
                                    }

                                    // Handling Late Clock-in and Early Clock-out
                                    if (!countByEmpcodeClockin[item.empcode]) {
                                        countByEmpcodeClockin[item.empcode] = 1;
                                    }
                                    if (!countByEmpcodeClockout[item.empcode]) {
                                        countByEmpcodeClockout[item.empcode] = 1;
                                    }

                                    if (updatedClockInStatus === "Late - ClockIn") {
                                        updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                                        countByEmpcodeClockin[item.empcode]++;
                                    }

                                    if (updatedClockOutStatus === "Early - ClockOut") {
                                        updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                                        countByEmpcodeClockout[item.empcode]++;
                                    }

                                    return {
                                        ...item,
                                        department,
                                        fromdate,
                                        todate,
                                        clockinstatus: updatedClockInStatus,
                                        clockoutstatus: updatedClockOutStatus,
                                    };
                                });

                                userRows.push(...processedRecords.filter(Boolean));
                            });
                        }
                        // console.log(userRows, 'userRows')
                        const finalUserRows = userRows?.map((item, index) => (
                            {
                                ...item,
                                attendanceauto: getattendancestatus(item),
                                daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
                                appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                lopcalculation: getFinalLop(
                                    getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                paidpresent: getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                ),
                                lopday: getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                paidpresentday: getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                                    )
                                ),
                                isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                                isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                            }));

                        const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                        function getPreviousRelevantEntry(index, array) {
                            for (let i = index - 1; i >= 0; i--) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        function getNextRelevantEntry(index, array) {
                            for (let i = index + 1; i < array.length; i++) {
                                if (array[i].shift !== 'Week Off') {
                                    return array[i];
                                }
                            }
                            return null;
                        }

                        finalUserRows.forEach((item, index, array) => {
                            if (item.shift === 'Week Off') {
                                const previousItem = getPreviousRelevantEntry(index, array);
                                const nextItem = getNextRelevantEntry(index, array);

                                const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

                                const isPreviousManualPaidFull =
                                    previousItem &&
                                    previousItem.appliedthrough === 'Manual' &&
                                    previousItem.paidpresent === 'Yes - Full Day';

                                const isNextManualPaidFull =
                                    nextItem &&
                                    nextItem.appliedthrough === 'Manual' &&
                                    nextItem.paidpresent === 'Yes - Full Day';

                                const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
                                const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

                                if (isPrevLop && isNextLop) {
                                    item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
                                } else if (isPrevLop) {
                                    item.clockinstatus = 'BeforeWeekOffAbsent';
                                    item.clockoutstatus = 'BeforeWeekOffAbsent';
                                } else if (isNextLop) {
                                    item.clockinstatus = 'AfterWeekOffAbsent';
                                    item.clockoutstatus = 'AfterWeekOffAbsent';
                                }

                                // Recalculate attendance status if needed
                                item.attendanceauto = getattendancestatus(item);
                                item.daystatus = item.attendanceautostatus || getattendancestatus(item);
                                item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
                                item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
                                item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
                                item.lopcalculation = getFinalLop(
                                    getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
                                item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
                                item.paidpresent = getFinalPaid(
                                    getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                    getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                );
                                item.lopday = getAssignLeaveDayForLop(
                                    getFinalLop(
                                        getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.paidpresentday = getAssignLeaveDayForPaid(
                                    getFinalPaid(
                                        getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                                        getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                                    )
                                );
                                item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
                                item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

                            }
                            if (attStatusOption.includes(item.daystatus) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {
                                const previousItem = array[index - 1];
                                const nextItem = array[index + 1];

                                const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

                                if (hasRelevantStatus(previousItem)) {
                                    if (!weekOption.includes(previousItem.clockinstatus)) {
                                        previousItem.clockinstatus = 'Week Off';
                                        previousItem.clockoutstatus = 'Week Off';
                                        previousItem.attendanceauto = getattendancestatus(previousItem);
                                        previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                                        previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.lopcalculation = getFinalLop(
                                            getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                            getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                        );
                                        previousItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                                                getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                                            )
                                        );
                                        previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                        previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                                    }
                                }
                                if (hasRelevantStatus(nextItem)) {
                                    if (!weekOption.includes(nextItem.clockinstatus)) {
                                        nextItem.clockinstatus = 'Week Off';
                                        nextItem.clockoutstatus = 'Week Off';
                                        nextItem.attendanceauto = getattendancestatus(nextItem);
                                        nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                                        nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.lopcalculation = getFinalLop(
                                            getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.paidpresent = getFinalPaid(
                                            getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                            getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                        );
                                        nextItem.lopday = getAssignLeaveDayForLop(
                                            getFinalLop(
                                                getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.paidpresentday = getAssignLeaveDayForPaid(
                                            getFinalPaid(
                                                getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                                                getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                                            )
                                        );
                                        nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                        nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                                    }
                                }
                            }
                        })

                        let finalResult = finalUserRows.filter(data => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate);
                        return {
                            ...val,
                            serialNumber: index + 1,
                            alldays: finalResult,
                        }
                    });
                    // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber')
                    setUserShiftsAttReport(itemsWithSerialNumber);
                    setSearchQueryAttReport("");
                    setIsHeadings(dayarr);
                    setColumnVisibilityAttReport({
                        serialNumber: true,
                        empcode: true,
                        username: true,
                        company: true,
                        branch: true,
                        unit: true,
                        team: true,
                        department: true,
                        ...dayarr.reduce((acc, data, index) => {
                            acc[data] = true;
                            return acc;
                        }, {}),
                    });
                    setLoader(false);
                    setTotalPagesAttReport(Math.ceil(itemsWithSerialNumber.length / pageSizeAttReport));
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

            if (filterUser.attmode === 'Attendance Summary Report') {
                getAllResults()
                    .then(async (results) => {
                        // console.log(results.allResults, 'results.allResults')
                        const finalresult = [];
                        let totalemployeesArray = [];
                        let totalcurrentshiftArray = [];
                        let paidpresentdayArray = [];
                        let absentArray = [];
                        let totalinArray = [];
                        let totaloutArray = [];
                        let totalpendingArray = [];
                        let facilitypresentArray = [];
                        let wfhpresentArray = [];
                        let facilityabsentArray = [];
                        let wfhabsentArray = [];
                        let earlyclockinArray = [];
                        let onpresentArray = [];
                        let graceclockinArray = [];
                        let lateclockinArray = [];
                        let weekoffArray = [];
                        let holidayArray = [];
                        let permissionArray = [];
                        let clslArray = [];
                        let onclockoutArray = [];
                        let earlyclockoutArray = [];
                        let overclockoutArray = [];
                        let autoclockoutArray = [];
                        let shiftnotstartedArray = [];
                        let nostatusArray = [];
                        let notallottedArray = [];
                        let weekoffpresentArray = [];
                        let longleaveabsentArray = [];
                        let blabsentArray = [];
                        let doubledayabsentArray = [];
                        let weekoffabsentArray = [];

                        results.allResults?.forEach(item => {
                            // console.log(item, 'item')
                            const leaveOnDateApproved = leaveresult.find((d) => d.date === item.rowformattedDate && d.empcode === item.empcode);
                            const permissionOnDateApproved = permissionresult.find((d) => d.date === item.finalDate && d.employeeid === item.empcode);
                            const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                            // employee
                            if (item.username !== '') {
                                totalemployeesArray.push(item);
                            }

                            // current shift
                            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
                                totalcurrentshiftArray.push(item);
                            }

                            // present
                            if (item.isweekoff !== 'Yes' && item.isholiday !== 'Yes' && !leaveOnDateApproved && (item.paidpresent === 'Yes - Full Day' || item.paidpresent === 'Yes - Half Day')) {
                                paidpresentdayArray.push(item);
                            }

                            // absent
                            if (item.lopcalculation === 'Yes - Full Day' || item.lopcalculation === 'Yes - Half Day' || item.lopcalculation === 'Yes - Double Day' || item.lopcalculation === 'Yes - Double Half Day') {
                                absentArray.push(item);
                            }

                            // totalin
                            if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
                                totalinArray.push(item);
                            }

                            // totalout
                            if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
                                totaloutArray.push(item);
                            }

                            // facilitypresent
                            if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
                                facilitypresentArray.push(item);
                            }

                            // wfhpresent
                            if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
                                wfhpresentArray.push(item);
                            }

                            // facilityabsent
                            if (item.workmode !== 'Remote' && item.lop === 'Yes') {
                                facilityabsentArray.push(item);
                            }

                            // wfhabsent
                            if (item.workmode === 'Remote' && item.lop === 'Yes') {
                                wfhabsentArray.push(item);
                            }

                            // earlyclockin
                            if (item.clockinstatus?.includes('Early - ClockIn')) {
                                earlyclockinArray.push(item);
                            }

                            // onpresent
                            if (item.clockinstatus === 'On - Present') {
                                onpresentArray.push(item);
                            }

                            // gracetime
                            if (item.clockinstatus === 'Grace - ClockIn') {
                                graceclockinArray.push(item);
                            }

                            // lateclockin
                            if (item.clockinstatus?.includes('Late - ClockIn')) {
                                lateclockinArray.push(item);
                            }

                            // weekoff
                            let weekoffdayscount = 0;
                            if (item.isweekoff === 'Yes') {
                                weekoffdayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                                weekoffArray.push(item);
                            }

                            // holiday
                            let holidaydayscount = 0;
                            if (item.isholiday === 'Yes') {
                                holidaydayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                                holidayArray.push(item);
                            }

                            // permission
                            if (permissionOnDateApproved) {
                                permissionArray.push(item);
                            }

                            // clsl
                            if (leaveOnDateApproved) {
                                clslArray.push(item);
                            }

                            // onclockout
                            if (item.clockoutstatus === 'On - ClockOut') {
                                onclockoutArray.push(item);
                            }

                            // earlyclockout
                            if (item.clockoutstatus?.includes('Early - ClockOut')) {
                                earlyclockoutArray.push(item);
                            }

                            // overclockout
                            if (item.clockoutstatus === 'Over - ClockOut') {
                                overclockoutArray.push(item);
                            }

                            // automisclockout
                            if (item.clockoutstatus === 'Auto Mis - ClockOut') {
                                autoclockoutArray.push(item);
                            }

                            // shiftnotstarted
                            if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
                                shiftnotstartedArray.push(item);
                            }

                            // nostatus
                            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
                                nostatusArray.push(item);
                            }

                            // notallotted
                            if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
                                notallottedArray.push(item);
                            }

                            // weekoffpresent
                            if (item.weekoffpresentstatus === true) {
                                weekoffpresentArray.push(item);
                            }

                            // longleave and longabsent
                            if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
                                longleaveabsentArray.push(item);
                            }

                            // blabsent
                            if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
                                blabsentArray.push(item);
                            }

                            // doubledayabsent
                            if (item.lopcalculation?.includes("Double")) {
                                doubledayabsentArray.push(item);
                            }

                            // weekoffabsent
                            if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
                                weekoffabsentArray.push(item);
                            }

                            const existingEntryIndex = finalresult.findIndex(entry => entry.empcode === item.empcode);

                            if (existingEntryIndex !== -1) {

                                // employee
                                if (item.username !== '') {
                                    finalresult[existingEntryIndex].username++;
                                }

                                // current shift
                                if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // present
                                if (item.paidpresentbefore === 'Yes') {
                                    finalresult[existingEntryIndex].paidpresentday++;
                                }

                                // absent
                                if (item.lop === 'Yes') {
                                    finalresult[existingEntryIndex].lopcount++;
                                }

                                // totalin
                                if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
                                    finalresult[existingEntryIndex].clockin++;
                                }

                                // totalout
                                if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
                                    finalresult[existingEntryIndex].clockout++;
                                }

                                // facilitypresent
                                if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
                                    finalresult[existingEntryIndex].workmode++;
                                }

                                // wfhpresent
                                if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
                                    finalresult[existingEntryIndex].workmode++;
                                }

                                // facilityabsent
                                if (item.workmode !== 'Remote' && item.lop === 'Yes') {
                                    finalresult[existingEntryIndex].workmode++;
                                }

                                // wfhabsent
                                if (item.workmode === 'Remote' && item.lop === 'Yes') {
                                    finalresult[existingEntryIndex].workmode++;
                                }

                                // earlyclockin
                                if (item.clockinstatus?.includes('Early - ClockIn')) {
                                    finalresult[existingEntryIndex].clockin++;
                                }

                                // onpresent
                                if (item.clockinstatus === 'On - Present') {
                                    finalresult[existingEntryIndex].clockin++;
                                }

                                // gracetime
                                if (item.clockinstatus === 'Grace - ClockIn') {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // lateclockin
                                if (item.clockinstatus?.includes('Late - ClockIn')) {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // weekoff
                                if (item.isweekoff === 'Yes') {
                                    finalresult[existingEntryIndex].weekoff++;
                                }

                                // holiday
                                if (item.isholiday === 'Yes') {
                                    finalresult[existingEntryIndex].holidayCount++;
                                }

                                // permission
                                if (permissionOnDateApproved) {
                                    finalresult[existingEntryIndex].permissionCount++;
                                }

                                // clsl
                                if (leaveOnDateApproved) {
                                    finalresult[existingEntryIndex].leaveCount++;
                                }

                                // shift
                                if (item.shift !== 'Not Allotted') {
                                    finalresult[existingEntryIndex].shift++;
                                }

                                // onclockout
                                if (item.clockoutstatus === 'On - ClockOut') {
                                    finalresult[existingEntryIndex].clockoutstatus++;
                                }

                                // earlyclockout
                                if (item.clockoutstatus?.includes('Early - ClockOut')) {
                                    finalresult[existingEntryIndex].clockoutstatus++;
                                }

                                // overclockout
                                if (item.clockoutstatus === 'Over - ClockOut') {
                                    finalresult[existingEntryIndex].clockoutstatus++;
                                }

                                // automisclockout
                                if (item.clockoutstatus === 'Auto Mis - ClockOut') {
                                    finalresult[existingEntryIndex].clockoutstatus++;
                                }

                                // shiftnotstarted
                                if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // nostatus
                                if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
                                    finalresult[existingEntryIndex].nostatus++;
                                }

                                // notallotted
                                if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // weekoffpresent
                                if (item.weekoffpresentstatus === true) {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // longleave and longabsent
                                if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // blabsent
                                if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // doubledayabsent
                                if (item.lopcalculation?.includes("Double")) {
                                    finalresult[existingEntryIndex].lopcalculation++;
                                }

                                // weekoffabsent
                                if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
                                    finalresult[existingEntryIndex].clockinstatus++;
                                }

                                // Double Day Lop
                                if (item.lopcalculation === 'Yes - Double Day') {
                                    finalresult[existingEntryIndex].doublelopcount++;
                                }

                                // Double Half Day
                                if (item.lopcalculation === 'Yes - Double Half Day') {
                                    finalresult[existingEntryIndex].doublehalflopcount++;
                                }

                                // finalresult[existingEntryIndex].lopcount = String(parseFloat(finalresult[existingEntryIndex].lopcount) + parseFloat(item.lopcount));
                                // finalresult[existingEntryIndex].paidpresentday = String(parseFloat(finalresult[existingEntryIndex].paidpresentday) + parseFloat(item.paidpresentday));

                            } else {

                                const inAndOutArray = [...totalinArray, ...totaloutArray];

                                totalpendingArray = totalemployeesArray.filter(emp =>
                                    !inAndOutArray.some(io => io.username === emp.username)
                                );

                                const newItem = {
                                    id: item.id,
                                    empcode: item.empcode,
                                    username: item.username,
                                    company: item.company,
                                    branch: item.branch,
                                    unit: item.unit,
                                    team: item.team,
                                    department: item.department,
                                    totalnumberofdays: item.totalnumberofdays,
                                    empshiftdays: item.empshiftdays,
                                    shift: item.shift !== 'Not Allotted' ? 1 : 0,
                                    totalcounttillcurrendate: item.totalcounttillcurrendate,
                                    totalshift: item.totalshift,
                                    totalpaiddays: 0,

                                    // table count starts
                                    date: item.rowformattedDate,
                                    totalemployees: item.username !== '' ? 1 : 0,
                                    totalcurrentshift: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') ? 1 : 0,
                                    paidpresentday: item.paidpresentbefore === 'Yes' ? 1 : 0,
                                    lopcount: item.lop === 'Yes' ? 1 : 0,
                                    totalin: (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) ? 1 : 0,
                                    totalout: (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') ? 1 : 0,
                                    totalpending: 0,
                                    facilitypresent: (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
                                    wfhpresent: (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
                                    facilityabsent: (item.workmode !== 'Remote' && item.lop === 'Yes') ? 1 : 0,
                                    wfhabsent: (item.workmode === 'Remote' && item.lop === 'Yes') ? 1 : 0,
                                    earlyclockin: item.clockinstatus?.includes('Early - ClockIn') ? 1 : 0,
                                    onpresent: item.clockinstatus === 'On - Present' ? 1 : 0,
                                    graceclockin: item.clockinstatus === 'Grace - ClockIn' ? 1 : 0,
                                    lateclockin: item.clockinstatus?.includes('Late - ClockIn') ? 1 : 0,
                                    earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
                                    weekoff: weekoffdayscount,
                                    holidayCount: holidaydayscount,
                                    permissionCount: permissionOnDateApproved ? 1 : 0,
                                    leaveCount: leaveOnDateApproved ? 1 : 0,
                                    onclockout: item.clockoutstatus === 'On - ClockOut' ? 1 : 0,
                                    earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
                                    overclockout: item.clockoutstatus === 'Over - ClockOut' ? 1 : 0,
                                    autoclockout: item.clockoutstatus === 'Auto Mis - ClockOut' ? 1 : 0,
                                    shiftnotstarted: (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') ? 1 : 0,
                                    nostatus: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.paidpresent === 'No' && item.modetarget === 'No' && item.lopcalculation === 'No') ? 1 : 0,
                                    notallotted: (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') ? 1 : 0,
                                    weekoffpresent: item.weekoffpresentstatus === true ? 1 : 0,
                                    longleaveabsent: (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) ? 1 : 0,
                                    blabsent: (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') ? 1 : 0,
                                    doubledayabsent: item.lopcalculation?.includes("Double") ? 1 : 0,
                                    weekoffabsent: (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) ? 1 : 0,
                                    doublelopcount: item.lopcalculation === "Yes - Double Day" ? 1 : 0,
                                    doublehalflopcount: item.lopcalculation === "Double Half Day" ? 0.5 : 0,
                                    totalemployeesArray,
                                    totalcurrentshiftArray,
                                    paidpresentdayArray,
                                    absentArray,
                                    totalinArray,
                                    totaloutArray,
                                    totalpendingArray,
                                    facilitypresentArray,
                                    wfhpresentArray,
                                    facilityabsentArray,
                                    wfhabsentArray,
                                    earlyclockinArray,
                                    onpresentArray,
                                    graceclockinArray,
                                    lateclockinArray,
                                    weekoffArray,
                                    holidayArray,
                                    permissionArray,
                                    clslArray,
                                    onclockoutArray,
                                    earlyclockoutArray,
                                    overclockoutArray,
                                    autoclockoutArray,
                                    shiftnotstartedArray,
                                    nostatusArray,
                                    notallottedArray,
                                    weekoffpresentArray,
                                    longleaveabsentArray,
                                    blabsentArray,
                                    doubledayabsentArray,
                                    weekoffabsentArray,
                                };
                                // console.log(newItem, 'newitem')
                                finalresult.push(newItem);
                            }
                        });
                        // console.log(finalresult, ' fianlresult')

                        let resultdata = finalresult?.map((item, index) => {
                            const finalPaidPresentDays = Number(item.paidpresentday) - (Number(item.weekoff) + Number(item.holidayCount) + Number(item.leaveCount) + Number(item.doublelopcount) + Number(item.doublehalflopcount));

                            return {
                                ...item,
                                totalemployees: Number(item.totalemployees),
                                lopcount: Number(item.lopcount),
                                clsl: item.leaveCount,
                                paidpresentday: finalPaidPresentDays < 0 ? 0 : finalPaidPresentDays,
                            };
                        });
                        // console.log(resultdata, ' resultdata')

                        let groupedResult = [];

                        // if (['Company', 'Branch', 'Unit', 'Team'].includes(filterUser.filtertype)) {
                        groupedResult = resultdata.reduce((acc, curr, index) => {
                            let groupKey = '';

                            if (curr.team === isUserRoleAccess.team) {
                                groupKey = `${curr.company}-${curr.branch}-${curr.unit}-${curr.team}`;
                            }

                            // Calculate totalpending based on match with group values
                            const matchingPending = totalpendingArray.filter((data) => data.company === curr.company && data.branch === curr.branch && data.unit === curr.unit && data.team === curr.team);

                            if (!acc[groupKey]) {
                                acc[groupKey] = {
                                    id: `${index + 1}_${groupKey}`,
                                    company: curr.company,
                                    branch: curr.branch,
                                    unit: curr.unit,
                                    team: curr.team,
                                    date: curr.date,
                                    totalemployeesArray,
                                    totalcurrentshiftArray,
                                    paidpresentdayArray,
                                    absentArray,
                                    totalinArray,
                                    totaloutArray,
                                    totalpendingArray,
                                    facilitypresentArray,
                                    wfhpresentArray,
                                    facilityabsentArray,
                                    wfhabsentArray,
                                    earlyclockinArray,
                                    onpresentArray,
                                    graceclockinArray,
                                    lateclockinArray,
                                    weekoffArray,
                                    holidayArray,
                                    permissionArray,
                                    clslArray,
                                    onclockoutArray,
                                    earlyclockoutArray,
                                    overclockoutArray,
                                    autoclockoutArray,
                                    shiftnotstartedArray,
                                    nostatusArray,
                                    notallottedArray,
                                    weekoffpresentArray,
                                    longleaveabsentArray,
                                    blabsentArray,
                                    doubledayabsentArray,
                                    weekoffabsentArray,
                                    totalemployees: 0,
                                    totalcurrentshift: 0,
                                    paidpresentday: 0,
                                    lopcount: 0,
                                    totalin: 0,
                                    totalout: 0,
                                    totalpending: matchingPending?.length,
                                    facilitypresent: 0,
                                    wfhpresent: 0,
                                    facilityabsent: 0,
                                    wfhabsent: 0,
                                    earlyclockin: 0,
                                    onpresent: 0,
                                    graceclockin: 0,
                                    lateclockin: 0,
                                    weekoff: 0,
                                    holidayCount: 0,
                                    permissionCount: 0,
                                    clsl: 0,
                                    onclockout: 0,
                                    earlyclockout: 0,
                                    overclockout: 0,
                                    autoclockout: 0,
                                    shiftnotstarted: 0,
                                    nostatus: 0,
                                    notallotted: 0,
                                    weekoffpresent: 0,
                                    longleaveabsent: 0,
                                    blabsent: 0,
                                    doubledayabsent: 0,
                                    weekoffabsent: 0,
                                };
                            }

                            acc[groupKey].totalemployees += Number(curr.totalemployees);
                            acc[groupKey].totalcurrentshift += Number(curr.totalcurrentshift);
                            acc[groupKey].paidpresentday += Number(curr.paidpresentday);
                            acc[groupKey].lopcount += Number(curr.lopcount);
                            acc[groupKey].totalin += Number(curr.totalin);
                            acc[groupKey].totalout += Number(curr.totalout);
                            acc[groupKey].totalpending = matchingPending.length;
                            acc[groupKey].facilitypresent += Number(curr.facilitypresent);
                            acc[groupKey].wfhpresent += Number(curr.wfhpresent);
                            acc[groupKey].facilityabsent += Number(curr.facilityabsent);
                            acc[groupKey].wfhabsent += Number(curr.wfhabsent);
                            acc[groupKey].earlyclockin += Number(curr.earlyclockin);
                            acc[groupKey].onpresent += Number(curr.onpresent);
                            acc[groupKey].graceclockin += Number(curr.graceclockin);
                            acc[groupKey].lateclockin += Number(curr.lateclockin);
                            acc[groupKey].weekoff += Number(curr.weekoff);
                            acc[groupKey].holidayCount += Number(curr.holidayCount);
                            acc[groupKey].permissionCount += Number(curr.permissionCount);
                            acc[groupKey].clsl += Number(curr.clsl);
                            acc[groupKey].onclockout += Number(curr.onclockout);
                            acc[groupKey].earlyclockout += Number(curr.earlyclockout);
                            acc[groupKey].overclockout += Number(curr.overclockout);
                            acc[groupKey].autoclockout += Number(curr.autoclockout);
                            acc[groupKey].shiftnotstarted += Number(curr.shiftnotstarted);
                            acc[groupKey].nostatus += Number(curr.nostatus);
                            acc[groupKey].notallotted += Number(curr.notallotted);
                            acc[groupKey].weekoffpresent += Number(curr.weekoffpresent);
                            acc[groupKey].longleaveabsent += Number(curr.longleaveabsent);
                            acc[groupKey].blabsent += Number(curr.blabsent);
                            acc[groupKey].doubledayabsent += Number(curr.doubledayabsent);
                            acc[groupKey].weekoffabsent += Number(curr.weekoffabsent);

                            return acc;
                        }, {});

                        // Convert grouped object back to array
                        groupedResult = Object.values(groupedResult).map((item, index) => ({ ...item, serialNumber: index + 1 }));
                        // }
                        // console.log(groupedResult);

                        setUserShiftsUserShiftSummary(groupedResult);
                        setSearchQueryUserShiftSummary('');
                        setLoader(false);
                        setTotalPagesUserShiftSummary(Math.ceil(groupedResult.length / pageSizeUserShiftSummary));
                    })
                    .catch((error) => {
                        setLoader(true);
                        console.error('Error in getting all results:', error);
                    });
            }

            if (filterUser.attmode === 'Attendance Summary Report - Hierarchy') {
                getAllResults().then(async (results) => {
                    // console.log(results.allResults, 'results.allResults')
                    const finalresult = [];
                    let totalemployeesArray = [];
                    let totalcurrentshiftArray = [];
                    let paidpresentdayArray = [];
                    let absentArray = [];
                    let totalinArray = [];
                    let totaloutArray = [];
                    let totalpendingArray = [];
                    let facilitypresentArray = [];
                    let wfhpresentArray = [];
                    let facilityabsentArray = [];
                    let wfhabsentArray = [];
                    let earlyclockinArray = [];
                    let onpresentArray = [];
                    let graceclockinArray = [];
                    let lateclockinArray = [];
                    let weekoffArray = [];
                    let holidayArray = [];
                    let permissionArray = [];
                    let clslArray = [];
                    let onclockoutArray = [];
                    let earlyclockoutArray = [];
                    let overclockoutArray = [];
                    let autoclockoutArray = [];
                    let shiftnotstartedArray = [];
                    let nostatusArray = [];
                    let notallottedArray = [];
                    let weekoffpresentArray = [];
                    let longleaveabsentArray = [];
                    let blabsentArray = [];
                    let doubledayabsentArray = [];
                    let weekoffabsentArray = [];

                    const uniqueUsers = results.allResults.filter(
                        (user, index, self) =>
                            index === self.findIndex(u =>
                                u.rowusername === user.rowusername && u.empcode === user.empcode
                            )
                    );

                    uniqueUsers?.forEach(item => {
                        // console.log(item, 'item')
                        const leaveOnDateApproved = leaveresult.find((d) => d.date === item.rowformattedDate && d.empcode === item.empcode);
                        const permissionOnDateApproved = permissionresult.find((d) => d.date === item.finalDate && d.employeeid === item.empcode);
                        const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

                        // employee
                        if (item.username !== '') {
                            totalemployeesArray.push(item);
                        }

                        // current shift
                        if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
                            totalcurrentshiftArray.push(item);
                        }

                        // present
                        if (item.isweekoff !== 'Yes' && item.isholiday !== 'Yes' && !leaveOnDateApproved && (item.paidpresent === 'Yes - Full Day' || item.paidpresent === 'Yes - Half Day')) {
                            paidpresentdayArray.push(item);
                        }

                        // absent
                        if (item.lopcalculation === 'Yes - Full Day' || item.lopcalculation === 'Yes - Half Day' || item.lopcalculation === 'Yes - Double Day' || item.lopcalculation === 'Yes - Double Half Day') {
                            absentArray.push(item);
                        }

                        // totalin
                        if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
                            totalinArray.push(item);
                        }

                        // totalout
                        if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
                            totaloutArray.push(item);
                        }

                        // facilitypresent
                        if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
                            facilitypresentArray.push(item);
                        }

                        // wfhpresent
                        if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
                            wfhpresentArray.push(item);
                        }

                        // facilityabsent
                        if (item.workmode !== 'Remote' && item.lop === 'Yes') {
                            facilityabsentArray.push(item);
                        }

                        // wfhabsent
                        if (item.workmode === 'Remote' && item.lop === 'Yes') {
                            wfhabsentArray.push(item);
                        }

                        // earlyclockin
                        if (item.clockinstatus?.includes('Early - ClockIn')) {
                            earlyclockinArray.push(item);
                        }

                        // onpresent
                        if (item.clockinstatus === 'On - Present') {
                            onpresentArray.push(item);
                        }

                        // gracetime
                        if (item.clockinstatus === 'Grace - ClockIn') {
                            graceclockinArray.push(item);
                        }

                        // lateclockin
                        if (item.clockinstatus?.includes('Late - ClockIn')) {
                            lateclockinArray.push(item);
                        }

                        // weekoff
                        let weekoffdayscount = 0;
                        if (item.isweekoff === 'Yes') {
                            weekoffdayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                            weekoffArray.push(item);
                        }

                        // holiday
                        let holidaydayscount = 0;
                        if (item.isholiday === 'Yes') {
                            holidaydayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
                            holidayArray.push(item);
                        }

                        // permission
                        if (permissionOnDateApproved) {
                            permissionArray.push(item);
                        }

                        // clsl
                        if (leaveOnDateApproved) {
                            clslArray.push(item);
                        }

                        // onclockout
                        if (item.clockoutstatus === 'On - ClockOut') {
                            onclockoutArray.push(item);
                        }

                        // earlyclockout
                        if (item.clockoutstatus?.includes('Early - ClockOut')) {
                            earlyclockoutArray.push(item);
                        }

                        // overclockout
                        if (item.clockoutstatus === 'Over - ClockOut') {
                            overclockoutArray.push(item);
                        }

                        // automisclockout
                        if (item.clockoutstatus === 'Auto Mis - ClockOut') {
                            autoclockoutArray.push(item);
                        }

                        // shiftnotstarted
                        if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
                            shiftnotstartedArray.push(item);
                        }

                        // nostatus
                        if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
                            nostatusArray.push(item);
                        }

                        // notallotted
                        if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
                            notallottedArray.push(item);
                        }

                        // weekoffpresent
                        if (item.weekoffpresentstatus === true) {
                            weekoffpresentArray.push(item);
                        }

                        // longleave and longabsent
                        if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
                            longleaveabsentArray.push(item);
                        }

                        // blabsent
                        if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
                            blabsentArray.push(item);
                        }

                        // doubledayabsent
                        if (item.lopcalculation?.includes("Double")) {
                            doubledayabsentArray.push(item);
                        }

                        // weekoffabsent
                        if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
                            weekoffabsentArray.push(item);
                        }

                        const existingEntryIndex = finalresult.findIndex(entry => entry.empcode === item.empcode);

                        if (existingEntryIndex !== -1) {

                            // employee
                            if (item.username !== '') {
                                finalresult[existingEntryIndex].username++;
                            }

                            // current shift
                            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // present
                            if (item.paidpresentbefore === 'Yes') {
                                finalresult[existingEntryIndex].paidpresentday++;
                            }

                            // absent
                            if (item.lop === 'Yes') {
                                finalresult[existingEntryIndex].lopcount++;
                            }

                            // totalin
                            if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
                                finalresult[existingEntryIndex].clockin++;
                            }

                            // totalout
                            if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
                                finalresult[existingEntryIndex].clockout++;
                            }

                            // facilitypresent
                            if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
                                finalresult[existingEntryIndex].workmode++;
                            }

                            // wfhpresent
                            if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
                                finalresult[existingEntryIndex].workmode++;
                            }

                            // facilityabsent
                            if (item.workmode !== 'Remote' && item.lop === 'Yes') {
                                finalresult[existingEntryIndex].workmode++;
                            }

                            // wfhabsent
                            if (item.workmode === 'Remote' && item.lop === 'Yes') {
                                finalresult[existingEntryIndex].workmode++;
                            }

                            // earlyclockin
                            if (item.clockinstatus?.includes('Early - ClockIn')) {
                                finalresult[existingEntryIndex].clockin++;
                            }

                            // onpresent
                            if (item.clockinstatus === 'On - Present') {
                                finalresult[existingEntryIndex].clockin++;
                            }

                            // gracetime
                            if (item.clockinstatus === 'Grace - ClockIn') {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // lateclockin
                            if (item.clockinstatus?.includes('Late - ClockIn')) {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // weekoff
                            if (item.isweekoff === 'Yes') {
                                finalresult[existingEntryIndex].weekoff++;
                            }

                            // holiday
                            if (item.isholiday === 'Yes') {
                                finalresult[existingEntryIndex].holidayCount++;
                            }

                            // permission
                            if (permissionOnDateApproved) {
                                finalresult[existingEntryIndex].permissionCount++;
                            }

                            // clsl
                            if (leaveOnDateApproved) {
                                finalresult[existingEntryIndex].leaveCount++;
                            }

                            // shift
                            if (item.shift !== 'Not Allotted') {
                                finalresult[existingEntryIndex].shift++;
                            }

                            // onclockout
                            if (item.clockoutstatus === 'On - ClockOut') {
                                finalresult[existingEntryIndex].clockoutstatus++;
                            }

                            // earlyclockout
                            if (item.clockoutstatus?.includes('Early - ClockOut')) {
                                finalresult[existingEntryIndex].clockoutstatus++;
                            }

                            // overclockout
                            if (item.clockoutstatus === 'Over - ClockOut') {
                                finalresult[existingEntryIndex].clockoutstatus++;
                            }

                            // automisclockout
                            if (item.clockoutstatus === 'Auto Mis - ClockOut') {
                                finalresult[existingEntryIndex].clockoutstatus++;
                            }

                            // shiftnotstarted
                            if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // nostatus
                            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
                                finalresult[existingEntryIndex].nostatus++;
                            }

                            // notallotted
                            if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // weekoffpresent
                            if (item.weekoffpresentstatus === true) {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // longleave and longabsent
                            if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // blabsent
                            if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // doubledayabsent
                            if (item.lopcalculation?.includes("Double")) {
                                finalresult[existingEntryIndex].lopcalculation++;
                            }

                            // weekoffabsent
                            if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
                                finalresult[existingEntryIndex].clockinstatus++;
                            }

                            // Double Day Lop
                            if (item.lopcalculation === 'Yes - Double Day') {
                                finalresult[existingEntryIndex].doublelopcount++;
                            }

                            // Double Half Day
                            if (item.lopcalculation === 'Yes - Double Half Day') {
                                finalresult[existingEntryIndex].doublehalflopcount++;
                            }

                            // finalresult[existingEntryIndex].lopcount = String(parseFloat(finalresult[existingEntryIndex].lopcount) + parseFloat(item.lopcount));
                            // finalresult[existingEntryIndex].paidpresentday = String(parseFloat(finalresult[existingEntryIndex].paidpresentday) + parseFloat(item.paidpresentday));

                        } else {

                            const inAndOutArray = [...totalinArray, ...totaloutArray];

                            totalpendingArray = totalemployeesArray.filter(emp =>
                                !inAndOutArray.some(io => io.username === emp.username)
                            );

                            const newItem = {
                                id: item.id,
                                empcode: item.empcode,
                                username: item.username,
                                company: item.company,
                                branch: item.branch,
                                unit: item.unit,
                                team: item.team,
                                department: item.department,
                                totalnumberofdays: item.totalnumberofdays,
                                empshiftdays: item.empshiftdays,
                                shift: item.shift !== 'Not Allotted' ? 1 : 0,
                                totalcounttillcurrendate: item.totalcounttillcurrendate,
                                totalshift: item.totalshift,
                                totalpaiddays: 0,

                                // table count starts
                                date: item.rowformattedDate,
                                totalemployees: item.username !== '' ? 1 : 0,
                                totalcurrentshift: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') ? 1 : 0,
                                paidpresentday: item.paidpresentbefore === 'Yes' ? 1 : 0,
                                lopcount: item.lop === 'Yes' ? 1 : 0,
                                totalin: (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) ? 1 : 0,
                                totalout: (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') ? 1 : 0,
                                totalpending: 0,
                                facilitypresent: (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
                                wfhpresent: (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
                                facilityabsent: (item.workmode !== 'Remote' && item.lop === 'Yes') ? 1 : 0,
                                wfhabsent: (item.workmode === 'Remote' && item.lop === 'Yes') ? 1 : 0,
                                earlyclockin: item.clockinstatus?.includes('Early - ClockIn') ? 1 : 0,
                                onpresent: item.clockinstatus === 'On - Present' ? 1 : 0,
                                graceclockin: item.clockinstatus === 'Grace - ClockIn' ? 1 : 0,
                                lateclockin: item.clockinstatus?.includes('Late - ClockIn') ? 1 : 0,
                                earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
                                weekoff: weekoffdayscount,
                                holidayCount: holidaydayscount,
                                permissionCount: permissionOnDateApproved ? 1 : 0,
                                leaveCount: leaveOnDateApproved ? 1 : 0,
                                onclockout: item.clockoutstatus === 'On - ClockOut' ? 1 : 0,
                                earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
                                overclockout: item.clockoutstatus === 'Over - ClockOut' ? 1 : 0,
                                autoclockout: item.clockoutstatus === 'Auto Mis - ClockOut' ? 1 : 0,
                                shiftnotstarted: (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') ? 1 : 0,
                                nostatus: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.paidpresent === 'No' && item.modetarget === 'No' && item.lopcalculation === 'No') ? 1 : 0,
                                notallotted: (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') ? 1 : 0,
                                weekoffpresent: item.weekoffpresentstatus === true ? 1 : 0,
                                longleaveabsent: (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) ? 1 : 0,
                                blabsent: (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') ? 1 : 0,
                                doubledayabsent: item.lopcalculation?.includes("Double") ? 1 : 0,
                                weekoffabsent: (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) ? 1 : 0,
                                doublelopcount: item.lopcalculation === "Yes - Double Day" ? 1 : 0,
                                doublehalflopcount: item.lopcalculation === "Double Half Day" ? 0.5 : 0,
                                totalemployeesArray,
                                totalcurrentshiftArray,
                                paidpresentdayArray,
                                absentArray,
                                totalinArray,
                                totaloutArray,
                                totalpendingArray,
                                facilitypresentArray,
                                wfhpresentArray,
                                facilityabsentArray,
                                wfhabsentArray,
                                earlyclockinArray,
                                onpresentArray,
                                graceclockinArray,
                                lateclockinArray,
                                weekoffArray,
                                holidayArray,
                                permissionArray,
                                clslArray,
                                onclockoutArray,
                                earlyclockoutArray,
                                overclockoutArray,
                                autoclockoutArray,
                                shiftnotstartedArray,
                                nostatusArray,
                                notallottedArray,
                                weekoffpresentArray,
                                longleaveabsentArray,
                                blabsentArray,
                                doubledayabsentArray,
                                weekoffabsentArray,
                            };
                            // console.log(newItem, 'newitem')
                            finalresult.push(newItem);
                        }
                    });
                    // console.log(finalresult, ' fianlresult')

                    let resultdata = finalresult?.map((item, index) => {
                        const finalPaidPresentDays = Number(item.paidpresentday) - (Number(item.weekoff) + Number(item.holidayCount) + Number(item.leaveCount) + Number(item.doublelopcount) + Number(item.doublehalflopcount));

                        return {
                            ...item,
                            totalemployees: Number(item.totalemployees),
                            lopcount: Number(item.lopcount),
                            clsl: item.leaveCount,
                            paidpresentday: finalPaidPresentDays < 0 ? 0 : finalPaidPresentDays,
                        }
                    });
                    // console.log(resultdata, ' resultdata')

                    let groupedResult = [];

                    groupedResult = resultdata.reduce((acc, curr, index) => {
                        let groupKey = `${curr.date}`;

                        // Calculate totalpending based on match with group values
                        const matchingPending = totalpendingArray.filter(data => data.rowformattedDate === curr.date);

                        if (!acc[groupKey]) {
                            acc[groupKey] = {
                                id: `${index + 1}_${groupKey}`,
                                company: curr.company,
                                branch: curr.branch,
                                unit: curr.unit,
                                team: curr.team,
                                date: curr.date,
                                totalemployeesArray,
                                totalcurrentshiftArray,
                                paidpresentdayArray,
                                absentArray,
                                totalinArray,
                                totaloutArray,
                                totalpendingArray,
                                facilitypresentArray,
                                wfhpresentArray,
                                facilityabsentArray,
                                wfhabsentArray,
                                earlyclockinArray,
                                onpresentArray,
                                graceclockinArray,
                                lateclockinArray,
                                weekoffArray,
                                holidayArray,
                                permissionArray,
                                clslArray,
                                onclockoutArray,
                                earlyclockoutArray,
                                overclockoutArray,
                                autoclockoutArray,
                                shiftnotstartedArray,
                                nostatusArray,
                                notallottedArray,
                                weekoffpresentArray,
                                longleaveabsentArray,
                                blabsentArray,
                                doubledayabsentArray,
                                weekoffabsentArray,
                                totalemployees: 0,
                                totalcurrentshift: 0,
                                paidpresentday: 0,
                                lopcount: 0,
                                totalin: 0,
                                totalout: 0,
                                totalpending: matchingPending?.length,
                                facilitypresent: 0,
                                wfhpresent: 0,
                                facilityabsent: 0,
                                wfhabsent: 0,
                                earlyclockin: 0,
                                onpresent: 0,
                                graceclockin: 0,
                                lateclockin: 0,
                                weekoff: 0,
                                holidayCount: 0,
                                permissionCount: 0,
                                clsl: 0,
                                onclockout: 0,
                                earlyclockout: 0,
                                overclockout: 0,
                                autoclockout: 0,
                                shiftnotstarted: 0,
                                nostatus: 0,
                                notallotted: 0,
                                weekoffpresent: 0,
                                longleaveabsent: 0,
                                blabsent: 0,
                                doubledayabsent: 0,
                                weekoffabsent: 0,
                            };
                        }

                        acc[groupKey].totalemployees += Number(curr.totalemployees);
                        acc[groupKey].totalcurrentshift += Number(curr.totalcurrentshift);
                        acc[groupKey].paidpresentday += Number(curr.paidpresentday);
                        acc[groupKey].lopcount += Number(curr.lopcount);
                        acc[groupKey].totalin += Number(curr.totalin);
                        acc[groupKey].totalout += Number(curr.totalout);
                        acc[groupKey].totalpending = matchingPending.length;
                        acc[groupKey].facilitypresent += Number(curr.facilitypresent);
                        acc[groupKey].wfhpresent += Number(curr.wfhpresent);
                        acc[groupKey].facilityabsent += Number(curr.facilityabsent);
                        acc[groupKey].wfhabsent += Number(curr.wfhabsent);
                        acc[groupKey].earlyclockin += Number(curr.earlyclockin);
                        acc[groupKey].onpresent += Number(curr.onpresent);
                        acc[groupKey].graceclockin += Number(curr.graceclockin);
                        acc[groupKey].lateclockin += Number(curr.lateclockin);
                        acc[groupKey].weekoff += Number(curr.weekoff);
                        acc[groupKey].holidayCount += Number(curr.holidayCount);
                        acc[groupKey].permissionCount += Number(curr.permissionCount);
                        acc[groupKey].clsl += Number(curr.clsl);
                        acc[groupKey].onclockout += Number(curr.onclockout);
                        acc[groupKey].earlyclockout += Number(curr.earlyclockout);
                        acc[groupKey].overclockout += Number(curr.overclockout);
                        acc[groupKey].autoclockout += Number(curr.autoclockout);
                        acc[groupKey].shiftnotstarted += Number(curr.shiftnotstarted);
                        acc[groupKey].nostatus += Number(curr.nostatus);
                        acc[groupKey].notallotted += Number(curr.notallotted);
                        acc[groupKey].weekoffpresent += Number(curr.weekoffpresent);
                        acc[groupKey].longleaveabsent += Number(curr.longleaveabsent);
                        acc[groupKey].blabsent += Number(curr.blabsent);
                        acc[groupKey].doubledayabsent += Number(curr.doubledayabsent);
                        acc[groupKey].weekoffabsent += Number(curr.weekoffabsent);

                        return acc;
                    }, {});

                    // Convert grouped object back to array
                    groupedResult = Object.values(groupedResult).map((item, index) => ({ ...item, serialNumber: index + 1 }));

                    // console.log(groupedResult);

                    setUserShiftsUserShiftSummaryHier(groupedResult);
                    setSearchQueryUserShiftSummaryHier("");
                    setLoader(false);
                    setTotalPagesUserShiftSummaryHier(Math.ceil(groupedResult.length / pageSizeUserShiftSummaryHier));
                }).catch(error => {
                    setLoader(true);
                    console.error('Error in getting all results:', error);
                });
            }

        } catch (err) {
            setLoader(true);
            handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    const fetchOverAllSettings = async () => {
        try {
            let res = await axios.get(`${SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            setAttSettings(
                res?.data?.attendancecontrolcriteria[
                res?.data?.attendancecontrolcriteria?.length - 1
                ]
            );
        } catch (err) {
            handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    useEffect(() => {
        fetchOverAllSettings();
    }, []);

    const handleSubmit = (e) => {
        e.preventDefault();

        if (filterUser.attmode === 'Please Select Attendance Mode') {
            setPopupContentMalert("Please Select Attendance Mode");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else if (filterUser.fromdate === "") {
            setPopupContentMalert("Please Select From Date");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else if ((filterUser.attmode !== 'Attendance Summary Report' || filterUser.attmode !== 'Attendance Summary Report - Hierarchy') && filterUser.todate === "") {
            setPopupContentMalert("Please Select To Date");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else if (filterUser.attmode === 'Attendance Review' && selectedOptionsStatus.length === 0) {
            setPopupContentMalert("Please Select Attendance Status");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else {
            setUserShifts([]);
            setItems([]);
            setUserShiftsAttDay([]);
            setItemsAttDay([]);
            setUserShiftsAttShort([]);
            setUserShiftsAttMonth([]);
            setUserShiftsAttReview([]);
            setUserShiftsAttReport([]);
            setUserShiftsUserShiftSummary([]);
            setUserShiftsUserShiftSummaryHier([]);
            fetchFilteredUsersStatus();
        }
    };

    const handleClear = async (e) => {
        e.preventDefault();
        setLoader(false);
        setFilterUser({
            attmode: "Please Select Attendance Mode",
            mode: "My Hierarchy List",
            level: "Primary",
            fromdate: today,
            todate: today,
            listpageaccessmode: listpageaccessby,
        });
        setSelectedMode("Today");
        setUserShifts([]);
        setItems([]);
        setUserShiftsAttDay([]);
        setItemsAttDay([]);
        setUserShiftsAttShort([]);
        setUserShiftsAttMonth([]);
        setUserShiftsAttReview([]);
        setUserShiftsAttReport([]);
        setUserShiftsUserShiftSummary([]);
        setUserShiftsUserShiftSummaryHier([]);
        setPageAttTeam(1);
        // fetchClearFilteredUsersStatus();
        setPopupContent("Cleared Successfully");
        setPopupSeverity("success");
        handleClickOpenPopup();
    };

    //serial no for listing items
    const addSerialNumber = async (datas) => {
        setItems(datas);
    };

    useEffect(() => {
        addSerialNumber(userShifts);
    }, [userShifts]);

    //serial no for listing items
    const addSerialNumberAttDay = async (datas) => {
        setItemsAttDay(datas);
    };

    useEffect(() => {
        addSerialNumberAttDay(userShiftsAttDay);
    }, [userShiftsAttDay]);

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ["apply", "reset", "cancel"],
            },
        };
    }, []);

    const onGridReady = useCallback((params) => {
        setGridApi(params.api);
        setColumnApi(params.columnApi);
    }, []);

    // Function to handle filter changes
    const onFilterChanged = () => {
        if (gridApi) {
            const filterModel = gridApi.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowData([]);
            } else {
                // Filters are active, capture filtered data
                const filteredData = [];
                gridApi.forEachNodeAfterFilterAndSort((node) => {
                    filteredData.push(node.data); // Collect filtered row data
                });
                setFilteredRowData(filteredData);
            }
        }
    };

    const onPaginationChanged = useCallback(() => {
        if (gridRefTableAttTeam.current) {
            const gridApi = gridRefTableAttTeam.current.api;
            const currentPage = gridApi.paginationGetCurrentPage() + 1;
            const totalPagesAttTeam = gridApi.paginationGetTotalPages();
            setPageAttTeam(currentPage);
            setTotalPagesAttTeam(totalPagesAttTeam);
        }
    }, []);

    const columnDataTable = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibility.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibility.empcode, pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibility.username, pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibility.company, },
        { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibility.branch, },
        { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibility.unit, },
        { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibility.team, },
        { field: "department", headerName: "Department", flex: 0, width: 130, hide: !columnVisibility.department, },
        { field: "date", headerName: "Date", flex: 0, width: 110, hide: !columnVisibility.date, },
        { field: "shiftmode", headerName: "Shift Mode", flex: 0, width: 110, hide: !columnVisibility.shiftmode, },
        { field: "shift", headerName: "Shift", flex: 0, width: 150, hide: !columnVisibility.shift, },
        { field: "changeshift", headerName: "Change Shift", flex: 0, width: 150, hide: !columnVisibility.changeshift, },
        { field: "leavestatus", headerName: "Leave Status", flex: 0, width: 150, hide: !columnVisibility.leavestatus, },
        { field: "permissionstatus", headerName: "Permission Status", flex: 0, width: 150, hide: !columnVisibility.permissionstatus, },
        { field: "clockin", headerName: "ClockIn", flex: 0, width: 120, hide: !columnVisibility.clockin, },
        {
            field: "clockinstatus", headerName: "ClockInStatus", flex: 0, width: 200, hide: !columnVisibility.clockinstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                                backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                                '&:hover': {
                                    color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                                    backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                                }
                            }}
                        >
                            {params.data.clockinstatus}
                        </Button>
                    </Grid >
                );
            },
        },
        { field: "clockout", headerName: "ClockOut", flex: 0, width: 120, hide: !columnVisibility.clockout, },
        {
            field: "clockoutstatus", headerName: "ClockOutStatus", flex: 0, width: 200, hide: !columnVisibility.clockoutstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                                backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                                '&:hover': {
                                    color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                                    backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                                }
                            }}
                        >
                            {params.data.clockoutstatus}
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "attendanceauto", headerName: "Attendance", flex: 0, width: 200, hide: !columnVisibility.attendanceauto,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                    backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                }
                            }}
                        >
                            {params.data.attendanceauto}
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "daystatus", headerName: "Day Status", flex: 0, width: 200, hide: !columnVisibility.daystatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                                backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                                    backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                }
                            }}
                        >
                            {params.data.daystatus}
                        </Button>
                    </Grid >
                );
            },
        },
        { field: "appliedthrough", headerName: "Applied Through", flex: 0, width: 120, hide: !columnVisibility.appliedthrough, },
        { field: "isweekoff", headerName: "Is Week Off", flex: 0, width: 120, hide: !columnVisibility.isweekoff, },
        { field: "isholiday", headerName: "Is Holiday", flex: 0, width: 120, hide: !columnVisibility.isholiday, },
        { field: "lopcalculation", headerName: "LOP Calculation", flex: 0, width: 120, hide: !columnVisibility.lopcalculation, },
        { field: "modetarget", headerName: "Target", flex: 0, width: 120, hide: !columnVisibility.modetarget, },
        { field: "paidpresent", headerName: "Paid Present", flex: 0, width: 120, hide: !columnVisibility.paidpresent, },
        { field: "lopday", headerName: "LOP Day", flex: 0, width: 120, hide: !columnVisibility.lopday, },
        { field: "paidpresentday", headerName: "Paid Present Day", flex: 0, width: 120, hide: !columnVisibility.paidpresentday, },
    ];

    const columnDataTableAttDay = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityAttDay.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityAttDay.empcode, pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityAttDay.username, pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 150, hide: !columnVisibilityAttDay.company, },
        { field: "branch", headerName: "Branch", flex: 0, width: 150, hide: !columnVisibilityAttDay.branch, },
        { field: "unit", headerName: "Unit", flex: 0, width: 150, hide: !columnVisibilityAttDay.unit, },
        { field: "team", headerName: "Team", flex: 0, width: 150, hide: !columnVisibilityAttDay.team, },
        { field: "department", headerName: "Department", flex: 0, width: 200, hide: !columnVisibilityAttDay.department, },
        { field: "date", headerName: "Date", flex: 0, width: 170, hide: !columnVisibilityAttDay.date, },
        { field: "shiftmode", headerName: "Shift Mode", flex: 0, width: 110, hide: !columnVisibilityAttDay.shiftmode, },
        { field: "shift", headerName: "Shift", flex: 0, width: 170, hide: !columnVisibilityAttDay.shift, },
        { field: "leavestatus", headerName: "Leave Status", flex: 0, width: 150, hide: !columnVisibilityAttDay.leavestatus, },
        { field: "permissionstatus", headerName: "Permission Status", flex: 0, width: 150, hide: !columnVisibilityAttDay.permissionstatus, },
        { field: "shiftworkinghours", headerName: "Shift Working Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttDay.shiftworkinghours, ...headerStyle, },
        { field: "prodstartdate", headerName: "Production Shift Start Date", flex: 0, width: 200, hide: !columnVisibilityAttDay.prodstartdate, ...headerStyle, },
        { field: "prodstarttime", headerName: "Production Shift Start Time", flex: 0, width: 200, hide: !columnVisibilityAttDay.prodstarttime, ...headerStyle, },
        { field: "prodenddate", headerName: "Production Shift End Date", flex: 0, width: 200, hide: !columnVisibilityAttDay.prodenddate, ...headerStyle, },
        { field: "prodendtime", headerName: "Production Shift End Time", flex: 0, width: 200, hide: !columnVisibilityAttDay.prodendtime, ...headerStyle, },
        { field: "clockin", headerName: "Clock In Time", flex: 0, width: 200, hide: !columnVisibilityAttDay.clockin, ...headerStyle, },
        { field: "clockout", headerName: "Clock Out Time", flex: 0, width: 200, hide: !columnVisibilityAttDay.clockout, ...headerStyle, },
        { field: "shiftbeforeothours", headerName: "Shift Before OT Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttDay.shiftbeforeothours, ...headerStyle, },
        { field: "shiftafterothours", headerName: "Shift After OT Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttDay.shiftafterothours, ...headerStyle, },
        { field: "totalothours", headerName: "Total OT Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttDay.totalothours, ...headerStyle, },
    ]

    //Datatable
    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchQueryAttTeam(value);
        applyNormalFilter(value);
        setFilteredRowData([]);
    };

    const applyNormalFilter = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = items?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItems(filtered);
        setPageAttTeam(1);
    };

    const applyAdvancedFilter = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = items?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItems(filtered); // Update filtered data
        setAdvancedFilter(filters);
        // handleCloseSearchAttTeam(); // Close the popover after search
    };

    // Undo filter funtion
    const handleResetSearch = () => {
        setAdvancedFilter(null);
        setSearchQueryAttTeam("");
        setFilteredDataItems(userShifts);
    };

    // Show filtered combination in the search bar
    const getSearchDisplay = () => {
        if (advancedFilter && advancedFilter.length > 0) {
            return advancedFilter.map((filter, index) => {
                let showname = columnDataTable.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilter.length > 1 ? advancedFilter[1].condition : '') + ' ');
        }
        return searchQueryAttTeam;
    };

    const handlePageChange = (newPage) => {
        if (newPage >= 1 && newPage <= totalPagesAttTeam) {
            setPageAttTeam(newPage);
            gridRefTableAttTeam.current.api.paginationGoToPage(newPage - 1);
        }
    };

    const handlePageSizeChange = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttTeam(newSize);
        if (gridApi) {
            gridApi.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumns = () => {
        const updatedVisibility = { ...columnVisibility };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibility(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibility");
        if (savedVisibility) {
            setColumnVisibility(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibility", JSON.stringify(columnVisibility));
    }, [columnVisibility]);

    // Function to filter columns based on search query
    const filteredColumns = columnDataTable?.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManage.toLowerCase())
    );

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibility = (field) => {
        if (!gridApi) return;

        setColumnVisibility((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApi.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMoved = useCallback(debounce((event) => {
        if (!event.columnApi) return;

        const visible_columns = event.columnApi.getAllColumns().filter(col => {
            const colState = event.columnApi.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibility((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisible = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibility((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormat, setFormat] = useState("");
    let exportColumnNamescrt = [
        "Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department",
        "Date", "Shift Mode", "Shift", "Change Shift", "Leave Status", "Permission Status", "ClockIn", "ClockInStatus", "ClockOut", "ClockOutStatus", "Attendance",
        "Day Status", "Applied Through", "Is Week Off", "Is Holiday", "LOP Calculation", "Target", "Paid Present", "LOP Day", "Paid Present Day",
    ]
    let exportRowValuescrt = [
        'empcode', 'username', 'company', 'branch', 'unit', 'team', 'department', 'date', 'shiftmode', 'shift', 'changeshift', 'leavestatus', 'permissionstatus', 'clockin', 'clockinstatus',
        'clockout', 'clockoutstatus', 'attendanceauto', 'daystatus', 'appliedthrough', 'isweekoff', 'isholiday', 'lopcalculation', 'modetarget', 'paidpresent', 'lopday', 'paidpresentday',
    ]

    // print...
    const componentRef = useRef();
    const handleprint = useReactToPrint({
        content: () => componentRef.current,
        documentTitle: "Team User Shift Roaster",
        pageStyle: "print",
    });

    // image
    const handleCaptureImage = () => {
        if (gridRefImageAttTeam.current) {
            domtoimage.toBlob(gridRefImageAttTeam.current)
                .then((blob) => {
                    saveAs(blob, "Team User Shift Roaster.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredData = filteredDataItems?.slice((pageAttTeam - 1) * pageSizeAttTeam, pageAttTeam * pageSizeAttTeam);
    const totalPagesAttTeamOuter = Math.ceil(filteredDataItems?.length / pageSizeAttTeam);
    const visiblePages = Math.min(totalPagesAttTeamOuter, 3);
    const firstVisiblePage = Math.max(1, pageAttTeam - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesAttTeamOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageAttTeam * pageSizeAttTeam;
    const indexOfFirstItem = indexOfLastItem - pageSizeAttTeam;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

    //Attendance Day Shift
    //Datatable
    const handleSearchChangeAttDay = (e) => {
        const value = e.target.value;
        setSearchQueryAttDay(value);
        applyNormalFilterAttDay(value);
        setFilteredRowData([]);
    };

    const applyNormalFilterAttDay = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttDay?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsAttDay(filtered);
        setPageAttDay(1);
    };

    const applyAdvancedFilterAttDay = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttDay?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsAttDay(filtered);
        setAdvancedFilterAttDay(filters);
        // handleCloseSearchAttDay(); 
    };

    // Undo filter funtion
    const handleResetSearchAttDay = () => {
        setAdvancedFilterAttDay(null);
        setSearchQueryAttDay("");
        setFilteredDataItemsAttDay(userShifts);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayAttDay = () => {
        if (advancedFilterAttDay && advancedFilterAttDay.length > 0) {
            return advancedFilterAttDay.map((filter, index) => {
                let showname = columnDataTableAttDay.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterAttDay.length > 1 ? advancedFilterAttDay[1].condition : '') + ' ');
        }
        return searchQueryAttDay;
    };

    const handlePageChangeAttDay = (newPage) => {
        if (newPage >= 1 && newPage <= totalPagesAttDay) {
            setPageAttDay(newPage);
            gridRefTableAttDay.current.api.paginationGoToPage(newPage - 1);
        }
    };

    const handlePageSizeChangeAttDay = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttDay(newSize);
        if (gridApiAttDay) {
            gridApiAttDay.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsAttDay = () => {
        const updatedVisibility = { ...columnVisibilityAttDay };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityAttDay(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibilityAttDay");
        if (savedVisibility) {
            setColumnVisibilityAttDay(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibilityAttDay", JSON.stringify(columnVisibilityAttDay));
    }, [columnVisibilityAttDay]);

    // Function to filter columns based on search query
    const filteredColumnsAttDay = columnDataTableAttDay.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageAttDay.toLowerCase())
    );

    // Manage Columns functionality
    const toggleColumnVisibilityAttDay = (field) => {
        if (!gridApiAttDay) return;

        setColumnVisibilityAttDay((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiAttDay.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedAttDay = useCallback(debounce((event) => {
        if (!event.columnApiAttDay) return;

        const visible_columns = event.columnApiAttDay.getAllColumns().filter(col => {
            const colState = event.columnApiAttDay.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityAttDay((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleAttDay = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityAttDay((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    let exportColumnNamescrtAttDay = [
        "Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department",
        "Date", "Shift Mode", "Shift", "Leave Status", "Permission Status", "Shift Working Hours (HH:MM:SS)", "Production Shift Start Date", "Production Shift Start Time",
        "Production Shift End Date", "Production Shift End Time", "Clock In Time", "Clock Out Time", "Shift Before OT Hours (HH:MM:SS)", "Shift After OT Hours (HH:MM:SS)", "Total OT Hours (HH:MM:SS)"
    ]
    let exportRowValuescrtAttDay = [
        'empcode', 'username', 'company', 'branch', 'unit', 'team',
        'department', 'date', 'shiftmode', 'shift', 'leavestatus', 'permissionstatus', 'shiftworkinghours', 'prodstartdate', 'prodstarttime', 'prodenddate', 'prodendtime', 'clockin', 'clockout', 'shiftbeforeothours', 'shiftafterothours', 'totalothours'
    ]

    // print...
    const componentRefAttDay = useRef();
    const handleprintAttDay = useReactToPrint({
        content: () => componentRefAttDay.current,
        documentTitle: "Team Attendance Shift Report",
        pageStyle: "print",
    });

    // image
    const handleCaptureImageAttDay = () => {
        if (gridRefImageAttDay.current) {
            domtoimage.toBlob(gridRefImageAttDay.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Shift Report.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredDataAttDay = filteredDataItemsAttDay?.slice((pageAttDay - 1) * pageSizeAttDay, pageAttDay * pageSizeAttDay);
    const totalPagesAttDayOuter = Math.ceil(filteredDataItemsAttDay?.length / pageSizeAttDay);
    const visiblePagesAttDay = Math.min(totalPagesAttDayOuter, 3);
    const firstVisiblePageAttDay = Math.max(1, pageAttDay - 1);
    const lastVisiblePageAttDay = Math.min(firstVisiblePageAttDay + visiblePagesAttDay - 1, totalPagesAttDayOuter);
    const pageNumbersAttDay = [];
    const indexOfLastItemAttDay = pageAttDay * pageSizeAttDay;
    const indexOfFirstItemAttDay = indexOfLastItemAttDay - pageSizeAttDay;
    for (let i = firstVisiblePageAttDay; i <= lastVisiblePageAttDay; i++) { pageNumbersAttDay.push(i); }

    return (
        <Box>
            <Headtitle title={"Team Attendance Overall Report"} />
            {/* ****** Header Content ****** */}
            <PageHeading
                title="Team Attendance Overall Report"
                modulename="Human Resources"
                submodulename="HR"
                mainpagename="Attendance"
                subpagename="Attendance Reports"
                subsubpagename="Team Attendance Overall Report"
            />
            {isUserRoleCompare?.includes("lteamattendanceoverallreport") && (
                <>
                    <Box sx={userStyle.selectcontainer}>
                        <Grid container spacing={2}>
                            <Grid item md={12} sm={12} xs={12}>
                                <Typography sx={userStyle.importheadtext}>Team Attendance Overall Report</Typography>
                            </Grid>
                            <>
                                {listpageaccessby === "Reporting to Based" ? <></> :
                                    <>
                                        <Grid item lg={2} md={2.5} xs={12} sm={6}>
                                            <Typography>Attendance Mode<b style={{ color: "red" }}>*</b></Typography>
                                            <Selects
                                                options={attModeOptions}
                                                styles={colourStyles}
                                                value={{ label: filterUser.attmode, value: filterUser.attmode }}
                                                onChange={(e) => {
                                                    setFilterUser({ ...filterUser, attmode: e.value, });
                                                    setLoader(false);
                                                }}
                                            />
                                        </Grid>
                                        {filterUser.attmode !== 'Attendance Summary Report' ?
                                            <>
                                                <Grid item lg={2} md={2.5} xs={12} sm={6}>
                                                    <Typography>Mode<b style={{ color: "red" }}>*</b></Typography>
                                                    <Selects
                                                        options={modeDropDowns}
                                                        styles={colourStyles}
                                                        isDisabled={isDisableModeDropdown}
                                                        value={{ label: filterUser.mode, value: filterUser.mode }}
                                                        onChange={(e) => {
                                                            setFilterUser({ ...filterUser, mode: e.value, });
                                                        }}
                                                    />
                                                </Grid>
                                                <Grid item lg={2} md={2.5} xs={12} sm={6}>
                                                    <Typography>Level<b style={{ color: "red" }}>*</b></Typography>
                                                    <Selects
                                                        options={sectorDropDowns}
                                                        styles={colourStyles}
                                                        value={{ label: filterUser.level, value: filterUser.level }}
                                                        onChange={(e) => {
                                                            setFilterUser({ ...filterUser, level: e.value, });
                                                        }}
                                                    />
                                                </Grid>
                                            </>
                                            : null}
                                    </>}
                                {filterUser.attmode === 'Attendance Review' ?
                                    <Grid item md={2} xs={12} sm={12}>
                                        <FormControl fullWidth size="small">
                                            <Typography>Attendance Status<b style={{ color: 'red' }}>*</b></Typography>
                                            <MultiSelect
                                                options={attStatusOptionDropdown}
                                                value={selectedOptionsStatus}
                                                onChange={(e) => { handleStatusChange(e); }}
                                                valueRenderer={customValueRendererStatus}
                                                labelledBy="Please Select Status"
                                            />
                                        </FormControl>
                                    </Grid> : null}
                                {filterUser.attmode === 'Attendance Month Status' ?
                                    (
                                        <>
                                            <Grid item md={2} sm={12} xs={12}>
                                                <FormControl fullWidth size="small">
                                                    <Typography>Select Month</Typography>
                                                    <Selects
                                                        maxMenuHeight={200}
                                                        styles={colourStyles}
                                                        options={(isMonthyear.isyear.value < new Date(serverTime).getFullYear()) ? months : months.filter((d) => d.value <= currentMonthIndex + 1)}
                                                        value={isMonthyear.ismonth}
                                                        onChange={(e) => handleGetMonth(e.value)}
                                                    />
                                                </FormControl>
                                            </Grid>
                                            <Grid item md={2} sm={12} xs={12}>
                                                <FormControl fullWidth size="small">
                                                    <Typography> Select Year</Typography>
                                                    <Selects
                                                        maxMenuHeight={200}
                                                        styles={colourStyles}
                                                        options={getyear}
                                                        value={isMonthyear.isyear}
                                                        onChange={(e) => handleGetYear(e.value)}
                                                    />
                                                </FormControl>
                                            </Grid>
                                        </>
                                    ) : (
                                        <>
                                            {(filterUser.attmode !== 'Attendance Summary Report' && filterUser.attmode !== 'Attendance Summary Report - Hierarchy') ? (
                                                <Grid item md={2} xs={12} sm={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>Filter Mode<b style={{ color: "red" }}>*</b> </Typography>
                                                        <Selects
                                                            labelId="mode-select-label"
                                                            options={mode}
                                                            value={{ label: selectedMode, value: selectedMode }}
                                                            onChange={(selectedOption) => {
                                                                // Reset the date fields to empty strings
                                                                let fromdate = '';
                                                                let todate = '';

                                                                // If a valid option is selected, get the date range
                                                                if (selectedOption.value) {
                                                                    const dateRange = getDateRange(selectedOption.value);
                                                                    fromdate = dateRange.fromdate; // Already formatted in 'dd-MM-yyyy'
                                                                    todate = dateRange.todate; // Already formatted in 'dd-MM-yyyy'
                                                                }
                                                                // Set the state with formatted dates
                                                                setFilterUser({
                                                                    ...filterUser,
                                                                    fromdate: formatDateForInput(new Date(fromdate.split('-').reverse().join('-'))), // Convert to 'yyyy-MM-dd'
                                                                    todate: formatDateForInput(new Date(todate.split('-').reverse().join('-'))), // Convert to 'yyyy-MM-dd'
                                                                });
                                                                setSelectedMode(selectedOption.value); // Update the mode
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            ) : null}
                                            <Grid item md={2} xs={12} sm={12}>
                                                <FormControl fullWidth size="small">
                                                    <Typography>From Date<b style={{ color: "red" }}>*</b></Typography>
                                                    <OutlinedInput
                                                        id="component-outlined"
                                                        type="date"
                                                        disabled={(filterUser.attmode !== 'Attendance Summary Report' && filterUser.attmode !== 'Attendance Summary Report - Hierarchy') ? selectedMode != "Custom" : ''}
                                                        value={filterUser.fromdate}
                                                        onChange={(e) => {
                                                            const selectedDate = e.target.value;
                                                            // Ensure that the selected date is not in the future
                                                            const currentDate = new Date(serverTime).toISOString().split("T")[0];
                                                            if (selectedDate <= currentDate) {
                                                                setFilterUser({
                                                                    ...filterUser,
                                                                    fromdate: selectedDate,
                                                                    todate: selectedDate,
                                                                });
                                                            } else {
                                                                // Handle the case where the selected date is in the future (optional)
                                                                // You may choose to show a message or take other actions.
                                                                console.log("Please select a date on or before today.");
                                                            }
                                                        }}
                                                    // Set the max attribute to the current date
                                                    // inputProps={{ max: new Date(serverTime).toISOString().split("T")[0] }}
                                                    />
                                                </FormControl>
                                            </Grid>
                                            {(filterUser.attmode !== 'Attendance Summary Report' && filterUser.attmode !== 'Attendance Summary Report - Hierarchy') ?
                                                <Grid item md={2} xs={12} sm={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            {" "}
                                                            To Date<b style={{ color: "red" }}>*</b>{" "}
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlined"
                                                            type="date"
                                                            disabled={selectedMode != "Custom"}
                                                            value={filterUser.todate}
                                                            onChange={(e) => {
                                                                const selectedDate = e.target.value;
                                                                // Ensure that the selected date is not in the future
                                                                const currentDate = new Date(serverTime)
                                                                    .toISOString()
                                                                    .split("T")[0];
                                                                const fromdateval =
                                                                    filterUser.fromdate != "" &&
                                                                    new Date(filterUser.fromdate)
                                                                        .toISOString()
                                                                        .split("T")[0];
                                                                if (filterUser.fromdate == "") {
                                                                    setPopupContentMalert("Please Select From Date");
                                                                    setPopupSeverityMalert("warning");
                                                                    handleClickOpenPopupMalert();
                                                                } else if (selectedDate < fromdateval) {
                                                                    setFilterUser({ ...filterUser, todate: "" });
                                                                    setPopupContentMalert("To Date should be after or equal to From Date");
                                                                    setPopupSeverityMalert("warning");
                                                                    handleClickOpenPopupMalert();
                                                                } else {
                                                                    setFilterUser({ ...filterUser, todate: selectedDate });
                                                                }
                                                                // else if (selectedDate <= currentDate) {
                                                                //     setFilterUser({ ...filterUser, todate: selectedDate });
                                                                // } else {
                                                                //     console.log("Please select a date on or before today.");
                                                                // }
                                                            }}
                                                        // Set the max attribute to the current date
                                                        // inputProps={{
                                                        //     max: new Date(serverTime).toISOString().split("T")[0],
                                                        //     min:
                                                        //         filterUser.fromdate !== "" ? filterUser.fromdate : null,
                                                        // }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                : null}
                                        </>
                                    )}
                                <Grid item lg={1} md={2} sm={2} xs={6} >
                                    <Box sx={(theme) => ({ mt: { lg: 3, md: 2, sm: 1, xs: 0, } })}>
                                        <Button sx={buttonStyles.buttonsubmit} variant="contained" onClick={handleSubmit} > Filter </Button>
                                    </Box>
                                </Grid>
                                <Grid item lg={1} md={2} sm={2} xs={6}>
                                    <Box sx={(theme) => ({ mt: { lg: 3, md: 2, sm: 1, xs: 0, } })}>
                                        <Button sx={buttonStyles.btncancel} onClick={handleClear} > Clear </Button>
                                    </Box>
                                </Grid>
                            </>
                        </Grid>
                    </Box><br />
                    {/* ****** Table Start ****** */}
                    {filterUser.attmode === 'User Shift Roaster' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}>Team User Shift Roaster</Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttTeam}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChange}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShifts?.length}>All</MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpen(true);
                                                        setFormat("xl");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileExcel />
                                                    &ensp;Export to Excel&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendancestatus") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpen(true);
                                                        setFormat("csv");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileCsv />
                                                    &ensp;Export to CSV&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprint}>
                                                    {" "}
                                                    &ensp; <FaPrint /> &ensp;Print&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpen(true);
                                                    }}
                                                >
                                                    <FaFilePdf />
                                                    &ensp;Export to PDF&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={handleCaptureImage}
                                                >
                                                    {" "}
                                                    <ImageIcon sx={{ fontSize: "15px" }} />{" "}
                                                    &ensp;Image&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilter && (
                                                        <IconButton onClick={handleResetSearch}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttTeam} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplay()}
                                            onChange={handleSearchChange}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilter}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>{" "}  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumns}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumns}> Manage Columns  </Button><br /> <br />
                            {loader ?
                                <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box> :
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttTeam} >
                                        <AgGridReact
                                            rowData={filteredDataItems}
                                            columnDefs={columnDataTable.filter((column) => columnVisibility[column.field])}
                                            ref={gridRefTableAttTeam}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttTeam}
                                            onPaginationChanged={onPaginationChanged}
                                            onGridReady={onGridReady}
                                            onColumnMoved={handleColumnMoved}
                                            onColumnVisible={handleColumnVisible}
                                            onFilterChanged={onFilterChanged}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            }
                        </Box>
                    ) : null}
                    {filterUser.attmode === 'Attendance Day Shift' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}> Team Attendance Shift Report </Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttDay}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeAttDay}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsAttDay?.length}>  All </MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}  >
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttDay(true)
                                                    // fetchUsersStatus()
                                                    setFormat("xl")
                                                }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttDay(true)
                                                    // fetchUsersStatus()
                                                    setFormat("csv")
                                                }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintAttDay}> &ensp;  <FaPrint /> &ensp;Print&ensp; </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenAttDay(true)
                                                    }}
                                                ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleCaptureImageAttDay}> <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp; </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterAttDay && (
                                                        <IconButton onClick={handleResetSearchAttDay}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttDay} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayAttDay()}
                                            onChange={handleSearchChangeAttDay}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterAttDay}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsAttDay}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsAttDay}> Manage Columns  </Button> <br /><br />
                            {loader ? (
                                <>
                                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <ThreeDots
                                            height="80"
                                            width="80"
                                            radius="9"
                                            color="#1976d2"
                                            ariaLabel="three-dots-loading"
                                            wrapperStyle={{}}
                                            wrapperClassName=""
                                            visible={true}
                                        />
                                    </Box>
                                </>
                            ) : (
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttDay} >
                                        <AgGridReact
                                            rowData={filteredDataItemsAttDay}
                                            columnDefs={columnDataTableAttDay.filter((column) => columnVisibilityAttDay[column.field])}
                                            ref={gridRefTableAttDay}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttDay}
                                            onPaginationChanged={onPaginationChanged}
                                            onGridReady={onGridReady}
                                            onColumnMoved={handleColumnMoved}
                                            onColumnVisible={handleColumnVisible}
                                            onFilterChanged={onFilterChanged}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            )}
                        </Box>
                    ) : null}

                    <TeamAttOverallReviewAndReport userShiftsAttReview={userShiftsAttReview} userShiftsAttReport={userShiftsAttReport} loader={loader} filterUser={filterUser}
                        setSearchQueryAttReview={setSearchQueryAttReview} setPageAttReview={setPageAttReview} setTotalPagesAttReview={setTotalPagesAttReview} pageAttReview={pageAttReview} pageSizeAttReview={pageSizeAttReview} setPageSizeAttReview={setPageSizeAttReview} searchQueryAttReview={searchQueryAttReview}
                        setSearchQueryAttReport={setSearchQueryAttReport} setPageAttReport={setPageAttReport} setTotalPagesAttReport={setTotalPagesAttReport} pageAttReport={pageAttReport} pageSizeAttReport={pageSizeAttReport} setPageSizeAttReport={setPageSizeAttReport} searchQueryAttReport={searchQueryAttReport} isHeadings={isHeadings} headArr={headArr} attStatus={attStatus} />
                    <TeamAttOverallShortAndMonth userShiftsAttShort={userShiftsAttShort} userShiftsAttMonth={userShiftsAttMonth} loader={loader} filterUser={filterUser}
                        setSearchQueryAttShort={setSearchQueryAttShort} setPageAttShort={setPageAttShort} setTotalPagesAttShort={setTotalPagesAttShort} pageAttShort={pageAttShort} pageSizeAttShort={pageSizeAttShort} setPageSizeAttShort={setPageSizeAttShort} searchQueryAttShort={searchQueryAttShort}
                        setSearchQueryAttMonth={setSearchQueryAttMonth} setPageAttMonth={setPageAttMonth} setTotalPagesAttMonth={setTotalPagesAttMonth} pageAttMonth={pageAttMonth} pageSizeAttMonth={pageSizeAttMonth} setPageSizeAttMonth={setPageSizeAttMonth} searchQueryAttMonth={searchQueryAttMonth}
                    />
                    <TeamAttOverallSummary userShiftsUserShiftSummary={userShiftsUserShiftSummary} loader={loader} setSearchQueryUserShiftSummary={setSearchQueryUserShiftSummary} setPageUserShiftSummary={setPageUserShiftSummary} setTotalPagesUserShiftSummary={setTotalPagesUserShiftSummary} setPageSizeUserShiftSummary={setPageSizeUserShiftSummary} totalPagesUserShiftSummary={totalPagesUserShiftSummary} pageUserShiftSummary={pageUserShiftSummary} pageSizeUserShiftSummary={pageSizeUserShiftSummary} searchQueryUserShiftSummary={searchQueryUserShiftSummary} filterUser={filterUser} serverTime={serverTime} />
                    <TeamAttOverallSummaryHierarchy userShiftsUserShiftSummaryHier={userShiftsUserShiftSummaryHier} loader={loader} setSearchQueryUserShiftSummaryHier={setSearchQueryUserShiftSummaryHier} setPageUserShiftSummaryHier={setPageUserShiftSummaryHier} setTotalPagesUserShiftSummaryHier={setTotalPagesUserShiftSummaryHier} setPageSizeUserShiftSummaryHier={setPageSizeUserShiftSummaryHier} totalPagesUserShiftSummaryHier={totalPagesUserShiftSummaryHier} pageUserShiftSummaryHier={pageUserShiftSummaryHier} pageSizeUserShiftSummaryHier={pageSizeUserShiftSummaryHier} searchQueryUserShiftSummaryHier={searchQueryUserShiftSummaryHier} filterUser={filterUser} serverTime={serverTime} />

                    {/* ****** Table End ****** */}
                </>
            )}

            {/* Manage Column */}
            <Popover
                id={id}
                open={isManageColumnsOpen}
                anchorEl={anchorEl}
                onClose={handleCloseManageColumns}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumns}
                    searchQuery={searchQueryManage}
                    setSearchQuery={setSearchQueryManage}
                    filteredColumns={filteredColumns}
                    columnVisibility={columnVisibility}
                    toggleColumnVisibility={toggleColumnVisibility}
                    setColumnVisibility={setColumnVisibility}
                    initialColumnVisibility={initialColumnVisibility}
                    columnDataTable={columnDataTable}
                />
            </Popover>

            {/* Search Bar */}
            <Popover
                id={idSearchAttTeam}
                open={openSearchAttTeam}
                anchorEl={anchorElSearchAttTeam}
                onClose={handleCloseSearchAttTeam}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <AdvancedSearchBar columns={columnDataTable.filter(data => data.field !== "actions")} onSearch={applyAdvancedFilter} initialSearchValue={searchQueryAttTeam} handleCloseSearch={handleCloseSearchAttTeam} />
            </Popover>

            <Popover
                id={idSearchAttDay}
                open={openSearchAttDay}
                anchorEl={anchorElSearchAttDay}
                onClose={handleCloseSearchAttDay}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <Box sx={{ padding: '10px' }}>
                    <AdvancedSearchBar columns={columnDataTableAttDay} onSearch={applyAdvancedFilterAttDay} initialSearchValue={searchQueryAttDay} handleCloseSearch={handleCloseSearchAttDay} />
                </Box>
            </Popover>

            {/* Alert  */}
            <Box>
                <Dialog open={isErrorOpen} onClose={handleCloseerr} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <Typography variant="h6">{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" color="error" onClick={handleCloseerr}>
                            ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpen}
                handleCloseFilterMod={handleCloseFilterMod}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpen}
                isPdfFilterOpen={isPdfFilterOpen}
                setIsPdfFilterOpen={setIsPdfFilterOpen}
                handleClosePdfFilterMod={handleClosePdfFilterMod}
                filteredDataTwo={(filteredRowData.length > 0 ? filteredRowData : filteredData) ?? []}
                itemsTwo={items ?? []}
                filename={"Team User Shift Roaster"}
                exportColumnNames={exportColumnNamescrt}
                exportRowValues={exportRowValuescrt}
                componentRef={componentRef}
            />

            <ExportData
                isFilterOpen={isFilterOpenAttDay}
                handleCloseFilterMod={handleCloseFilterModAttDay}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenAttDay}
                isPdfFilterOpen={isPdfFilterOpenAttDay}
                setIsPdfFilterOpen={setIsPdfFilterOpenAttDay}
                handleClosePdfFilterMod={handleClosePdfFilterModAttDay}
                filteredDataTwo={(filteredRowDataAttDay.length > 0 ? filteredRowDataAttDay : filteredDataAttDay) ?? []}
                itemsTwo={itemsAttDay ?? []}
                filename={"Team Attendance Shift Report"}
                exportColumnNames={exportColumnNamescrtAttDay}
                exportRowValues={exportRowValuescrtAttDay}
                componentRef={componentRefAttDay}
            />

        </Box>
    );
}

export default TeamAttendanceOverallReportList;