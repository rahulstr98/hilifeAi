import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import { FaFileExcel, FaFileCsv, FaPrint, FaFilePdf, FaSearch } from 'react-icons/fa';
import { Box, Typography, OutlinedInput, Select, Chip, MenuItem, Dialog, DialogContent, InputAdornment, DialogActions, FormControl, Grid, Button, Popover, IconButton, Tooltip } from "@mui/material";
import { userStyle, colourStyles } from "../../../pageStyle";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from 'axios';
import { SERVICE } from "../../../services/Baseservice";
import { handleApiError } from "../../../components/Errorhandling";
import { useReactToPrint } from "react-to-print";
import { UserRoleAccessContext } from "../../../context/Appcontext";
import { AuthContext } from "../../../context/Appcontext";
import Headtitle from "../../../components/Headtitle";
import { ThreeDots } from "react-loader-spinner";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import { MultiSelect } from "react-multi-select-component";
import { getCurrentServerTime } from '../../../components/getCurrentServerTime';
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import ImageIcon from "@mui/icons-material/Image";
import { saveAs } from "file-saver";
import Selects from "react-select";
import moment from 'moment';
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import AggregatedSearchBar from "../../../components/AggregatedSearchBar";
import AggridTable from "../../../components/AggridTable";
import domtoimage from 'dom-to-image';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import ExportData from "../../../components/ExportData";
import MessageAlert from "../../../components/MessageAlert";
import PageHeading from "../../../components/PageHeading";
import AlertDialog from "../../../components/Alert";
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from "../../../components/ManageColumn";
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

const ScrollingText = ({ text }) => {

  const containerRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    const containerWidth = containerRef.current.offsetWidth;
    const textElement = textRef.current;

    if (!textElement) return; // Add a null check here

    const textWidth = textElement.offsetWidth;
    let position = 0;

    const scrollText = () => {
      position -= 1;
      if (position < -textWidth) {
        position = containerWidth;
      }
      textElement.style.transform = `translateX(${position}px)`;
      requestAnimationFrame(scrollText);
    };

    scrollText();

    return () => cancelAnimationFrame(scrollText);
  }, []);

  return (
    <Grid item xs={8} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", }}>
      <Typography sx={userStyle.importheadtext}>{"Attendance Summary Report"}</Typography>
      <div ref={containerRef} style={{ overflow: "hidden", width: "50%", whiteSpace: "nowrap" }}>
        <span ref={textRef} style={{ color: "red", display: "inline-block" }}>{text}</span>
      </div>
    </Grid>
  );
};

const ScrollingTextView = ({ text, tableName }) => {

  const containerRef = useRef(null);
  const textRef = useRef(null);

  useEffect(() => {
    const containerWidth = containerRef.current.offsetWidth;
    const textElement = textRef.current;

    if (!textElement) return; // Add a null check here

    const textWidth = textElement.offsetWidth;
    let position = 0;

    const scrollText = () => {
      position -= 1;
      if (position < -textWidth) {
        position = containerWidth;
      }
      textElement.style.transform = `translateX(${position}px)`;
      requestAnimationFrame(scrollText);
    };

    scrollText();

    return () => cancelAnimationFrame(scrollText);
  }, []);

  return (
    <Grid item xs={8} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", }}>
      <Typography sx={userStyle.HeaderText}>{tableName}</Typography>
      <div ref={containerRef} style={{ overflow: "hidden", width: "50%", whiteSpace: "nowrap" }}>
        <span ref={textRef} style={{ color: "red", display: "inline-block" }}>{text}</span>
      </div>
    </Grid>
  );
};

function AttendanceSummaryReportList() {

  const [serverTime, setServerTime] = useState(null);
  useEffect(() => {
    const fetchTime = async () => {
      const time = await getCurrentServerTime();
      setServerTime(time);
      setFilterUser({ ...filterUser, fromdate: moment(time).format('YYYY-MM-DD'), todate: moment(time).format('YYYY-MM-DD') });
    };

    fetchTime();
  }, []);

  function formatCustomDateTime(date) {
    if (!date) {
      return '';
    }
    const dd = String(date.getDate()).padStart(2, '0');
    const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
    const yyyy = date.getFullYear();

    let hh = date.getHours();
    const min = String(date.getMinutes()).padStart(2, '0');
    const ss = String(date.getSeconds()).padStart(2, '0');
    const period = hh >= 12 ? 'PM' : 'AM';

    hh = String(hh).padStart(2, '0');

    return `${dd}-${mm}-${yyyy} ${hh}:${min}:${ss} ${period}`;
  }

  const { isUserRoleAccess, isUserRoleCompare, isAssignBranch, allUsersLimit, alldepartment, allTeam, pageName, setPageName, buttonStyles } = useContext(UserRoleAccessContext);
  const { auth } = useContext(AuthContext);

  var today = new Date(serverTime);
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0"); // January is 0!
  var yyyy = today.getFullYear();
  today = yyyy + "-" + mm + "-" + dd;

  const gridRefTableUserShiftSummary = useRef(null);
  const gridRefImageUserShiftSummary = useRef(null);
  const gridRefImageUserShiftSummaryViewPopup = useRef(null);
  const gridRefTableView = useRef(null);
  const gridRefTableImgView = useRef(null);

  let overallBoxStyle = {
    background: '#fff',
    borderRadius: '5px',
    padding: '10px 12px 10px 60px',
    boxShadow: '0 4px 12px rgba(0,0,0,0.51)',
    display: 'flex',
    alignItems: 'center',
    position: 'relative',
  }

  const [selectedCompany, setSelectedCompany] = useState([]);
  const [valueCompany, setValueCompany] = useState([]);
  const [selectedBranch, setSelectedBranch] = useState([]);
  const [valueBranch, setValueBranch] = useState([]);
  const [selectedUnit, setSelectedUnit] = useState([]);
  const [valueUnit, setValueUnit] = useState([]);
  const [selectedTeam, setSelectedTeam] = useState([]);
  const [valueTeam, setValueTeam] = useState([]);
  const [selectedDep, setSelectedDep] = useState([]);
  const [valueDep, setValueDep] = useState([]);
  const [selectedEmp, setSelectedEmp] = useState([]);
  const [valueEmp, setValueEmp] = useState([]);
  const [userShifts, setUserShifts] = useState([]);
  const [attStatus, setAttStatus] = useState([]);
  const [attModearr, setAttModearr] = useState([]);
  const [attStatusOption, setAttStatusOption] = useState([]);
  const [showAlert, setShowAlert] = useState();
  const [loader, setLoader] = useState(false);

  const [viewData, setViewData] = useState([]);
  const [tableName, setTableName] = useState('');

  // State to track advanced filter
  const [advancedFilter, setAdvancedFilter] = useState(null);
  const [gridApi, setGridApi] = useState(null);
  const [columnApi, setColumnApi] = useState(null);
  const [filteredDataItems, setFilteredDataItems] = useState([]);
  const [filteredRowData, setFilteredRowData] = useState([]);

  const [itemsView, setItemsView] = useState([]);
  const [loaderView, setLoaderView] = useState(false);
  const [selectedRowsView, setSelectedRowsView] = useState([]);

  const [filteredRowDataView, setFilteredRowDataView] = useState([]);
  const [filteredChangesView, setFilteredChangesView] = useState(null);
  const [isHandleChangeView, setIsHandleChangeView] = useState(false);
  const [searchedStringView, setSearchedStringView] = useState("");

  const [filterUser, setFilterUser] = useState({ filtertype: "Company", fromdate: today, todate: today, });

  // Datatable
  const [pageUserShiftSummary, setPageUserShiftSummary] = useState(1);
  const [pageSizeUserShiftSummary, setPageSizeUserShiftSummary] = useState(10);
  const [searchQueryUserShiftSummary, setSearchQueryUserShiftSummary] = useState("");
  const [totalPagesUserShiftSummary, setTotalPagesUserShiftSummary] = useState(1);

  const [pageView, setPageView] = useState(1);
  const [pageSizeView, setPageSizeView] = useState(10);
  const [searchQueryView, setSearchQueryView] = useState("");

  const [isFilterOpenView, setIsFilterOpenView] = useState(false);
  const [isPdfFilterOpenView, setIsPdfFilterOpenView] = useState(false);
  // page refersh reload
  const handleCloseFilterModView = () => { setIsFilterOpenView(false); };
  const handleClosePdfFilterModView = () => { setIsPdfFilterOpenView(false); };

  // Error Popup model
  const [isErrorOpen, setIsErrorOpen] = useState(false);
  const handleClickOpenerr = () => { setIsErrorOpen(true); };
  const handleCloseerr = () => { setIsErrorOpen(false); };

  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isPdfFilterOpen, setIsPdfFilterOpen] = useState(false);
  // pageUserShiftSummary refersh reload
  const handleCloseFilterMod = () => { setIsFilterOpen(false); };
  const handleClosePdfFilterMod = () => { setIsPdfFilterOpen(false); };

  const [openPopupMalert, setOpenPopupMalert] = useState(false);
  const [popupContentMalert, setPopupContentMalert] = useState("");
  const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
  const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
  const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

  const [openPopup, setOpenPopup] = useState(false);
  const [popupContent, setPopupContent] = useState("");
  const [popupSeverity, setPopupSeverity] = useState("");
  const handleClickOpenPopup = () => { setOpenPopup(true); };
  const handleClosePopup = () => { setOpenPopup(false); }

  // View model
  const [openview, setOpenview] = useState(false);
  const handleClickOpenview = () => { setOpenview(true); };
  const handleCloseview = () => {
    setOpenview(false);
    setViewData([]);
    setPageView(1);
    setSearchQueryView("");
  }

  // History model
  const [openHistoryview, setOpenHistoryview] = useState(false);
  const handleClickOpenHistoryview = () => { setOpenHistoryview(true); };
  const handleCloseHistoryview = () => { setOpenHistoryview(false); }

  // pageUserShiftSummary refersh reload
  const handleBeforeUnload = (event) => {
    event.preventDefault();
    event.returnValue = ""; // This is required for Chrome support
  };

  useEffect(() => {
    const beforeUnloadHandler = (event) => handleBeforeUnload(event);
    window.addEventListener("beforeunload", beforeUnloadHandler);
    return () => {
      window.removeEventListener("beforeunload", beforeUnloadHandler);
    };
  }, []);

  // Manage Columns
  const [isManageColumnsOpenUserShiftSummary, setManageColumnsOpenUserShiftSummary] = useState(false);
  const [anchorElUserShiftSummary, setAnchorElUserShiftSummary] = useState(null);
  const [searchQueryManageUserShiftSummary, setSearchQueryManageUserShiftSummary] = useState("");
  const handleOpenManageColumnsUserShiftSummary = (event) => {
    setAnchorElUserShiftSummary(event.currentTarget);
    setManageColumnsOpenUserShiftSummary(true);
  };
  const handleCloseManageColumnsUserShiftSummary = () => {
    setManageColumnsOpenUserShiftSummary(false);
    setSearchQueryManageUserShiftSummary("");
  };
  const openManageColumnsUserShiftSummary = Boolean(anchorElUserShiftSummary);
  const idManageColumnsUserShiftSummary = openManageColumnsUserShiftSummary ? "simple-popover" : undefined;

  // Search bar
  const [anchorElSearchUserShiftSummary, setAnchorElSearchUserShiftSummary] = React.useState(null);
  const handleClickSearchUserShiftSummary = (event) => {
    setAnchorElSearchUserShiftSummary(event.currentTarget);
  };
  const handleCloseSearchUserShiftSummary = () => {
    setAnchorElSearchUserShiftSummary(null);
    setSearchQueryUserShiftSummary("");
  };

  const openSearchUserShiftSummary = Boolean(anchorElSearchUserShiftSummary);
  const idSearchUserShiftSummary = openSearchUserShiftSummary ? 'simple-popover' : undefined;

  const [searchQueryManageView, setSearchQueryManageView] = useState("");
  const [isManageColumnsOpenView, setManageColumnsOpenView] = useState(false);
  const [anchorElView, setAnchorElView] = useState(null);

  const handleOpenManageColumnsView = (event) => {
    setAnchorElView(event.currentTarget);
    setManageColumnsOpenView(true);
  };
  const handleCloseManageColumnsView = () => {
    setManageColumnsOpenView(false);
    setSearchQueryManageView("");
  };

  const openView = Boolean(anchorElView);
  const idView = openView ? "simple-popover" : undefined;

  const [selectedMode, setSelectedMode] = useState("Today");
  const mode = [
    { label: "Today", value: "Today" },
    { label: "Tomorrow", value: "Tomorrow" },
    { label: "Yesterday", value: "Yesterday" },
    { label: "This Week", value: "This Week" },
    { label: "This Month", value: "This Month" },
    { label: "Last Week", value: "Last Week" },
    { label: "Last Month", value: "Last Month" },
    { label: "Custom", value: "Custom" }
  ]

  const modeOptions = [
    { label: 'Department', value: "Department" },
    { label: "Employee", value: "Employee" },
  ];

  // Show All Columns & Manage Columns
  const initialColumnVisibilityUserShiftSummary = {
    serialNumber: true,
    company: true,
    branch: true,
    unit: true,
    team: true,
    history: true,
    totalemployees: true,
    totalcurrentshift: true,
    paidpresentday: true,
    lopcount: true,
    totalin: true,
    totalout: true,
    totalpending: true,
    facilitypresent: true,
    wfhpresent: true,
    facilityabsent: true,
    wfhabsent: true,
    earlyclockin: true,
    onpresent: true,
    graceclockin: true,
    lateclockin: true,
    weekoff: true,
    holidayCount: true,
    permissionCount: true,
    clsl: true,
    onclockout: true,
    earlyclockout: true,
    overclockout: true,
    autoclockout: true,
    shiftnotstarted: true,
    nostatus: true,
    notallotted: true,
    weekoffpresent: true,
    longleaveabsent: true,
    blabsent: true,
    doubledayabsent: true,
    weekoffabsent: true,
  };
  const [columnVisibilityUserShiftSummary, setColumnVisibilityUserShiftSummary] = useState(initialColumnVisibilityUserShiftSummary);


  const initialColumnVisibilityView = {
    serialNumber: true,
    empcode: true,
    username: true,
    company: true,
    branch: true,
    unit: true,
    team: true,
    department: true,
    date: true,
    shiftmode: true,
    shift: true,
    changeshift: true,
    leavestatus: true,
    permissionstatus: true,
    clockin: true,
    clockout: true,
    clockinstatus: true,
    clockoutstatus: true,
    attendanceauto: true,
    daystatus: true,
    appliedthrough: true,
    isweekoff: true,
    isholiday: true,
    lopcalculation: true,
    modetarget: true,
    paidpresent: true,
    lopday: true,
    paidpresentday: true,
  };

  const [columnVisibilityView, setColumnVisibilityView] = useState(initialColumnVisibilityView);

  // Table row color
  const getRowStyle = (params) => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: '#f0f0f0' }; // Even row
    } else {
      return { background: '#ffffff' }; // Odd row
    }
  }

  useEffect(() => {
    getapi();
  }, []);

  const getapi = async () => {
    let userchecks = axios.post(`${SERVICE.CREATE_USERCHECKS}`, {
      headers: {
        'Authorization': `Bearer ${auth.APIToken}`,
      },
      empcode: String(isUserRoleAccess?.empcode),
      companyname: String(isUserRoleAccess?.companyname),
      pagename: String("Attendance Summary Report"),
      commonid: String(isUserRoleAccess?._id),
      date: String(new Date(serverTime)),
      addedby: [
        {
          name: String(isUserRoleAccess?.username),
          // date: String(new Date(serverTime)),
        },
      ],
    });
  }

  //get all Sub vendormasters.
  const fetchAttedanceStatus = async () => {
    setPageName(!pageName)
    try {
      let res_vendor = await axios.get(SERVICE.ATTENDANCE_STATUS, {
        headers: {
          'Authorization': `Bearer ${auth.APIToken}`
        }
      });
      setAttStatus(res_vendor?.data?.attendancestatus);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  }

  //get all Attendance Status name.
  const fetchAttMode = async () => {
    setPageName(!pageName)
    try {
      let res_freq = await axios.get(SERVICE.ATTENDANCE_MODE_STATUS, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setAttModearr(res_freq?.data?.allattmodestatus);
      let result = res_freq?.data?.allattmodestatus.filter((data, index) => {
        return data.appliedthrough != "Auto";
      });

      setAttStatusOption(result.map((d) => d.name));
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  useEffect(() => {
    fetchAttedanceStatus();
    fetchAttMode();
  }, []);

  const accessbranch = isUserRoleAccess?.role?.includes("Manager")
    ? isAssignBranch?.map((data) => ({
      branch: data.branch,
      company: data.company,
      unit: data.unit,
    }))
    : isAssignBranch
      ?.filter((data) => {
        let fetfinalurl = [];

        if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 &&
          data?.subpagenameurl?.length !== 0 &&
          data?.subsubpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.subsubpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 &&
          data?.subpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.subpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.mainpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.submodulenameurl;
        } else if (data?.modulenameurl?.length !== 0) {
          fetfinalurl = data.modulenameurl;
        } else {
          fetfinalurl = [];
        }

        const remove = [
          window.location.pathname?.substring(1),
          window.location.pathname,
        ];
        return fetfinalurl?.some((item) => remove?.includes(item));
      })
      ?.map((data) => ({
        branch: data.branch,
        company: data.company,
        unit: data.unit,
      }));

  // Pre select dropdowns
  useEffect(() => {
    // Remove duplicates based on the 'company' field
    const uniqueIsAssignBranch = accessbranch.reduce((acc, current) => {
      const x = acc.find(item => item.company === current.company && item.branch === current.branch && item.unit === current.unit);
      if (!x) {
        acc.push(current);
      }
      return acc;
    }, []);

    const company = [...new Set(uniqueIsAssignBranch.map(data => data.company))].map((data) => ({
      label: data,
      value: data,
    }));
    setSelectedCompany(company);
    setValueCompany(
      company.map((a, index) => {
        return a.value;
      })
    );
    const branch = uniqueIsAssignBranch?.filter(
      (val) =>
        company?.map(comp => comp.value === val.company)
    )?.map(data => ({
      label: data.branch,
      value: data.branch,
    })).filter((item, index, self) => {
      return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
    })
    setSelectedBranch(branch);
    setValueBranch(
      branch.map((a, index) => {
        return a.value;
      })
    );
    const unit = uniqueIsAssignBranch?.filter(
      (val) =>
        company?.map(comp => comp.value === val.company) && branch?.map(comp => comp.value === val.branch)
    )?.map(data => ({
      label: data.unit,
      value: data.unit,
    })).filter((item, index, self) => {
      return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
    })
    setSelectedUnit(unit);
    setValueUnit(
      unit.map((a, index) => {
        return a.value;
      })
    );
    // Create team options based on selected company, branch, and unit
    const team = allTeam
      ?.filter(val =>
        company.some(comp => comp.value === val.company) &&
        branch.some(br => br.value === val.branch) &&
        unit.some(uni => uni.value === val.unit)
      )
      .map(data => ({
        label: data.teamname,
        value: data.teamname,
      }));
    setSelectedTeam(team);
    setValueTeam(team.map(a => a.value));
    const allemployees = allUsersLimit
      ?.filter(val =>
        company.some(comp => comp.value === val.company) &&
        branch.some(br => br.value === val.branch) &&
        unit.some(uni => uni.value === val.unit) &&
        team.some(team => team.value === val.team)
      )
      .map(data => ({
        label: data.companyname,
        value: data.companyname,
      }));
    setSelectedEmp(allemployees);
    setValueEmp(allemployees.map(a => a.value));
  }, [isAssignBranch])

  //company multiselect
  const handleCompanyChange = (options) => {
    setValueCompany(
      options.map((a, index) => {
        return a.value;
      })
    );
    setSelectedCompany(options);
    setSelectedBranch([]);
    setValueBranch([]);
    setSelectedUnit([]);
    setValueUnit([]);
    setSelectedTeam([]);
    setValueTeam([]);
    setSelectedDep([]);
    setValueDep([]);
    setSelectedEmp([]);
    setValueEmp([]);
  };

  const customValueRendererCompany = (valueCompany, _categoryname) => {
    return valueCompany?.length
      ? valueCompany.map(({ label }) => label)?.join(", ")
      : "Please Select Company";
  };

  //branchto multiselect dropdown changes
  const handleBranchChange = (options) => {
    setSelectedBranch(options);
    setValueBranch(
      options.map((a, index) => {
        return a.value;
      })
    );
    setSelectedUnit([]);
    setValueUnit([]);
    setSelectedTeam([]);
    setValueTeam([]);
    setSelectedEmp([]);
    setValueEmp([]);
    setSelectedDep([]);
    setValueDep([]);
  };

  const customValueRendererBranch = (valueCate, _employeename) => {
    return valueCate.length
      ? valueCate.map(({ label }) => label).join(", ")
      : "Please select Branch";
  };

  // unitto multiselect dropdown changes
  const handleUnitChange = (options) => {
    setSelectedUnit(options);
    setValueUnit(
      options.map((a, index) => {
        return a.value;
      })
    );
    setSelectedTeam([]);
    setValueTeam([]);
    setSelectedEmp([]);
    setValueEmp([]);
  };
  const customValueRendererUnit = (valueCate, _employeename) => {
    return valueCate.length
      ? valueCate.map(({ label }) => label).join(", ")
      : "Please select Unit";
  };

  //Teamto multiselect dropdown changes
  const handleTeamChange = (options) => {
    setSelectedTeam(options);
    setValueTeam(
      options.map((a, index) => {
        return a.value;
      })
    );
    setSelectedEmp([]);
    setValueEmp([]);
  };
  const customValueRendererTeam = (valueCate, _employeename) => {
    return valueCate.length
      ? valueCate.map(({ label }) => label).join(", ")
      : "Please select Team";
  };

  // Employee    
  const handleEmployeeChange = (options) => {
    setSelectedEmp(options);
    setValueEmp(
      options.map((a, index) => {
        return a.value;
      })
    );
  };

  const customValueRendererEmp = (valueCate, _employees) => {
    return valueCate.length
      ? valueCate.map(({ label }) => label).join(", ")
      : "Please Select Employee";
  };

  const [searchInputValue, setSearchInputValue] = useState('');
  const [isBoxFocused, setIsBoxFocused] = React.useState(false);

  const handlePasteForEmp = (e) => {
    e.preventDefault();
    const pastedText = e.clipboardData.getData('text');

    // Process the pasted text
    const pastedNames = pastedText
      .split(/[\n,]+/)
      .map(name => name.trim())
      .filter(name => name !== "");

    // Update the state
    updateEmployees(pastedNames);

    // Clear the search input after paste
    setSearchInputValue('');

    // Refocus the element
    e.target.focus();
  };

  useEffect(() => {
    updateEmployees([]); // Pass an empty array instead of an empty string
  }, [allUsersLimit, valueCompany, valueBranch, valueUnit, valueTeam]);

  const updateEmployees = (pastedNames) => {

    const namesArray = Array.isArray(pastedNames) ? pastedNames : [];

    const availableOptions = allUsersLimit
      ?.filter(
        (comp) =>
          valueCompany?.includes(comp.company) &&
          valueBranch?.includes(comp.branch) &&
          valueUnit?.includes(comp.unit) &&
          valueTeam?.includes(comp.team)
      )
      ?.map(data => data.companyname.replace(/\s*\.\s*/g, ".").trim())

    const matchedValues = namesArray.filter((name) =>
      availableOptions.includes(name.replace(/\s*\.\s*/g, ".").trim())
    );

    // Update selected options
    const newOptions = matchedValues.map(value => ({
      label: value,
      value: value
    }));

    setSelectedEmp(prev => {
      const newValues = newOptions.filter(
        newOpt => !prev.some(prevOpt => prevOpt.value === newOpt.value)
      );
      return [...prev, ...newValues];
    });

    // Update other states...
    setValueEmp(prev => [...new Set([...prev, ...matchedValues])]);
  };

  // Handle clicks outside the Box
  useEffect(() => {
    const handleClickOutside = (e) => {
      const boxElement = document.getElementById("paste-box"); // Add an ID to the Box
      if (boxElement && !boxElement.contains(e.target)) {
        setIsBoxFocused(false); // Reset focus state if clicking outside the Box
      }
    };

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const handleDelete = (e, value) => {
    e.preventDefault();
    setSelectedEmp((current) => current.filter(emp => emp.value !== value));
    setValueEmp((current) => current.filter(empValue => empValue !== value));
  };

  // Department
  const handleDepartmentChange = (options) => {
    setSelectedDep(options);
    setValueDep(
      options.map((a, index) => {
        return a.value;
      })
    );
  };

  const customValueRendererDepartment = (valueDep, _categoryname) => {
    return valueDep?.length
      ? valueDep.map(({ label }) => label)?.join(", ")
      : "Please Select Department";
  };

  const getattendancestatus = (alldata) => {
    // console.log(alldata?.clockinstatus, alldata?.clockoutstatus)
    let result = attStatus.filter((data, index) => {
      return data?.clockinstatus === alldata?.clockinstatus && data?.clockoutstatus === alldata?.clockoutstatus
    })
    return result[0]?.name
  }

  const getAttModeAppliedThr = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.appliedthrough
  }

  const getAttModeLop = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.lop === true ? 'Yes' : 'No';
  }

  const getAttModeLopType = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.loptype
  }

  const getFinalLop = (rowlop, rowloptype) => {
    return (rowloptype === undefined || rowloptype === "") ? rowlop : (rowlop + ' - ' + rowloptype);
  }

  const getAttModeTarget = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.target === true ? 'Yes' : 'No';
  }

  const getAttModePaidPresent = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.paidleave === true ? 'Yes' : 'No';
  }

  const getAttModePaidPresentType = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus
    })
    return result[0]?.paidleavetype;
  }

  const getFinalPaid = (rowpaid, rowpaidtype) => {
    return (rowpaidtype === undefined || rowpaidtype === "") ? rowpaid : (rowpaid + ' - ' + rowpaidtype);
  }

  const getAssignLeaveDayForLop = (rowlopday) => {
    if (rowlopday === 'Yes - Double Day') {
      return '2'
    } else if (rowlopday === 'Yes - Full Day') {
      return '1';
    } else if (rowlopday === 'Yes - Half Day') {
      return '0.5'
    } else {
      return '0';
    }
  }

  const getAssignLeaveDayForPaid = (rowpaidday) => {
    if (rowpaidday === 'Yes - Double Day') {
      return '2'
    } else if (rowpaidday === 'Yes - Full Day') {
      return '1';
    } else if (rowpaidday === 'Yes - Half Day') {
      return '0.5'
    } else {
      return '0';
    }
  }

  const getCount = (rowlopstatus) => {
    if (rowlopstatus === 'Yes - Double Day') {
      return '2'
    } else if (rowlopstatus === 'Yes - Full Day') {
      return '1';
    } else if (rowlopstatus === 'Yes - Half Day') {
      return '0.5'
    } else {
      return '0';
    }
  }

  const getIsWeekoff = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus;
    })
    return result[0]?.weekoff === true ? 'Yes' : 'No';
  }

  const getIsHoliday = (rowdaystatus) => {
    let result = attModearr.filter((data, index) => {
      return data?.name === rowdaystatus;
    })
    return result[0]?.holiday === true ? 'Yes' : 'No';
  }

  function getMonthsInRange(fromdate, todate) {
    const startDate = new Date(fromdate);
    const endDate = new Date(todate);
    const monthNames = [
      "January", "February", "March", "April", "May", "June",
      "July", "August", "September", "October", "November", "December"
    ];

    const result = [];

    // Previous month based on `fromdate`
    const prevMonth = startDate.getMonth() === 0 ? 11 : startDate.getMonth() - 1;
    const prevYear = startDate.getMonth() === 0 ? startDate.getFullYear() - 1 : startDate.getFullYear();
    result.push({ month: monthNames[prevMonth], year: prevYear.toString() });

    // Add selected months between `fromdate` and `todate`
    const currentDate = new Date(startDate);
    currentDate.setDate(1); // Normalize to the start of the month
    while (
      currentDate.getFullYear() < endDate.getFullYear() ||
      (currentDate.getFullYear() === endDate.getFullYear() && currentDate.getMonth() <= endDate.getMonth())
    ) {
      result.push({
        month: monthNames[currentDate.getMonth()],
        year: currentDate.getFullYear().toString()
      });
      currentDate.setMonth(currentDate.getMonth() + 1);
    }

    // Next month based on `todate`
    const nextMonth = endDate.getMonth() === 11 ? 0 : endDate.getMonth() + 1;
    const nextYear = endDate.getMonth() === 11 ? endDate.getFullYear() + 1 : endDate.getFullYear();
    result.push({ month: monthNames[nextMonth], year: nextYear.toString() });

    return result;
  }

  const fetchFilteredUsersStatus = async () => {
    setPageName(!pageName)
    setUserShifts([]);
    setLoader(true);
    setPageUserShiftSummary(1);
    setPageSizeUserShiftSummary(10);

    try {

      let res_emp = await axios.post(SERVICE.USER_FOR_ALL_ATTENDANCE_PAGE_INDIVIDUAL_TYPE, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
        type: filterUser.filtertype,
        company: [...valueCompany],
        branch: [...valueBranch],
        unit: [...valueUnit],
        team: [...valueTeam],
        employee: [...valueEmp],
        department: [...valueDep],
        assignbranch: accessbranch,
      });

      let res = await axios.get(`${SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      let attendanceCriteriaData = res?.data?.attendancecontrolcriteria[0];

      // console.log(res_emp?.data?.users.length, 'userResult')

      function splitArray(array, chunkSize) {
        const resultarr = [];
        for (let i = 0; i < array.length; i += chunkSize) {
          const chunk = array.slice(i, i + chunkSize);
          resultarr.push({
            data: chunk,
          });
        }
        return resultarr;
      }
      // console.log(res_emp?.data?.users, 'res_emp?.data?.users')
      let employeelistnames = res_emp?.data?.users.length > 0 ? [...new Set(res_emp?.data?.users.map(item => item.companyname))] : []
      const resultarr = splitArray(employeelistnames, 10);
      // console.log(resultarr, 'resultarr')

      const montharray = getMonthsInRange(filterUser.fromdate, filterUser.todate);
      // console.log(montharray);

      async function sendBatchRequest(batch) {
        try {
          let res_applyleave = await axios.post(SERVICE.APPLYLEAVE_APPROVED, {
            headers: {
              Authorization: `Bearer ${auth.APIToken}`,
            },
            employee: batch.data,
          });

          let leaveresult = res_applyleave?.data?.applyleaves?.filter(data => data.leavetype !== 'Leave Without Pay (LWP)');
          let leaveresultWithoutPay = res_applyleave?.data?.applyleaves?.filter(data => data.leavetype === 'Leave Without Pay (LWP)');

          let res = await axios.post(SERVICE.USER_CLOCKIN_CLOCKOUT_STATUS_FILTER, {
            employee: batch.data,
            // attDates: daysArray,
            fromdate: filterUser.fromdate,
            todate: filterUser.todate,
            montharray: [...montharray],
          }, {
            headers: {
              Authorization: `Bearer ${auth.APIToken}`,
            }
          })

          let res_type = await axios.get(SERVICE.LEAVETYPE, {
            headers: {
              Authorization: `Bearer ${auth.APIToken}`,
            },
          });

          let resdatawithlwp = [...res_type?.data?.leavetype, { leavetype: 'Leave Without Pay (LWP)', code: "LWP" }]

          let leavestatusApproved = [];
          resdatawithlwp?.map((type) => {
            res_applyleave?.data?.applyleaves && res_applyleave?.data?.applyleaves?.forEach((d) => {
              if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Single' && d.leavestatus === 'Shift') {
                leavestatusApproved.push(type.code + ' ' + d.status)
              }
              if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double' && d.leavestatus === 'Shift') {
                leavestatusApproved.push('DL' + ' - ' + type.code + ' ' + d.status)
              }
              if (type.leavetype === d.leavetype && d.tookleavecheckstatus === 'Double Day' && d.leavestatus === 'Shift') {
                leavestatusApproved.push('DDL' + ' - ' + type.code + ' ' + d.status)
              }
            });
          });

          const rearr = [...new Set(leavestatusApproved)];

          // console.log(rearr, 'rearr')

          const filtered = res?.data?.finaluser?.filter(d => {
            const formattedDate = new Date(d.finalDate);
            const reasonDate = new Date(d.reasondate);
            const dojDate = new Date(d.doj);

            if (d.reasondate && d.reasondate !== "") {
              return (formattedDate <= reasonDate);
            } else if (d.doj && d.doj !== "") {
              return (formattedDate >= dojDate);
            } else {
              return d;
            }
          });
          // console.log(res?.data?.finaluser, 'filteredBatch')

          const findPreviousNonWeekOff = (items, index) => {
            for (let i = index - 1; i >= 0; i--) {
              if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                return items[i];
              }
            }
            return null;
          };

          const findNextNonWeekOff = (items, index) => {
            for (let i = index + 1; i < items.length; i++) {
              if (items[i].clockinstatus !== 'Week Off' && items[i].clockoutstatus !== 'Week Off') {
                return items[i];
              }
            }
            return null;
          };

          const changedWeekoffResult = filtered?.map((item, index) => {
            let updatedClockInStatus = item.clockinstatus;
            let updatedClockOutStatus = item.clockoutstatus;

            const itemDate = moment(item.rowformattedDate, "DD/MM/YYYY");

            // For Week Off status
            if (item.clockinstatus === 'Week Off' && item.clockoutstatus === 'Week Off') {
              const prev = findPreviousNonWeekOff(filtered, index);
              const next = findNextNonWeekOff(filtered, index);

              const isPrevLeave = leaveresult.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
              const isPrevAbsent = prev && prev.empcode === item.empcode && prev.clockinstatus === 'Absent' && prev.clockoutstatus === 'Absent' && prev.clockin === '00:00:00' && prev.clockout === '00:00:00';

              const isNextLeave = leaveresult.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
              const isNextAbsent = next && next.empcode === item.empcode && next.clockinstatus === 'Absent' && next.clockoutstatus === 'Absent' && next.clockin === '00:00:00' && next.clockout === '00:00:00';

              const isPrevLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => prev && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(prev.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);
              const isNextLeaveWithoutPay = leaveresultWithoutPay.some(leaveItem => next && moment(leaveItem.date, "DD/MM/YYYY").isSame(moment(next.rowformattedDate, "DD/MM/YYYY"), 'day') && leaveItem.empcode === item.empcode);

              if (isPrevLeave && isNextLeave) {
                updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffLeave';
              } else if (isPrevAbsent && isNextAbsent) {
                updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
              } else if (isPrevLeaveWithoutPay && isNextLeaveWithoutPay) {
                updatedClockInStatus = updatedClockOutStatus = 'BeforeAndAfterWeekOffAbsent';
              } else if (isPrevLeave) {
                updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffLeave';
              } else if (isPrevAbsent || isPrevLeaveWithoutPay) {
                updatedClockInStatus = updatedClockOutStatus = 'BeforeWeekOffAbsent';
              } else if (isNextLeave) {
                updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffLeave';
              } else if (isNextAbsent || isNextLeaveWithoutPay) {
                updatedClockInStatus = updatedClockOutStatus = 'AfterWeekOffAbsent';
              }
            }

            return {
              ...item,
              clockinstatus: updatedClockInStatus,
              clockoutstatus: updatedClockOutStatus,
            };
          });
          // console.log(changedWeekoffResult, 'changedWeekoffResult')

          const resultBefore = [];

          const empGrouped = {};

          changedWeekoffResult.forEach(item => {
            if (!empGrouped[item.empcode]) empGrouped[item.empcode] = [];
            empGrouped[item.empcode].push(item);
          });

          const leaveStatuses = [
            ...rearr,
            "Absent", "BL - Absent",
          ];

          // console.log(leaveStatuses, 'leaveStatuses')
          Object.keys(empGrouped).forEach(empcode => {
            const records = empGrouped[empcode]
              .sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

            let streak = [];
            let counterIn = 1;
            let counterOut = 1;

            for (let i = 0; i < records.length; i++) {
              const current = records[i];
              const isWeekOff = current.shift === "Week Off";
              const isShiftNotStarted = current.clockinstatus === 'Shift Not Started' && current.clockoutstatus === 'Shift Not Started'

              const isLeaveDay =
                current.clockin === "00:00:00" &&
                current.clockout === "00:00:00" &&
                leaveStatuses.includes(current.clockinstatus) &&
                !isWeekOff && !isShiftNotStarted;

              if (isLeaveDay) {
                streak.push(current);
              } else if (isWeekOff) {
                // Push Week Off directly, don’t reset streak
                resultBefore.push(current);
              } else {
                // Encountered present day, finalize streak
                if (streak.length > attendanceCriteriaData?.longabsentcount) {
                  streak.forEach(day => {
                    let clockinstatus = day.clockinstatus;
                    let clockoutstatus = day.clockoutstatus;

                    if (clockinstatus === "Absent") {
                      clockinstatus = `${counterIn++}Long Absent`;
                    } else if (clockinstatus === "BL - Absent") {
                      clockinstatus = `${counterIn++}Long BL - Absent`;
                    } else if (rearr?.includes(clockinstatus)) {
                      clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                    }

                    if (clockoutstatus === "Absent") {
                      clockoutstatus = `${counterOut++}Long Absent`;
                    } else if (clockoutstatus === "BL - Absent") {
                      clockoutstatus = `${counterOut++}Long BL - Absent`;
                    } else if (rearr?.includes(clockoutstatus)) {
                      clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                    }

                    resultBefore.push({
                      ...day,
                      clockinstatus,
                      clockoutstatus
                    });
                  });
                } else {
                  resultBefore.push(...streak); // push as-is
                }

                resultBefore.push(current); // current present day
                streak = [];
                counterIn = 1;
                counterOut = 1;
              }
            }

            // Remaining streak at end
            if (streak.length > attendanceCriteriaData?.longabsentcount) {
              streak.forEach(day => {
                let clockinstatus = day.clockinstatus;
                let clockoutstatus = day.clockoutstatus;

                if (clockinstatus === "Absent") {
                  clockinstatus = `${counterIn++}Long Absent`;
                } else if (clockinstatus === "BL - Absent") {
                  clockinstatus = `${counterIn++}Long BL - Absent`;
                } else if (rearr?.includes(clockinstatus)) {
                  clockinstatus = `${counterIn++}Long Leave ${rearr?.filter(d => d === clockinstatus)}`;
                }

                if (clockoutstatus === "Absent") {
                  clockoutstatus = `${counterOut++}Long Absent`;
                } else if (clockoutstatus === "BL - Absent") {
                  clockoutstatus = `${counterOut++}Long BL - Absent`;
                } else if (rearr?.includes(clockoutstatus)) {
                  clockoutstatus = `${counterOut++}Long Leave ${rearr?.filter(d => d === clockoutstatus)}`;
                }

                resultBefore.push({
                  ...day,
                  clockinstatus,
                  clockoutstatus
                });
              });
            } else {
              resultBefore.push(...streak);
            }
          });
          resultBefore.sort((a, b) => moment(a.rowformattedDate, "DD/MM/YYYY") - moment(b.rowformattedDate, "DD/MM/YYYY"));

          // console.log(resultBefore, 'resultBefore')

          // Group data by empcode
          let groupedData = {};
          resultBefore.forEach((item) => {
            if (!groupedData[item.empcode]) {
              groupedData[item.empcode] = {
                attendanceRecords: [],
                departmentDateSet: item.departmentDateSet || [],
              };
            }
            groupedData[item.empcode].attendanceRecords.push(item);
          });
          // console.log(groupedData, 'groupedData')
          let result = [];

          for (let empcode in groupedData) {
            let { attendanceRecords, departmentDateSet } = groupedData[empcode];

            departmentDateSet.forEach((dateRange) => {
              let { fromdate, todate, department } = dateRange;

              let countByEmpcodeClockin = {};
              let countByEmpcodeClockout = {};

              let recordsInDateRange = attendanceRecords.filter((record) => {
                let formattedDate = new Date(record.finalDate);
                return department === record.department && formattedDate >= new Date(fromdate) && formattedDate <= new Date(todate);
              });

              let processedRecords = recordsInDateRange.map((item) => {
                let formattedDate = new Date(item.finalDate);
                let reasonDate = item.reasondate ? new Date(item.reasondate) : null;
                let dojDate = item.doj ? new Date(item.doj) : null;

                let updatedClockInStatus = item.clockinstatus;
                let updatedClockOutStatus = item.clockoutstatus;

                // Check if the date falls within the reasonDate or dojDate
                if (reasonDate && formattedDate > reasonDate) {
                  return null;
                }
                if (dojDate && formattedDate < dojDate) {
                  return null;
                }

                // Handling Late Clock-in and Early Clock-out
                if (!countByEmpcodeClockin[item.empcode]) {
                  countByEmpcodeClockin[item.empcode] = 1;
                }
                if (!countByEmpcodeClockout[item.empcode]) {
                  countByEmpcodeClockout[item.empcode] = 1;
                }

                if (updatedClockInStatus === "Late - ClockIn") {
                  updatedClockInStatus = `${countByEmpcodeClockin[item.empcode]}Late - ClockIn`;
                  countByEmpcodeClockin[item.empcode]++;
                }

                if (updatedClockOutStatus === "Early - ClockOut") {
                  updatedClockOutStatus = `${countByEmpcodeClockout[item.empcode]}Early - ClockOut`;
                  countByEmpcodeClockout[item.empcode]++;
                }

                return {
                  ...item,
                  department,
                  fromdate,
                  todate,
                  clockinstatus: updatedClockInStatus,
                  clockoutstatus: updatedClockOutStatus,
                };
              });

              result.push(...processedRecords.filter(Boolean));
            });
          }

          // console.log(result, 'result')

          const itemsWithSerialNumber = result?.map((item) => (
            {
              ...item,
              id: item.id,
              shiftmode: item.shiftMode,
              uniqueid: item.id,
              userid: item.userid,
              attendanceauto: getattendancestatus(item),
              daystatus: item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item),
              appliedthrough: getAttModeAppliedThr(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              lop: getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              loptype: getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              lopcalculation: getFinalLop(
                getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
              ),
              lopcount: getCount(
                getFinalLop(
                  getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                  getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                )
              ),
              modetarget: getAttModeTarget(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              paidpresentbefore: getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              paidleavetype: getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              paidpresent: getFinalPaid(
                getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
              ),
              lopday: getAssignLeaveDayForLop(
                getFinalLop(
                  getAttModeLop(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                  getAttModeLopType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                )
              ),
              paidpresentday: getAssignLeaveDayForPaid(
                getFinalPaid(
                  getAttModePaidPresent(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
                  getAttModePaidPresentType(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item))
                )
              ),
              isweekoff: getIsWeekoff(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
              isholiday: getIsHoliday(item.attendanceautostatus ? item.attendanceautostatus : getattendancestatus(item)),
            }));

          // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber bef')
          const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

          function getPreviousRelevantEntry(index, array) {
            for (let i = index - 1; i >= 0; i--) {
              if (array[i].shift !== 'Week Off') {
                return array[i];
              }
            }
            return null;
          }

          function getNextRelevantEntry(index, array) {
            for (let i = index + 1; i < array.length; i++) {
              if (array[i].shift !== 'Week Off') {
                return array[i];
              }
            }
            return null;
          }

          itemsWithSerialNumber.forEach((item, index, array) => {
            if (item.shift === 'Week Off') {
              const previousItem = getPreviousRelevantEntry(index, array);
              const nextItem = getNextRelevantEntry(index, array);

              const isLopRelevant = (entry) => entry && (entry.lopcalculation === 'Yes - Full Day' || entry.lopcalculation === 'Yes - Double Day');

              const isPreviousManualPaidFull =
                previousItem &&
                previousItem.appliedthrough === 'Manual' &&
                previousItem.paidpresent === 'Yes - Full Day';

              const isNextManualPaidFull =
                nextItem &&
                nextItem.appliedthrough === 'Manual' &&
                nextItem.paidpresent === 'Yes - Full Day';

              const isPrevLop = isLopRelevant(previousItem) && !isPreviousManualPaidFull;
              const isNextLop = isLopRelevant(nextItem) && !isNextManualPaidFull;

              if (isPrevLop && isNextLop) {
                item.clockinstatus = 'BeforeAndAfterWeekOffAbsent';
                item.clockoutstatus = 'BeforeAndAfterWeekOffAbsent';
              } else if (isPrevLop) {
                item.clockinstatus = 'BeforeWeekOffAbsent';
                item.clockoutstatus = 'BeforeWeekOffAbsent';
              } else if (isNextLop) {
                item.clockinstatus = 'AfterWeekOffAbsent';
                item.clockoutstatus = 'AfterWeekOffAbsent';
              }

              // Recalculate attendance status if needed
              item.attendanceauto = getattendancestatus(item);
              item.daystatus = item.attendanceautostatus || getattendancestatus(item);
              item.appliedthrough = getAttModeAppliedThr(item.attendanceautostatus || getattendancestatus(item));
              item.lop = getAttModeLop(item.attendanceautostatus || getattendancestatus(item));
              item.loptype = getAttModeLopType(item.attendanceautostatus || getattendancestatus(item));
              item.lopcalculation = getFinalLop(
                getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
              );
              item.lopcount = getCount(
                getFinalLop(
                  getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                  getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                )
              );
              item.modetarget = getAttModeTarget(item.attendanceautostatus || getattendancestatus(item));
              item.paidpresentbefore = getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item));
              item.paidleavetype = getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item));
              item.paidpresent = getFinalPaid(
                getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
              );
              item.lopday = getAssignLeaveDayForLop(
                getFinalLop(
                  getAttModeLop(item.attendanceautostatus || getattendancestatus(item)),
                  getAttModeLopType(item.attendanceautostatus || getattendancestatus(item))
                )
              );
              item.paidpresentday = getAssignLeaveDayForPaid(
                getFinalPaid(
                  getAttModePaidPresent(item.attendanceautostatus || getattendancestatus(item)),
                  getAttModePaidPresentType(item.attendanceautostatus || getattendancestatus(item))
                )
              );
              item.isweekoff = getIsWeekoff(item.attendanceautostatus || getattendancestatus(item));
              item.isholiday = getIsHoliday(item.attendanceautostatus || getattendancestatus(item));

            }
            if (attStatusOption.includes(item.daystatus) && item.clockin === "00:00:00" && item.clockout === "00:00:00" && item.appliedthrough === 'Manual' && item.paidpresent === "Yes - Full Day") {
              const previousItem = array[index - 1];
              const nextItem = array[index + 1];

              const hasRelevantStatus = (entry) => entry && ((weekOption.includes(entry.clockinstatus) || weekOption.includes(entry.clockoutstatus)) && entry.shift === 'Week Off');

              if (hasRelevantStatus(previousItem)) {
                if (!weekOption.includes(previousItem.clockinstatus)) {
                  previousItem.clockinstatus = 'Week Off';
                  previousItem.clockoutstatus = 'Week Off';
                  previousItem.attendanceauto = getattendancestatus(previousItem);
                  previousItem.daystatus = previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem);
                  previousItem.appliedthrough = getAttModeAppliedThr(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.lop = getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.loptype = getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.lopcalculation = getFinalLop(
                    getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                    getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                  );
                  previousItem.lopcount = getCount(
                    getFinalLop(
                      getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                      getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                    )
                  );
                  previousItem.modetarget = getAttModeTarget(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.paidpresentbefore = getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.paidleavetype = getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.paidpresent = getFinalPaid(
                    getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                    getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                  );
                  previousItem.lopday = getAssignLeaveDayForLop(
                    getFinalLop(
                      getAttModeLop(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                      getAttModeLopType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                    )
                  );
                  previousItem.paidpresentday = getAssignLeaveDayForPaid(
                    getFinalPaid(
                      getAttModePaidPresent(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem)),
                      getAttModePaidPresentType(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem))
                    )
                  );
                  previousItem.isweekoff = getIsWeekoff(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                  previousItem.isholiday = getIsHoliday(previousItem.attendanceautostatus ? previousItem.attendanceautostatus : getattendancestatus(previousItem));
                }
              }
              if (hasRelevantStatus(nextItem)) {
                if (!weekOption.includes(nextItem.clockinstatus)) {
                  nextItem.clockinstatus = 'Week Off';
                  nextItem.clockoutstatus = 'Week Off';
                  nextItem.attendanceauto = getattendancestatus(nextItem);
                  nextItem.daystatus = nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem);
                  nextItem.appliedthrough = getAttModeAppliedThr(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.lop = getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.loptype = getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.lopcalculation = getFinalLop(
                    getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                    getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                  );
                  nextItem.lopcount = getCount(
                    getFinalLop(
                      getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                      getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                    )
                  );
                  nextItem.modetarget = getAttModeTarget(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.paidpresentbefore = getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.paidleavetype = getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.paidpresent = getFinalPaid(
                    getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                    getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                  );
                  nextItem.lopday = getAssignLeaveDayForLop(
                    getFinalLop(
                      getAttModeLop(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                      getAttModeLopType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                    )
                  );
                  nextItem.paidpresentday = getAssignLeaveDayForPaid(
                    getFinalPaid(
                      getAttModePaidPresent(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem)),
                      getAttModePaidPresentType(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem))
                    )
                  );
                  nextItem.isweekoff = getIsWeekoff(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                  nextItem.isholiday = getIsHoliday(nextItem.attendanceautostatus ? nextItem.attendanceautostatus : getattendancestatus(nextItem));
                }
              }
            }
          })
          // console.log(itemsWithSerialNumber, 'itemsWithSerialNumber')
          let finalResult = itemsWithSerialNumber.filter(data => data.finalDate >= filterUser.fromdate && data.finalDate <= filterUser.todate);

          return finalResult;

        } catch (err) {
          console.error("Error in POST request for batch:", batch.data, err);
        }
      }

      async function getAllResults() {
        let allResults = [];
        for (let batch of resultarr) {
          const finaldata = await sendBatchRequest(batch);
          allResults = allResults.concat(finaldata);
        }

        return { allResults }; // Return both results as an object
      }

      getAllResults().then(async (results) => {
        // console.log(results, 'results')
        let res_applyleave = await axios.post(SERVICE.APPLYLEAVE_APPROVED, {
          headers: {
            Authorization: `Bearer ${auth.APIToken}`,
          },
          employee: results.allResults?.map(data => data.username),
        });

        let leaveresult = res_applyleave?.data?.applyleaves?.filter(data => data.leavetype !== 'Leave Without Pay (LWP)');

        let res_permission = await axios.post(SERVICE.PERMISSIONS_APPROVED, {
          headers: {
            Authorization: `Bearer ${auth.APIToken}`,
          },
          employee: results.allResults?.map(data => data.username),
        });
        let permissionresult = res_permission?.data?.permissions;

        const finalresult = [];
        let totalemployeesArray = [];
        let totalcurrentshiftArray = [];
        let paidpresentdayArray = [];
        let absentArray = [];
        let totalinArray = [];
        let totaloutArray = [];
        let totalpendingArray = [];
        let facilitypresentArray = [];
        let wfhpresentArray = [];
        let facilityabsentArray = [];
        let wfhabsentArray = [];
        let earlyclockinArray = [];
        let onpresentArray = [];
        let graceclockinArray = [];
        let lateclockinArray = [];
        let weekoffArray = [];
        let holidayArray = [];
        let permissionArray = [];
        let clslArray = [];
        let onclockoutArray = [];
        let earlyclockoutArray = [];
        let overclockoutArray = [];
        let autoclockoutArray = [];
        let shiftnotstartedArray = [];
        let nostatusArray = [];
        let notallottedArray = [];
        let weekoffpresentArray = [];
        let longleaveabsentArray = [];
        let blabsentArray = [];
        let doubledayabsentArray = [];
        let weekoffabsentArray = [];

        results.allResults?.forEach(item => {
          // console.log(item, 'item')
          const leaveOnDateApproved = leaveresult.find((d) => d.date === item.rowformattedDate && d.empcode === item.empcode);
          const permissionOnDateApproved = permissionresult.find((d) => d.date === item.finalDate && d.employeeid === item.empcode);
          const weekOption = ['BeforeWeekOffAbsent', 'AfterWeekOffAbsent', 'BeforeWeekOffLeave', 'AfterWeekOffLeave', 'BeforeAndAfterWeekOffAbsent', 'BeforeAndAfterWeekOffLeave'];

          // employee
          if (item.username !== '') {
            totalemployeesArray.push(item);
          }

          // current shift
          if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
            totalcurrentshiftArray.push(item);
          }

          // present
          if (item.isweekoff !== 'Yes' && item.isholiday !== 'Yes' && !leaveOnDateApproved && (item.paidpresent === 'Yes - Full Day' || item.paidpresent === 'Yes - Half Day')) {
            paidpresentdayArray.push(item);
          }

          // absent
          if (item.lopcalculation === 'Yes - Full Day' || item.lopcalculation === 'Yes - Half Day' || item.lopcalculation === 'Yes - Double Day' || item.lopcalculation === 'Yes - Double Half Day') {
            absentArray.push(item);
          }

          // totalin
          if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
            totalinArray.push(item);
          }

          // totalout
          if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
            totaloutArray.push(item);
          }

          // facilitypresent
          if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
            facilitypresentArray.push(item);
          }

          // wfhpresent
          if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
            wfhpresentArray.push(item);
          }

          // facilityabsent
          if (item.workmode !== 'Remote' && item.lop === 'Yes') {
            facilityabsentArray.push(item);
          }

          // wfhabsent
          if (item.workmode === 'Remote' && item.lop === 'Yes') {
            wfhabsentArray.push(item);
          }

          // earlyclockin
          if (item.clockinstatus?.includes('Early - ClockIn')) {
            earlyclockinArray.push(item);
          }

          // onpresent
          if (item.clockinstatus === 'On - Present') {
            onpresentArray.push(item);
          }

          // gracetime
          if (item.clockinstatus === 'Grace - ClockIn') {
            graceclockinArray.push(item);
          }

          // lateclockin
          if (item.clockinstatus?.includes('Late - ClockIn')) {
            lateclockinArray.push(item);
          }

          // weekoff
          let weekoffdayscount = 0;
          if (item.isweekoff === 'Yes') {
            weekoffdayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
            weekoffArray.push(item);
          }

          // holiday
          let holidaydayscount = 0;
          if (item.isholiday === 'Yes') {
            holidaydayscount = item.paidpresent === "Yes - Full Day" ? 1 : 0.5;
            holidayArray.push(item);
          }

          // permission
          if (permissionOnDateApproved) {
            permissionArray.push(item);
          }

          // clsl
          if (leaveOnDateApproved) {
            clslArray.push(item);
          }

          // onclockout
          if (item.clockoutstatus === 'On - ClockOut') {
            onclockoutArray.push(item);
          }

          // earlyclockout
          if (item.clockoutstatus?.includes('Early - ClockOut')) {
            earlyclockoutArray.push(item);
          }

          // overclockout
          if (item.clockoutstatus === 'Over - ClockOut') {
            overclockoutArray.push(item);
          }

          // automisclockout
          if (item.clockoutstatus === 'Auto Mis - ClockOut') {
            autoclockoutArray.push(item);
          }

          // shiftnotstarted
          if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
            shiftnotstartedArray.push(item);
          }

          // nostatus
          if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
            nostatusArray.push(item);
          }

          // notallotted
          if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
            notallottedArray.push(item);
          }

          // weekoffpresent
          if (item.weekoffpresentstatus === true) {
            weekoffpresentArray.push(item);
          }

          // longleave and longabsent
          if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
            longleaveabsentArray.push(item);
          }

          // blabsent
          if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
            blabsentArray.push(item);
          }

          // doubledayabsent
          if (item.lopcalculation?.includes("Double")) {
            doubledayabsentArray.push(item);
          }

          // weekoffabsent
          if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
            weekoffabsentArray.push(item);
          }

          const existingEntryIndex = finalresult.findIndex(entry => entry.empcode === item.empcode);

          if (existingEntryIndex !== -1) {

            // employee
            if (item.username !== '') {
              finalresult[existingEntryIndex].username++;
            }

            // current shift
            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // present
            if (item.paidpresentbefore === 'Yes') {
              finalresult[existingEntryIndex].paidpresentday++;
            }

            // absent
            if (item.lop === 'Yes') {
              finalresult[existingEntryIndex].lopcount++;
            }

            // totalin
            if (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) {
              finalresult[existingEntryIndex].clockin++;
            }

            // totalout
            if (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') {
              finalresult[existingEntryIndex].clockout++;
            }

            // facilitypresent
            if (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') {
              finalresult[existingEntryIndex].workmode++;
            }

            // wfhpresent
            if (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') {
              finalresult[existingEntryIndex].workmode++;
            }

            // facilityabsent
            if (item.workmode !== 'Remote' && item.lop === 'Yes') {
              finalresult[existingEntryIndex].workmode++;
            }

            // wfhabsent
            if (item.workmode === 'Remote' && item.lop === 'Yes') {
              finalresult[existingEntryIndex].workmode++;
            }

            // earlyclockin
            if (item.clockinstatus?.includes('Early - ClockIn')) {
              finalresult[existingEntryIndex].clockin++;
            }

            // onpresent
            if (item.clockinstatus === 'On - Present') {
              finalresult[existingEntryIndex].clockin++;
            }

            // gracetime
            if (item.clockinstatus === 'Grace - ClockIn') {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // lateclockin
            if (item.clockinstatus?.includes('Late - ClockIn')) {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // weekoff
            if (item.isweekoff === 'Yes') {
              finalresult[existingEntryIndex].weekoff++;
            }

            // holiday
            if (item.isholiday === 'Yes') {
              finalresult[existingEntryIndex].holidayCount++;
            }

            // permission
            if (permissionOnDateApproved) {
              finalresult[existingEntryIndex].permissionCount++;
            }

            // clsl
            if (leaveOnDateApproved) {
              finalresult[existingEntryIndex].leaveCount++;
            }

            // shift
            if (item.shift !== 'Not Allotted') {
              finalresult[existingEntryIndex].shift++;
            }

            // onclockout
            if (item.clockoutstatus === 'On - ClockOut') {
              finalresult[existingEntryIndex].clockoutstatus++;
            }

            // earlyclockout
            if (item.clockoutstatus?.includes('Early - ClockOut')) {
              finalresult[existingEntryIndex].clockoutstatus++;
            }

            // overclockout
            if (item.clockoutstatus === 'Over - ClockOut') {
              finalresult[existingEntryIndex].clockoutstatus++;
            }

            // automisclockout
            if (item.clockoutstatus === 'Auto Mis - ClockOut') {
              finalresult[existingEntryIndex].clockoutstatus++;
            }

            // shiftnotstarted
            if (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // nostatus
            if (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.attendanceauto === undefined && item.daystatus === undefined) {
              finalresult[existingEntryIndex].nostatus++;
            }

            // notallotted
            if (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // weekoffpresent
            if (item.weekoffpresentstatus === true) {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // longleave and longabsent
            if (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // blabsent
            if (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // doubledayabsent
            if (item.lopcalculation?.includes("Double")) {
              finalresult[existingEntryIndex].lopcalculation++;
            }

            // weekoffabsent
            if (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) {
              finalresult[existingEntryIndex].clockinstatus++;
            }

            // Double Day Lop
            if (item.lopcalculation === 'Yes - Double Day') {
              finalresult[existingEntryIndex].doublelopcount++;
            }

            // Double Half Day
            if (item.lopcalculation === 'Yes - Double Half Day') {
              finalresult[existingEntryIndex].doublehalflopcount++;
            }

            // finalresult[existingEntryIndex].lopcount = String(parseFloat(finalresult[existingEntryIndex].lopcount) + parseFloat(item.lopcount));
            // finalresult[existingEntryIndex].paidpresentday = String(parseFloat(finalresult[existingEntryIndex].paidpresentday) + parseFloat(item.paidpresentday));

          } else {

            const inAndOutArray = [...totalinArray, ...totaloutArray];

            totalpendingArray = totalemployeesArray.filter(emp =>
              !inAndOutArray.some(io => io.username === emp.username)
            );

            const newItem = {
              id: item.id,
              empcode: item.empcode,
              username: item.username,
              company: item.company,
              branch: item.branch,
              unit: item.unit,
              team: item.team,
              department: item.department,
              totalnumberofdays: item.totalnumberofdays,
              empshiftdays: item.empshiftdays,
              shift: item.shift !== 'Not Allotted' ? 1 : 0,
              totalcounttillcurrendate: item.totalcounttillcurrendate,
              totalshift: item.totalshift,
              totalpaiddays: 0,

              // table count starts
              date: item.rowformattedDate,
              totalemployees: item.username !== '' ? 1 : 0,
              totalcurrentshift: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted') ? 1 : 0,
              paidpresentday: item.paidpresentbefore === 'Yes' ? 1 : 0,
              lopcount: item.lop === 'Yes' ? 1 : 0,
              totalin: (item.clockin !== '00:00:00' && (item.clockout === '00:00:00' || item.clockout === '' || item.clockout === undefined)) ? 1 : 0,
              totalout: (item.clockin !== '00:00:00' && item.clockout !== '00:00:00') ? 1 : 0,
              totalpending: 0,
              facilitypresent: (item.workmode !== 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
              wfhpresent: (item.workmode === 'Remote' && item.paidpresentbefore === 'Yes') ? 1 : 0,
              facilityabsent: (item.workmode !== 'Remote' && item.lop === 'Yes') ? 1 : 0,
              wfhabsent: (item.workmode === 'Remote' && item.lop === 'Yes') ? 1 : 0,
              earlyclockin: item.clockinstatus?.includes('Early - ClockIn') ? 1 : 0,
              onpresent: item.clockinstatus === 'On - Present' ? 1 : 0,
              graceclockin: item.clockinstatus === 'Grace - ClockIn' ? 1 : 0,
              lateclockin: item.clockinstatus?.includes('Late - ClockIn') ? 1 : 0,
              earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
              weekoff: weekoffdayscount,
              holidayCount: holidaydayscount,
              permissionCount: permissionOnDateApproved ? 1 : 0,
              leaveCount: leaveOnDateApproved ? 1 : 0,
              onclockout: item.clockoutstatus === 'On - ClockOut' ? 1 : 0,
              earlyclockout: item.clockoutstatus?.includes('Early - ClockOut') ? 1 : 0,
              overclockout: item.clockoutstatus === 'Over - ClockOut' ? 1 : 0,
              autoclockout: item.clockoutstatus === 'Auto Mis - ClockOut' ? 1 : 0,
              shiftnotstarted: (item.clockinstatus === 'Shift Not Started' && item.clockoutstatus === 'Shift Not Started') ? 1 : 0,
              nostatus: (item.clockinstatus !== 'Shift Not Started' && item.clockoutstatus !== 'Shift Not Started' && item.clockinstatus !== 'Not Allotted' && item.clockoutstatus !== 'Not Allotted' && item.paidpresent === 'No' && item.modetarget === 'No' && item.lopcalculation === 'No') ? 1 : 0,
              notallotted: (item.clockinstatus === 'Not Allotted' && item.clockoutstatus === 'Not Allotted') ? 1 : 0,
              weekoffpresent: item.weekoffpresentstatus === true ? 1 : 0,
              longleaveabsent: (item.clockinstatus?.includes('Long') && item.clockoutstatus?.includes('Long')) ? 1 : 0,
              blabsent: (item.clockinstatus === 'BL - Absent' && item.clockoutstatus === 'BL - Absent') ? 1 : 0,
              doubledayabsent: item.lopcalculation?.includes("Double") ? 1 : 0,
              weekoffabsent: (weekOption?.includes(item.clockinstatus) && weekOption?.includes(item.clockoutstatus)) ? 1 : 0,
              doublelopcount: item.lopcalculation === "Yes - Double Day" ? 1 : 0,
              doublehalflopcount: item.lopcalculation === "Double Half Day" ? 0.5 : 0,
              totalemployeesArray,
              totalcurrentshiftArray,
              paidpresentdayArray,
              absentArray,
              totalinArray,
              totaloutArray,
              totalpendingArray,
              facilitypresentArray,
              wfhpresentArray,
              facilityabsentArray,
              wfhabsentArray,
              earlyclockinArray,
              onpresentArray,
              graceclockinArray,
              lateclockinArray,
              weekoffArray,
              holidayArray,
              permissionArray,
              clslArray,
              onclockoutArray,
              earlyclockoutArray,
              overclockoutArray,
              autoclockoutArray,
              shiftnotstartedArray,
              nostatusArray,
              notallottedArray,
              weekoffpresentArray,
              longleaveabsentArray,
              blabsentArray,
              doubledayabsentArray,
              weekoffabsentArray,
            };
            // console.log(newItem, 'newitem')
            finalresult.push(newItem);
          }
        });
        // console.log(finalresult, ' fianlresult')

        let resultdata = finalresult?.map((item, index) => {
          const finalPaidPresentDays = Number(item.paidpresentday) - (Number(item.weekoff) + Number(item.holidayCount) + Number(item.leaveCount) + Number(item.doublelopcount) + Number(item.doublehalflopcount));
          // console.log(finalPaidPresentDays, 'finalPaidPresentDays')
          return {
            ...item,
            totalemployees: Number(item.totalemployees),
            lopcount: Number(item.lopcount),
            clsl: item.leaveCount,
            paidpresentday: finalPaidPresentDays < 0 ? 0 : finalPaidPresentDays,
          }
        });
        // console.log(resultdata, ' resultdata')

        let groupedResult = [];

        if (['Company', 'Branch', 'Unit', 'Team'].includes(filterUser.filtertype)) {
          groupedResult = resultdata.reduce((acc, curr, index) => {
            let groupKey = '';

            if (filterUser.filtertype === 'Company') {
              groupKey = `${curr.company}/${curr.branch}`;
            } else if (filterUser.filtertype === 'Branch') {
              groupKey = `${curr.company}/${curr.branch}`;
            } else if (filterUser.filtertype === 'Unit') {
              groupKey = `${curr.company}/${curr.branch}/${curr.unit}`;
            } else if (filterUser.filtertype === 'Team') {
              groupKey = `${curr.company}/${curr.branch}/${curr.unit}/${curr.team}`;
            }

            // Calculate totalpending based on match with group values
            const matchingPending = totalpendingArray.filter(data => {
              if (filterUser.filtertype === 'Company') {
                return data.company === curr.company && data.branch === curr.branch;
              } else if (filterUser.filtertype === 'Branch') {
                return data.company === curr.company && data.branch === curr.branch;
              } else if (filterUser.filtertype === 'Unit') {
                return data.company === curr.company && data.branch === curr.branch && data.unit === curr.unit;
              } else if (filterUser.filtertype === 'Team') {
                return data.company === curr.company && data.branch === curr.branch && data.unit === curr.unit && data.team === curr.team;
              }
            });

            if (!acc[groupKey]) {
              acc[groupKey] = {
                id: `${index + 1}_${groupKey}`,
                company: curr.company,
                branch: curr.branch,
                unit: ['Unit', 'Team'].includes(filterUser.filtertype) ? curr.unit : '',
                team: ['Team'].includes(filterUser.filtertype) ? curr.team : '',
                date: curr.date,
                totalemployeesArray,
                totalcurrentshiftArray,
                paidpresentdayArray,
                absentArray,
                totalinArray,
                totaloutArray,
                totalpendingArray,
                facilitypresentArray,
                wfhpresentArray,
                facilityabsentArray,
                wfhabsentArray,
                earlyclockinArray,
                onpresentArray,
                graceclockinArray,
                lateclockinArray,
                weekoffArray,
                holidayArray,
                permissionArray,
                clslArray,
                onclockoutArray,
                earlyclockoutArray,
                overclockoutArray,
                autoclockoutArray,
                shiftnotstartedArray,
                nostatusArray,
                notallottedArray,
                weekoffpresentArray,
                longleaveabsentArray,
                blabsentArray,
                doubledayabsentArray,
                weekoffabsentArray,
                totalemployees: 0,
                totalcurrentshift: 0,
                paidpresentday: 0,
                lopcount: 0,
                totalin: 0,
                totalout: 0,
                totalpending: matchingPending?.length,
                facilitypresent: 0,
                wfhpresent: 0,
                facilityabsent: 0,
                wfhabsent: 0,
                earlyclockin: 0,
                onpresent: 0,
                graceclockin: 0,
                lateclockin: 0,
                weekoff: 0,
                holidayCount: 0,
                permissionCount: 0,
                clsl: 0,
                onclockout: 0,
                earlyclockout: 0,
                overclockout: 0,
                autoclockout: 0,
                shiftnotstarted: 0,
                nostatus: 0,
                notallotted: 0,
                weekoffpresent: 0,
                longleaveabsent: 0,
                blabsent: 0,
                doubledayabsent: 0,
                weekoffabsent: 0,
              };
            }

            acc[groupKey].totalemployees += Number(curr.totalemployees);
            acc[groupKey].totalcurrentshift += Number(curr.totalcurrentshift);
            acc[groupKey].paidpresentday += Number(curr.paidpresentday);
            acc[groupKey].lopcount += Number(curr.lopcount);
            acc[groupKey].totalin += Number(curr.totalin);
            acc[groupKey].totalout += Number(curr.totalout);
            acc[groupKey].totalpending = matchingPending.length;
            acc[groupKey].facilitypresent += Number(curr.facilitypresent);
            acc[groupKey].wfhpresent += Number(curr.wfhpresent);
            acc[groupKey].facilityabsent += Number(curr.facilityabsent);
            acc[groupKey].wfhabsent += Number(curr.wfhabsent);
            acc[groupKey].earlyclockin += Number(curr.earlyclockin);
            acc[groupKey].onpresent += Number(curr.onpresent);
            acc[groupKey].graceclockin += Number(curr.graceclockin);
            acc[groupKey].lateclockin += Number(curr.lateclockin);
            acc[groupKey].weekoff += Number(curr.weekoff);
            acc[groupKey].holidayCount += Number(curr.holidayCount);
            acc[groupKey].permissionCount += Number(curr.permissionCount);
            acc[groupKey].clsl += Number(curr.clsl);
            acc[groupKey].onclockout += Number(curr.onclockout);
            acc[groupKey].earlyclockout += Number(curr.earlyclockout);
            acc[groupKey].overclockout += Number(curr.overclockout);
            acc[groupKey].autoclockout += Number(curr.autoclockout);
            acc[groupKey].shiftnotstarted += Number(curr.shiftnotstarted);
            acc[groupKey].nostatus += Number(curr.nostatus);
            acc[groupKey].notallotted += Number(curr.notallotted);
            acc[groupKey].weekoffpresent += Number(curr.weekoffpresent);
            acc[groupKey].longleaveabsent += Number(curr.longleaveabsent);
            acc[groupKey].blabsent += Number(curr.blabsent);
            acc[groupKey].doubledayabsent += Number(curr.doubledayabsent);
            acc[groupKey].weekoffabsent += Number(curr.weekoffabsent);

            return acc;
          }, {});

          // Convert grouped object back to array
          groupedResult = Object.values(groupedResult).map((item, index) => ({ ...item, serialNumber: index + 1 }));
        }
        // console.log(groupedResult);

        setUserShifts(groupedResult);
        setFilteredDataItems(groupedResult);
        setSearchQueryUserShiftSummary("");
        setLoader(false);
        setTotalPagesUserShiftSummary(Math.ceil(groupedResult.length / pageSizeUserShiftSummary));
      }).catch(error => {
        setLoader(true);
        console.error('Error in getting all results:', error);
      });
    } catch (err) { setLoader(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (filterUser.filtertype === "Please Select Filter Type" || filterUser.filtertype === "" || filterUser.filtertype === undefined) {
      setPopupContentMalert("Please Select Filter Type for Employee Names");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (selectedCompany?.length === 0) {
      setPopupContentMalert("Please Select Company");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (["Individual", "Team", "Branch", "Unit"]?.includes(filterUser.filtertype) && selectedBranch.length === 0) {
      setPopupContentMalert("Please Select Branch");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (["Individual", "Team", "Unit"]?.includes(filterUser.filtertype) && selectedUnit.length === 0) {
      setPopupContentMalert("Please Select Unit");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (["Individual", "Team"]?.includes(filterUser.filtertype) && selectedTeam.length === 0) {
      setPopupContentMalert("Please Select Team");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (["Individual"]?.includes(filterUser.filtertype) && selectedEmp.length === 0) {
      setPopupContentMalert("Please Select Employee Names");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (["Department"]?.includes(filterUser.filtertype) && selectedDep.length === 0) {
      setPopupContentMalert("Please Select Department");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
    else if (filterUser.fromdate === '' && filterUser.todate === '') {
      setPopupContentMalert("Please Select Date");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    } else {
      fetchFilteredUsersStatus();
    }
  };

  const handleClear = async (e) => {
    e.preventDefault();
    setUserShifts([]);
    setFilterUser({ filtertype: "Company", fromdate: today, todate: today, });
    setSelectedMode("Today")
    setSelectedCompany([]);
    setSelectedBranch([]);
    setSelectedUnit([]);
    setSelectedTeam([]);
    setSelectedDep([]);
    setSelectedEmp([]);
    setValueCompany([]);
    setValueBranch([]);
    setValueUnit([]);
    setValueTeam([])
    setValueDep([]);
    setValueEmp([]);
    setPageUserShiftSummary(1);
    setPopupContent("Cleared Successfully");
    setPopupSeverity("success");
    handleClickOpenPopup();
  };

  const getCode = (rowdata, column) => {
    setLoaderView(true);
    try {
      handleClickOpenview();
      if (column === 'totalemployees') {
        setTableName('Total Employees List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.totalemployeesArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.totalemployeesArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.totalemployeesArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'totalcurrentshift') {
        setTableName('Total Current Shift List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.totalcurrentshiftArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.totalcurrentshiftArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.totalcurrentshiftArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'paidpresentday') {
        setTableName('Present List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.paidpresentdayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.paidpresentdayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.paidpresentdayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'lopcount') {
        setTableName('Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.absentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.absentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.absentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'totalin') {
        setTableName('Total In List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.totalinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.totalinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.totalinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'totalout') {
        setTableName('Total Out List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.totaloutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.totaloutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.totaloutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'totalpending') {
        setTableName('Total Pending List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.totalpendingArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.totalpendingArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.totalpendingArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'facilitypresent') {
        setTableName('Facility Present List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.facilitypresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.facilitypresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.facilitypresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'wfhpresent') {
        setTableName('WFH Present List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.wfhpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.wfhpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.wfhpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'facilityabsent') {
        setTableName('Facility Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.facilityabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.facilityabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.facilityabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'wfhabsent') {
        setTableName('WFH Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.wfhabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.wfhabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.wfhabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'earlyclockin') {
        setTableName('Early - ClockIn List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.earlyclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.earlyclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.earlyclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'onpresent') {
        setTableName('On - Present List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.onpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.onpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.onpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'graceclockin') {
        setTableName('Grace - ClockIn List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.graceclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.graceclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.graceclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'lateclockin') {
        setTableName('Late - ClockIn List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.lateclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.lateclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.lateclockinArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'weekoff') {
        setTableName('Week Off List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.weekoffArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.weekoffArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.weekoffArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'holidayCount') {
        setTableName('Holiday List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.holidayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.holidayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.holidayArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'permissionCount') {
        setTableName('Permission List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.permissionArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.permissionArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.permissionArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'clsl') {
        setTableName('CL/SL List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.clslArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.clslArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.clslArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'onclockout') {
        setTableName('On - ClockOut List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.onclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.onclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.onclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'earlyclockout') {
        setTableName('Early - ClockOut List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.earlyclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.earlyclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.earlyclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'overclockout') {
        setTableName('Over - ClockOut List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.overclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.overclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.overclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'autoclockout') {
        setTableName('Auto - ClockOut List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.autoclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.autoclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.autoclockoutArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'shiftnotstarted') {
        setTableName('Shift Not Started List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.shiftnotstartedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.shiftnotstartedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.shiftnotstartedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'nostatus') {
        setTableName('No Status List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.nostatusArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.nostatusArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.nostatusArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'notallotted') {
        setTableName('Not Allotted List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.notallottedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.notallottedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.notallottedArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'weekoffpresent') {
        setTableName('Weekoff Present List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.weekoffpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.weekoffpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.weekoffpresentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'longleaveabsent') {
        setTableName('Long Leave & Long Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.longleaveabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.longleaveabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.longleaveabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'blabsent') {
        setTableName('BL - Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.blabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.blabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.blabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'doubledayabsent') {
        setTableName('Double Day Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.doubledayabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.doubledayabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.doubledayabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      if (column === 'weekoffabsent') {
        setTableName('Weekoff Absent List');
        if (filterUser.filtertype === 'Company' || filterUser.filtertype === 'Branch') {
          setViewData(rowdata.weekoffabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Unit') {
          setViewData(rowdata.weekoffabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
        if (filterUser.filtertype === 'Team') {
          setViewData(rowdata.weekoffabsentArray?.filter(data => data.company === rowdata.company && data.branch === rowdata.branch && data.unit === rowdata.unit && data.team === rowdata.team)
            .map((item, index) => ({
              ...item,
              serialNumber: index + 1,
            })));
        }
      }
      setLoaderView(false);
    } catch (err) {
      setLoaderView(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
    }
  };

  const [historyViewData, setHistoryViewData] = useState({});
  const [currentServerTimeView, setCurrentServerTimeView] = useState(null);
  const getHistoryCode = async (rowdata) => {
    const time = await getCurrentServerTime();
    setCurrentServerTimeView(time);
    try {
      handleClickOpenHistoryview();
      setHistoryViewData(rowdata);
    } catch (err) {
      setLoaderView(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
    }
  }

  const defaultColDef = useMemo(() => {
    return {
      filter: true,
      resizable: true,
      filterParams: {
        buttons: ["apply", "reset", "cancel"],
      },
    };
  }, []);

  const onGridReady = useCallback((params) => {
    setGridApi(params.api);
    setColumnApi(params.columnApi);
  }, []);

  // Function to handle filter changes
  const onFilterChanged = () => {
    if (gridApi) {
      const filterModel = gridApi.getFilterModel(); // Get the current filter model

      // Check if filters are active
      if (Object.keys(filterModel).length === 0) {
        // No filters active, clear the filtered data state
        setFilteredRowData([]);
      } else {
        // Filters are active, capture filtered data
        const filteredData = [];
        gridApi.forEachNodeAfterFilterAndSort((node) => {
          filteredData.push(node.data);
        });
        setFilteredRowData(filteredData);
      }
    }
  };

  const onPaginationChanged = useCallback(() => {
    if (gridRefTableUserShiftSummary.current) {
      const gridApi = gridRefTableUserShiftSummary.current.api;
      const currentPage = gridApi.paginationGetCurrentPage() + 1;
      const totalPagesUserShiftSummary = gridApi.paginationGetTotalPages();
      setPageUserShiftSummary(currentPage);
      setTotalPagesUserShiftSummary(totalPagesUserShiftSummary);
    }
  }, []);

  const onPageSizeChange = useCallback((event) => {
    const value = event.target.value;

    if (value === 'ALL') {
      setPageSizeUserShiftSummary(filteredDataItems.length); // Show all data
    } else {
      setPageSizeUserShiftSummary(Number(value)); // Convert to number
    }

    // Optionally reset pagination to the first page when page size changes
    setPageUserShiftSummary(1);
  }, [filteredDataItems.length]);

  const columnDataTableUserShiftSummary = [
    { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityUserShiftSummary.serialNumber, pinned: 'left', lockPinned: true, },
    { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.company, },
    { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.branch, },
    { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.unit, },
    { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.team, },
    {
      field: "history", headerName: "History", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.history,
      cellRenderer: (params) => {
        return (
          <Grid>
            <Button size="small" onClick={() => { getHistoryCode(params.data); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "totalemployees", headerName: "Total Employees", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.totalemployees,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.totalemployees}
            <Button size="small" onClick={() => { getCode(params.data, 'totalemployees'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "totalcurrentshift", headerName: "Total Current Shift", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.totalcurrentshift,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.totalcurrentshift}
            <Button size="small" onClick={() => { getCode(params.data, 'totalcurrentshift'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "paidpresentday", headerName: "Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.paidpresentday,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.paidpresentday}
            <Button size="small" onClick={() => { getCode(params.data, 'paidpresentday'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "lopcount", headerName: "Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.lopcount,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.lopcount}
            <Button size="small" onClick={() => { getCode(params.data, 'lopcount'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "totalin", headerName: "Total In", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalin,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.totalin}
            <Button size="small" onClick={() => { getCode(params.data, 'totalin'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "totalout", headerName: "Total Out", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalout,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.totalout}
            <Button size="small" onClick={() => { getCode(params.data, 'totalout'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "totalpending", headerName: "Total Pending", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalpending,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.totalpending}
            <Button size="small" onClick={() => { getCode(params.data, 'totalpending'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "facilitypresent", headerName: "Facility Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.facilitypresent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.facilitypresent}
            <Button size="small" onClick={() => { getCode(params.data, 'facilitypresent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "wfhpresent", headerName: "WFH Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.wfhpresent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.wfhpresent}
            <Button size="small" onClick={() => { getCode(params.data, 'wfhpresent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "facilityabsent", headerName: "Facility Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.facilityabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.facilityabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'facilityabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "wfhabsent", headerName: "WFH Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.wfhabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.wfhabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'wfhabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "earlyclockin", headerName: "Early - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.earlyclockin,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.earlyclockin}
            <Button size="small" onClick={() => { getCode(params.data, 'earlyclockin'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "onpresent", headerName: "On - Present", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.onpresent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.onpresent}
            <Button size="small" onClick={() => { getCode(params.data, 'onpresent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "graceclockin", headerName: "Grace - ClockIn", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.graceclockin,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.graceclockin}
            <Button size="small" onClick={() => { getCode(params.data, 'graceclockin'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "lateclockin", headerName: "Late - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.lateclockin,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.lateclockin}
            <Button size="small" onClick={() => { getCode(params.data, 'lateclockin'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "weekoff", headerName: "Week Off", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.weekoff,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.weekoff}
            <Button size="small" onClick={() => { getCode(params.data, 'weekoff'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "holidayCount", headerName: "Holiday", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.holidayCount,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.holidayCount}
            <Button size="small" onClick={() => { getCode(params.data, 'holidayCount'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "permissionCount", headerName: "Permission", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.permissionCount,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.permissionCount}
            <Button size="small" onClick={() => { getCode(params.data, 'permissionCount'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "clsl", headerName: "CL/SL", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.clsl,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.clsl}
            <Button size="small" onClick={() => { getCode(params.data, 'clsl'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "onclockout", headerName: "On - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.onclockout,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.onclockout}
            <Button size="small" onClick={() => { getCode(params.data, 'onclockout'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "earlyclockout", headerName: "Early - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.earlyclockout,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.earlyclockout}
            <Button size="small" onClick={() => { getCode(params.data, 'earlyclockout'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "overclockout", headerName: "Over - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.overclockout,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.overclockout}
            <Button size="small" onClick={() => { getCode(params.data, 'overclockout'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "autoclockout", headerName: "Auto-Mis ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.autoclockout,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.autoclockout}
            <Button size="small" onClick={() => { getCode(params.data, 'autoclockout'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "shiftnotstarted", headerName: "Shift Not Started", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.shiftnotstarted,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.shiftnotstarted}
            <Button size="small" onClick={() => { getCode(params.data, 'shiftnotstarted'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "nostatus", headerName: "No Status", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.nostatus,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.nostatus}
            <Button size="small" onClick={() => { getCode(params.data, 'nostatus'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "notallotted", headerName: "Not Allotted", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.notallotted,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.notallotted}
            <Button size="small" onClick={() => { getCode(params.data, 'notallotted'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "weekoffpresent", headerName: "Weekoff Present", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.weekoffpresent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.weekoffpresent}
            <Button size="small" onClick={() => { getCode(params.data, 'weekoffpresent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "longleaveabsent", headerName: "Long Leave & Long Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.longleaveabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.longleaveabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'longleaveabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "blabsent", headerName: "BL Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.blabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.blabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'blabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "doubledayabsent", headerName: "Double Day Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.doubledayabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.doubledayabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'doubledayabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "weekoffabsent", headerName: "Weekoff Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.weekoffabsent,
      cellRenderer: (params) => {
        return (
          <Grid sx={{ display: 'flex' }}>
            {params.data.weekoffabsent}
            <Button size="small" onClick={() => { getCode(params.data, 'weekoffabsent'); }} sx={{ marginTop: '5px', }}>
              View
            </Button>
          </Grid >
        );
      },
    },
  ];

  const columnDataTableView = [
    { field: "serialNumber", headerName: "SNo", flex: 0, width: 75, hide: !columnVisibilityView.serialNumber, pinned: 'left', lockPinned: true },
    { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityView.empcode, pinned: 'left', lockPinned: true, },
    { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityView.username, pinned: 'left', lockPinned: true, },
    { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibilityView.company, },
    { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibilityView.branch, },
    { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibilityView.unit, },
    { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibilityView.team, },
    { field: "department", headerName: "Department", flex: 0, width: 130, hide: !columnVisibilityView.department, },
    { field: "date", headerName: "Date", flex: 0, width: 110, hide: !columnVisibilityView.date, },
    { field: "shiftmode", headerName: "Shift Mode", flex: 0, width: 110, hide: !columnVisibilityView.shiftmode, },
    { field: "shift", headerName: "Shift", flex: 0, width: 150, hide: !columnVisibilityView.shift, },
    { field: "changeshift", headerName: "Change Shift", flex: 0, width: 150, hide: !columnVisibilityView.changeshift, },
    { field: "leavestatus", headerName: "Leave Status", flex: 0, width: 150, hide: !columnVisibilityView.leavestatus, },
    { field: "permissionstatus", headerName: "Permission Status", flex: 0, width: 150, hide: !columnVisibilityView.permissionstatus, },
    { field: "clockin", headerName: "ClockIn", flex: 0, width: 120, hide: !columnVisibilityView.clockin, },
    {
      field: "clockinstatus", headerName: "ClockInStatus", flex: 0, width: 200, hide: !columnVisibilityView.clockinstatus,
      cellRenderer: (params) => {
        return (
          <Grid>
            <Button size="small"
              sx={{
                marginTop: '10px',
                textTransform: 'capitalize',
                borderRadius: '4px',
                boxShadow: 'none',
                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                fontWeight: '400',
                fontSize: '0.575rem',
                lineHeight: '1.43',
                letterSpacing: '0.01071em',
                display: 'flex',
                padding: (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                cursor: 'default',
                color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                '&:hover': {
                  color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                  backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                }
              }}
            >
              {params.data.clockinstatus}
            </Button>
          </Grid >
        );
      },
    },
    { field: "clockout", headerName: "ClockOut", flex: 0, width: 120, hide: !columnVisibilityView.clockout, },
    {
      field: "clockoutstatus", headerName: "ClockOutStatus", flex: 0, width: 200, hide: !columnVisibilityView.clockoutstatus,
      cellRenderer: (params) => {
        return (
          <Grid>
            <Button size="small"
              sx={{
                marginTop: '10px',
                textTransform: 'capitalize',
                borderRadius: '4px',
                boxShadow: 'none',
                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                fontWeight: '400',
                fontSize: '0.575rem',
                lineHeight: '1.43',
                letterSpacing: '0.01071em',
                display: 'flex',
                padding: (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                cursor: 'default',
                color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                '&:hover': {
                  color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                  backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                }
              }}
            >
              {params.data.clockoutstatus}
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "attendanceauto", headerName: "Attendance", flex: 0, width: 200, hide: !columnVisibilityView.attendanceauto,
      cellRenderer: (params) => {
        return (
          <Grid>
            <Button size="small"
              sx={{
                marginTop: '10px',
                textTransform: 'capitalize',
                borderRadius: '4px',
                boxShadow: 'none',
                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                fontWeight: '400',
                fontSize: '0.575rem',
                lineHeight: '1.43',
                letterSpacing: '0.01071em',
                display: 'flex',
                padding: '3px 8px',
                cursor: 'default',
                color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                '&:hover': {
                  color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                  backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                }
              }}
            >
              {params.data.attendanceauto}
            </Button>
          </Grid >
        );
      },
    },
    {
      field: "daystatus", headerName: "Day Status", flex: 0, width: 200, hide: !columnVisibilityView.daystatus,
      cellRenderer: (params) => {
        return (
          <Grid>
            <Button size="small"
              sx={{
                marginTop: '10px',
                textTransform: 'capitalize',
                borderRadius: '4px',
                boxShadow: 'none',
                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                fontWeight: '400',
                fontSize: '0.575rem',
                lineHeight: '1.43',
                letterSpacing: '0.01071em',
                display: 'flex',
                padding: '3px 8px',
                cursor: 'default',
                color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                '&:hover': {
                  color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                  backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                }
              }}
            >
              {params.data.daystatus}
            </Button>
          </Grid >
        );
      },
    },
    { field: "appliedthrough", headerName: "Applied Through", flex: 0, width: 120, hide: !columnVisibilityView.appliedthrough, },
    { field: "isweekoff", headerName: "Is Week Off", flex: 0, width: 120, hide: !columnVisibilityView.isweekoff, },
    { field: "isholiday", headerName: "Is Holiday", flex: 0, width: 120, hide: !columnVisibilityView.isholiday, },
    { field: "lopcalculation", headerName: "LOP Calculation", flex: 0, width: 120, hide: !columnVisibilityView.lopcalculation, },
    { field: "modetarget", headerName: "Target", flex: 0, width: 120, hide: !columnVisibilityView.modetarget, },
    { field: "paidpresent", headerName: "Paid Present", flex: 0, width: 120, hide: !columnVisibilityView.paidpresent, },
    { field: "lopday", headerName: "LOP Day", flex: 0, width: 120, hide: !columnVisibilityView.lopday, },
    { field: "paidpresentday", headerName: "Paid Present Day", flex: 0, width: 120, hide: !columnVisibilityView.paidpresentday, },
  ];

  // Datatable
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchQueryUserShiftSummary(value);
    applyNormalFilter(value);
    setFilteredRowData([]);
  };

  const applyNormalFilter = (searchValue) => {

    // Split the search query into individual terms
    const searchTerms = searchValue.toLowerCase().split(" ");

    // Modify the filtering logic to check each term
    const filtered = userShifts?.filter((item) => {
      return searchTerms.every((term) =>
        Object.values(item).join(" ").toLowerCase().includes(term)
      );
    });
    setFilteredDataItems(filtered);
    setPageUserShiftSummary(1);
  };

  const applyAdvancedFilter = (filters, logicOperator) => {
    // Apply filtering logic with multiple conditions
    const filtered = userShifts?.filter((item) => {
      return filters.reduce((acc, filter, index) => {
        const { column, condition, value } = filter;
        const itemValue = String(item[column])?.toLowerCase();
        const filterValue = String(value).toLowerCase();

        let match;
        switch (condition) {
          case "Contains":
            match = itemValue.includes(filterValue);
            break;
          case "Does Not Contain":
            match = !itemValue?.includes(filterValue);
            break;
          case "Equals":
            match = itemValue === filterValue;
            break;
          case "Does Not Equal":
            match = itemValue !== filterValue;
            break;
          case "Begins With":
            match = itemValue.startsWith(filterValue);
            break;
          case "Ends With":
            match = itemValue.endsWith(filterValue);
            break;
          case "Blank":
            match = !itemValue;
            break;
          case "Not Blank":
            match = !!itemValue;
            break;
          default:
            match = true;
        }

        // Combine conditions with AND/OR logic
        if (index === 0) {
          return match; // First filter is applied directly
        } else if (logicOperator === "AND") {
          return acc && match;
        } else {
          return acc || match;
        }
      }, true);
    });

    setFilteredDataItems(filtered);
    setAdvancedFilter(filters);
    // handleCloseSearchUserShiftSummary(); 
  };

  // Undo filter funtion
  const handleResetSearch = () => {
    setAdvancedFilter(null);
    setSearchQueryUserShiftSummary("");
    setFilteredDataItems(userShifts);
  };

  // Show filtered combination in the search bar
  const getSearchDisplay = () => {
    if (advancedFilter && advancedFilter.length > 0) {
      return advancedFilter.map((filter, index) => {
        let showname = columnDataTableUserShiftSummary.find(col => col.field === filter.column)?.headerName;
        return `${showname} ${filter.condition} "${filter.value}"`;
      }).join(' ' + (advancedFilter.length > 1 ? advancedFilter[1].condition : '') + ' ');
    }
    return searchQueryUserShiftSummary;
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPagesUserShiftSummary) {
      setPageUserShiftSummary(newPage);
      gridRefTableUserShiftSummary.current.api.paginationGoToPage(newPage - 1);
    }
  };

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    setPageSizeUserShiftSummary(newSize);
    if (gridApi) {
      gridApi.paginationSetPageSize(newSize);
    }
  };

  // Show All Columns functionality
  const handleShowAllColumns = () => {
    const updatedVisibility = { ...columnVisibilityUserShiftSummary };
    for (const columnKey in updatedVisibility) {
      updatedVisibility[columnKey] = true;
    }
    setColumnVisibilityUserShiftSummary(updatedVisibility);
  };

  const handleShowAllColumnsView = () => {
    const updatedVisibilityView = { ...columnVisibilityView };
    for (const columnKey in updatedVisibilityView) {
      updatedVisibilityView[columnKey] = true;
    }
    setColumnVisibilityView(updatedVisibilityView);
  };

  useEffect(() => {
    // Retrieve column visibility from localStorage (if available)
    const savedVisibility = localStorage.getItem("columnVisibilityUserShiftSummary");
    if (savedVisibility) {
      setColumnVisibilityUserShiftSummary(JSON.parse(savedVisibility));
    }
  }, []);

  useEffect(() => {
    // Save column visibility to localStorage whenever it changes
    localStorage.setItem("columnVisibilityUserShiftSummary", JSON.stringify(columnVisibilityUserShiftSummary));
  }, [columnVisibilityUserShiftSummary]);

  // Function to filter columns based on search query
  const filteredColumns = columnDataTableUserShiftSummary.filter((column) =>
    column.headerName.toLowerCase().includes(searchQueryManageUserShiftSummary.toLowerCase())
  );

  const filteredColumnsView = columnDataTableView.filter((column) =>
    column.headerName.toLowerCase().includes(searchQueryManageView.toLowerCase())
  );

  function debounce(func, wait) {
    let timeout;
    return function (...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }

  // Manage Columns functionality
  const toggleColumnVisibility = (field) => {
    if (!gridApi) return;

    setColumnVisibilityUserShiftSummary((prevVisibility) => {
      const newVisibility = !prevVisibility[field];

      // Update the visibility in the grid
      gridApi.setColumnVisible(field, newVisibility);

      return {
        ...prevVisibility,
        [field]: newVisibility,
      };
    });
  };

  const toggleColumnVisibilityView = (field) => {
    setColumnVisibilityView((prevVisibility) => ({
      ...prevVisibility,
      [field]: !prevVisibility[field],
    }));
  };

  const handleColumnMoved = useCallback(debounce((event) => {
    if (!event.columnApi) return;

    const visible_columns = event.columnApi.getAllColumns().filter(col => {
      const colState = event.columnApi.getColumnState().find(state => state.colId === col.colId);
      return colState && !colState.hide;
    }).map(col => col.colId);

    setColumnVisibilityUserShiftSummary((prevVisibility) => {
      const updatedVisibility = { ...prevVisibility };

      // Ensure columns that are visible stay visible
      Object.keys(updatedVisibility).forEach(colId => {
        updatedVisibility[colId] = visible_columns.includes(colId);
      });

      return updatedVisibility;
    });
  }, 300), []);

  const handleColumnVisible = useCallback((event) => {
    const colId = event.column.getColId();

    // Update visibility based on event, but only when explicitly triggered by grid
    setColumnVisibilityUserShiftSummary((prevVisibility) => ({
      ...prevVisibility,
      [colId]: event.visible, // Set visibility directly from the event
    }));
  }, []);

  // Excel
  const [fileFormat, setFormat] = useState('');
  let exportColumnNamescrt = [
    "Company", "Branch", "Unit", "Team", "Total Employees", "Total Current Shift", "Present", "Absent", "Total In", "Total Out", "Total Pending", "Facility Present", "WFH Present", "Facility Absent", "WFH Absent", "Early - ClockIn", "On - Present", "Grace - ClockIn", "Late - ClockIn", "Week Off", "Holiday",
    "Permission", "CL/SL", "On - ClockOut", "Early - ClockOut", "Over - ClockOut", "Auto - ClockOut", "Shift Not Started", "No Status", "Not Allotted", "Weekoff Present", "Long Leave & Long Absent", "BL Absent", "Double Day Absent", "Weekoff Absent",
  ]
  let exportRowValuescrt = [
    'company', 'branch', 'unit', 'team', 'totalemployees', 'totalcurrentshift', 'paidpresentday', 'lopcount', 'totalin', 'totalout', 'totalpending', 'facilitypresent', 'wfhpresent', 'facilityabsent', 'wfhabsent', 'earlyclockin', 'onpresent', 'graceclockin', 'lateclockin', 'weekoff', 'holidayCount',
    'permissionCount', 'clsl', 'onclockout', 'earlyclockout', 'overclockout', 'autoclockout', 'shiftnotstarted', 'nostatus', 'notallotted', 'weekoffpresent', 'longleaveabsent', 'blabsent', 'doubledayabsent', 'weekoffabsent',
  ]

  let exportColumnNamesView = [
    "Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department",
    "Date", "Shift Mode", "Shift", "Change Shift", "Leave Status", "Permission Status", "ClockIn", "ClockInStatus", "ClockOut", "ClockOutStatus", "Attendance",
    "Day Status", "Applied Through", "Is Week Off", "Is Holiday", "LOP Calculation", "Target", "Paid Present", "LOP Day", "Paid Present Day",
  ];
  let exportRowValuesView = [
    'empcode', 'username', 'company', 'branch', 'unit', 'team', 'department', 'date', 'shiftmode', 'shift', 'changeshift', 'leavestatus', 'permissionstatus', 'clockin', 'clockinstatus',
    'clockout', 'clockoutstatus', 'attendanceauto', 'daystatus', 'appliedthrough', 'isweekoff', 'isholiday', 'lopcalculation', 'modetarget', 'paidpresent', 'lopday', 'paidpresentday',
  ];

  // print...
  const componentRef = useRef();
  const handleprint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: "Attendance Summary Report",
    pageStyle: "print",
  });

  const componentRefView = useRef();
  const handleprintView = useReactToPrint({
    content: () => componentRefView.current,
    documentTitle: `${tableName}`,
    pageStyle: "print",
  });

  // image
  const handleCaptureImage = () => {
    if (gridRefImageUserShiftSummary.current) {
      domtoimage.toBlob(gridRefImageUserShiftSummary.current)
        .then((blob) => {
          saveAs(blob, "Attendance Summary Report.png");
        })
        .catch((error) => {
          console.error("dom-to-image error: ", error);
        });
    }
  };

  const handleCaptureImageView = () => {
    if (gridRefTableImgView.current) {
      domtoimage.toBlob(gridRefTableImgView.current)
        .then((blob) => {
          saveAs(blob, `${tableName}.png`);
        })
        .catch((error) => {
          console.error("dom-to-image error: ", error);
        });
    }
  };

  // image view
  const handleCaptureImageViewPopup = () => {
    if (gridRefImageUserShiftSummaryViewPopup.current) {
      domtoimage.toBlob(gridRefImageUserShiftSummaryViewPopup.current)
        .then((blob) => {
          saveAs(blob, "Attendance Summary Report.png");
        })
        .catch((error) => {
          console.error("dom-to-image error: ", error);
        });
    }
  };

  // Pagination for innter filter
  const getVisiblePageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 3;

    const startPage = Math.max(1, pageUserShiftSummary - 1);
    const endPage = Math.min(totalPagesUserShiftSummary, startPage + maxVisiblePages - 1);

    // Loop through and add visible pageUserShiftSummary numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    // If there are more pages after the last visible pageUserShiftSummary, show ellipsis
    if (endPage < totalPagesUserShiftSummary) {
      pageNumbers.push("...");
    }

    return pageNumbers;
  };

  const addSerialNumberView = (datas) => {
    setItemsView(datas);
  };

  useEffect(() => {
    addSerialNumberView(viewData);
  }, [viewData]);

  const handlePageSizeChangeView = (event) => {
    setPageSizeView(Number(event.target.value));
    setPageView(1);
  };

  // Pagination for outer filter
  const filteredData = filteredDataItems?.slice((pageUserShiftSummary - 1) * pageSizeUserShiftSummary, pageUserShiftSummary * pageSizeUserShiftSummary);
  const totalPagesUserShiftSummaryOuter = Math.ceil(filteredDataItems?.length / pageSizeUserShiftSummary);
  const visiblePages = Math.min(totalPagesUserShiftSummaryOuter, 3);
  const firstVisiblePage = Math.max(1, pageUserShiftSummary - 1);
  const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesUserShiftSummaryOuter);
  const pageNumbers = [];
  const indexOfLastItem = pageUserShiftSummary * pageSizeUserShiftSummary;
  const indexOfFirstItem = indexOfLastItem - pageSizeUserShiftSummary;
  for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

  // Split the search query into individual terms
  const searchTermsView = searchQueryView.toLowerCase().split(" ");
  // Modify the filtering logic to check each term
  const filteredDatasView = itemsView?.filter((item) => {
    return searchTermsView.every((term) =>
      Object.values(item).join(" ").toLowerCase().includes(term)
    );
  });

  const filteredDataView = filteredDatasView?.slice((pageView - 1) * pageSizeView, pageView * pageSizeView);
  const totalPagesView = Math.ceil(filteredDatasView.length / pageSizeView);
  const visiblePagesView = Math.min(totalPagesView, 3);
  const firstVisiblePageView = Math.max(1, pageView - 1);
  const lastVisiblePageView = Math.min(firstVisiblePageView + visiblePagesView - 1, totalPagesView);
  const pageNumbersView = [];
  const indexOfLastItemView = pageView * pageSizeView;
  const indexOfFirstItemView = indexOfLastItemView - pageSizeView;
  for (let i = firstVisiblePageView; i <= lastVisiblePageView; i++) {
    pageNumbersView.push(i);
  }

  const rowDataTableView = filteredDataView.map((item, index) => {
    return {
      ...item,
    };
  });

  return (
    <Box>
      <Headtitle title={"ATTENDANCE SUMMARY REPORT"} />
      {/* ****** Header Content ****** */}
      <PageHeading
        title="Attendance Summary Report"
        modulename="Human Resources"
        submodulename="HR"
        mainpagename="Attendance"
        subpagename="Attendance Rports"
        subsubpagename="Attendance Summary Report"
      />
      {isUserRoleCompare?.includes("lattendancesummaryreport") && (
        <>
          <Box sx={userStyle.selectcontainer}>
            <Grid container spacing={2}>
              <Grid item md={12} sm={12} xs={12}>
                <Typography sx={userStyle.importheadtext}> Attendance Summary Report </Typography>
              </Grid>
              {/* <Grid item md={3} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>Mode<b style={{ color: "red" }}>*</b></Typography>
                                    <Selects
                                        options={modeOptions}
                                        styles={colourStyles}
                                        value={{ label: filterUser.mode, value: filterUser.mode }}
                                        onChange={(e) => {
                                            setFilterUser({ ...filterUser, mode: e.value, });
                                            setSelectedDep([]);
                                            setValueDep([]);
                                            setSelectedEmp([]);
                                            setValueEmp([]);
                                        }}
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={3} xs={12} sm={12}>
                                <Typography>Company<b style={{ color: "red" }}>*</b></Typography>
                                <FormControl size="small" fullWidth>
                                    <MultiSelect
                                        options={accessbranch?.map(data => ({
                                            label: data.company,
                                            value: data.company,
                                        })).filter((item, index, self) => {
                                            return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                                        })}
                                        value={selectedCompany}
                                        onChange={(e) => {
                                            handleCompanyChange(e);
                                            setFilterUser({ ...filterUser, department: 'Please Select Department' });
                                        }}
                                        valueRenderer={customValueRendererCompany}
                                        labelledBy="Please Select Company"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={3} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography> Branch<b style={{ color: "red" }}>*</b> </Typography>
                                    <MultiSelect
                                        options={accessbranch?.filter(
                                            (comp) =>
                                                valueCompany?.includes(comp.company)
                                        )?.map(data => ({
                                            label: data.branch,
                                            value: data.branch,
                                        })).filter((item, index, self) => {
                                            return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                                        })}
                                        value={selectedBranch}
                                        onChange={(e) => {
                                            handleBranchChangeFrom(e);
                                            setFilterUser({ ...filterUser, department: 'Please Select Department' });
                                        }}
                                        valueRenderer={customValueRendererBranchFrom}
                                        labelledBy="Please Select Branch"
                                    />
                                </FormControl>
                            </Grid>
                            <Grid item md={3} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography> Unit<b style={{ color: "red" }}>*</b> </Typography>
                                    <MultiSelect
                                        options={accessbranch?.filter(
                                            (comp) =>
                                                valueCompany?.includes(comp.company) && valueBranch?.includes(comp.branch)
                                        )?.map(data => ({
                                            label: data.unit,
                                            value: data.unit,
                                        })).filter((item, index, self) => {
                                            return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                                        })}
                                        value={selectedUnit}
                                        onChange={(e) => {
                                            handleUnitChangeFrom(e);
                                            setFilterUser({ ...filterUser, department: 'Please Select Department' });
                                        }}
                                        valueRenderer={customValueRendererUnitFrom}
                                        labelledBy="Please Select Unit"
                                    />
                                </FormControl>
                            </Grid>
                            {filterUser.mode === 'Department' ?
                                <Grid item md={3} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography> Department<b style={{ color: "red" }}>*</b> </Typography>
                                        <MultiSelect
                                            options={alldepartment?.map(data => ({
                                                label: data.deptname,
                                                value: data.deptname,
                                            })).filter((item, index, self) => {
                                                return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                                            })}
                                            value={selectedDep}
                                            onChange={(e) => {
                                                handleDepChangeFrom(e);
                                            }}
                                            valueRenderer={customValueRendererDepFrom}
                                            labelledBy="Please Select Department"
                                        />
                                    </FormControl>
                                </Grid>
                                : null}
                            {filterUser.mode === 'Employee' ?
                                <Grid item md={3} sm={12} xs={12} sx={{ display: "flex", flexDirection: "row" }}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Employee<b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <MultiSelect
                                            options={allUsersLimit?.filter(
                                                (comp) =>
                                                    valueCompany?.includes(comp.company) && valueBranch?.includes(comp.branch) && valueUnit?.includes(comp.unit)
                                            )?.map(data => ({
                                                label: data.companyname,
                                                value: data.companyname,
                                            })).filter((item, index, self) => {
                                                return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                                            })}
                                            value={selectedEmp}
                                            onChange={(e) => {
                                                handleEmployeeChange(e);
                                            }}
                                            valueRenderer={customValueRendererEmp}
                                            labelledBy="Please Select Employee"
                                        />
                                    </FormControl>
                                </Grid>
                                : null} */}
              <Grid item md={3} xs={12} sm={12}>
                <FormControl fullWidth size="small">
                  <Typography> Type<b style={{ color: "red" }}>*</b> </Typography>
                  <Selects
                    options={[
                      // { label: "Individual", value: "Individual" },
                      { label: "Company", value: "Company" },
                      { label: "Branch", value: "Branch" },
                      { label: "Unit", value: "Unit" },
                      { label: "Team", value: "Team" },
                      // { label: "Department", value: "Department" },
                    ]}
                    styles={colourStyles}
                    value={{ label: filterUser.filtertype, value: filterUser.filtertype, }}
                    onChange={(e) => {
                      setFilterUser({ ...filterUser, filtertype: e.value });
                      setSelectedCompany([]);
                      setValueCompany([]);
                      setSelectedBranch([]);
                      setValueBranch([]);
                      setSelectedUnit([]);
                      setValueUnit([]);
                      setSelectedTeam([]);
                      setValueTeam([]);
                      setSelectedEmp([]);
                      setValueEmp([]);
                      setSelectedDep([]);
                      setValueDep([]);
                    }}
                  />
                </FormControl>
              </Grid>
              <Grid item md={3} xs={12} sm={12}>
                <FormControl fullWidth size="small">
                  <Typography>
                    Company<b style={{ color: "red" }}>*</b>
                  </Typography>
                  <MultiSelect
                    options={accessbranch?.map(data => ({
                      label: data.company,
                      value: data.company,
                    })).filter((item, index, self) => {
                      return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                    })}
                    value={selectedCompany}
                    onChange={(e) => {
                      handleCompanyChange(e);
                    }}
                    valueRenderer={customValueRendererCompany}
                    labelledBy="Please Select Company"
                  />
                </FormControl>
              </Grid>
              {["Individual", "Team"]?.includes(filterUser.filtertype) ? <>
                {/* Branch Unit Team */}
                <Grid item md={3} xs={12} sm={12}>
                  <FormControl fullWidth size="small">
                    <Typography> Branch<b style={{ color: "red" }}>*</b> </Typography>
                    <MultiSelect
                      options={accessbranch?.filter(
                        (comp) =>
                          valueCompany?.includes(comp.company)
                      )?.map(data => ({
                        label: data.branch,
                        value: data.branch,
                      })).filter((item, index, self) => {
                        return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                      })}
                      value={selectedBranch}
                      onChange={handleBranchChange}
                      valueRenderer={customValueRendererBranch}
                      labelledBy="Please Select Branch"
                    />
                  </FormControl>
                </Grid>
                <Grid item md={3} xs={12} sm={12}>
                  <FormControl fullWidth size="small">
                    <Typography> Unit<b style={{ color: "red" }}>*</b></Typography>
                    <MultiSelect
                      options={accessbranch?.filter(
                        (comp) =>
                          valueCompany?.includes(comp.company) && valueBranch?.includes(comp.branch)
                      )?.map(data => ({
                        label: data.unit,
                        value: data.unit,
                      })).filter((item, index, self) => {
                        return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                      })}
                      value={selectedUnit}
                      onChange={handleUnitChange}
                      valueRenderer={customValueRendererUnit}
                      labelledBy="Please Select Branch"
                    />
                  </FormControl>
                </Grid>
                <Grid item md={3} xs={12} sm={12}>
                  <FormControl fullWidth size="small">
                    <Typography> Team<b style={{ color: "red" }}>*</b></Typography>
                    <MultiSelect
                      options={allTeam
                        ?.filter((u) => valueCompany?.includes(u.company) && valueBranch?.includes(u.branch) && valueUnit?.includes(u.unit))
                        .map((u) => ({
                          ...u,
                          label: u.teamname,
                          value: u.teamname,
                        }))}
                      value={selectedTeam}
                      onChange={handleTeamChange}
                      valueRenderer={customValueRendererTeam}
                      labelledBy="Please Select Branch"
                    />
                  </FormControl>
                </Grid>
              </>
                : ["Branch"]?.includes(filterUser.filtertype) ?
                  <>
                    <Grid item md={3} xs={12} sm={12}>
                      <FormControl fullWidth size="small">
                        <Typography> Branch<b style={{ color: "red" }}>*</b></Typography>
                        <MultiSelect
                          options={accessbranch?.filter(
                            (comp) =>
                              valueCompany?.includes(comp.company)
                          )?.map(data => ({
                            label: data.branch,
                            value: data.branch,
                          })).filter((item, index, self) => {
                            return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                          })}
                          value={selectedBranch}
                          onChange={handleBranchChange}
                          valueRenderer={customValueRendererBranch}
                          labelledBy="Please Select Branch"
                        />
                      </FormControl>
                    </Grid>
                  </>
                  :
                  ["Unit"]?.includes(filterUser.filtertype) ?
                    <>
                      <Grid item md={3} xs={12} sm={12}>
                        <FormControl fullWidth size="small">
                          <Typography> Branch<b style={{ color: "red" }}>*</b></Typography>
                          <MultiSelect
                            options={accessbranch?.filter(
                              (comp) =>
                                valueCompany?.includes(comp.company)
                            )?.map(data => ({
                              label: data.branch,
                              value: data.branch,
                            })).filter((item, index, self) => {
                              return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                            })}
                            value={selectedBranch}
                            onChange={handleBranchChange}
                            valueRenderer={customValueRendererBranch}
                            labelledBy="Please Select Branch"
                          />
                        </FormControl>
                      </Grid>
                      <Grid item md={3} xs={12} sm={12}>
                        <FormControl fullWidth size="small">
                          <Typography> Unit<b style={{ color: "red" }}>*</b></Typography>
                          <MultiSelect
                            options={accessbranch?.filter(
                              (comp) =>
                                valueCompany?.includes(comp.company) && valueBranch?.includes(comp.branch)
                            )?.map(data => ({
                              label: data.unit,
                              value: data.unit,
                            })).filter((item, index, self) => {
                              return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
                            })}
                            value={selectedUnit}
                            onChange={handleUnitChange}
                            valueRenderer={customValueRendererUnit}
                            labelledBy="Please Select Branch"
                          />
                        </FormControl>
                      </Grid>
                    </>
                    : ""
              }
              <Grid item md={3} sm={12} xs={12}>
                <FormControl fullWidth size="small">
                  <Typography> Date<b style={{ color: "red" }}>*</b>{" "} </Typography>
                  <OutlinedInput
                    id="component-outlined"
                    type="date"
                    // disabled={selectedMode != "Custom"}
                    value={filterUser.fromdate}
                    onChange={(e) => {
                      const selectedDate = e.target.value;
                      // Ensure that the selected date is not in the future
                      const currentDate = new Date(serverTime).toISOString().split("T")[0];
                      // if (selectedDate <= currentDate) {
                      setFilterUser({ ...filterUser, fromdate: selectedDate, todate: selectedDate });
                      // } else {
                      // Handle the case where the selected date is in the future (optional)
                      // You may choose to show a message or take other actions.
                      // }
                    }}
                  // Set the max attribute to the current date
                  // inputProps={{ max: new Date(serverTime).toISOString().split("T")[0] }}
                  />
                </FormControl>
              </Grid>
            </Grid>
            <Grid container spacing={1}>
              <Grid item lg={1} md={2} sm={2} xs={6} >
                <Box sx={(theme) => ({ mt: { lg: 3, md: 2, sm: 1, xs: 0, } })}>
                  <Button sx={buttonStyles.buttonsubmit} variant="contained" onClick={handleSubmit} > Filter </Button>
                </Box>
              </Grid>
              <Grid item lg={1} md={2} sm={2} xs={6}>
                <Box sx={(theme) => ({ mt: { lg: 3, md: 2, sm: 1, xs: 0, } })}>
                  <Button sx={buttonStyles.btncancel} onClick={handleClear} > Clear </Button>
                </Box>
              </Grid>
            </Grid>
          </Box><br />
          {/* ****** Table Start ****** */}
          <Box sx={userStyle.container}>
            {/* ******************************************************EXPORT Buttons****************************************************** */}
            <Grid item xs={8}>
              <ScrollingText text="Total counts may mismatch if employees have a double shift." />
            </Grid>
            <Grid container spacing={1} style={userStyle.dataTablestyle}>
              <Grid item md={2} xs={12} sm={12}>
                <Box>
                  <label>Show entries:</label>
                  <Select
                    id="pageSizeSelect"
                    value={pageSizeUserShiftSummary}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 180,
                          width: 80,
                        },
                      },
                    }}
                    onChange={handlePageSizeChange}
                    sx={{ width: "77px" }}
                  >
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={25}>25</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                    <MenuItem value={userShifts?.length}>  All </MenuItem>
                  </Select>
                </Box>
              </Grid>
              <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}  >
                <Box>
                  {isUserRoleCompare?.includes("excelattendancesummaryreport") && (
                    <>
                      <Button onClick={(e) => {
                        setIsFilterOpen(true)
                        setFormat("xl")
                      }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("csvattendancesummaryreport") && (
                    <>
                      <Button onClick={(e) => {
                        setIsFilterOpen(true)
                        setFormat("csv")
                      }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("printattendancesummaryreport") && (
                    <>
                      <Button sx={userStyle.buttongrp} onClick={handleprint}> &ensp;  <FaPrint /> &ensp;Print&ensp; </Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("pdfattendancesummaryreport") && (
                    <>
                      <Button sx={userStyle.buttongrp}
                        onClick={() => {
                          setIsPdfFilterOpen(true)
                        }}
                      ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("imageattendancesummaryreport") && (
                    <>
                      <Button sx={userStyle.buttongrp} onClick={handleCaptureImage}> <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp; </Button>
                    </>
                  )}
                </Box>
              </Grid>
              <Grid item md={2} xs={12} sm={12}>
                <FormControl fullWidth size="small">
                  <OutlinedInput size="small"
                    id="outlined-adornment-weight"
                    startAdornment={
                      <InputAdornment position="start">
                        <FaSearch />
                      </InputAdornment>
                    }
                    endAdornment={
                      <InputAdornment position="end">
                        {advancedFilter && (
                          <IconButton onClick={handleResetSearch}>
                            <MdClose />
                          </IconButton>
                        )}
                        <Tooltip title="Show search options">
                          <span>
                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchUserShiftSummary} />
                          </span>
                        </Tooltip>
                      </InputAdornment>}
                    aria-describedby="outlined-weight-helper-text"
                    inputProps={{ 'aria-label': 'weight', }}
                    type="text"
                    value={getSearchDisplay()}
                    onChange={handleSearchChange}
                    placeholder="Type to search..."
                    disabled={!!advancedFilter}
                  />
                </FormControl>
              </Grid>
            </Grid><br />
            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumns}>  Show All Columns </Button>&ensp;
            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsUserShiftSummary}> Manage Columns  </Button><br /><br />
            {loader ?
              <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
              </Box> :
              <>
                <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageUserShiftSummary} >
                  <AgGridReact
                    rowData={filteredDataItems}
                    columnDefs={columnDataTableUserShiftSummary.filter((column) => columnVisibilityUserShiftSummary[column.field])}
                    ref={gridRefTableUserShiftSummary}
                    defaultColDef={defaultColDef}
                    domLayout={"autoHeight"}
                    getRowStyle={getRowStyle}
                    pagination={true}
                    paginationPageSizeSelector={[]}
                    paginationPageSize={pageSizeUserShiftSummary}
                    onPaginationChanged={onPaginationChanged}
                    onGridReady={onGridReady}
                    onColumnMoved={handleColumnMoved}
                    onColumnVisible={handleColumnVisible}
                    onFilterChanged={onFilterChanged}
                    // suppressPaginationPanel={true}
                    suppressSizeToFit={true}
                    suppressAutoSize={true}
                    suppressColumnVirtualisation={true}
                    colResizeDefault={"shift"}
                    cellSelection={true}
                    copyHeadersToClipboard={true}
                  />
                </Box>
              </>
            } {/* ****** Table End ****** */}
          </Box>
        </>
      )
      }

      {/* View model */}
      <Dialog
        open={openview}
        onClose={handleClickOpenview}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        maxWidth="lg" fullWidth
        scroll="paper"
        sx={{ marginTop: '95px' }}
      >
        <Box sx={{ padding: "20px 20px" }}>
          <Grid container spacing={2}>
            <Grid item xs={10}>
              <ScrollingTextView text="Total counts may mismatch if employees have a double shift." tableName={tableName} />
            </Grid>
            <Grid item md={1} sx={6} xs={12}>
              <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseview}>{" "}Back{" "}</Button>
            </Grid>
          </Grid><br />
          <Box>
            {/* ******************************************************EXPORT Buttons****************************************************** */}
            <Grid container spacing={2} style={userStyle.dataTablestyle}>
              <Grid item md={2} xs={12} sm={12}>
                <Box>
                  <label>Show entries:</label>
                  <Select
                    id="pageSizeSelect"
                    value={pageSizeView}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 180,
                          width: 80,
                        },
                      },
                    }}
                    onChange={handlePageSizeChangeView}
                    sx={{ width: "77px" }}
                  >
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={25}>25</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                    <MenuItem value={viewData?.length}>All</MenuItem>
                  </Select>
                </Box>
              </Grid>
              <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                <Box>
                  {isUserRoleCompare?.includes("excelattendancesummaryreport") && (
                    <>
                      <Button onClick={(e) => { setIsFilterOpenView(true); setFormat("xl"); }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("csvattendancesummaryreport") && (
                    <>
                      <Button onClick={(e) => { setIsFilterOpenView(true); setFormat("csv"); }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("printclienterrormonthamount") && (
                    <>
                      <Button sx={userStyle.buttongrp} onClick={handleprintView}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("pdfattendancesummaryreport") && (
                    <>
                      <Button sx={userStyle.buttongrp} onClick={() => { setIsPdfFilterOpenView(true); }}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                    </>
                  )}
                  {isUserRoleCompare?.includes("imageattendancesummaryreport") && (
                    <>
                      <Button sx={userStyle.buttongrp} onClick={handleCaptureImageView}><ImageIcon sx={{ fontSize: "15px" }} />{" "}&ensp;Image&ensp;</Button>
                    </>
                  )}
                </Box>
              </Grid>
              <Grid item md={2} xs={6} sm={6}>
                <Box>
                  <AggregatedSearchBar
                    columnDataTable={columnDataTableView}
                    setItems={setItemsView}
                    addSerialNumber={addSerialNumberView}
                    setPage={setPageView}
                    maindatas={viewData}
                    setSearchedString={setSearchedStringView}
                    searchQuery={searchQueryView}
                    setSearchQuery={setSearchQueryView}
                    paginated={false}
                    totalDatas={viewData}
                  />
                </Box>
              </Grid>
            </Grid><br />
            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsView}>Show All Columns</Button>&ensp;
            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsView}>Manage Columns</Button><br /><br />
            {loaderView ? (
              <>
                <Box sx={{ display: "flex", justifyContent: "center" }}>
                  <ThreeDots
                    height="80"
                    width="80"
                    radius="9"
                    color="#1976d2"
                    ariaLabel="three-dots-loading"
                    wrapperStyle={{}}
                    wrapperClassName=""
                    visible={true}
                  />
                </Box>
              </>
            ) : (
              <>
                <AggridTable
                  rowDataTable={rowDataTableView}
                  columnDataTable={columnDataTableView}
                  columnVisibility={columnVisibilityView}
                  page={pageView}
                  setPage={setPageView}
                  pageSize={pageSizeView}
                  totalPages={totalPagesView}
                  setColumnVisibility={setColumnVisibilityView}
                  isHandleChange={isHandleChangeView}
                  items={itemsView}
                  gridRefTable={gridRefTableView}
                  paginated={false}
                  filteredDatas={filteredDatasView}
                  // totalDatas={totalDatasView}
                  selectedRows={selectedRowsView}
                  setSelectedRows={setSelectedRowsView}
                  searchQuery={searchedStringView}
                  handleShowAllColumns={handleShowAllColumnsView}
                  setFilteredRowData={setFilteredRowDataView}
                  filteredRowData={filteredRowDataView}
                  setFilteredChanges={setFilteredChangesView}
                  filteredChanges={filteredChangesView}
                  gridRefTableImg={gridRefTableImgView}
                  itemsList={viewData}
                />
              </>
            )}
          </Box>
        </Box>
      </Dialog>

      {/* History model */}
      <Dialog
        open={openHistoryview}
        onClose={handleClickOpenHistoryview}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
        maxWidth="lg" fullWidth
        scroll="paper"
        sx={{ marginTop: '95px' }}
      >
        <Box sx={{ padding: "20px 20px" }}>
          <Grid container spacing={2}>
            <Grid item xs={10}>
              <Typography sx={userStyle.HeaderText}><b>{'Attendance Status History'}</b></Typography>
            </Grid>
            <Grid item md={1} sm={6} xs={12} >
              <Button sx={{
                display: 'flex', justifyContent: 'center',
                background: 'rgb(60 181 170)',
                color: "white",
                boxShadow: "none",
                borderRadius: "3px",
                padding: "4px 6px",
                height: '38px',
                "&:hover": {
                  backgroundColor: "rgb(60 181 170)", color: "white",
                },
              }} onClick={handleCaptureImageViewPopup}> <ImageIcon sx={{ fontSize: "14px" }} />Copy</Button>
            </Grid>
            <Grid item md={1} sm={6} xs={12}>
              <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseHistoryview}>{" "}Back{" "}</Button>
            </Grid>
          </Grid><br />
          <Box ref={gridRefImageUserShiftSummaryViewPopup}>
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <Typography sx={userStyle.SubHeaderText}><b>{`Attendance Status As On (${formatCustomDateTime(currentServerTimeView)})`}</b></Typography>
              </Grid>
              <Grid item md={12} sm={12} xs={12}>
                <Typography sx={userStyle.SubHeaderText}><b>{
                  historyViewData.unit !== "" ? `Attendance summary of: Company: ${historyViewData.company} / Branch: ${historyViewData.branch} / Unit: ${historyViewData.unit} / Date: ${historyViewData.date}`
                    : historyViewData.team !== "" ? `Attendance summary of: Company: ${historyViewData.company} / Branch: ${historyViewData.branch} / Unit: ${historyViewData.unit} / Team: ${historyViewData.team} / Date: ${historyViewData.date}`
                      : `Attendance summary of: Company: ${historyViewData.company} / Branch: ${historyViewData.branch} / Date: ${historyViewData.date}`
                }</b></Typography>
              </Grid>
            </Grid><br />
            <Grid container spacing={2}>
              <Grid item md={1}></Grid>
              {/* left side */}
              <Grid item md={4} sm={12} xs={12}>
                <Grid container spacing={1}>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.totalemployees}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Strength"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.totalcurrentshift}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Current Shift"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.paidpresentday}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Present"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.lopcount}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.totalin}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Total In"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #397bd4',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.totalout}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#397bd4' }}>{"Total No. Total Out"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#397bd4',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.totalpending}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Pending"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.facilitypresent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Facility Present"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.wfhpresent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. WFH Present"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.facilityabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Facility Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.wfhabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. WFH Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.earlyclockin}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#84c358' }}>{"Total No. Early-Clockin"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.onpresent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. On-Present"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.graceclockin}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Grace-Clockin"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.lateclockin}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Late-Clockin"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.weekoff}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Week Off"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={1}></Grid>
              {/* rigth side */}
              <Grid item md={4} sm={12} xs={12} >
                <Grid container spacing={1}>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.holidayCount}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Holiday"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.permissionCount}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Permission"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.clsl}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. CL/SL"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.onclockout}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. On-Clockout"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.earlyclockout}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Early-Clockout"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.overclockout}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Over-Clockout"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.autoclockout}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Auto-Mis Clockout"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.shiftnotstarted}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Shift Not Started"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.nostatus}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. No Status"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.notallotted}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Not Allotted"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #86c257',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.weekoffpresent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Weekoff Present"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#86c257',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ffa32c',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.longleaveabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Long Leave & Long Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ffa32c',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #ff5c4b',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.blabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. BL-Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#ff5c4b',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #8a69fe',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.doubledayabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Double Day Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#8a69fe',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                  <Grid item md={12} sm={12} xs={12}>
                    <Box sx={overallBoxStyle}>
                      <Box sx={{
                        position: 'absolute',
                        top: '50%',
                        left: 0,
                        transform: 'translate(-50%, -50%)',
                        width: 50,
                        height: 50,
                        borderRadius: '50%',
                        border: '6px solid #00bbce',
                        backgroundColor: '#fff',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        fontSize: 18,
                        fontWeight: 'bold',
                        color: '#333',
                        zIndex: 1,
                      }}>{historyViewData.weekoffabsent}</Box>
                      <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Weekoff Absent"}</Typography></Box>
                      <Box sx={{
                        width: 8,
                        height: '70%',
                        backgroundColor: '#00bbce',
                        position: 'absolute',
                        right: '-8px',
                        top: '15%',
                        borderTopRightRadius: '6px',
                        borderBottomRightRadius: '6px',
                      }} />
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
              <Grid item md={2}></Grid>
            </Grid>
          </Box>
        </Box>
      </Dialog >

      {/* Manage Column */}
      < Popover
        id={idManageColumnsUserShiftSummary}
        open={isManageColumnsOpenUserShiftSummary}
        anchorEl={anchorElUserShiftSummary}
        onClose={handleCloseManageColumnsUserShiftSummary}
        anchorOrigin={{ vertical: "bottom", horizontal: "left", }
        }
      >
        <ManageColumnsContent
          handleClose={handleCloseManageColumnsUserShiftSummary}
          searchQuery={searchQueryManageUserShiftSummary}
          setSearchQuery={setSearchQueryManageUserShiftSummary}
          filteredColumns={filteredColumns}
          columnVisibility={columnVisibilityUserShiftSummary}
          toggleColumnVisibility={toggleColumnVisibility}
          setColumnVisibility={setColumnVisibilityUserShiftSummary}
          initialColumnVisibility={initialColumnVisibilityUserShiftSummary}
          columnDataTable={columnDataTableUserShiftSummary}
        />
      </Popover >

      {/* Manage Column */}
      < Popover
        id={idView}
        open={isManageColumnsOpenView}
        anchorEl={anchorElView}
        onClose={handleCloseManageColumnsView}
        anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
      >
        <ManageColumnsContent
          handleClose={handleCloseManageColumnsView}
          searchQuery={searchQueryManageView}
          setSearchQuery={setSearchQueryManageView}
          filteredColumns={filteredColumnsView}
          columnVisibility={columnVisibilityView}
          toggleColumnVisibility={toggleColumnVisibilityView}
          setColumnVisibility={setColumnVisibilityView}
          initialColumnVisibility={initialColumnVisibilityView}
          columnDataTable={columnDataTableView}
        />
      </Popover >

      {/* Search Bar */}
      < Popover
        id={idSearchUserShiftSummary}
        open={openSearchUserShiftSummary}
        anchorEl={anchorElSearchUserShiftSummary}
        onClose={handleCloseSearchUserShiftSummary}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
      >
        <AdvancedSearchBar columns={columnDataTableUserShiftSummary} onSearch={applyAdvancedFilter} initialSearchValue={searchQueryUserShiftSummary} handleCloseSearch={handleCloseSearchUserShiftSummary} />
      </Popover >

      {/* ALERT DIALOG */}
      < Box >
        <Dialog open={isErrorOpen} onClose={handleCloseerr} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
          <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
            <Typography variant="h6">{showAlert}</Typography>
          </DialogContent>
          <DialogActions>
            <Button variant="contained" color="error" onClick={handleCloseerr}>
              ok
            </Button>
          </DialogActions>
        </Dialog>
      </Box >
      <MessageAlert
        openPopup={openPopupMalert}
        handleClosePopup={handleClosePopupMalert}
        popupContent={popupContentMalert}
        popupSeverity={popupSeverityMalert}
      />
      {/* SUCCESS */}
      <AlertDialog
        openPopup={openPopup}
        handleClosePopup={handleClosePopup}
        popupContent={popupContent}
        popupSeverity={popupSeverity}
      />
      {/* EXTERNAL COMPONENTS -------------- END */}
      {/* PRINT PDF EXCEL CSV */}
      <ExportData
        isFilterOpen={isFilterOpen}
        handleCloseFilterMod={handleCloseFilterMod}
        fileFormat={fileFormat}
        setIsFilterOpen={setIsFilterOpen}
        isPdfFilterOpen={isPdfFilterOpen}
        setIsPdfFilterOpen={setIsPdfFilterOpen}
        handleClosePdfFilterMod={handleClosePdfFilterMod}
        filteredDataTwo={(filteredRowData.length > 0 ? filteredRowData : filteredData) ?? []}
        itemsTwo={userShifts ?? []}
        filename={"Attendance Summary Report"}
        exportColumnNames={exportColumnNamescrt}
        exportRowValues={exportRowValuescrt}
        componentRef={componentRef}
      />
      <ExportData
        isFilterOpen={isFilterOpenView}
        handleCloseFilterMod={handleCloseFilterModView}
        fileFormat={fileFormat}
        setIsFilterOpen={setIsFilterOpenView}
        isPdfFilterOpen={isPdfFilterOpenView}
        setIsPdfFilterOpen={setIsPdfFilterOpenView}
        handleClosePdfFilterMod={handleClosePdfFilterModView}
        filteredDataTwo={(filteredChangesView !== null ? filteredRowDataView : rowDataTableView) ?? []}
        itemsTwo={viewData ?? []}
        filename={tableName}
        exportColumnNames={exportColumnNamesView}
        exportRowValues={exportRowValuesView}
        componentRef={componentRefView}
      />
    </Box >
  );
}

export default AttendanceSummaryReportList;