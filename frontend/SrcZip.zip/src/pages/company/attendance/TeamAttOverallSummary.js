import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from 'react';
import { FaFileExcel, FaFileCsv, FaPrint, FaFilePdf, FaSearch } from 'react-icons/fa';
import { Box, Typography, OutlinedInput, Select, MenuItem, Dialog, InputAdornment, FormControl, Grid, Button, Popover, IconButton, Tooltip } from '@mui/material';
import { userStyle } from '../../../pageStyle';
import 'jspdf-autotable';
import { handleApiError } from '../../../components/Errorhandling';
import { useReactToPrint } from 'react-to-print';
import { UserRoleAccessContext } from '../../../context/Appcontext';
import { getCurrentServerTime } from '../../../components/getCurrentServerTime';
import { ThreeDots } from 'react-loader-spinner';
import ImageIcon from '@mui/icons-material/Image';
import { saveAs } from 'file-saver';
import { IoMdOptions } from 'react-icons/io';
import { MdClose } from 'react-icons/md';
import AggregatedSearchBar from '../../../components/AggregatedSearchBar';
import AggridTable from '../../../components/AggridTable';
import domtoimage from 'dom-to-image';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import ExportData from '../../../components/ExportData';
import MessageAlert from '../../../components/MessageAlert';
import AlertDialog from '../../../components/Alert';
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from '../../../components/ManageColumn';
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function TeamAttSummaryList({ userShiftsUserShiftSummary, loader, setSearchQueryUserShiftSummary, setPageUserShiftSummary, setTotalPagesUserShiftSummary, setPageSizeUserShiftSummary, totalPagesUserShiftSummary, pageUserShiftSummary, pageSizeUserShiftSummary, searchQueryUserShiftSummary, filterUser }) {

    let overallBoxStyle = {
        background: '#fff',
        borderRadius: '5px',
        padding: '10px 12px 10px 60px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.51)',
        display: 'flex',
        alignItems: 'center',
        position: 'relative',
    }

    function formatCustomDateTime(date) {
        if (!date) {
            return '';
        }
        const dd = String(date.getDate()).padStart(2, '0');
        const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const yyyy = date.getFullYear();

        let hh = date.getHours();
        const min = String(date.getMinutes()).padStart(2, '0');
        const ss = String(date.getSeconds()).padStart(2, '0');
        const period = hh >= 12 ? 'PM' : 'AM';

        hh = String(hh).padStart(2, '0');

        return `${dd}-${mm}-${yyyy} ${hh}:${min}:${ss} ${period}`;
    }

    const gridRefTableUserShiftSummary = useRef(null);
    const gridRefImageUserShiftSummary = useRef(null);
    const gridRefImageUserShiftSummaryViewPopup = useRef(null);
    const gridRefTableView = useRef(null);
    const gridRefTableImgView = useRef(null);

    const { isUserRoleAccess, isUserRoleCompare, buttonStyles } = useContext(UserRoleAccessContext);

    const [viewData, setViewData] = useState([]);
    const [tableName, setTableName] = useState('');
    const [itemsAttSummary, setItemsAttSummary] = useState([]);

    const [advancedFilterUserShiftSummary, setAdvancedFilterUserShiftSummary] = useState(null);
    const [gridApiUserShiftSummary, setGridApiUserShiftSummary] = useState(null);
    const [columnApiUserShiftSummary, setColumnApiUserShiftSummary] = useState(null);
    const [filteredDataItemsUserShiftSummary, setFilteredDataItemsUserShiftSummary] = useState(userShiftsUserShiftSummary);
    const [filteredRowDataUserShiftSummary, setFilteredRowDataUserShiftSummary] = useState([]);

    const [itemsView, setItemsView] = useState([]);
    const [loaderView, setLoaderView] = useState(false);
    const [selectedRowsView, setSelectedRowsView] = useState([]);

    const [filteredRowDataView, setFilteredRowDataView] = useState([]);
    const [filteredChangesView, setFilteredChangesView] = useState(null);
    const [isHandleChangeView, setIsHandleChangeView] = useState(false);
    const [searchedStringView, setSearchedStringView] = useState('');

    const [pageView, setPageView] = useState(1);
    const [pageSizeView, setPageSizeView] = useState(10);
    const [searchQueryView, setSearchQueryView] = useState('');

    const [isFilterOpenView, setIsFilterOpenView] = useState(false);
    const [isPdfFilterOpenView, setIsPdfFilterOpenView] = useState(false);
    // page refersh reload
    const handleCloseFilterModView = () => {
        setIsFilterOpenView(false);
    };
    const handleClosePdfFilterModView = () => {
        setIsPdfFilterOpenView(false);
    };

    // Error Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const handleClickOpenerr = () => {
        setIsErrorOpen(true);
    };
    const handleCloseerr = () => {
        setIsErrorOpen(false);
    };

    const [isFilterOpenUserShiftSummary, setIsFilterOpenUserShiftSummary] = useState(false);
    const [isPdfFilterOpenUserShiftSummary, setIsPdfFilterOpenUserShiftSummary] = useState(false);
    // pageUserShiftSummary refersh reload
    const handleCloseFilterModUserShiftSummary = () => {
        setIsFilterOpenUserShiftSummary(false);
    };
    const handleClosePdfFilterModUserShiftSummary = () => {
        setIsPdfFilterOpenUserShiftSummary(false);
    };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState('');
    const [popupSeverityMalert, setPopupSeverityMalert] = useState('');
    const handleClickOpenPopupMalert = () => {
        setOpenPopupMalert(true);
    };
    const handleClosePopupMalert = () => {
        setOpenPopupMalert(false);
    };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState('');
    const [popupSeverity, setPopupSeverity] = useState('');
    const handleClickOpenPopup = () => {
        setOpenPopup(true);
    };
    const handleClosePopup = () => {
        setOpenPopup(false);
    };

    // View model
    const [openview, setOpenview] = useState(false);
    const handleClickOpenview = () => {
        setOpenview(true);
    };
    const handleCloseview = () => {
        setOpenview(false);
        setViewData([]);
        setPageView(1);
        setSearchQueryView('');
    };

    // History model
    const [openHistoryview, setOpenHistoryview] = useState(false);
    const handleClickOpenHistoryview = () => { setOpenHistoryview(true); };
    const handleCloseHistoryview = () => { setOpenHistoryview(false); }

    // pageUserShiftSummary refersh reload
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ''; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener('beforeunload', beforeUnloadHandler);
        return () => {
            window.removeEventListener('beforeunload', beforeUnloadHandler);
        };
    }, []);

    // Manage Columns
    const [isManageColumnsOpenUserShiftSummary, setManageColumnsOpenUserShiftSummary] = useState(false);
    const [anchorElUserShiftSummary, setAnchorElUserShiftSummary] = useState(null);
    const [searchQueryManageUserShiftSummary, setSearchQueryManageUserShiftSummary] = useState('');
    const handleOpenManageColumnsUserShiftSummary = (event) => {
        setAnchorElUserShiftSummary(event.currentTarget);
        setManageColumnsOpenUserShiftSummary(true);
    };
    const handleCloseManageColumnsUserShiftSummary = () => {
        setManageColumnsOpenUserShiftSummary(false);
        setSearchQueryManageUserShiftSummary('');
    };
    const openManageColumnsUserShiftSummary = Boolean(anchorElUserShiftSummary);
    const idManageColumnsUserShiftSummary = openManageColumnsUserShiftSummary ? 'simple-popover' : undefined;

    // Search bar
    const [anchorElSearchUserShiftSummary, setAnchorElSearchUserShiftSummary] = React.useState(null);
    const handleClickSearchUserShiftSummary = (event) => {
        setAnchorElSearchUserShiftSummary(event.currentTarget);
    };
    const handleCloseSearchUserShiftSummary = () => {
        setAnchorElSearchUserShiftSummary(null);
        setSearchQueryUserShiftSummary('');
    };

    const openSearchUserShiftSummary = Boolean(anchorElSearchUserShiftSummary);
    const idSearchUserShiftSummary = openSearchUserShiftSummary ? 'simple-popover' : undefined;

    const [searchQueryManageView, setSearchQueryManageView] = useState('');
    const [isManageColumnsOpenView, setManageColumnsOpenView] = useState(false);
    const [anchorElView, setAnchorElView] = useState(null);

    const handleOpenManageColumnsView = (event) => {
        setAnchorElView(event.currentTarget);
        setManageColumnsOpenView(true);
    };
    const handleCloseManageColumnsView = () => {
        setManageColumnsOpenView(false);
        setSearchQueryManageView('');
    };

    const openView = Boolean(anchorElView);
    const idView = openView ? 'simple-popover' : undefined;

    const [selectedMode, setSelectedMode] = useState('Today');
    const mode = [
        { label: 'Today', value: 'Today' },
        { label: 'Tomorrow', value: 'Tomorrow' },
        { label: 'Yesterday', value: 'Yesterday' },
        { label: 'This Week', value: 'This Week' },
        { label: 'This Month', value: 'This Month' },
        { label: 'Last Week', value: 'Last Week' },
        { label: 'Last Month', value: 'Last Month' },
        { label: 'Custom', value: 'Custom' },
    ];

    const modeOptions = [
        { label: 'Department', value: 'Department' },
        { label: 'Employee', value: 'Employee' },
    ];

    // Show All Columns & Manage Columns
    const initialColumnVisibilityUserShiftSummary = {
        serialNumber: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        history: true,
        totalemployees: true,
        totalcurrentshift: true,
        paidpresentday: true,
        lopcount: true,
        totalin: true,
        totalout: true,
        totalpending: true,
        facilitypresent: true,
        wfhpresent: true,
        facilityabsent: true,
        wfhabsent: true,
        earlyclockin: true,
        onpresent: true,
        graceclockin: true,
        lateclockin: true,
        weekoff: true,
        holidayCount: true,
        permissionCount: true,
        clsl: true,
        onclockout: true,
        earlyclockout: true,
        overclockout: true,
        autoclockout: true,
        shiftnotstarted: true,
        nostatus: true,
        notallotted: true,
        weekoffpresent: true,
        longleaveabsent: true,
        blabsent: true,
        doubledayabsent: true,
        weekoffabsent: true,
    };
    const [columnVisibilityUserShiftSummary, setColumnVisibilityUserShiftSummary] = useState(initialColumnVisibilityUserShiftSummary);

    const initialColumnVisibilityView = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        date: true,
        shiftmode: true,
        shift: true,
        changeshift: true,
        leavestatus: true,
        permissionstatus: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        daystatus: true,
        appliedthrough: true,
        isweekoff: true,
        isholiday: true,
        lopcalculation: true,
        modetarget: true,
        paidpresent: true,
        lopday: true,
        paidpresentday: true,
    };

    const [columnVisibilityView, setColumnVisibilityView] = useState(initialColumnVisibilityView);

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    };

    const addSerialNumberAttSummary = async (datas) => {
        setItemsAttSummary(datas);
    };

    useEffect(() => {
        addSerialNumberAttSummary(userShiftsUserShiftSummary);
        setFilteredDataItemsUserShiftSummary(userShiftsUserShiftSummary);
    }, [userShiftsUserShiftSummary]);

    const getCode = (rowdata, column) => {
        setLoaderView(true);
        try {
            handleClickOpenview();
            if (column === 'totalemployees') {
                setTableName('Total Employees List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.totalemployeesArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalcurrentshift') {
                setTableName('Total Current Shift List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.totalcurrentshiftArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'paidpresentday') {
                setTableName('Present List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.paidpresentdayArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'lopcount') {
                setTableName('Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.absentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalin') {
                setTableName('Total In List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.totalinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalout') {
                setTableName('Total Out List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.totaloutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalpending') {
                setTableName('Total Pending List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.totalpendingArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'facilitypresent') {
                setTableName('Facility Present List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.facilitypresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'wfhpresent') {
                setTableName('WFH Present List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.wfhpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'facilityabsent') {
                setTableName('Facility Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.facilityabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'wfhabsent') {
                setTableName('WFH Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.wfhabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'earlyclockin') {
                setTableName('Early - ClockIn List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.earlyclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'onpresent') {
                setTableName('On - Present List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.onpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'graceclockin') {
                setTableName('Grace - ClockIn List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.graceclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'lateclockin') {
                setTableName('Late - ClockIn List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.lateclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoff') {
                setTableName('Week Off List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.weekoffArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'holidayCount') {
                setTableName('Holiday List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.holidayArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'permissionCount') {
                setTableName('Permission List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.permissionArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'clsl') {
                setTableName('CL/SL List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.clslArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'onclockout') {
                setTableName('On - ClockOut List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.onclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'earlyclockout') {
                setTableName('Early - ClockOut List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.earlyclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'overclockout') {
                setTableName('Over - ClockOut List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.overclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'autoclockout') {
                setTableName('Auto - ClockOut List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.autoclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'shiftnotstarted') {
                setTableName('Shift Not Started List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.shiftnotstartedArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'nostatus') {
                setTableName('No Status List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.nostatusArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'notallotted') {
                setTableName('Not Allotted List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.notallottedArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoffpresent') {
                setTableName('Weekoff Present List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.weekoffpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'longleaveabsent') {
                setTableName('Long Leave & Long Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.longleaveabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'blabsent') {
                setTableName('BL - Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.blabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'doubledayabsent') {
                setTableName('Double Day Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.doubledayabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoffabsent') {
                setTableName('Weekoff Absent List');
                if (rowdata.team === isUserRoleAccess.team) {
                    setViewData(rowdata.weekoffabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            setLoaderView(false);
        } catch (err) {
            setLoaderView(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    const [historyViewData, setHistoryViewData] = useState({});
    const [currentServerTime, setCurrentServerTime] = useState(null);
    const getHistoryCode = async (rowdata) => {
        const time = await getCurrentServerTime();
        setCurrentServerTime(time);
        try {
            handleClickOpenHistoryview();
            setHistoryViewData(rowdata);
        } catch (err) {
            setLoaderView(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    }

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ['apply', 'reset', 'cancel'],
            },
        };
    }, []);

    const onGridReadyUserShiftSummary = useCallback((params) => {
        setGridApiUserShiftSummary(params.api);
        setColumnApiUserShiftSummary(params.columnApiUserShiftSummary);
    }, []);

    // Function to handle filter changes
    const onFilterChangedUserShiftSummary = () => {
        if (gridApiUserShiftSummary) {
            const filterModel = gridApiUserShiftSummary.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataUserShiftSummary([]);
            } else {
                // Filters are active, capture filtered data
                const filteredDataUserShiftSummary = [];
                gridApiUserShiftSummary.forEachNodeAfterFilterAndSort((node) => {
                    filteredDataUserShiftSummary.push(node.data);
                });
                setFilteredRowDataUserShiftSummary(filteredDataUserShiftSummary);
            }
        }
    };

    const onPaginationChanged = useCallback(() => {
        if (gridRefTableUserShiftSummary.current) {
            const gridApiUserShiftSummary = gridRefTableUserShiftSummary.current.api;
            const currentPage = gridApiUserShiftSummary.paginationGetCurrentPage() + 1;
            const totalPagesUserShiftSummary = gridApiUserShiftSummary.paginationGetTotalPages();
            setPageUserShiftSummary(currentPage);
            setTotalPagesUserShiftSummary(totalPagesUserShiftSummary);
        }
    }, []);

    const columnDataTableUserShiftSummary = [
        { field: 'serialNumber', headerName: 'SNo', flex: 0, width: 80, hide: !columnVisibilityUserShiftSummary.serialNumber, pinned: 'left', lockPinned: true },
        { field: 'company', headerName: 'Company', flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.company },
        { field: 'branch', headerName: 'Branch', flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.branch },
        { field: 'unit', headerName: 'Unit', flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.unit },
        { field: 'team', headerName: 'Team', flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.team },
        {
            field: "history", headerName: "History", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.history,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small" onClick={() => { getHistoryCode(params.data); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalemployees", headerName: "Total Employees", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.totalemployees,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalemployees}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalemployees'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalcurrentshift", headerName: "Total Current Shift", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummary.totalcurrentshift,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalcurrentshift}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalcurrentshift'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "paidpresentday", headerName: "Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.paidpresentday,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.paidpresentday}
                        <Button size="small" onClick={() => { getCode(params.data, 'paidpresentday'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "lopcount", headerName: "Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.lopcount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.lopcount}
                        <Button size="small" onClick={() => { getCode(params.data, 'lopcount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalin", headerName: "Total In", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalin}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalout", headerName: "Total Out", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalout}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalpending", headerName: "Total Pending", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.totalpending,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalpending}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalpending'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "facilitypresent", headerName: "Facility Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.facilitypresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.facilitypresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'facilitypresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "wfhpresent", headerName: "WFH Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.wfhpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.wfhpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'wfhpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "facilityabsent", headerName: "Facility Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.facilityabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.facilityabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'facilityabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "wfhabsent", headerName: "WFH Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummary.wfhabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.wfhabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'wfhabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "earlyclockin", headerName: "Early - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.earlyclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.earlyclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'earlyclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "onpresent", headerName: "On - Present", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.onpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.onpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'onpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "graceclockin", headerName: "Grace - ClockIn", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.graceclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.graceclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'graceclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "lateclockin", headerName: "Late - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.lateclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.lateclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'lateclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoff", headerName: "Week Off", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.weekoff,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoff}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoff'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "holidayCount", headerName: "Holiday", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.holidayCount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.holidayCount}
                        <Button size="small" onClick={() => { getCode(params.data, 'holidayCount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "permissionCount", headerName: "Permission", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.permissionCount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.permissionCount}
                        <Button size="small" onClick={() => { getCode(params.data, 'permissionCount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "clsl", headerName: "CL/SL", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummary.clsl,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.clsl}
                        <Button size="small" onClick={() => { getCode(params.data, 'clsl'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "onclockout", headerName: "On - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.onclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.onclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'onclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "earlyclockout", headerName: "Early - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.earlyclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.earlyclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'earlyclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "overclockout", headerName: "Over - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.overclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.overclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'overclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "autoclockout", headerName: "Auto-Mis ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.autoclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.autoclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'autoclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "shiftnotstarted", headerName: "Shift Not Started", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.shiftnotstarted,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.shiftnotstarted}
                        <Button size="small" onClick={() => { getCode(params.data, 'shiftnotstarted'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "nostatus", headerName: "No Status", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.nostatus,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.nostatus}
                        <Button size="small" onClick={() => { getCode(params.data, 'nostatus'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "notallotted", headerName: "Not Allotted", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.notallotted,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.notallotted}
                        <Button size="small" onClick={() => { getCode(params.data, 'notallotted'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoffpresent", headerName: "Weekoff Present", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.weekoffpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoffpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoffpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "longleaveabsent", headerName: "Long Leave & Long Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.longleaveabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.longleaveabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'longleaveabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "blabsent", headerName: "BL Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.blabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.blabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'blabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "doubledayabsent", headerName: "Double Day Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.doubledayabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.doubledayabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'doubledayabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoffabsent", headerName: "Weekoff Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummary.weekoffabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoffabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoffabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
    ];

    const columnDataTableView = [
        { field: 'serialNumber', headerName: 'SNo', flex: 0, width: 75, hide: !columnVisibilityView.serialNumber, pinned: 'left', lockPinned: true },
        { field: 'empcode', headerName: 'Emp Code', flex: 0, width: 150, hide: !columnVisibilityView.empcode, pinned: 'left', lockPinned: true },
        { field: 'username', headerName: 'Employee Name', flex: 0, width: 250, hide: !columnVisibilityView.username, pinned: 'left', lockPinned: true },
        { field: 'company', headerName: 'Company', flex: 0, width: 130, hide: !columnVisibilityView.company },
        { field: 'branch', headerName: 'Branch', flex: 0, width: 130, hide: !columnVisibilityView.branch },
        { field: 'unit', headerName: 'Unit', flex: 0, width: 130, hide: !columnVisibilityView.unit },
        { field: 'team', headerName: 'Team', flex: 0, width: 130, hide: !columnVisibilityView.team },
        { field: 'department', headerName: 'Department', flex: 0, width: 130, hide: !columnVisibilityView.department },
        { field: 'date', headerName: 'Date', flex: 0, width: 110, hide: !columnVisibilityView.date },
        { field: 'shiftmode', headerName: 'Shift Mode', flex: 0, width: 110, hide: !columnVisibilityView.shiftmode },
        { field: 'shift', headerName: 'Shift', flex: 0, width: 150, hide: !columnVisibilityView.shift },
        { field: 'changeshift', headerName: 'Change Shift', flex: 0, width: 150, hide: !columnVisibilityView.changeshift },
        { field: 'leavestatus', headerName: 'Leave Status', flex: 0, width: 150, hide: !columnVisibilityView.leavestatus },
        { field: 'permissionstatus', headerName: 'Permission Status', flex: 0, width: 150, hide: !columnVisibilityView.permissionstatus },
        { field: 'clockin', headerName: 'ClockIn', flex: 0, width: 120, hide: !columnVisibilityView.clockin },
        {
            field: 'clockinstatus',
            headerName: 'ClockInStatus',
            flex: 0,
            width: 200,
            hide: !columnVisibilityView.clockinstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button
                            size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave' ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color:
                                    params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn'
                                        ? 'black'
                                        : params.data.clockinstatus === 'Holiday'
                                            ? 'black'
                                            : params.data.clockinstatus === 'Leave'
                                                ? 'white'
                                                : params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent'
                                                    ? '#462929'
                                                    : params.data.clockinstatus === 'Week Off'
                                                        ? 'white'
                                                        : params.data.clockinstatus === 'Grace - ClockIn'
                                                            ? '#052106'
                                                            : params.data.clockinstatus === 'On - Present'
                                                                ? 'black'
                                                                : params.data.clockinstatus === 'HBLOP'
                                                                    ? 'white'
                                                                    : params.data.clockinstatus === 'FLOP'
                                                                        ? 'white'
                                                                        : params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave'
                                                                            ? 'black'
                                                                            : params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave'
                                                                                ? 'black'
                                                                                : params.data.clockinstatus?.includes('Late')
                                                                                    ? '#15111d'
                                                                                    : '#15111d',
                                backgroundColor:
                                    params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn'
                                        ? 'rgb(156 239 156)'
                                        : params.data.clockinstatus === 'Holiday'
                                            ? '#B6FFFA'
                                            : params.data.clockinstatus === 'Leave'
                                                ? '#1640D6'
                                                : params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent'
                                                    ? '#ff00007d'
                                                    : params.data.clockinstatus === 'Week Off'
                                                        ? '#6b777991'
                                                        : params.data.clockinstatus === 'Grace - ClockIn'
                                                            ? 'rgb(243 203 117)'
                                                            : params.data.clockinstatus === 'On - Present'
                                                                ? '#E1AFD1'
                                                                : params.data.clockinstatus === 'HBLOP'
                                                                    ? '#DA0C81'
                                                                    : params.data.clockinstatus === 'FLOP'
                                                                        ? '#FE0000'
                                                                        : params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave'
                                                                            ? '#F2D1D1'
                                                                            : params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave'
                                                                                ? '#EEE3CB'
                                                                                : params.data.clockinstatus?.includes('Late')
                                                                                    ? '#610c9f57'
                                                                                    : 'rgb(243 203 117)',
                                '&:hover': {
                                    color:
                                        params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn'
                                            ? 'black'
                                            : params.data.clockinstatus === 'Holiday'
                                                ? 'black'
                                                : params.data.clockinstatus === 'Leave'
                                                    ? 'white'
                                                    : params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent'
                                                        ? '#462929'
                                                        : params.data.clockinstatus === 'Week Off'
                                                            ? 'white'
                                                            : params.data.clockinstatus === 'Grace - ClockIn'
                                                                ? '#052106'
                                                                : params.data.clockinstatus === 'On - Present'
                                                                    ? 'black'
                                                                    : params.data.clockinstatus === 'HBLOP'
                                                                        ? 'white'
                                                                        : params.data.clockinstatus === 'FLOP'
                                                                            ? 'white'
                                                                            : params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave'
                                                                                ? 'black'
                                                                                : params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave'
                                                                                    ? 'black'
                                                                                    : params.data.clockinstatus?.includes('Late')
                                                                                        ? '#15111d'
                                                                                        : '#15111d',
                                    backgroundColor:
                                        params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn'
                                            ? 'rgb(156 239 156)'
                                            : params.data.clockinstatus === 'Holiday'
                                                ? '#B6FFFA'
                                                : params.data.clockinstatus === 'Leave'
                                                    ? '#1640D6'
                                                    : params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent'
                                                        ? '#ff00007d'
                                                        : params.data.clockinstatus === 'Week Off'
                                                            ? '#6b777991'
                                                            : params.data.clockinstatus === 'Grace - ClockIn'
                                                                ? 'rgb(243 203 117)'
                                                                : params.data.clockinstatus === 'On - Present'
                                                                    ? '#E1AFD1'
                                                                    : params.data.clockinstatus === 'HBLOP'
                                                                        ? '#DA0C81'
                                                                        : params.data.clockinstatus === 'FLOP'
                                                                            ? '#FE0000'
                                                                            : params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave'
                                                                                ? '#F2D1D1'
                                                                                : params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave'
                                                                                    ? '#EEE3CB'
                                                                                    : params.data.clockinstatus?.includes('Late')
                                                                                        ? '#610c9f57'
                                                                                        : 'rgb(243 203 117)',
                                },
                            }}
                        >
                            {params.data.clockinstatus}
                        </Button>
                    </Grid>
                );
            },
        },
        { field: 'clockout', headerName: 'ClockOut', flex: 0, width: 120, hide: !columnVisibilityView.clockout },
        {
            field: 'clockoutstatus',
            headerName: 'ClockOutStatus',
            flex: 0,
            width: 200,
            hide: !columnVisibilityView.clockoutstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button
                            size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave' ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color:
                                    params.data.clockoutstatus === 'Holiday'
                                        ? 'black'
                                        : params.data.clockoutstatus === 'Leave'
                                            ? 'white'
                                            : params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent'
                                                ? '#462929'
                                                : params.data.clockoutstatus === 'Week Off'
                                                    ? 'white'
                                                    : params.data.clockoutstatus === 'On - ClockOut'
                                                        ? 'black'
                                                        : params.data.clockoutstatus === 'Over - ClockOut'
                                                            ? '#052106'
                                                            : params.data.clockoutstatus === 'Mis - ClockOut'
                                                                ? '#15111d'
                                                                : params.data.clockoutstatus?.includes('Early')
                                                                    ? '#052106'
                                                                    : params.data.clockoutstatus === 'HALOP'
                                                                        ? 'white'
                                                                        : params.data.clockoutstatus === 'FLOP'
                                                                            ? 'white'
                                                                            : params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave'
                                                                                ? 'black'
                                                                                : params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave'
                                                                                    ? 'black'
                                                                                    : params.data.clockoutstatus === 'Pending'
                                                                                        ? '#052106'
                                                                                        : '#052106',
                                backgroundColor:
                                    params.data.clockoutstatus === 'Holiday'
                                        ? '#B6FFFA'
                                        : params.data.clockoutstatus === 'Leave'
                                            ? '#1640D6'
                                            : params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent'
                                                ? '#ff00007d'
                                                : params.data.clockoutstatus === 'Week Off'
                                                    ? '#6b777991'
                                                    : params.data.clockoutstatus === 'On - ClockOut'
                                                        ? '#E1AFD1'
                                                        : params.data.clockoutstatus === 'Over - ClockOut'
                                                            ? 'rgb(156 239 156)'
                                                            : params.data.clockoutstatus === 'Mis - ClockOut'
                                                                ? '#610c9f57'
                                                                : params.data.clockoutstatus?.includes('Early')
                                                                    ? 'rgb(243 203 117)'
                                                                    : params.data.clockoutstatus === 'HALOP'
                                                                        ? '#DA0C81'
                                                                        : params.data.clockoutstatus === 'FLOP'
                                                                            ? '#FE0000'
                                                                            : params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave'
                                                                                ? '#F2D1D1'
                                                                                : params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave'
                                                                                    ? '#EEE3CB'
                                                                                    : params.data.clockoutstatus === 'Pending'
                                                                                        ? 'rgb(243 203 117)'
                                                                                        : 'rgb(243 203 117)',
                                '&:hover': {
                                    color:
                                        params.data.clockoutstatus === 'Holiday'
                                            ? 'black'
                                            : params.data.clockoutstatus === 'Leave'
                                                ? 'white'
                                                : params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent'
                                                    ? '#462929'
                                                    : params.data.clockoutstatus === 'Week Off'
                                                        ? 'white'
                                                        : params.data.clockoutstatus === 'On - ClockOut'
                                                            ? 'black'
                                                            : params.data.clockoutstatus === 'Over - ClockOut'
                                                                ? '#052106'
                                                                : params.data.clockoutstatus === 'Mis - ClockOut'
                                                                    ? '#15111d'
                                                                    : params.data.clockoutstatus?.includes('Early')
                                                                        ? '#052106'
                                                                        : params.data.clockoutstatus === 'HALOP'
                                                                            ? 'white'
                                                                            : params.data.clockoutstatus === 'FLOP'
                                                                                ? 'white'
                                                                                : params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave'
                                                                                    ? 'black'
                                                                                    : params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave'
                                                                                        ? 'black'
                                                                                        : params.data.clockoutstatus === 'Pending'
                                                                                            ? '#052106'
                                                                                            : '#052106',
                                    backgroundColor:
                                        params.data.clockoutstatus === 'Holiday'
                                            ? '#B6FFFA'
                                            : params.data.clockoutstatus === 'Leave'
                                                ? '#1640D6'
                                                : params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent'
                                                    ? '#ff00007d'
                                                    : params.data.clockoutstatus === 'Week Off'
                                                        ? '#6b777991'
                                                        : params.data.clockoutstatus === 'On - ClockOut'
                                                            ? '#E1AFD1'
                                                            : params.data.clockoutstatus === 'Over - ClockOut'
                                                                ? 'rgb(156 239 156)'
                                                                : params.data.clockoutstatus === 'Mis - ClockOut'
                                                                    ? '#610c9f57'
                                                                    : params.data.clockoutstatus?.includes('Early')
                                                                        ? 'rgb(243 203 117)'
                                                                        : params.data.clockoutstatus === 'HALOP'
                                                                            ? '#DA0C81'
                                                                            : params.data.clockoutstatus === 'FLOP'
                                                                                ? '#FE0000'
                                                                                : params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave'
                                                                                    ? '#F2D1D1'
                                                                                    : params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave'
                                                                                        ? '#EEE3CB'
                                                                                        : params.data.clockoutstatus === 'Pending'
                                                                                            ? 'rgb(243 203 117)'
                                                                                            : 'rgb(243 203 117)',
                                },
                            }}
                        >
                            {params.data.clockoutstatus}
                        </Button>
                    </Grid>
                );
            },
        },
        {
            field: 'attendanceauto',
            headerName: 'Attendance',
            flex: 0,
            width: 200,
            hide: !columnVisibilityView.attendanceauto,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button
                            size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === 'WEEKOFF' ? 'white' : '#052106',
                                backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === 'ABSENT' ? '#ff00007d' : params.data.attendanceauto === 'WEEKOFF' ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === 'WEEKOFF' ? 'white' : '#052106',
                                    backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === 'ABSENT' ? '#ff00007d' : params.data.attendanceauto === 'WEEKOFF' ? '#6b777991' : 'rgb(156 239 156)',
                                },
                            }}
                        >
                            {params.data.attendanceauto}
                        </Button>
                    </Grid>
                );
            },
        },
        {
            field: 'daystatus',
            headerName: 'Day Status',
            flex: 0,
            width: 200,
            hide: !columnVisibilityView.daystatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button
                            size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === 'WEEKOFF' ? 'white' : '#052106',
                                backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === 'ABSENT' ? '#ff00007d' : params.data.daystatus === 'WEEKOFF' ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === 'WEEKOFF' ? 'white' : '#052106',
                                    backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === 'ABSENT' ? '#ff00007d' : params.data.daystatus === 'WEEKOFF' ? '#6b777991' : 'rgb(156 239 156)',
                                },
                            }}
                        >
                            {params.data.daystatus}
                        </Button>
                    </Grid>
                );
            },
        },
        { field: 'appliedthrough', headerName: 'Applied Through', flex: 0, width: 120, hide: !columnVisibilityView.appliedthrough },
        { field: 'isweekoff', headerName: 'Is Week Off', flex: 0, width: 120, hide: !columnVisibilityView.isweekoff },
        { field: 'isholiday', headerName: 'Is Holiday', flex: 0, width: 120, hide: !columnVisibilityView.isholiday },
        { field: 'lopcalculation', headerName: 'LOP Calculation', flex: 0, width: 120, hide: !columnVisibilityView.lopcalculation },
        { field: 'modetarget', headerName: 'Target', flex: 0, width: 120, hide: !columnVisibilityView.modetarget },
        { field: 'paidpresent', headerName: 'Paid Present', flex: 0, width: 120, hide: !columnVisibilityView.paidpresent },
        { field: 'lopday', headerName: 'LOP Day', flex: 0, width: 120, hide: !columnVisibilityView.lopday },
        { field: 'paidpresentday', headerName: 'Paid Present Day', flex: 0, width: 120, hide: !columnVisibilityView.paidpresentday },
    ];

    // Datatable
    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchQueryUserShiftSummary(value);
        applyNormalFilterUserShiftSummary(value);
        setFilteredRowDataUserShiftSummary([]);
    };

    const applyNormalFilterUserShiftSummary = (searchValue) => {
        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(' ');

        // Modify the filtering logic to check each term
        const filtered = itemsAttSummary?.filter((item) => {
            return searchTerms.every((term) => Object.values(item).join(' ').toLowerCase().includes(term));
        });
        setFilteredDataItemsUserShiftSummary(filtered);
        setPageUserShiftSummary(1);
    };

    const applyAdvancedFilterUserShiftSummary = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttSummary?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case 'Contains':
                        match = itemValue.includes(filterValue);
                        break;
                    case 'Does Not Contain':
                        match = !itemValue?.includes(filterValue);
                        break;
                    case 'Equals':
                        match = itemValue === filterValue;
                        break;
                    case 'Does Not Equal':
                        match = itemValue !== filterValue;
                        break;
                    case 'Begins With':
                        match = itemValue.startsWith(filterValue);
                        break;
                    case 'Ends With':
                        match = itemValue.endsWith(filterValue);
                        break;
                    case 'Blank':
                        match = !itemValue;
                        break;
                    case 'Not Blank':
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === 'AND') {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsUserShiftSummary(filtered);
        setAdvancedFilterUserShiftSummary(filters);
        // handleCloseSearchUserShiftSummary();
    };

    // Undo filter funtion
    const handleResetSearchUserShiftSummary = () => {
        setAdvancedFilterUserShiftSummary(null);
        setSearchQueryUserShiftSummary('');
        setFilteredDataItemsUserShiftSummary(userShiftsUserShiftSummary);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayUserShiftSummary = () => {
        if (advancedFilterUserShiftSummary && advancedFilterUserShiftSummary.length > 0) {
            return advancedFilterUserShiftSummary
                .map((filter, index) => {
                    let showname = columnDataTableUserShiftSummary.find((col) => col.field === filter.column)?.headerName;
                    return `${showname} ${filter.condition} "${filter.value}"`;
                })
                .join(' ' + (advancedFilterUserShiftSummary.length > 1 ? advancedFilterUserShiftSummary[1].condition : '') + ' ');
        }
        return searchQueryUserShiftSummary;
    };

    const handlePageSizeChangeUserShiftSummary = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeUserShiftSummary(newSize);
        if (gridApiUserShiftSummary) {
            gridApiUserShiftSummary.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsUserShiftSummary = () => {
        const updatedVisibility = { ...columnVisibilityUserShiftSummary };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityUserShiftSummary(updatedVisibility);
    };

    const handleShowAllColumnsView = () => {
        const updatedVisibilityView = { ...columnVisibilityView };
        for (const columnKey in updatedVisibilityView) {
            updatedVisibilityView[columnKey] = true;
        }
        setColumnVisibilityView(updatedVisibilityView);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem('columnVisibilityUserShiftSummary');
        if (savedVisibility) {
            setColumnVisibilityUserShiftSummary(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem('columnVisibilityUserShiftSummary', JSON.stringify(columnVisibilityUserShiftSummary));
    }, [columnVisibilityUserShiftSummary]);

    // Function to filter columns based on search query
    const filteredColumns = columnDataTableUserShiftSummary.filter((column) => column.headerName.toLowerCase().includes(searchQueryManageUserShiftSummary.toLowerCase()));

    const filteredColumnsView = columnDataTableView.filter((column) => column.headerName.toLowerCase().includes(searchQueryManageView.toLowerCase()));

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibilityUserShiftSummary = (field) => {
        if (!gridApiUserShiftSummary) return;

        setColumnVisibilityUserShiftSummary((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiUserShiftSummary.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const toggleColumnVisibilityView = (field) => {
        setColumnVisibilityView((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    const handleColumnMovedUserShiftSummary = useCallback(
        debounce((event) => {
            if (!event.columnApiUserShiftSummary) return;

            const visible_columns = event.columnApiUserShiftSummary
                .getAllColumns()
                .filter((col) => {
                    const colState = event.columnApiUserShiftSummary.getColumnState().find((state) => state.colId === col.colId);
                    return colState && !colState.hide;
                })
                .map((col) => col.colId);

            setColumnVisibilityUserShiftSummary((prevVisibility) => {
                const updatedVisibility = { ...prevVisibility };

                // Ensure columns that are visible stay visible
                Object.keys(updatedVisibility).forEach((colId) => {
                    updatedVisibility[colId] = visible_columns.includes(colId);
                });

                return updatedVisibility;
            });
        }, 300),
        []
    );

    const handleColumnVisibleUserShiftSummary = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityUserShiftSummary((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormat, setFormat] = useState('');
    let exportColumnNamescrtUserShiftSummary = [
        "Company", "Branch", "Unit", "Team", "Total Employees", "Total Current Shift", "Present", "Absent", "Total In", "Total Out", "Total Pending", "Facility Present", "WFH Present", "Facility Absent", "WFH Absent", "Early - ClockIn", "On - Present", "Grace - ClockIn", "Late - ClockIn", "Week Off", "Holiday",
        "Permission", "CL/SL", "On - ClockOut", "Early - ClockOut", "Over - ClockOut", "Auto - ClockOut", "Shift Not Started", "No Status", "Not Allotted", "Weekoff Present", "Long Leave & Long Absent", "BL Absent", "Double Day Absent", "Weekoff Absent",
    ];
    let exportRowValuescrtUserShiftSummary = [
        'company', 'branch', 'unit', 'team', 'totalemployees', 'totalcurrentshift', 'paidpresentday', 'lopcount', 'totalin', 'totalout', 'totalpending', 'facilitypresent', 'wfhpresent', 'facilityabsent', 'wfhabsent', 'earlyclockin', 'onpresent', 'graceclockin', 'lateclockin', 'weekoff', 'holidayCount',
        'permissionCount', 'clsl', 'onclockout', 'earlyclockout', 'overclockout', 'autoclockout', 'shiftnotstarted', 'nostatus', 'notallotted', 'weekoffpresent', 'longleaveabsent', 'blabsent', 'doubledayabsent', 'weekoffabsent',
    ];

    let exportColumnNamesView = [
        'Emp Code',
        'Employee Name',
        'Company',
        'Branch',
        'Unit',
        'Team',
        'Department',
        'Date',
        'Shift Mode',
        'Shift',
        'Change Shift',
        'Leave Status',
        'Permission Status',
        'ClockIn',
        'ClockInStatus',
        'ClockOut',
        'ClockOutStatus',
        'Attendance',
        'Day Status',
        'Applied Through',
        'Is Week Off',
        'Is Holiday',
        'LOP Calculation',
        'Target',
        'Paid Present',
        'LOP Day',
        'Paid Present Day',
    ];
    let exportRowValuesView = [
        'empcode',
        'username',
        'company',
        'branch',
        'unit',
        'team',
        'department',
        'date',
        'shiftmode',
        'shift',
        'changeshift',
        'leavestatus',
        'permissionstatus',
        'clockin',
        'clockinstatus',
        'clockout',
        'clockoutstatus',
        'attendanceauto',
        'daystatus',
        'appliedthrough',
        'isweekoff',
        'isholiday',
        'lopcalculation',
        'modetarget',
        'paidpresent',
        'lopday',
        'paidpresentday',
    ];

    // print...
    const componentRefUserShiftSummary = useRef();
    const handleprintUserShiftSummary = useReactToPrint({
        content: () => componentRefUserShiftSummary.current,
        documentTitle: 'Team Attendance Summary Report',
        pageStyle: 'print',
    });

    const componentRefView = useRef();
    const handleprintView = useReactToPrint({
        content: () => componentRefView.current,
        documentTitle: `${tableName}`,
        pageStyle: 'print',
    });

    // image
    const handleCaptureImageUserShiftSummary = () => {
        if (gridRefImageUserShiftSummary.current) {
            domtoimage
                .toBlob(gridRefImageUserShiftSummary.current)
                .then((blob) => {
                    saveAs(blob, 'Team Attendance Summary Report.png');
                })
                .catch((error) => {
                    console.error('dom-to-image error: ', error);
                });
        }
    };

    const handleCaptureImageView = () => {
        if (gridRefTableImgView.current) {
            domtoimage
                .toBlob(gridRefTableImgView.current)
                .then((blob) => {
                    saveAs(blob, `${tableName}.png`);
                })
                .catch((error) => {
                    console.error('dom-to-image error: ', error);
                });
        }
    };

    // image view
    const handleCaptureImageViewPopup = () => {
        if (gridRefImageUserShiftSummaryViewPopup.current) {
            domtoimage.toBlob(gridRefImageUserShiftSummaryViewPopup.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Summary Report.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    const addSerialNumberView = (datas) => {
        setItemsView(datas);
    };

    useEffect(() => {
        addSerialNumberView(viewData);
    }, [viewData]);

    const handlePageSizeChangeView = (event) => {
        setPageSizeView(Number(event.target.value));
        setPageView(1);
    };

    // Pagination for outer filter
    const filteredDataUserShiftSummary = filteredDataItemsUserShiftSummary?.slice((pageUserShiftSummary - 1) * pageSizeUserShiftSummary, pageUserShiftSummary * pageSizeUserShiftSummary);
    const totalPagesUserShiftSummaryOuter = Math.ceil(filteredDataItemsUserShiftSummary?.length / pageSizeUserShiftSummary);
    const visiblePages = Math.min(totalPagesUserShiftSummaryOuter, 3);
    const firstVisiblePage = Math.max(1, pageUserShiftSummary - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesUserShiftSummaryOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageUserShiftSummary * pageSizeUserShiftSummary;
    const indexOfFirstItem = indexOfLastItem - pageSizeUserShiftSummary;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
        pageNumbers.push(i);
    }

    // Split the search query into individual terms
    const searchTermsView = searchQueryView.toLowerCase().split(' ');
    // Modify the filtering logic to check each term
    const filteredDatasView = itemsView?.filter((item) => {
        return searchTermsView.every((term) => Object.values(item).join(' ').toLowerCase().includes(term));
    });

    const filteredDataView = filteredDatasView?.slice((pageView - 1) * pageSizeView, pageView * pageSizeView);
    const totalPagesView = Math.ceil(filteredDatasView.length / pageSizeView);
    const visiblePagesView = Math.min(totalPagesView, 3);
    const firstVisiblePageView = Math.max(1, pageView - 1);
    const lastVisiblePageView = Math.min(firstVisiblePageView + visiblePagesView - 1, totalPagesView);
    const pageNumbersView = [];
    const indexOfLastItemView = pageView * pageSizeView;
    const indexOfFirstItemView = indexOfLastItemView - pageSizeView;
    for (let i = firstVisiblePageView; i <= lastVisiblePageView; i++) {
        pageNumbersView.push(i);
    }

    const rowDataTableView = filteredDataView.map((item, index) => {
        return {
            ...item,
        };
    });

    return (
        <Box>
            {isUserRoleCompare?.includes('lteamattendanceoverallreport') && (
                <>
                    {/* ****** Table Start ****** */}
                    {filterUser.attmode === 'Attendance Summary Report' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}> Team Attendance Summary Report </Typography>
                            </Grid>
                            <Grid container spacing={1} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeUserShiftSummary}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeUserShiftSummary}
                                            sx={{ width: '77px' }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsUserShiftSummary?.length}> All </MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                    <Box>
                                        {isUserRoleCompare?.includes('excelteamattendanceoverallreport') && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenUserShiftSummary(true);
                                                        setFormat('xl');
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileExcel />
                                                    &ensp;Export to Excel&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes('csvteamattendanceoverallreport') && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenUserShiftSummary(true);
                                                        setFormat('csv');
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileCsv />
                                                    &ensp;Export to CSV&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes('printteamattendanceoverallreport') && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintUserShiftSummary}>
                                                    {' '}
                                                    &ensp; <FaPrint /> &ensp;Print&ensp;{' '}
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes('pdfteamattendanceoverallreport') && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenUserShiftSummary(true);
                                                    }}
                                                >
                                                    <FaFilePdf />
                                                    &ensp;Export to PDF&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes('imageteamattendanceoverallreport') && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleCaptureImageUserShiftSummary}>
                                                    {' '}
                                                    <ImageIcon sx={{ fontSize: '15px' }} /> &ensp;Image&ensp;{' '}
                                                </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput
                                            size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterUserShiftSummary && (
                                                        <IconButton onClick={handleResetSearchUserShiftSummary}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer' }} onClick={handleClickSearchUserShiftSummary} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>
                                            }
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight' }}
                                            type="text"
                                            value={getSearchDisplayUserShiftSummary()}
                                            onChange={handleSearchChange}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterUserShiftSummary}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsUserShiftSummary}>
                                {' '}
                                Show All Columns{' '}
                            </Button>
                            &ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsUserShiftSummary}>
                                {' '}
                                Manage Columns{' '}
                            </Button>
                            <br />
                            <br />
                            {loader ? (
                                <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box>
                            ) : (
                                <>
                                    <Box sx={{ width: '100%' }} className={'ag-theme-quartz'} ref={gridRefImageUserShiftSummary}>
                                        <AgGridReact
                                            rowData={filteredDataItemsUserShiftSummary}
                                            columnDefs={columnDataTableUserShiftSummary.filter((column) => columnVisibilityUserShiftSummary[column.field])}
                                            ref={gridRefTableUserShiftSummary}
                                            defaultColDef={defaultColDef}
                                            domLayout={'autoHeight'}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSizeSelector={[]}
                                            paginationPageSize={pageSizeUserShiftSummary}
                                            onPaginationChanged={onPaginationChanged}
                                            onGridReady={onGridReadyUserShiftSummary}
                                            onColumnMoved={handleColumnMovedUserShiftSummary}
                                            onColumnVisible={handleColumnVisibleUserShiftSummary}
                                            onFilterChanged={onFilterChangedUserShiftSummary}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={'shift'}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            )}{' '}
                            {/* ****** Table End ****** */}
                        </Box>
                    ) : null}
                </>
            )}

            {/* View model */}
            <Dialog open={openview} onClose={handleClickOpenview} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" maxWidth="lg" fullWidth scroll="paper" sx={{ marginTop: '95px' }}>
                <Box sx={{ padding: '20px 20px' }}>
                    <Grid container spacing={2}>
                        <Grid item md={11} sx={6} xs={12}>
                            <Typography sx={userStyle.HeaderText}>{tableName}</Typography>
                        </Grid>
                        <Grid item md={1} sx={6} xs={12}>
                            <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseview}>
                                {' '}
                                Back{' '}
                            </Button>
                        </Grid>
                    </Grid>
                    <br />
                    <Box>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSizeView}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeView}
                                        sx={{ width: '77px' }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={viewData?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                <Box>
                                    {isUserRoleCompare?.includes('excelteamattendanceoverallreport') && (
                                        <>
                                            <Button
                                                onClick={(e) => {
                                                    setIsFilterOpenView(true);
                                                    setFormat('xl');
                                                }}
                                                sx={userStyle.buttongrp}
                                            >
                                                <FaFileExcel />
                                                &ensp;Export to Excel&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('csvteamattendanceoverallreport') && (
                                        <>
                                            <Button
                                                onClick={(e) => {
                                                    setIsFilterOpenView(true);
                                                    setFormat('csv');
                                                }}
                                                sx={userStyle.buttongrp}
                                            >
                                                <FaFileCsv />
                                                &ensp;Export to CSV&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('printteamattendanceoverallreport') && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintView}>
                                                &ensp;
                                                <FaPrint />
                                                &ensp;Print&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('pdfteamattendanceoverallreport') && (
                                        <>
                                            <Button
                                                sx={userStyle.buttongrp}
                                                onClick={() => {
                                                    setIsPdfFilterOpenView(true);
                                                }}
                                            >
                                                <FaFilePdf />
                                                &ensp;Export to PDF&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('imageteamattendanceoverallreport') && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImageView}>
                                                <ImageIcon sx={{ fontSize: '15px' }} /> &ensp;Image&ensp;
                                            </Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <Box>
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTableView}
                                        setItems={setItemsView}
                                        addSerialNumber={addSerialNumberView}
                                        setPage={setPageView}
                                        maindatas={viewData}
                                        setSearchedString={setSearchedStringView}
                                        searchQuery={searchQueryView}
                                        setSearchQuery={setSearchQueryView}
                                        paginated={false}
                                        totalDatas={viewData}
                                    />
                                </Box>
                            </Grid>
                        </Grid>
                        <br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsView}>
                            Show All Columns
                        </Button>
                        &ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsView}>
                            Manage Columns
                        </Button>
                        <br />
                        <br />
                        {loaderView ? (
                            <>
                                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box>
                            </>
                        ) : (
                            <>
                                <AggridTable
                                    rowDataTable={rowDataTableView}
                                    columnDataTable={columnDataTableView}
                                    columnVisibility={columnVisibilityView}
                                    page={pageView}
                                    setPage={setPageView}
                                    pageSize={pageSizeView}
                                    totalPages={totalPagesView}
                                    setColumnVisibility={setColumnVisibilityView}
                                    isHandleChange={isHandleChangeView}
                                    items={itemsView}
                                    gridRefTable={gridRefTableView}
                                    paginated={false}
                                    filteredDatas={filteredDatasView}
                                    // totalDatas={totalDatasView}
                                    selectedRows={selectedRowsView}
                                    setSelectedRows={setSelectedRowsView}
                                    searchQuery={searchedStringView}
                                    handleShowAllColumnsUserShiftSummary={handleShowAllColumnsView}
                                    setFilteredRowData={setFilteredRowDataView}
                                    filteredRowData={filteredRowDataView}
                                    setFilteredChanges={setFilteredChangesView}
                                    filteredChanges={filteredChangesView}
                                    gridRefTableImg={gridRefTableImgView}
                                    itemsList={viewData}
                                />
                            </>
                        )}
                    </Box>
                </Box>
            </Dialog>

            {/* History model */}
            <Dialog
                open={openHistoryview}
                onClose={handleClickOpenHistoryview}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="lg" fullWidth
                scroll="paper"
                sx={{ marginTop: '95px' }}
            >
                <Box sx={{ padding: "20px 20px" }}>
                    <Grid container spacing={2}>
                        <Grid item xs={10}>
                            <Typography sx={userStyle.HeaderText}><b>{'Attendance Status History'}</b></Typography>
                        </Grid>
                        <Grid item md={1} sm={6} xs={12} >
                            <Button sx={{
                                display: 'flex', justifyContent: 'center',
                                background: 'rgb(60 181 170)',
                                color: "white",
                                boxShadow: "none",
                                borderRadius: "3px",
                                padding: "4px 6px",
                                height: '38px',
                                "&:hover": {
                                    backgroundColor: "rgb(60 181 170)", color: "white",
                                },
                            }} onClick={handleCaptureImageViewPopup}> <ImageIcon sx={{ fontSize: "14px" }} />Copy</Button>
                        </Grid>
                        <Grid item md={1} sx={6} xs={12}>
                            <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseHistoryview}>{" "}Back{" "}</Button>
                        </Grid>
                    </Grid><br />
                    <Box ref={gridRefImageUserShiftSummaryViewPopup}>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Typography sx={userStyle.SubHeaderText}><b>{`Attendance Status As On (${formatCustomDateTime(currentServerTime)})`}</b></Typography>
                            </Grid>
                            <Grid item md={12} sm={12} xs={12}>
                                <Typography sx={userStyle.SubHeaderText}><b>{`Attendance summary of: Company: ${historyViewData.company} / Branch: ${historyViewData.branch} / Unit: ${historyViewData.unit} / Team: ${historyViewData.team} / Date: ${historyViewData.date}`}</b></Typography>
                            </Grid>
                        </Grid><br />
                        <Grid container spacing={2}>
                            <Grid item md={1}></Grid>
                            {/* left side */}
                            <Grid item md={4} sm={12} xs={12}>
                                <Grid container spacing={1}>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.totalemployees}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Strength"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.totalcurrentshift}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Current Shift"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.paidpresentday}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.lopcount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.totalin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Total In"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #397bd4',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.totalout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#397bd4' }}>{"Total No. Total Out"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#397bd4',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.totalpending}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Pending"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.facilitypresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Facility Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.wfhpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. WFH Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.facilityabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Facility Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.wfhabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. WFH Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.earlyclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#84c358' }}>{"Total No. Early-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.onpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. On-Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.graceclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Grace-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.lateclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Late-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.weekoff}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Week Off"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={1}></Grid>
                            {/* rigth side */}
                            <Grid item md={4} sm={12} xs={12} >
                                <Grid container spacing={1}>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.holidayCount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Holiday"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.permissionCount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Permission"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.clsl}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. CL/SL"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.onclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. On-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.earlyclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Early-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.overclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Over-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.autoclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Auto-Mis Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.shiftnotstarted}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Shift Not Started"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.nostatus}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. No Status"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.notallotted}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Not Allotted"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.weekoffpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Weekoff Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.longleaveabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Long Leave & Long Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.blabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. BL-Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.doubledayabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Double Day Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewData.weekoffabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Weekoff Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={2}></Grid>
                        </Grid>
                    </Box>
                </Box>
            </Dialog>

            {/* Manage Column */}
            <Popover id={idManageColumnsUserShiftSummary} open={isManageColumnsOpenUserShiftSummary} anchorEl={anchorElUserShiftSummary} onClose={handleCloseManageColumnsUserShiftSummary} anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsUserShiftSummary}
                    searchQuery={searchQueryManageUserShiftSummary}
                    setSearchQuery={setSearchQueryManageUserShiftSummary}
                    filteredColumns={filteredColumns}
                    columnVisibility={columnVisibilityUserShiftSummary}
                    toggleColumnVisibility={toggleColumnVisibilityUserShiftSummary}
                    setColumnVisibility={setColumnVisibilityUserShiftSummary}
                    initialColumnVisibility={initialColumnVisibilityUserShiftSummary}
                    columnDataTable={columnDataTableUserShiftSummary}
                />
            </Popover>

            {/* Manage Column */}
            <Popover id={idView} open={isManageColumnsOpenView} anchorEl={anchorElView} onClose={handleCloseManageColumnsView} anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsView}
                    searchQuery={searchQueryManageView}
                    setSearchQuery={setSearchQueryManageView}
                    filteredColumns={filteredColumnsView}
                    columnVisibility={columnVisibilityView}
                    toggleColumnVisibility={toggleColumnVisibilityView}
                    setColumnVisibility={setColumnVisibilityView}
                    initialColumnVisibility={initialColumnVisibilityView}
                    columnDataTable={columnDataTableView}
                />
            </Popover>

            {/* Search Bar */}
            <Popover id={idSearchUserShiftSummary} open={openSearchUserShiftSummary} anchorEl={anchorElSearchUserShiftSummary} onClose={handleCloseSearchUserShiftSummary} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
                <AdvancedSearchBar columns={columnDataTableUserShiftSummary} onSearch={applyAdvancedFilterUserShiftSummary} initialSearchValue={searchQueryUserShiftSummary} handleCloseSearch={handleCloseSearchUserShiftSummary} />
            </Popover>

            <MessageAlert openPopup={openPopupMalert} handleClosePopup={handleClosePopupMalert} popupContent={popupContentMalert} popupSeverity={popupSeverityMalert} />
            {/* SUCCESS */}
            <AlertDialog openPopup={openPopup} handleClosePopup={handleClosePopup} popupContent={popupContent} popupSeverity={popupSeverity} />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenUserShiftSummary}
                handleCloseFilterMod={handleCloseFilterModUserShiftSummary}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenUserShiftSummary}
                isPdfFilterOpen={isPdfFilterOpenUserShiftSummary}
                setIsPdfFilterOpen={setIsPdfFilterOpenUserShiftSummary}
                handleClosePdfFilterMod={handleClosePdfFilterModUserShiftSummary}
                filteredDataTwo={(filteredRowDataUserShiftSummary.length > 0 ? filteredRowDataUserShiftSummary : filteredDataUserShiftSummary) ?? []}
                itemsTwo={itemsAttSummary ?? []}
                filename={'Team Attendance Summary Report'}
                exportColumnNames={exportColumnNamescrtUserShiftSummary}
                exportRowValues={exportRowValuescrtUserShiftSummary}
                componentRef={componentRefUserShiftSummary}
            />
            <ExportData
                isFilterOpen={isFilterOpenView}
                handleCloseFilterMod={handleCloseFilterModView}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenView}
                isPdfFilterOpen={isPdfFilterOpenView}
                setIsPdfFilterOpen={setIsPdfFilterOpenView}
                handleClosePdfFilterMod={handleClosePdfFilterModView}
                filteredDataTwo={(filteredChangesView !== null ? filteredRowDataView : rowDataTableView) ?? []}
                itemsTwo={viewData ?? []}
                filename={tableName}
                exportColumnNames={exportColumnNamesView}
                exportRowValues={exportRowValuesView}
                componentRef={componentRefView}
            />
        </Box>
    );
}

export default TeamAttSummaryList;