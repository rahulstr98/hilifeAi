import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import { FaFileExcel, FaFileCsv, FaSearch, FaEdit, FaPrint, FaFilePdf } from "react-icons/fa";
import { Box, Typography, Chip, OutlinedInput, TableCell, Select, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Button, Popover, TextField, IconButton, InputAdornment, Tooltip, Table, TableContainer, Paper, TableHead, TableRow, TableBody, } from "@mui/material";
import { userStyle, colourStyles } from "../../../pageStyle.js";
import { handleApiError } from "../../../components/Errorhandling.js";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from '../../../axiosInstance';
import { SERVICE } from "../../../services/Baseservice.js";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { useReactToPrint } from "react-to-print";
import { UserRoleAccessContext } from "../../../context/Appcontext.js";
import { AuthContext } from "../../../context/Appcontext.js";
import Headtitle from "../../../components/Headtitle.js";
import { ThreeDots } from "react-loader-spinner";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import ImageIcon from "@mui/icons-material/Image";
import CloseIcon from "@mui/icons-material/Close";
import { saveAs } from "file-saver";
import Selects from "react-select";
import moment from "moment";
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import domtoimage from 'dom-to-image';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ExportData from "../../../components/ExportData.js";
import MessageAlert from "../../../components/MessageAlert.js";
import PageHeading from "../../../components/PageHeading.js";
import AlertDialog from "../../../components/Alert.js";
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from "../../../components/ManageColumn.js";
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function TeamAttOverallReviewAndReportList({ userShiftsAttReview, userShiftsAttReport, loader, filterUser,
    setSearchQueryAttReview, setPageAttReview, setTotalPagesAttReview, pageAttReview, pageSizeAttReview, setPageSizeAttReview, searchQueryAttReview,
    setSearchQueryAttReport, setPageAttReport, setTotalPagesAttReport, pageAttReport, pageSizeAttReport, setPageSizeAttReport, searchQueryAttReport, isHeadings, headArr, attStatus,
}) {

    const gridRefTableAttReview = useRef(null);
    const gridRefImageAttReview = useRef(null);
    const gridRefTableAttReport = useRef(null);
    const gridRefImageAttReport = useRef(null);

    const { isUserRoleCompare } = useContext(UserRoleAccessContext);

    const [itemsAttReview, setItemsAttReview] = useState([]);
    const [itemsAttReport, setItemsAttReport] = useState([]);
    const [showAlert, setShowAlert] = useState();

    const [advancedFilterAttReview, setAdvancedFilterAttReview] = useState(null);
    const [gridApiAttReview, setGridApiAttReview] = useState(null);
    const [columnApiAttReview, setColumnApiAttReview] = useState(null);
    const [filteredDataItemsAttReview, setFilteredDataItemsAttReview] = useState(userShiftsAttReview);
    const [filteredRowDataAttReview, setFilteredRowDataAttReview] = useState([]);

    const [advancedFilterAttReport, setAdvancedFilterAttReport] = useState(null);
    const [gridApiAttReport, setGridApiAttReport] = useState(null);
    const [columnApiAttReport, setColumnApiAttReport] = useState(null);
    const [filteredDataItemsAttReport, setFilteredDataItemsAttReport] = useState();
    const [filteredRowDataAttReport, setFilteredRowDataAttReport] = useState([]);

    // Error Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const handleClickOpenerr = () => { setIsErrorOpen(true); };
    const handleCloseerr = () => { setIsErrorOpen(false); };

    // Exports
    const [isFilterOpenAttReview, setIsFilterOpenAttReview] = useState(false);
    const [isPdfFilterOpenAttReview, setIsPdfFilterOpenAttReview] = useState(false);
    // pageAttReview refersh reload
    const handleCloseFilterModAttReview = () => { setIsFilterOpenAttReview(false); };
    const handleClosePdfFilterModAttReview = () => { setIsPdfFilterOpenAttReview(false); };

    const [isFilterOpenAttReport, setIsFilterOpenAttReport] = useState(false);
    const [isPdfFilterOpenAttReport, setIsPdfFilterOpenAttReport] = useState(false);
    // pageAttReview refersh reload
    const handleCloseFilterModAttReport = () => { setIsFilterOpenAttReport(false); };
    const handleClosePdfFilterModAttReport = () => { setIsPdfFilterOpenAttReport(false); };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); }

    // pageAttReview refersh reload
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    // Manage Columns
    const [isManageColumnsOpenAttReview, setManageColumnsOpenAttReview] = useState(false);
    const [anchorElAttReview, setAnchorElAttReview] = useState(null);
    const [searchQueryManageAttReview, setSearchQueryManageAttReview] = useState("");
    const handleOpenManageColumnsAttReview = (event) => {
        setAnchorElAttReview(event.currentTarget);
        setManageColumnsOpenAttReview(true);
    };
    const handleCloseManageColumnsAttReview = () => {
        setManageColumnsOpenAttReview(false);
        setSearchQueryManageAttReview("");
    };
    const openAttReview = Boolean(anchorElAttReview);
    const idAttReview = openAttReview ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttReview, setAnchorElSearchAttReview] = React.useState(null);
    const handleClickSearchAttReview = (event) => {
        setAnchorElSearchAttReview(event.currentTarget);
    };
    const handleCloseSearchAttReview = () => {
        setAnchorElSearchAttReview(null);
        setSearchQueryAttReview("");
    };

    const openSearchAttReview = Boolean(anchorElSearchAttReview);
    const idSearchAttReview = openSearchAttReview ? 'simple-popover' : undefined;

    // Manage Columns
    const [isManageColumnsOpenAttReport, setManageColumnsOpenAttReport] = useState(false);
    const [anchorElAttReport, setAnchorElAttReport] = useState(null);
    const [searchQueryManageAttReport, setSearchQueryManageAttReport] = useState("");
    const handleOpenManageColumnsAttReport = (event) => {
        setAnchorElAttReport(event.currentTarget);
        setManageColumnsOpenAttReport(true);
    };
    const handleCloseManageColumnsAttReport = () => {
        setManageColumnsOpenAttReport(false);
        setSearchQueryManageAttReport("");
    };
    const openAttReport = Boolean(anchorElAttReport);
    const idAttReport = openAttReport ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttReport, setAnchorElSearchAttReport] = React.useState(null);
    const handleClickSearchAttReport = (event) => {
        setAnchorElSearchAttReport(event.currentTarget);
    };
    const handleCloseSearchAttReport = () => {
        setAnchorElSearchAttReport(null);
        setSearchQueryAttReport("");
    };

    const openSearchAttReport = Boolean(anchorElSearchAttReport);
    const idSearchAttReport = openSearchAttReport ? 'simple-popover' : undefined;

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    }

    // Show All Columns & Manage Columns
    const initialColumnVisibilityAttReview = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        department: true,
        date: true,
        shift: true,
        leavestatus: true,
        permissionstatus: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        bookby: true,
    };

    const [columnVisibilityAttReview, setColumnVisibilityAttReview] = useState(initialColumnVisibilityAttReview);

    // Show All Columns & Manage Columns
    const initialColumnVisibilityAttReport = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        ...headArr.reduce((acc, data, index) => {
            acc[data] = true;
            return acc;
        }, {}),
    };
    const [columnVisibilityAttReport, setColumnVisibilityAttReport] = useState(initialColumnVisibilityAttReport);

    //serial no for listing itemsAttReview
    const addSerialNumberAttReview = async (datas) => {
        setItemsAttReview(datas);
        setColumnVisibilityAttReport({
            serialNumber: true,
            empcode: true,
            username: true,
            company: true,
            branch: true,
            unit: true,
            team: true,
            department: true,
            ...headArr.reduce((acc, data, index) => {
                acc[data] = true;
                return acc;
            }, {}),
        })
    };

    useEffect(() => {
        addSerialNumberAttReview(userShiftsAttReview);
        setFilteredDataItemsAttReview(userShiftsAttReview);
    }, [userShiftsAttReview]);

    const getattendancestatus = (alldata) => {
        let result = attStatus.filter((data, index) => {
            return data?.clockinstatus === alldata?.clockinstatus && data?.clockoutstatus === alldata?.clockoutstatus
        })
        return result[0]?.name
    }

    //serial no for listing itemsAttReview
    const addSerialNumberAttReport = async () => {
        const rowDataTable = userShiftsAttReport?.map(item => {
            const days = item.alldays.reduce((acc, data) => {
                // const dayIndex = acc.findIndex(d => d.date === data.rowformattedDate);
                const dayIndex = acc.findIndex(d => d.date === data.date);

                const attendanceStatus = data.attendanceautostatus ? data.attendanceautostatus : getattendancestatus(data);

                if (dayIndex > -1) {
                    if (data.shiftMode === "Main Shift") {
                        acc[dayIndex].mainShift = {
                            shift: data.shift,
                            attstatus: attendanceStatus,
                        };
                    } else if (data.shiftMode === "Second Shift") {
                        acc[dayIndex].secondShift = {
                            shift: data.shift,
                            attstatus: attendanceStatus,
                        };
                    }
                } else {
                    const newDay = {
                        date: data.date,
                        // date: data.rowformattedDate, // Ensure consistent date format
                        mainShift: data.shiftMode === "Main Shift" ? {
                            shift: data.shift,
                            attstatus: attendanceStatus,
                        } : {},
                        secondShift: data.shiftMode === "Second Shift" ? {
                            shift: data.shift,
                            attstatus: attendanceStatus,
                        } : {},
                    };

                    acc.push(newDay);
                }

                return acc;
            }, []);

            return {
                id: item.id,
                uniqueid: item.id,
                userid: item.userid,
                serialNumber: item.serialNumber,
                company: item.company,
                branch: item.branch,
                unit: item.unit,
                team: item.team,
                department: item.department,
                username: item.username,
                empcode: item.empcode,
                reasondate: item.reasondate,
                resonablestatus: item.resonablestatus,
                doj: item.doj,
                days: days,
            };
        });
        setItemsAttReport(rowDataTable);
        setFilteredDataItemsAttReport(rowDataTable);
    };

    useEffect(() => {
        addSerialNumberAttReport();
        setColumnVisibilityAttReport({
            serialNumber: true,
            empcode: true,
            username: true,
            company: true,
            branch: true,
            unit: true,
            team: true,
            department: true,
            ...isHeadings.reduce((acc, data, index) => {
                acc[data] = true;
                return acc;
            }, {}),
        });
    }, [userShiftsAttReport]);

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ["apply", "reset", "cancel"],
            },
        };
    }, []);

    const onGridReadyAttReview = useCallback((params) => {
        setGridApiAttReview(params.api);
        setColumnApiAttReview(params.columnApiAttReview);
    }, []);

    // Function to handle filter changes
    const onFilterChangedAttReview = () => {
        if (gridApiAttReview) {
            const filterModel = gridApiAttReview.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataAttReview([]);
            } else {
                // Filters are active, capture filtered data
                const filteredData = [];
                gridApiAttReview.forEachNodeAfterFilterAndSort((node) => {
                    filteredData.push(node.data); // Collect filtered row data
                });
                setFilteredRowDataAttReview(filteredData);
            }
        }
    };

    const onPaginationChangedAttReview = useCallback(() => {
        if (gridRefTableAttReview.current) {
            const gridApiAttReview = gridRefTableAttReview.current.api;
            const currentPage = gridApiAttReview.paginationGetCurrentPage() + 1;
            const totalPagesAttReview = gridApiAttReview.paginationGetTotalPages();
            setPageAttReview(currentPage);
            setTotalPagesAttReview(totalPagesAttReview);
        }
    }, []);

    const columnDataTableAttReview = [
        { field: 'serialNumber', headerName: 'SNo', flex: 0, width: 80, hide: !columnVisibilityAttReview.serialNumber, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'empcode', headerName: 'Emp Code', flex: 0, width: 150, hide: !columnVisibilityAttReview.empcode, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'username', headerName: 'Employee Name', flex: 0, width: 250, hide: !columnVisibilityAttReview.username, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'company', headerName: 'Company', flex: 0, width: 130, hide: !columnVisibilityAttReview.company, headerClassName: 'bold-header' },
        { field: 'branch', headerName: 'Branch', flex: 0, width: 130, hide: !columnVisibilityAttReview.branch, headerClassName: 'bold-header' },
        { field: 'unit', headerName: 'Unit', flex: 0, width: 130, hide: !columnVisibilityAttReview.unit, headerClassName: 'bold-header' },
        { field: 'department', headerName: 'Department', flex: 0, width: 130, hide: !columnVisibilityAttReview.department, headerClassName: 'bold-header' },
        { field: 'date', headerName: 'Date', flex: 0, width: 110, hide: !columnVisibilityAttReview.date, headerClassName: 'bold-header' },
        { field: 'shift', headerName: 'Shift Name', flex: 0, width: 150, hide: !columnVisibilityAttReview.shift, headerClassName: 'bold-header' },
        { field: 'leavestatus', headerName: 'Leave Status', flex: 0, width: 150, hide: !columnVisibilityAttReview.leavestatus },
        { field: 'permissionstatus', headerName: 'Permission Status', flex: 0, width: 150, hide: !columnVisibilityAttReview.permissionstatus },
        { field: 'clockinstatus', headerName: 'Clock In Status', flex: 0, width: 150, hide: !columnVisibilityAttReview.clockinstatus, headerClassName: 'bold-header' },
        { field: 'clockoutstatus', headerName: 'Clock Out Status', flex: 0, width: 150, hide: !columnVisibilityAttReview.clockoutstatus, headerClassName: 'bold-header' },
        {
            field: 'attendanceauto',
            headerName: 'Mode',
            flex: 0,
            width: 200,
            hide: !columnVisibilityAttReview.attendanceauto,
            headerClassName: 'bold-header',
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        <Button
                            size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                    backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                }
                            }}
                        >
                            {params.data.attendanceauto}
                        </Button>
                    </Grid>
                );
            },
        },
        { field: 'bookby', headerName: 'Attendance Status', flex: 0, width: 200, hide: !columnVisibilityAttReview.bookby, headerClassName: 'bold-header' },
    ];

    const columnDataTableAttReport = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityAttReport.serialNumber, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityAttReport.empcode, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityAttReport.username, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibilityAttReport.company, headerClassName: "bold-header" },
        { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibilityAttReport.branch, headerClassName: "bold-header" },
        { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibilityAttReport.unit, headerClassName: "bold-header" },
        { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibilityAttReport.team, headerClassName: "bold-header" },
        { field: "department", headerName: "Department", flex: 0, width: 130, hide: !columnVisibilityAttReport.department, headerClassName: "bold-header" },
        ...headArr.map((column) => {

            const formattedDate = column?.split(' ')[0];
            const [formatday1, fromatmonth1, formatyear1] = formattedDate.split('/');
            const formattedDateNew = new Date(`${formatyear1}-${fromatmonth1}-${formatday1}`);

            return {
                field: column,
                headerName: column,
                hide: !columnVisibilityAttReport[column],
                flex: 0,
                width: 200,
                filter: false,
                sortable: false,
                cellRenderer: (params) => {
                    // const dayData = params.data.days[index];
                    const dayData = params.data.days.find(day => day.date === column);

                    const reasonDate = new Date(params.data.reasondate);
                    const dojDate = new Date(params.data.doj);
                    const isDisable1 = formattedDateNew < dojDate
                    const isDisable2 = formattedDateNew > reasonDate

                    if (params.data.reasondate && params.data.reasondate != "" && formattedDateNew > reasonDate) {
                        return (
                            <Grid sx={{ display: 'flex', }}>
                                <Box sx={{ margin: '5px', }}>
                                    <Button
                                        size="small"
                                        sx={{
                                            textTransform: 'capitalize',
                                            borderRadius: '4px',
                                            boxShadow: 'none',
                                            fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                            fontWeight: '400',
                                            fontSize: '0.875rem',
                                            lineHeight: '1.43',
                                            letterSpacing: '0.01071em',
                                            display: 'flex',
                                            padding: '3px 10px',
                                            color: '#e4d7d7',
                                            backgroundColor: 'rgb(187 46 46)',
                                            pointerEvents: 'none',

                                        }}
                                    // Disable the button if the date is before the current date
                                    // disabled={isDisable2}
                                    >
                                        {params.data.resonablestatus}
                                    </Button>
                                </Box>
                            </Grid >
                        );
                    }
                    else if (params.data.doj && params.data.doj != "" && formattedDateNew < dojDate) {
                        return (
                            <Grid sx={{ display: 'flex', }} >
                                <Box sx={{ margin: '10px', }}>
                                    <Button
                                        size="small"
                                        sx={{
                                            // marginTop: '10px',
                                            textTransform: 'capitalize',
                                            borderRadius: '4px',
                                            boxShadow: 'none',
                                            fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                            fontWeight: '400',
                                            fontSize: '0.875rem',
                                            lineHeight: '1.43',
                                            letterSpacing: '0.01071em',
                                            display: 'flex',
                                            padding: '3px 10px',
                                            color: '#e4d7d7',
                                            backgroundColor: 'rgb(187 46 46)',
                                            pointerEvents: 'none',

                                        }}
                                    // Disable the button if the date is before the current date
                                    // disabled={isDisable1}
                                    >
                                        {"Not Joined"}
                                    </Button>
                                </Box>
                            </Grid >
                        );
                    }
                    else if (params.data.doj && params.data.doj != "" && formattedDateNew >= dojDate) {
                        if (!dayData) return null;
                        return (
                            <Grid container sx={{ display: 'block' }}>
                                <Box sx={{ margin: '5px' }}>
                                    {dayData?.mainShift && (
                                        <Grid item md={12}>
                                            <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                {dayData.mainShift.shift}
                                            </Typography>
                                            <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                {dayData.mainShift.attstatus}
                                            </Typography>
                                        </Grid>
                                    )}
                                    {dayData?.secondShift && (
                                        <Grid item md={12}>
                                            <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                {dayData.secondShift.shift}
                                            </Typography>
                                            <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                {dayData.secondShift.attstatus}
                                            </Typography>
                                        </Grid>
                                    )}
                                </Box>
                            </Grid>
                        );
                    }
                },
            }
        }),
    ];

    //Datatable
    const handleSearchChangeAttReview = (e) => {
        const value = e.target.value;
        setSearchQueryAttReview(value);
        applyNormalFilterAttReview(value);
        setFilteredRowDataAttReview([]);
    };

    const applyNormalFilterAttReview = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttReview?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsAttReview(filtered);
        setPageAttReview(1);
    };

    const applyAdvancedFilterAttReview = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttReview?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsAttReview(filtered); // Update filtered data
        setAdvancedFilterAttReview(filters);
        // handleCloseSearchAttReview(); // Close the popover after search
    };

    // Undo filter funtion
    const handleResetSearchAttReview = () => {
        setAdvancedFilterAttReview(null);
        setSearchQueryAttReview("");
        setFilteredDataItemsAttReview(userShiftsAttReview);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayAttReview = () => {
        if (advancedFilterAttReview && advancedFilterAttReview.length > 0) {
            return advancedFilterAttReview.map((filter, index) => {
                let showname = columnDataTableAttReview.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterAttReview.length > 1 ? advancedFilterAttReview[1].condition : '') + ' ');
        }
        return searchQueryAttReview;
    };

    const handlePageSizeChangeAttReview = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttReview(newSize);
        if (gridApiAttReview) {
            gridApiAttReview.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsAttReview = () => {
        const updatedVisibility = { ...columnVisibilityAttReview };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityAttReview(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibility");
        if (savedVisibility) {
            setColumnVisibilityAttReview(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibility", JSON.stringify(columnVisibilityAttReview));
    }, [columnVisibilityAttReview]);

    // Function to filter columns based on search query
    const filteredColumnsAttReview = columnDataTableAttReview?.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageAttReview.toLowerCase())
    );

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibilityAttReview = (field) => {
        if (!gridApiAttReview) return;

        setColumnVisibilityAttReview((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiAttReview.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedAttReview = useCallback(debounce((event) => {
        if (!event.columnApiAttReview) return;

        const visible_columns = event.columnApiAttReview.getAllColumns().filter(col => {
            const colState = event.columnApiAttReview.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityAttReview((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleAttReview = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityAttReview((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormat, setFormat] = useState("");
    let exportColumnNamescrtAttReview = [
        "Company", "Branch", "Unit", "Department", "Emp Code", "Employee Name", "Book By", "IP Address",
        "Date", "Shift", "Leave Status", "Permission Status", "ClockIn", "ClockOut", "ClockInStatus", "ClockOutStatus",
    ]
    let exportRowValuescrtAttReview = [
        "company", "branch", "unit", "department", "empcode", "username", "bookby", "ipaddress",
        "date", "shift", "leavestatus", "permissionstatus", "clockin", "clockout", "clockinstatus", "clockoutstatus",
    ]

    // print...
    const componentRefAttReview = useRef();
    const handleprintAttReview = useReactToPrint({
        content: () => componentRefAttReview.current,
        documentTitle: "Team Attendance Review",
        pageStyle: "print",
    });

    // image
    const handleCaptureImage = () => {
        if (gridRefImageAttReview.current) {
            domtoimage.toBlob(gridRefImageAttReview.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Review.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredDataAttReview = filteredDataItemsAttReview?.slice((pageAttReview - 1) * pageSizeAttReview, pageAttReview * pageSizeAttReview);
    const totalPagesAttReviewOuter = Math.ceil(filteredDataItemsAttReview?.length / pageSizeAttReview);
    const visiblePages = Math.min(totalPagesAttReviewOuter, 3);
    const firstVisiblePage = Math.max(1, pageAttReview - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesAttReviewOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageAttReview * pageSizeAttReview;
    const indexOfFirstItem = indexOfLastItem - pageSizeAttReview;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

    //Attendance Day Shift
    const onGridReadyAttReport = useCallback((params) => {
        setGridApiAttReport(params.api);
        setColumnApiAttReport(params.columnApiAttReport);
    }, []);

    // Function to handle filter changes
    const onFilterChangedAttReport = () => {
        if (gridApiAttReport) {
            const filterModel = gridApiAttReport.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataAttReport([]);
            } else {
                // Filters are active, capture filtered data
                const filteredData = [];
                gridApiAttReport.forEachNodeAfterFilterAndSort((node) => {
                    filteredData.push(node.data); // Collect filtered row data
                });
                setFilteredRowDataAttReport(filteredData);
            }
        }
    };

    const onPaginationChangedAttReport = useCallback(() => {
        if (gridRefTableAttReport.current) {
            const gridApiAttReport = gridRefTableAttReport.current.api;
            const currentPage = gridApiAttReport.paginationGetCurrentPage() + 1;
            const totalPagesAttReport = gridApiAttReport.paginationGetTotalPages();
            setPageAttReport(currentPage);
            setTotalPagesAttReport(totalPagesAttReport);
        }
    }, []);

    //Datatable
    const handleSearchChangeAttReport = (e) => {
        const value = e.target.value;
        setSearchQueryAttReport(value);
        applyNormalFilterAttReport(value);
        setFilteredRowDataAttReview([]);
    };

    const applyNormalFilterAttReport = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttReport?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsAttReport(filtered);
        setPageAttReport(1);
    };

    const applyAdvancedFilterAttReport = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttReport?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsAttReport(filtered);
        setAdvancedFilterAttReport(filters);
        // handleCloseSearchAttReport(); 
    };

    // Undo filter funtion
    const handleResetSearchAttReport = () => {
        setAdvancedFilterAttReport(null);
        setSearchQueryAttReport("");
        setFilteredDataItemsAttReport(userShiftsAttReport);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayAttReport = () => {
        if (advancedFilterAttReport && advancedFilterAttReport.length > 0) {
            return advancedFilterAttReport.map((filter, index) => {
                let showname = columnDataTableAttReport.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterAttReport.length > 1 ? advancedFilterAttReport[1].condition : '') + ' ');
        }
        return searchQueryAttReport;
    };

    const handlePageSizeChangeAttReport = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttReport(newSize);
        if (gridApiAttReport) {
            gridApiAttReport.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsAttReport = () => {
        const updatedVisibility = { ...columnVisibilityAttReport };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityAttReport(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibilityAttReport");
        if (savedVisibility) {
            setColumnVisibilityAttReport(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibilityAttReport", JSON.stringify(columnVisibilityAttReport));
    }, [columnVisibilityAttReport]);

    // Function to filter columns based on search query
    const filteredColumnsAttReport = columnDataTableAttReport.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageAttReport.toLowerCase())
    );

    // Manage Columns functionality
    const toggleColumnVisibilityAttReport = (field) => {
        if (!gridApiAttReport) return;

        setColumnVisibilityAttReport((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiAttReport.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedAttReport = useCallback(debounce((event) => {
        if (!event.columnApiAttReport) return;

        const visible_columns = event.columnApiAttReport.getAllColumns().filter(col => {
            const colState = event.columnApiAttReport.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityAttReport((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleAttReport = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityAttReport((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const fileName = "Attendance Report";
    const fileType = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8';
    const fileExtension = fileFormat === "xl" ? '.xlsx' : '.csv';
    const exportToCSV = (csvData, fileName) => {
        const ws = XLSX.utils.json_to_sheet(csvData);
        const wb = { Sheets: { 'data': ws }, SheetNames: ['data'] };
        const excelBuffer = XLSX.write(wb, { bookType: 'xlsx', type: 'array' });
        const data = new Blob([excelBuffer], { type: fileType });
        FileSaver.saveAs(data, fileName + fileExtension);
    }

    const handleExportXLAttReport = (isfilter) => {

        const headers = [
            'SNo',
            'Emp Code',
            'Employee Name',
            'Company',
            'Branch',
            'Unit',
            'Team',
            'Department',
            ...headArr.map(column => column),
        ];

        let data = [];
        let resultdata = (filteredRowDataAttReport.length > 0 ? filteredRowDataAttReport : filteredDataAttReport) ?? [];

        if (isfilter === "filtered") {
            data = resultdata.map((t, index) => {
                return [
                    index + 1,
                    t.empcode,
                    t.username,
                    t.company,
                    t.branch,
                    t.unit,
                    t.team,
                    t.department,
                    ...headArr.map((dateStr) => {
                        const dateParts = dateStr?.split(' ')[0]?.split('/');
                        const formattedDate = new Date(`${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`);

                        const dojDate = t.doj ? new Date(t.doj) : null;
                        const reasonDate = t.reasondate ? new Date(t.reasondate) : null;

                        const item = (t.days || []).find(d => d.date === dateStr);
                        let value = "";

                        if (t.reasondate && formattedDate > reasonDate) {
                            value = t.resonablestatus || "";
                        } else if (t.doj && formattedDate < dojDate) {
                            value = "Not Joined";
                        } else if (t.doj && formattedDate >= dojDate) {
                            if (!item) return "--"; // No shift data for this date

                            const main = item.mainShift
                                ? `1st Shift: ${item.mainShift.shift || ""} Status: ${item.mainShift.attstatus || ""}`
                                : "";

                            const second = item.secondShift && Object.keys(item.secondShift).length
                                ? `2nd Shift: ${item.secondShift.shift || ""} Status: ${item.secondShift.attstatus || ""}`
                                : "";

                            value = `${main}${second ? `\n${second}` : ""}`;
                        }

                        return value;
                    }),
                ];
            });
        }
        else if (isfilter === "overall") {
            data = itemsAttReport.map((t, index) => {
                return [
                    index + 1,
                    t.empcode,
                    t.username,
                    t.company,
                    t.branch,
                    t.unit,
                    t.team,
                    t.department,
                    ...headArr.map((dateStr) => {
                        const dateParts = dateStr?.split(' ')[0]?.split('/');
                        const formattedDate = new Date(`${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`);

                        const dojDate = t.doj ? new Date(t.doj) : null;
                        const reasonDate = t.reasondate ? new Date(t.reasondate) : null;

                        const item = (t.days || []).find(d => d.date === dateStr);
                        let value = "";

                        if (t.reasondate && formattedDate > reasonDate) {
                            value = t.resonablestatus || "";
                        } else if (t.doj && formattedDate < dojDate) {
                            value = "Not Joined";
                        } else if (t.doj && formattedDate >= dojDate) {
                            if (!item) return "--"; // No shift data for this date

                            const main = item.mainShift
                                ? `1st Shift: ${item.mainShift.shift || ""} Status: ${item.mainShift.attstatus || ""}`
                                : "";

                            const second = item.secondShift && Object.keys(item.secondShift).length
                                ? `2nd Shift: ${item.secondShift.shift || ""} Status: ${item.secondShift.attstatus || ""}`
                                : "";

                            value = `${main}${second ? `\n${second}` : ""}`;
                        }

                        return value;
                    }),
                ];
            });
        }

        // Add headers to the data array
        const formattedData = data.map(row => {
            const rowData = {};
            headers.forEach((header, index) => {
                rowData[header] = row[index];
            });
            return rowData;
        });

        // Export to CSV
        exportToCSV(formattedData, fileName);
        setIsFilterOpenAttReport(false);
    };

    // print...
    const componentRefAttReport = useRef();
    const handleprintAttReport = useReactToPrint({
        content: () => componentRefAttReport.current,
        documentTitle: "Attendance Report",
        pageStyle: "print",
    });

    const downloadPdfAttReport = (isfilter) => {
        const doc = new jsPDF({ orientation: "landscape" });

        // Define the table headers
        const headers = [
            "SNo",
            "Emp Code",
            "Employee Name",
            "Company",
            "Branch",
            "Unit",
            "Team",
            "Department",
            ...headArr.map(column => column),
        ];

        const getDataForPdf = (row, index) => {
            const rowData = [
                index + 1,
                row.empcode,
                row.username,
                row.company,
                row.branch,
                row.unit,
                row.team,
                row.department,
            ];

            headArr.forEach((dateStr) => {
                const dateParts = dateStr?.split(' ')[0]?.split('/');
                const formattedDate = new Date(`${dateParts[2]}-${dateParts[1]}-${dateParts[0]}`);

                const dojDate = row.doj ? new Date(row.doj) : null;
                const reasonDate = row.reasondate ? new Date(row.reasondate) : null;

                const item = (row.days || []).find(d => d.date === dateStr);

                if (row.reasondate && formattedDate > reasonDate) {
                    rowData.push(row.resonablestatus || "");
                } else if (row.doj && formattedDate < dojDate) {
                    rowData.push("Not Joined");
                } else if (row.doj && formattedDate >= dojDate) {
                    if (!item) return "--"; // No shift data for this date

                    const main = item.mainShift
                        ? `1st Shift: ${item.mainShift.shift || ""} Status: ${item.mainShift.attstatus || ""}`
                        : "";

                    const second = item.secondShift && Object.keys(item.secondShift).length
                        ? `2nd Shift: ${item.secondShift.shift || ""} Status: ${item.secondShift.attstatus || ""}`
                        : "";

                    rowData.push(`${main}${second ? `\n${second}` : ""}`);
                }
            });

            return rowData;
        };

        let data = [];
        let resultdata = (filteredRowDataAttReport.length > 0 ? filteredRowDataAttReport : filteredDataAttReport) ?? []
        if (isfilter === "filtered") {
            data = resultdata.map(getDataForPdf);
        } else {
            data = itemsAttReport.map(getDataForPdf);
        }

        // Split data into chunks to fit on pages
        const columnsPerSheet = 10; // Number of columns per sheet
        const chunks = [];

        for (let i = 0; i < headers.length; i += columnsPerSheet) {
            const chunkHeaders = headers.slice(i, i + columnsPerSheet);
            const chunkData = data.map(row => row.slice(i, i + columnsPerSheet + 1));

            chunks.push({ headers: chunkHeaders, data: chunkData });
        }

        chunks.forEach((chunk, index) => {
            if (index > 0) {
                doc.addPage({ orientation: "landscape" }); // Add a new landscape pageAttReport for each chunk, except the first one
            }

            doc.autoTable({
                theme: "grid",
                styles: { fontSize: 8 },
                head: [chunk.headers],
                body: chunk.data,
                startY: 20, // Adjust startY to leave space for headers
                margin: { top: 20, left: 10, right: 10, bottom: 10 } // Adjust margin as needed
            });
        });

        doc.save("Attendance Report.pdf");
    };

    // image
    const handleCaptureImageAttReport = () => {
        if (gridRefImageAttReport.current) {
            domtoimage.toBlob(gridRefImageAttReport.current)
                .then((blob) => {
                    saveAs(blob, "Attendance Report.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredDataAttReport = filteredDataItemsAttReport?.slice((pageAttReport - 1) * pageSizeAttReport, pageAttReport * pageSizeAttReport);
    const totalPagesAttReportOuter = Math.ceil(filteredDataItemsAttReport?.length / pageSizeAttReport);
    const visiblePagesAttReport = Math.min(totalPagesAttReportOuter, 3);
    const firstVisiblePageAttReport = Math.max(1, pageAttReport - 1);
    const lastVisiblePageAttReport = Math.min(firstVisiblePageAttReport + visiblePagesAttReport - 1, totalPagesAttReportOuter);
    const pageNumbersAttReport = [];
    const indexOfLastItemAttReport = pageAttReport * pageSizeAttReport;
    const indexOfFirstItemAttReport = indexOfLastItemAttReport - pageSizeAttReport;
    for (let i = firstVisiblePageAttReport; i <= lastVisiblePageAttReport; i++) { pageNumbersAttReport.push(i); }

    return (
        <Box>
            {isUserRoleCompare?.includes("lteamattendanceoverallreport") && (
                <>
                    {/* ****** Table Start ****** */}
                    {filterUser.attmode === 'Attendance Review' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}>Team Attendance Review</Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttReview}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeAttReview}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsAttReview?.length}>All</MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenAttReview(true);
                                                        setFormat("xl");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileExcel />
                                                    &ensp;Export to Excel&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendancestatus") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenAttReview(true);
                                                        setFormat("csv");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileCsv />
                                                    &ensp;Export to CSV&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintAttReview}>
                                                    {" "}
                                                    &ensp; <FaPrint /> &ensp;Print&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenAttReview(true);
                                                    }}
                                                >
                                                    <FaFilePdf />
                                                    &ensp;Export to PDF&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={handleCaptureImage}
                                                >
                                                    {" "}
                                                    <ImageIcon sx={{ fontSize: "15px" }} />{" "}
                                                    &ensp;Image&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterAttReview && (
                                                        <IconButton onClick={handleResetSearchAttReview}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttReview} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayAttReview()}
                                            onChange={handleSearchChangeAttReview}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterAttReview}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>{" "}  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsAttReview}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsAttReview}> Manage Columns  </Button><br /> <br />
                            {loader ?
                                <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box> :
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttReview} >
                                        <AgGridReact
                                            rowData={filteredDataItemsAttReview}
                                            columnDefs={columnDataTableAttReview.filter((column) => columnVisibilityAttReview[column.field])}
                                            ref={gridRefTableAttReview}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttReview}
                                            onPaginationChanged={onPaginationChangedAttReview}
                                            onGridReady={onGridReadyAttReview}
                                            onColumnMoved={handleColumnMovedAttReview}
                                            onColumnVisible={handleColumnVisibleAttReview}
                                            onFilterChanged={onFilterChangedAttReview}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            }
                        </Box>
                    ) : null}
                    {filterUser.attmode === 'Attendance Report' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}> Team Attendance Day Shift </Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttReport}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeAttReport}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsAttReport?.length}>  All </MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}  >
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttReport(true)
                                                    // fetchUsersStatus()
                                                    setFormat("xl")
                                                }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendanceoverallreport") && (
                                            <>

                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttReport(true)
                                                    // fetchUsersStatus()
                                                    setFormat("csv")
                                                }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintAttReport}> &ensp;  <FaPrint /> &ensp;Print&ensp; </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenAttReport(true)
                                                    }}
                                                ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleCaptureImageAttReport}> <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp; </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterAttReport && (
                                                        <IconButton onClick={handleResetSearchAttReport}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttReport} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayAttReport()}
                                            onChange={handleSearchChangeAttReport}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterAttReport}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsAttReport}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsAttReport}> Manage Columns  </Button> <br /><br />
                            {loader ? (
                                <>
                                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <ThreeDots
                                            height="80"
                                            width="80"
                                            radius="9"
                                            color="#1976d2"
                                            ariaLabel="three-dots-loading"
                                            wrapperStyle={{}}
                                            wrapperClassName=""
                                            visible={true}
                                        />
                                    </Box>
                                </>
                            ) : (
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttReport} >
                                        <AgGridReact
                                            rowData={filteredDataItemsAttReport}
                                            columnDefs={columnDataTableAttReport.filter((column) => columnVisibilityAttReport[column.field])}
                                            ref={gridRefTableAttReport}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttReport}
                                            onPaginationChanged={onPaginationChangedAttReport}
                                            onGridReady={onGridReadyAttReport}
                                            onColumnMoved={handleColumnMovedAttReport}
                                            onColumnVisible={handleColumnVisibleAttReport}
                                            onFilterChanged={onFilterChangedAttReport}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            )}
                        </Box>
                    ) : null}
                    {/* ****** Table End ****** */}
                </>
            )}

            {/* Manage Column */}
            <Popover
                id={idAttReview}
                open={isManageColumnsOpenAttReview}
                anchorEl={anchorElAttReview}
                onClose={handleCloseManageColumnsAttReview}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsAttReview}
                    searchQuery={searchQueryManageAttReview}
                    setSearchQuery={setSearchQueryManageAttReview}
                    filteredColumns={filteredColumnsAttReview}
                    columnVisibility={columnVisibilityAttReview}
                    toggleColumnVisibility={toggleColumnVisibilityAttReview}
                    setColumnVisibility={setColumnVisibilityAttReview}
                    initialColumnVisibility={initialColumnVisibilityAttReview}
                    columnDataTable={columnDataTableAttReview}
                />
            </Popover>

            {/* Search Bar */}
            <Popover
                id={idSearchAttReview}
                open={openSearchAttReview}
                anchorEl={anchorElSearchAttReview}
                onClose={handleCloseSearchAttReview}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <AdvancedSearchBar columns={columnDataTableAttReview.filter(data => data.field !== "actions")} onSearch={applyAdvancedFilterAttReview} initialSearchValue={searchQueryAttReview} handleCloseSearch={handleCloseSearchAttReview} />
            </Popover>

            {/* Manage Column */}
            <Popover
                id={idAttReport}
                open={isManageColumnsOpenAttReport}
                anchorEl={anchorElAttReport}
                onClose={handleCloseManageColumnsAttReport}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsAttReport}
                    searchQuery={searchQueryManageAttReport}
                    setSearchQuery={setSearchQueryManageAttReport}
                    filteredColumns={filteredColumnsAttReport}
                    columnVisibility={columnVisibilityAttReport}
                    toggleColumnVisibility={toggleColumnVisibilityAttReport}
                    setColumnVisibility={setColumnVisibilityAttReport}
                    initialColumnVisibility={initialColumnVisibilityAttReport}
                    columnDataTable={columnDataTableAttReport}
                />
            </Popover>

            <Popover
                id={idSearchAttReport}
                open={openSearchAttReport}
                anchorEl={anchorElSearchAttReport}
                onClose={handleCloseSearchAttReport}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <Box sx={{ padding: '10px' }}>
                    <AdvancedSearchBar columns={columnDataTableAttReport} onSearch={applyAdvancedFilterAttReport} initialSearchValue={searchQueryAttReport} handleCloseSearch={handleCloseSearchAttReport} />
                </Box>
            </Popover>

            {/* Alert  */}
            <Box>
                <Dialog open={isErrorOpen} onClose={handleCloseerr} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <Typography variant="h6">{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" color="error" onClick={handleCloseerr}>
                            ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenAttReview}
                handleCloseFilterMod={handleCloseFilterModAttReview}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenAttReview}
                isPdfFilterOpen={isPdfFilterOpenAttReview}
                setIsPdfFilterOpen={setIsPdfFilterOpenAttReview}
                handleClosePdfFilterMod={handleClosePdfFilterModAttReview}
                filteredDataTwo={(filteredRowDataAttReview.length > 0 ? filteredRowDataAttReview : filteredDataAttReview) ?? []}
                itemsTwo={itemsAttReview ?? []}
                filename={"Team Attendance Review"}
                exportColumnNames={exportColumnNamescrtAttReview}
                exportRowValues={exportRowValuescrtAttReview}
                componentRef={componentRefAttReview}
            />

            {/* Print layout */}
            <TableContainer component={Paper} sx={userStyle.printcls}>
                <Table sx={{ minWidth: 700 }} aria-label="customized table" id="usertablereport" ref={componentRefAttReport}>
                    <TableHead>
                        <TableRow>
                            <TableCell>SNo</TableCell>
                            <TableCell>Emp Code</TableCell>
                            <TableCell>Employee Name</TableCell>
                            <TableCell>Company</TableCell>
                            <TableCell>Branch</TableCell>
                            <TableCell>Unit</TableCell>
                            <TableCell>Team</TableCell>
                            <TableCell>Department</TableCell>
                            {headArr.map((column, index) => {
                                return (
                                    <React.Fragment key={index}>
                                        <TableCell>
                                            <Box sx={userStyle.tableheadstyle}>
                                                {column}
                                            </Box>
                                        </TableCell>
                                    </React.Fragment>
                                );
                            })}
                        </TableRow>
                    </TableHead>
                    <TableBody align="left">
                        {(filteredRowDataAttReport.length > 0 ? filteredRowDataAttReport : filteredDataAttReport) &&
                            (filteredRowDataAttReport.length > 0 ? filteredRowDataAttReport : filteredDataAttReport).map((row, rowindex) => (
                                <TableRow key={rowindex}>
                                    <TableCell>{row.serialNumber}</TableCell>
                                    <TableCell>{row.empcode}</TableCell>
                                    <TableCell>{row.username}</TableCell>
                                    <TableCell>{row.company}</TableCell>
                                    <TableCell>{row.branch}</TableCell>
                                    <TableCell>{row.unit}</TableCell>
                                    <TableCell>{row.team}</TableCell>
                                    <TableCell>{row.department}</TableCell>
                                    {headArr.map((column, colIndex) => {

                                        const formattedDate = column?.split(' ')[0];
                                        const [formatday1, fromatmonth1, formatyear1] = formattedDate.split('/');
                                        const formattedDateNew = new Date(`${formatyear1}-${fromatmonth1}-${formatday1}`);

                                        // Find the corresponding data for this date
                                        const matchingDay = row.days.find(day => day.date.startsWith(column.split(' ')[0]));

                                        const reasonDate = new Date(row.reasondate);
                                        const dojDate = new Date(row.doj);

                                        if (row.reasondate && row.reasondate != "" && formattedDateNew > reasonDate) {
                                            return (
                                                <Grid sx={{ display: 'flex', }}>
                                                    <Box sx={{ margin: '5px', }}>
                                                        <Button
                                                            size="small"
                                                            sx={{
                                                                textTransform: 'capitalize',
                                                                borderRadius: '4px',
                                                                boxShadow: 'none',
                                                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                                                fontWeight: '400',
                                                                fontSize: '0.875rem',
                                                                lineHeight: '1.43',
                                                                letterSpacing: '0.01071em',
                                                                display: 'flex',
                                                                padding: '3px 10px',
                                                                color: '#e4d7d7',
                                                                backgroundColor: 'rgb(187 46 46)',
                                                                pointerEvents: 'none',

                                                            }}
                                                        // Disable the button if the date is before the current date
                                                        // disabled={isDisable2}
                                                        >
                                                            {row.resonablestatus}
                                                        </Button>
                                                    </Box>
                                                </Grid >
                                            );
                                        }
                                        else if (row.doj && row.doj != "" && formattedDateNew < dojDate) {
                                            return (
                                                <Grid sx={{ display: 'flex', }} >
                                                    <Box sx={{ margin: '10px', }}>
                                                        <Button
                                                            size="small"
                                                            sx={{
                                                                // marginTop: '10px',
                                                                textTransform: 'capitalize',
                                                                borderRadius: '4px',
                                                                boxShadow: 'none',
                                                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                                                fontWeight: '400',
                                                                fontSize: '0.875rem',
                                                                lineHeight: '1.43',
                                                                letterSpacing: '0.01071em',
                                                                display: 'flex',
                                                                padding: '3px 10px',
                                                                color: '#e4d7d7',
                                                                backgroundColor: 'rgb(187 46 46)',
                                                                pointerEvents: 'none',

                                                            }}
                                                        // Disable the button if the date is before the current date
                                                        // disabled={isDisable1}
                                                        >
                                                            {"Not Joined"}
                                                        </Button>
                                                    </Box>
                                                </Grid >
                                            );
                                        }
                                        else if (row.doj && row.doj != "" && formattedDateNew >= dojDate) {
                                            if (!matchingDay) return null;
                                            return (
                                                <TableCell key={colIndex}>
                                                    {matchingDay ? (
                                                        <Grid container sx={{ display: 'block' }}>
                                                            <Grid md={12}>
                                                                <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                                    {matchingDay.mainShift.shift}
                                                                </Typography>
                                                                <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                                    {matchingDay.mainShift.attstatus}
                                                                </Typography>
                                                            </Grid>
                                                            <Grid md={12}>
                                                                <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                                    {matchingDay.secondShift.shift}
                                                                </Typography>
                                                                <Typography variant="body2" sx={{ fontSize: '12px' }}>
                                                                    {matchingDay.secondShift.attstatus}
                                                                </Typography>
                                                            </Grid>
                                                        </Grid>
                                                    ) : (
                                                        <TableCell></TableCell> // Empty cell if no matching data
                                                    )}
                                                </TableCell>
                                            );
                                        }
                                    })}
                                </TableRow>
                            ))}
                    </TableBody>
                </Table>
            </TableContainer>

            <Dialog open={isFilterOpenAttReport} onClose={handleCloseFilterModAttReport} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                <DialogContent sx={{ textAlign: "center", alignItems: "center", justifyContent: "center" }}>
                    <IconButton
                        aria-label="close"
                        onClick={handleCloseFilterModAttReport}
                        sx={{
                            position: "absolute",
                            right: 8,
                            top: 8,
                            color: (theme) => theme.palette.grey[500],
                        }}
                    >
                        <CloseIcon />
                    </IconButton>

                    {fileFormat === 'xl' ?
                        <FaFileExcel style={{ fontSize: "70px", color: "green" }} />
                        : <FaFileCsv style={{ fontSize: "70px", color: "green" }} />
                    }
                    <Typography variant="h5" sx={{ textAlign: "center" }}>
                        Choose Export
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button
                        autoFocus variant="contained"
                        onClick={(e) => {
                            handleExportXLAttReport("filtered")
                        }}
                    >
                        Export Filtered Data
                    </Button>
                    <Button autoFocus variant="contained"
                        onClick={(e) => {
                            handleExportXLAttReport("overall")
                        }}
                    >
                        Export Over All Data
                    </Button>
                </DialogActions>
            </Dialog>
            {/*Export pdf Data  */}
            <Dialog open={isPdfFilterOpenAttReport} onClose={handleClosePdfFilterModAttReport} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                <DialogContent sx={{ textAlign: "center", alignItems: "center", justifyContent: "center" }}>
                    <IconButton
                        aria-label="close"
                        onClick={handleClosePdfFilterModAttReport}
                        sx={{
                            position: "absolute",
                            right: 8,
                            top: 8,
                            color: (theme) => theme.palette.grey[500],
                        }}
                    >
                        <CloseIcon />
                    </IconButton>

                    <PictureAsPdfIcon sx={{ fontSize: "80px", color: "red" }} />
                    <Typography variant="h5" sx={{ textAlign: "center" }}>
                        Choose Export
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button
                        variant="contained"
                        onClick={(e) => {
                            downloadPdfAttReport("filtered")
                            setIsPdfFilterOpenAttReport(false);
                        }}
                    >
                        Export Filtered Data
                    </Button>
                    <Button variant="contained"
                        onClick={(e) => {
                            downloadPdfAttReport("overall")
                            setIsPdfFilterOpenAttReport(false);
                        }}
                    >
                        Export Over All Data
                    </Button>
                </DialogActions>
            </Dialog>

        </Box>
    );
}

export default TeamAttOverallReviewAndReportList;