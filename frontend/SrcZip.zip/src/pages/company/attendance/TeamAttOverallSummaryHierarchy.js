import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import { FaFileExcel, FaFileCsv, FaPrint, FaFilePdf, FaSearch } from 'react-icons/fa';
import { Box, Typography, OutlinedInput, Select, MenuItem, Dialog, InputAdornment, FormControl, Grid, Button, Popover, IconButton, Tooltip } from "@mui/material";
import { userStyle, } from "../../../pageStyle";
import "jspdf-autotable";
import { handleApiError } from "../../../components/Errorhandling";
import { useReactToPrint } from "react-to-print";
import { UserRoleAccessContext } from "../../../context/Appcontext";
import { AuthContext } from "../../../context/Appcontext";
import { ThreeDots } from "react-loader-spinner";
import ImageIcon from "@mui/icons-material/Image";
import { getCurrentServerTime } from '../../../components/getCurrentServerTime';
import { saveAs } from "file-saver";
import moment from 'moment';
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import AggregatedSearchBar from "../../../components/AggregatedSearchBar";
import AggridTable from "../../../components/AggridTable";
import domtoimage from 'dom-to-image';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import ExportData from "../../../components/ExportData";
import MessageAlert from "../../../components/MessageAlert";
import AlertDialog from "../../../components/Alert";
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from "../../../components/ManageColumn";
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

const ScrollingText = ({ text }) => {
    const containerRef = useRef(null);
    const textRef = useRef(null);

    useEffect(() => {
        const containerWidth = containerRef.current.offsetWidth;
        const textElement = textRef.current;

        if (!textElement) return; // Add a null check here

        const textWidth = textElement.offsetWidth;
        let position = 0;

        const scrollText = () => {
            position -= 1;
            if (position < -textWidth) {
                position = containerWidth;
            }
            textElement.style.transform = `translateX(${position}px)`;
            requestAnimationFrame(scrollText);
        };

        scrollText();

        return () => cancelAnimationFrame(scrollText);
    }, []);

    return (
        <Grid item xs={8} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", }}>
            <Typography sx={userStyle.importheadtext}>{"Team Attendance Summary Report - Hierarchy"}</Typography>
            <div ref={containerRef} style={{ overflow: "hidden", width: "50%", whiteSpace: "nowrap" }}>
                <span ref={textRef} style={{ color: "red", display: "inline-block" }}>{text}</span>
            </div>
        </Grid>
    );
};

const ScrollingTextView = ({ text, tableNameHier }) => {
    const containerRef = useRef(null);
    const textRef = useRef(null);

    useEffect(() => {
        const containerWidth = containerRef.current.offsetWidth;
        const textElement = textRef.current;

        if (!textElement) return; // Add a null check here

        const textWidth = textElement.offsetWidth;
        let position = 0;

        const scrollText = () => {
            position -= 1;
            if (position < -textWidth) {
                position = containerWidth;
            }
            textElement.style.transform = `translateX(${position}px)`;
            requestAnimationFrame(scrollText);
        };

        scrollText();

        return () => cancelAnimationFrame(scrollText);
    }, []);

    return (
        <Grid item xs={8} sx={{ display: "flex", justifyContent: "space-between", alignItems: "center", }}>
            <Typography sx={userStyle.HeaderText}>{tableNameHier}</Typography>
            <div ref={containerRef} style={{ overflow: "hidden", width: "50%", whiteSpace: "nowrap" }}>
                <span ref={textRef} style={{ color: "red", display: "inline-block" }}>{text}</span>
            </div>
        </Grid>
    );
};

function TeamAttSummaryHierarchyList({ userShiftsUserShiftSummaryHier, loader, setSearchQueryUserShiftSummaryHier, setPageUserShiftSummaryHier, setTotalPagesUserShiftSummaryHier, setPageSizeUserShiftSummaryHier, totalPagesUserShiftSummaryHier, pageUserShiftSummaryHier, pageSizeUserShiftSummaryHier, searchQueryUserShiftSummaryHier, filterUser }) {

    let overallBoxStyle = {
        background: '#fff',
        borderRadius: '5px',
        padding: '10px 12px 10px 60px',
        boxShadow: '0 4px 12px rgba(0,0,0,0.51)',
        display: 'flex',
        alignItems: 'center',
        position: 'relative',
    }

    function formatCustomDateTime(date) {
        if (!date) {
            return '';
        }
        const dd = String(date.getDate()).padStart(2, '0');
        const mm = String(date.getMonth() + 1).padStart(2, '0'); // Months are 0-based
        const yyyy = date.getFullYear();

        let hh = date.getHours();
        const min = String(date.getMinutes()).padStart(2, '0');
        const ss = String(date.getSeconds()).padStart(2, '0');
        const period = hh >= 12 ? 'PM' : 'AM';

        hh = String(hh).padStart(2, '0');

        return `${dd}-${mm}-${yyyy} ${hh}:${min}:${ss} ${period}`;
    }

    const gridRefTableUserShiftSummaryHier = useRef(null);
    const gridRefImageUserShiftSummaryHier = useRef(null);
    const gridRefImageUserShiftSummaryViewPopupHier = useRef(null);
    const gridRefTableView = useRef(null);
    const gridRefTableImgView = useRef(null);

    const { isUserRoleAccess, isUserRoleCompare, isAssignBranch, allUsersLimit, alldepartment, allTeam, pageName, setPageName, buttonStyles } = useContext(UserRoleAccessContext);
    const { auth } = useContext(AuthContext);

    const [viewDataHier, setViewDataHier] = useState([]);
    const [tableNameHier, setTableNameHier] = useState('');
    const [itemsAttSummaryHier, setItemsAttSummaryHier] = useState([]);

    const [advancedFilterUserShiftSummaryHier, setAdvancedFilterUserShiftSummaryHier] = useState(null);
    const [gridApiUserShiftSummaryHier, setGridApiUserShiftSummaryHier] = useState(null);
    const [columnApiUserShiftSummaryHier, setColumnApiUserShiftSummaryHier] = useState(null);
    const [filteredDataItemsUserShiftSummaryHier, setFilteredDataItemsUserShiftSummaryHier] = useState(userShiftsUserShiftSummaryHier);
    const [filteredRowDataUserShiftSummaryHier, setFilteredRowDataUserShiftSummaryHier] = useState([]);

    const [itemsViewHier, setItemsViewHier] = useState([]);
    const [loaderViewHier, setLoaderViewHier] = useState(false);
    const [selectedRowsViewHier, setSelectedRowsViewHier] = useState([]);

    const [filteredRowDataViewHier, setFilteredRowDataViewHier] = useState([]);
    const [filteredChangesViewHier, setFilteredChangesViewHier] = useState(null);
    const [isHandleChangeViewHier, setIsHandleChangeViewHier] = useState(false);
    const [searchedStringViewHier, setSearchedStringViewHier] = useState("");

    const [pageViewHier, setPageViewHier] = useState(1);
    const [pageSizeViewHier, setPageSizeViewHier] = useState(10);
    const [searchQueryViewHier, setSearchQueryViewHier] = useState("");

    const [isFilterOpenViewHier, setIsFilterOpenViewHier] = useState(false);
    const [isPdfFilterOpenViewHier, setIsPdfFilterOpenViewHier] = useState(false);
    // page refersh reload
    const handleCloseFilterModViewHier = () => { setIsFilterOpenViewHier(false); };
    const handleClosePdfFilterModViewHier = () => { setIsPdfFilterOpenViewHier(false); };

    const [isFilterOpenUserShiftSummaryHier, setIsFilterOpenUserShiftSummaryHier] = useState(false);
    const [isPdfFilterOpenUserShiftSummaryHier, setIsPdfFilterOpenUserShiftSummaryHier] = useState(false);
    // pageUserShiftSummaryHier refersh reload
    const handleCloseFilterModUserShiftSummaryHier = () => { setIsFilterOpenUserShiftSummaryHier(false); };
    const handleClosePdfFilterModUserShiftSummaryHier = () => { setIsPdfFilterOpenUserShiftSummaryHier(false); };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); }

    // View model
    const [openviewHier, setOpenviewHier] = useState(false);
    const handleClickOpenviewHier = () => { setOpenviewHier(true); };
    const handleCloseviewHier = () => {
        setOpenviewHier(false);
        setViewDataHier([]);
        setPageViewHier(1);
        setSearchQueryViewHier("");
    }

    // History model
    const [openHistoryviewHier, setOpenHistoryviewHier] = useState(false);
    const handleClickOpenHistoryviewHier = () => { setOpenHistoryviewHier(true); };
    const handleCloseHistoryviewHier = () => { setOpenHistoryviewHier(false); }

    // pageUserShiftSummaryHier refersh reload
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    // Manage Columns
    const [isManageColumnsOpenUserShiftSummaryHier, setManageColumnsOpenUserShiftSummaryHier] = useState(false);
    const [anchorElUserShiftSummaryHier, setAnchorElUserShiftSummaryHier] = useState(null);
    const [searchQueryManageUserShiftSummaryHier, setSearchQueryManageUserShiftSummaryHier] = useState("");
    const handleOpenManageColumnsUserShiftSummaryHier = (event) => {
        setAnchorElUserShiftSummaryHier(event.currentTarget);
        setManageColumnsOpenUserShiftSummaryHier(true);
    };
    const handleCloseManageColumnsUserShiftSummaryHier = () => {
        setManageColumnsOpenUserShiftSummaryHier(false);
        setSearchQueryManageUserShiftSummaryHier("");
    };
    const openManageColumnsUserShiftSummaryHier = Boolean(anchorElUserShiftSummaryHier);
    const idManageColumnsUserShiftSummaryHier = openManageColumnsUserShiftSummaryHier ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchUserShiftSummaryHier, setAnchorElSearchUserShiftSummaryHier] = React.useState(null);
    const handleClickSearchUserShiftSummaryHier = (event) => {
        setAnchorElSearchUserShiftSummaryHier(event.currentTarget);
    };
    const handleCloseSearchUserShiftSummaryHier = () => {
        setAnchorElSearchUserShiftSummaryHier(null);
        setSearchQueryUserShiftSummaryHier("");
    };

    const openSearchUserShiftSummaryHier = Boolean(anchorElSearchUserShiftSummaryHier);
    const idSearchUserShiftSummaryHier = openSearchUserShiftSummaryHier ? 'simple-popover' : undefined;

    const [searchQueryManageViewHier, setSearchQueryManageViewHier] = useState("");
    const [isManageColumnsOpenViewHier, setManageColumnsOpenViewHier] = useState(false);
    const [anchorElViewHier, setAnchorElViewHier] = useState(null);

    const handleOpenManageColumnsViewHier = (event) => {
        setAnchorElViewHier(event.currentTarget);
        setManageColumnsOpenViewHier(true);
    };
    const handleCloseManageColumnsViewHier = () => {
        setManageColumnsOpenViewHier(false);
        setSearchQueryManageViewHier("");
    };

    const openViewHier = Boolean(anchorElViewHier);
    const idViewHier = openViewHier ? "simple-popover" : undefined;

    // Show All Columns & Manage Columns
    const initialColumnVisibilityUserShiftSummaryHier = {
        serialNumber: true,
        date: true,
        history: true,
        totalemployees: true,
        totalcurrentshift: true,
        paidpresentday: true,
        lopcount: true,
        totalin: true,
        totalout: true,
        totalpending: true,
        facilitypresent: true,
        wfhpresent: true,
        facilityabsent: true,
        wfhabsent: true,
        earlyclockin: true,
        onpresent: true,
        graceclockin: true,
        lateclockin: true,
        weekoff: true,
        holidayCount: true,
        permissionCount: true,
        clsl: true,
        onclockout: true,
        earlyclockout: true,
        overclockout: true,
        autoclockout: true,
        shiftnotstarted: true,
        nostatus: true,
        notallotted: true,
        weekoffpresent: true,
        longleaveabsent: true,
        blabsent: true,
        doubledayabsent: true,
        weekoffabsent: true,
    };
    const [columnVisibilityUserShiftSummaryHier, setColumnVisibilityUserShiftSummaryHier] = useState(initialColumnVisibilityUserShiftSummaryHier);

    const initialColumnVisibilityView = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        date: true,
        shiftmode: true,
        shift: true,
        changeshift: true,
        leavestatus: true,
        permissionstatus: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        daystatus: true,
        appliedthrough: true,
        isweekoff: true,
        isholiday: true,
        lopcalculation: true,
        modetarget: true,
        paidpresent: true,
        lopday: true,
        paidpresentday: true,
    };

    const [columnVisibilityView, setColumnVisibilityView] = useState(initialColumnVisibilityView);

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    }

    const addSerialNumberAttSummary = async (datas) => {
        setItemsAttSummaryHier(datas);
    };

    useEffect(() => {
        addSerialNumberAttSummary(userShiftsUserShiftSummaryHier);
        setFilteredDataItemsUserShiftSummaryHier(userShiftsUserShiftSummaryHier);
    }, [userShiftsUserShiftSummaryHier]);

    function getMonthsInRange(fromdate, todate) {
        const startDate = new Date(fromdate);
        const endDate = new Date(todate);
        const monthNames = [
            "January", "February", "March", "April", "May", "June",
            "July", "August", "September", "October", "November", "December"
        ];

        const result = [];

        // Previous month based on `fromdate`
        const prevMonth = startDate.getMonth() === 0 ? 11 : startDate.getMonth() - 1;
        const prevYear = startDate.getMonth() === 0 ? startDate.getFullYear() - 1 : startDate.getFullYear();
        result.push({ month: monthNames[prevMonth], year: prevYear.toString() });

        // Add selected months between `fromdate` and `todate`
        const currentDate = new Date(startDate);
        currentDate.setDate(1); // Normalize to the start of the month
        while (
            currentDate.getFullYear() < endDate.getFullYear() ||
            (currentDate.getFullYear() === endDate.getFullYear() && currentDate.getMonth() <= endDate.getMonth())
        ) {
            result.push({
                month: monthNames[currentDate.getMonth()],
                year: currentDate.getFullYear().toString()
            });
            currentDate.setMonth(currentDate.getMonth() + 1);
        }

        // Next month based on `todate`
        const nextMonth = endDate.getMonth() === 11 ? 0 : endDate.getMonth() + 1;
        const nextYear = endDate.getMonth() === 11 ? endDate.getFullYear() + 1 : endDate.getFullYear();
        result.push({ month: monthNames[nextMonth], year: nextYear.toString() });

        return result;
    }

    const getCode = (rowdata, column) => {
        setLoaderViewHier(true);
        try {
            handleClickOpenviewHier();
            if (column === 'totalemployees') {
                setTableNameHier('Total Employees List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.totalemployeesArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalcurrentshift') {
                setTableNameHier('Total Current Shift List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.totalcurrentshiftArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'paidpresentday') {
                setTableNameHier('Present List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.paidpresentdayArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'lopcount') {
                setTableNameHier('Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.absentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalin') {
                setTableNameHier('Total In List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.totalinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalout') {
                setTableNameHier('Total Out List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.totaloutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'totalpending') {
                setTableNameHier('Total Pending List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.totalpendingArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'facilitypresent') {
                setTableNameHier('Facility Present List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.facilitypresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'wfhpresent') {
                setTableNameHier('WFH Present List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.wfhpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'facilityabsent') {
                setTableNameHier('Facility Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.facilityabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'wfhabsent') {
                setTableNameHier('WFH Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.wfhabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'earlyclockin') {
                setTableNameHier('Early - ClockIn List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.earlyclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'onpresent') {
                setTableNameHier('On - Present List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.onpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'graceclockin') {
                setTableNameHier('Grace - ClockIn List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.graceclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'lateclockin') {
                setTableNameHier('Late - ClockIn List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.lateclockinArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoff') {
                setTableNameHier('Week Off List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.weekoffArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'holidayCount') {
                setTableNameHier('Holiday List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.holidayArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'permissionCount') {
                setTableNameHier('Permission List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.permissionArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'clsl') {
                setTableNameHier('CL/SL List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.clslArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'onclockout') {
                setTableNameHier('On - ClockOut List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.onclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'earlyclockout') {
                setTableNameHier('Early - ClockOut List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.earlyclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'overclockout') {
                setTableNameHier('Over - ClockOut List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.overclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'autoclockout') {
                setTableNameHier('Auto - ClockOut List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.autoclockoutArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'shiftnotstarted') {
                setTableNameHier('Shift Not Started List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.shiftnotstartedArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'nostatus') {
                setTableNameHier('No Status List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.nostatusArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'notallotted') {
                setTableNameHier('Not Allotted List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.notallottedArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoffpresent') {
                setTableNameHier('Weekoff Present List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.weekoffpresentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'longleaveabsent') {
                setTableNameHier('Long Leave & Long Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.longleaveabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'blabsent') {
                setTableNameHier('BL - Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.blabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'doubledayabsent') {
                setTableNameHier('Double Day Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.doubledayabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            if (column === 'weekoffabsent') {
                setTableNameHier('Weekoff Absent List');
                if (filterUser.fromdate === moment(rowdata.date, 'DD/MM/YYYY').format('YYYY-MM-DD')) {
                    setViewDataHier(rowdata.weekoffabsentArray
                        .map((item, index) => ({
                            ...item,
                            serialNumber: index + 1,
                        })));
                }
            }
            setLoaderViewHier(false);
        } catch (err) {
            setLoaderViewHier(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    const [historyViewDataHier, setHistoryViewDataHier] = useState({});
    const [currentServerTimeHier, setCurrentServerTimeHier] = useState(null);
    const getHistoryCode = async (rowdata) => {
        const time = await getCurrentServerTime();
        setCurrentServerTimeHier(time);
        try {
            handleClickOpenHistoryviewHier();
            setHistoryViewDataHier(rowdata);
        } catch (err) {
            setLoaderViewHier(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    }

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ["apply", "reset", "cancel"],
            },
        };
    }, []);

    const onGridReadyUserShiftSummaryHier = useCallback((params) => {
        setGridApiUserShiftSummaryHier(params.api);
        setColumnApiUserShiftSummaryHier(params.columnApiUserShiftSummaryHier);
    }, []);

    // Function to handle filter changes
    const onFilterChangedUserShiftSummaryHier = () => {
        if (gridApiUserShiftSummaryHier) {
            const filterModel = gridApiUserShiftSummaryHier.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataUserShiftSummaryHier([]);
            } else {
                // Filters are active, capture filtered data
                const filteredDataUserShiftSummaryHier = [];
                gridApiUserShiftSummaryHier.forEachNodeAfterFilterAndSort((node) => {
                    filteredDataUserShiftSummaryHier.push(node.data);
                });
                setFilteredRowDataUserShiftSummaryHier(filteredDataUserShiftSummaryHier);
            }
        }
    };

    const onPaginationChanged = useCallback(() => {
        if (gridRefTableUserShiftSummaryHier.current) {
            const gridApiUserShiftSummaryHier = gridRefTableUserShiftSummaryHier.current.api;
            const currentPage = gridApiUserShiftSummaryHier.paginationGetCurrentPage() + 1;
            const totalPagesUserShiftSummaryHier = gridApiUserShiftSummaryHier.paginationGetTotalPages();
            setPageUserShiftSummaryHier(currentPage);
            setTotalPagesUserShiftSummaryHier(totalPagesUserShiftSummaryHier);
        }
    }, []);

    const columnDataTableUserShiftSummaryHier = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityUserShiftSummaryHier.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "date", headerName: "Date", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummaryHier.date, },
        {
            field: "history", headerName: "History", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummaryHier.history,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small" onClick={() => { getHistoryCode(params.data); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalemployees", headerName: "Total Employees", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummaryHier.totalemployees,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalemployees}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalemployees'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalcurrentshift", headerName: "Total Current Shift", flex: 0, width: 130, hide: !columnVisibilityUserShiftSummaryHier.totalcurrentshift,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalcurrentshift}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalcurrentshift'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "paidpresentday", headerName: "Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.paidpresentday,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.paidpresentday}
                        <Button size="small" onClick={() => { getCode(params.data, 'paidpresentday'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "lopcount", headerName: "Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.lopcount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.lopcount}
                        <Button size="small" onClick={() => { getCode(params.data, 'lopcount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalin", headerName: "Total In", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.totalin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalin}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalout", headerName: "Total Out", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.totalout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalout}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "totalpending", headerName: "Total Pending", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.totalpending,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.totalpending}
                        <Button size="small" onClick={() => { getCode(params.data, 'totalpending'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "facilitypresent", headerName: "Facility Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.facilitypresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.facilitypresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'facilitypresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "wfhpresent", headerName: "WFH Present", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.wfhpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.wfhpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'wfhpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "facilityabsent", headerName: "Facility Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.facilityabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.facilityabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'facilityabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "wfhabsent", headerName: "WFH Absent", flex: 0, width: 110, hide: !columnVisibilityUserShiftSummaryHier.wfhabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.wfhabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'wfhabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "earlyclockin", headerName: "Early - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.earlyclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.earlyclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'earlyclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "onpresent", headerName: "On - Present", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.onpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.onpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'onpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "graceclockin", headerName: "Grace - ClockIn", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.graceclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.graceclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'graceclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "lateclockin", headerName: "Late - ClockIn", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.lateclockin,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.lateclockin}
                        <Button size="small" onClick={() => { getCode(params.data, 'lateclockin'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoff", headerName: "Week Off", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.weekoff,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoff}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoff'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "holidayCount", headerName: "Holiday", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.holidayCount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.holidayCount}
                        <Button size="small" onClick={() => { getCode(params.data, 'holidayCount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "permissionCount", headerName: "Permission", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.permissionCount,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.permissionCount}
                        <Button size="small" onClick={() => { getCode(params.data, 'permissionCount'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "clsl", headerName: "CL/SL", flex: 0, width: 150, hide: !columnVisibilityUserShiftSummaryHier.clsl,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.clsl}
                        <Button size="small" onClick={() => { getCode(params.data, 'clsl'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "onclockout", headerName: "On - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.onclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.onclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'onclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "earlyclockout", headerName: "Early - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.earlyclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.earlyclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'earlyclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "overclockout", headerName: "Over - ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.overclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.overclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'overclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "autoclockout", headerName: "Auto-Mis ClockOut", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.autoclockout,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.autoclockout}
                        <Button size="small" onClick={() => { getCode(params.data, 'autoclockout'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "shiftnotstarted", headerName: "Shift Not Started", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.shiftnotstarted,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.shiftnotstarted}
                        <Button size="small" onClick={() => { getCode(params.data, 'shiftnotstarted'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "nostatus", headerName: "No Status", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.nostatus,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.nostatus}
                        <Button size="small" onClick={() => { getCode(params.data, 'nostatus'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "notallotted", headerName: "Not Allotted", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.notallotted,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.notallotted}
                        <Button size="small" onClick={() => { getCode(params.data, 'notallotted'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoffpresent", headerName: "Weekoff Present", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.weekoffpresent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoffpresent}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoffpresent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "longleaveabsent", headerName: "Long Leave & Long Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.longleaveabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.longleaveabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'longleaveabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "blabsent", headerName: "BL Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.blabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.blabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'blabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "doubledayabsent", headerName: "Double Day Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.doubledayabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.doubledayabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'doubledayabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "weekoffabsent", headerName: "Weekoff Absent", flex: 0, width: 120, hide: !columnVisibilityUserShiftSummaryHier.weekoffabsent,
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {params.data.weekoffabsent}
                        <Button size="small" onClick={() => { getCode(params.data, 'weekoffabsent'); }} sx={{ marginTop: '5px', }}>
                            View
                        </Button>
                    </Grid >
                );
            },
        },
    ];

    const columnDataTableView = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 75, hide: !columnVisibilityView.serialNumber, pinned: 'left', lockPinned: true },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityView.empcode, pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityView.username, pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibilityView.company, },
        { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibilityView.branch, },
        { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibilityView.unit, },
        { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibilityView.team, },
        { field: "department", headerName: "Department", flex: 0, width: 130, hide: !columnVisibilityView.department, },
        { field: "date", headerName: "Date", flex: 0, width: 110, hide: !columnVisibilityView.date, },
        { field: "shiftmode", headerName: "Shift Mode", flex: 0, width: 110, hide: !columnVisibilityView.shiftmode, },
        { field: "shift", headerName: "Shift", flex: 0, width: 150, hide: !columnVisibilityView.shift, },
        { field: "changeshift", headerName: "Change Shift", flex: 0, width: 150, hide: !columnVisibilityView.changeshift, },
        { field: "leavestatus", headerName: "Leave Status", flex: 0, width: 150, hide: !columnVisibilityView.leavestatus, },
        { field: "permissionstatus", headerName: "Permission Status", flex: 0, width: 150, hide: !columnVisibilityView.permissionstatus, },
        { field: "clockin", headerName: "ClockIn", flex: 0, width: 120, hide: !columnVisibilityView.clockin, },
        {
            field: "clockinstatus", headerName: "ClockInStatus", flex: 0, width: 200, hide: !columnVisibilityView.clockinstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                                backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                                '&:hover': {
                                    color: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'black' : params.data.clockinstatus === 'Holiday' ? 'black' : params.data.clockinstatus === 'Leave' ? 'white' : (params.data.clockinstatus === 'Absent' || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#462929' : params.data.clockinstatus === 'Week Off' ? 'white' : params.data.clockinstatus === 'Grace - ClockIn' ? '#052106' : params.data.clockinstatus === 'On - Present' ? 'black' : params.data.clockinstatus === 'HBLOP' ? 'white' : params.data.clockinstatus === 'FLOP' ? 'white' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockinstatus?.includes('Late') ? '#15111d' : '#15111d',
                                    backgroundColor: (params.data.clockinstatus === 'Present' || params.data.clockinstatus === 'Early - ClockIn') ? 'rgb(156 239 156)' : params.data.clockinstatus === 'Holiday' ? '#B6FFFA' : params.data.clockinstatus === 'Leave' ? '#1640D6' : (params.data.clockinstatus === "Absent" || params.data.clockinstatus?.includes('Long') || params.data.clockinstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockinstatus === 'Week Off' ? '#6b777991' : params.data.clockinstatus === 'Grace - ClockIn' ? 'rgb(243 203 117)' : params.data.clockinstatus === 'On - Present' ? '#E1AFD1' : params.data.clockinstatus === 'HBLOP' ? '#DA0C81' : params.data.clockinstatus === 'FLOP' ? '#FE0000' : (params.data.clockinstatus === 'AfterWeekOffAbsent' || params.data.clockinstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockinstatus === 'BeforeWeekOffAbsent' || params.data.clockinstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockinstatus?.includes('Late') ? '#610c9f57' : 'rgb(243 203 117)',
                                }
                            }}
                        >
                            {params.data.clockinstatus}
                        </Button>
                    </Grid >
                );
            },
        },
        { field: "clockout", headerName: "ClockOut", flex: 0, width: 120, hide: !columnVisibilityView.clockout, },
        {
            field: "clockoutstatus", headerName: "ClockOutStatus", flex: 0, width: 200, hide: !columnVisibilityView.clockoutstatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '3px 5px' : '3px 8px',
                                cursor: 'default',
                                color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                                backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                                '&:hover': {
                                    color: params.data.clockoutstatus === 'Holiday' ? 'black' : params.data.clockoutstatus === 'Leave' ? 'white' : (params.data.clockoutstatus === 'Absent' || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#462929' : params.data.clockoutstatus === 'Week Off' ? 'white' : params.data.clockoutstatus === 'On - ClockOut' ? 'black' : params.data.clockoutstatus === 'Over - ClockOut' ? '#052106' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#15111d' : params.data.clockoutstatus?.includes('Early') ? '#052106' : params.data.clockoutstatus === 'HALOP' ? 'white' : params.data.clockoutstatus === 'FLOP' ? 'white' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? 'black' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? 'black' : params.data.clockoutstatus === 'Pending' ? '#052106' : '#052106',
                                    backgroundColor: params.data.clockoutstatus === 'Holiday' ? '#B6FFFA' : params.data.clockoutstatus === 'Leave' ? '#1640D6' : (params.data.clockoutstatus === "Absent" || params.data.clockoutstatus?.includes('Long') || params.data.clockoutstatus === 'BL - Absent') ? '#ff00007d' : params.data.clockoutstatus === 'Week Off' ? '#6b777991' : params.data.clockoutstatus === 'On - ClockOut' ? '#E1AFD1' : params.data.clockoutstatus === 'Over - ClockOut' ? 'rgb(156 239 156)' : params.data.clockoutstatus === 'Mis - ClockOut' ? '#610c9f57' : params.data.clockoutstatus?.includes('Early') ? 'rgb(243 203 117)' : params.data.clockoutstatus === 'HALOP' ? '#DA0C81' : params.data.clockoutstatus === 'FLOP' ? '#FE0000' : (params.data.clockoutstatus === 'AfterWeekOffAbsent' || params.data.clockoutstatus === 'AfterWeekOffLeave') ? '#F2D1D1' : (params.data.clockoutstatus === 'BeforeWeekOffAbsent' || params.data.clockoutstatus === 'BeforeWeekOffLeave') ? '#EEE3CB' : params.data.clockoutstatus === 'Pending' ? 'rgb(243 203 117)' : 'rgb(243 203 117)',
                                }
                            }}
                        >
                            {params.data.clockoutstatus}
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "attendanceauto", headerName: "Attendance", flex: 0, width: 200, hide: !columnVisibilityView.attendanceauto,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.attendanceauto === 'HOLIDAY' ? 'black' : params.data.attendanceauto === 'ABSENT' ? '#462929' : params.data.attendanceauto === "WEEKOFF" ? 'white' : '#052106',
                                    backgroundColor: params.data.attendanceauto === 'HOLIDAY' ? '#B6FFFA' : params.data.attendanceauto === "ABSENT" ? '#ff00007d' : params.data.attendanceauto === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                }
                            }}
                        >
                            {params.data.attendanceauto}
                        </Button>
                    </Grid >
                );
            },
        },
        {
            field: "daystatus", headerName: "Day Status", flex: 0, width: 200, hide: !columnVisibilityView.daystatus,
            cellRenderer: (params) => {
                return (
                    <Grid>
                        <Button size="small"
                            sx={{
                                marginTop: '10px',
                                textTransform: 'capitalize',
                                borderRadius: '4px',
                                boxShadow: 'none',
                                fontFamily: 'Roboto,"Helvetica","Arial",sans-serif',
                                fontWeight: '400',
                                fontSize: '0.575rem',
                                lineHeight: '1.43',
                                letterSpacing: '0.01071em',
                                display: 'flex',
                                padding: '3px 8px',
                                cursor: 'default',
                                color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                                backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                '&:hover': {
                                    color: params.data.daystatus === 'HOLIDAY' ? 'black' : params.data.daystatus === 'ABSENT' ? '#462929' : params.data.daystatus === "WEEKOFF" ? 'white' : '#052106',
                                    backgroundColor: params.data.daystatus === 'HOLIDAY' ? '#B6FFFA' : params.data.daystatus === "ABSENT" ? '#ff00007d' : params.data.daystatus === "WEEKOFF" ? '#6b777991' : 'rgb(156 239 156)',
                                }
                            }}
                        >
                            {params.data.daystatus}
                        </Button>
                    </Grid >
                );
            },
        },
        { field: "appliedthrough", headerName: "Applied Through", flex: 0, width: 120, hide: !columnVisibilityView.appliedthrough, },
        { field: "isweekoff", headerName: "Is Week Off", flex: 0, width: 120, hide: !columnVisibilityView.isweekoff, },
        { field: "isholiday", headerName: "Is Holiday", flex: 0, width: 120, hide: !columnVisibilityView.isholiday, },
        { field: "lopcalculation", headerName: "LOP Calculation", flex: 0, width: 120, hide: !columnVisibilityView.lopcalculation, },
        { field: "modetarget", headerName: "Target", flex: 0, width: 120, hide: !columnVisibilityView.modetarget, },
        { field: "paidpresent", headerName: "Paid Present", flex: 0, width: 120, hide: !columnVisibilityView.paidpresent, },
        { field: "lopday", headerName: "LOP Day", flex: 0, width: 120, hide: !columnVisibilityView.lopday, },
        { field: "paidpresentday", headerName: "Paid Present Day", flex: 0, width: 120, hide: !columnVisibilityView.paidpresentday, },
    ];

    // Datatable
    const handleSearchChange = (e) => {
        const value = e.target.value;
        setSearchQueryUserShiftSummaryHier(value);
        applyNormalFilterUserShiftSummaryHier(value);
        setFilteredRowDataUserShiftSummaryHier([]);
    };

    const applyNormalFilterUserShiftSummaryHier = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttSummaryHier?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsUserShiftSummaryHier(filtered);
        setPageUserShiftSummaryHier(1);
    };

    const applyAdvancedFilterUserShiftSummaryHier = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttSummaryHier?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsUserShiftSummaryHier(filtered);
        setAdvancedFilterUserShiftSummaryHier(filters);
        // handleCloseSearchUserShiftSummaryHier(); 
    };

    // Undo filter funtion
    const handleResetSearchUserShiftSummaryHier = () => {
        setAdvancedFilterUserShiftSummaryHier(null);
        setSearchQueryUserShiftSummaryHier("");
        setFilteredDataItemsUserShiftSummaryHier(userShiftsUserShiftSummaryHier);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayUserShiftSummaryHier = () => {
        if (advancedFilterUserShiftSummaryHier && advancedFilterUserShiftSummaryHier.length > 0) {
            return advancedFilterUserShiftSummaryHier.map((filter, index) => {
                let showname = columnDataTableUserShiftSummaryHier.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterUserShiftSummaryHier.length > 1 ? advancedFilterUserShiftSummaryHier[1].condition : '') + ' ');
        }
        return searchQueryUserShiftSummaryHier;
    };

    const handlePageSizeChangeUserShiftSummaryHier = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeUserShiftSummaryHier(newSize);
        if (gridApiUserShiftSummaryHier) {
            gridApiUserShiftSummaryHier.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsUserShiftSummaryHier = () => {
        const updatedVisibility = { ...columnVisibilityUserShiftSummaryHier };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityUserShiftSummaryHier(updatedVisibility);
    };

    const handleShowAllColumnsView = () => {
        const updatedVisibilityView = { ...columnVisibilityView };
        for (const columnKey in updatedVisibilityView) {
            updatedVisibilityView[columnKey] = true;
        }
        setColumnVisibilityView(updatedVisibilityView);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibilityUserShiftSummaryHier");
        if (savedVisibility) {
            setColumnVisibilityUserShiftSummaryHier(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibilityUserShiftSummaryHier", JSON.stringify(columnVisibilityUserShiftSummaryHier));
    }, [columnVisibilityUserShiftSummaryHier]);

    // Function to filter columns based on search query
    const filteredColumns = columnDataTableUserShiftSummaryHier.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageUserShiftSummaryHier.toLowerCase())
    );

    const filteredColumnsView = columnDataTableView.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageViewHier.toLowerCase())
    );

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibilityUserShiftSummaryHier = (field) => {
        if (!gridApiUserShiftSummaryHier) return;

        setColumnVisibilityUserShiftSummaryHier((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiUserShiftSummaryHier.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const toggleColumnVisibilityView = (field) => {
        setColumnVisibilityView((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    const handleColumnMovedUserShiftSummaryHier = useCallback(debounce((event) => {
        if (!event.columnApiUserShiftSummaryHier) return;

        const visible_columns = event.columnApiUserShiftSummaryHier.getAllColumns().filter(col => {
            const colState = event.columnApiUserShiftSummaryHier.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityUserShiftSummaryHier((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleUserShiftSummaryHier = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityUserShiftSummaryHier((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormat, setFormat] = useState('');
    let exportColumnNamescrtUserShiftSummaryHier = [
        "Date", "Total Employees", "Total Current Shift", "Present", "Absent", "Total In", "Total Out", "Total Pending", "Facility Present", "WFH Present", "Facility Absent", "WFH Absent", "Early - ClockIn", "On - Present", "Grace - ClockIn", "Late - ClockIn", "Week Off", "Holiday",
        "Permission", "CL/SL", "On - ClockOut", "Early - ClockOut", "Over - ClockOut", "Auto - ClockOut", "Shift Not Started", "No Status", "Not Allotted", "Weekoff Present", "Long Leave & Long Absent", "BL Absent", "Double Day Absent", "Weekoff Absent",
    ]
    let exportRowValuescrtUserShiftSummaryHier = [
        'date', 'totalemployees', 'totalcurrentshift', 'paidpresentday', 'lopcount', 'totalin', 'totalout', 'totalpending', 'facilitypresent', 'wfhpresent', 'facilityabsent', 'wfhabsent', 'earlyclockin', 'onpresent', 'graceclockin', 'lateclockin', 'weekoff', 'holidayCount',
        'permissionCount', 'clsl', 'onclockout', 'earlyclockout', 'overclockout', 'autoclockout', 'shiftnotstarted', 'nostatus', 'notallotted', 'weekoffpresent', 'longleaveabsent', 'blabsent', 'doubledayabsent', 'weekoffabsent',
    ]

    let exportColumnNamesView = ["Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department",
        "Date", "Shift Mode", "Shift", "Change Shift", "Leave Status", "Permission Status", "ClockIn", "ClockInStatus", "ClockOut", "ClockOutStatus", "Attendance",
        "Day Status", "Applied Through", "Is Week Off", "Is Holiday", "LOP Calculation", "Target", "Paid Present", "LOP Day", "Paid Present Day",];
    let exportRowValuesView = ['empcode', 'username', 'company', 'branch', 'unit', 'team', 'department', 'date', 'shiftmode', 'shift', 'changeshift', 'leavestatus', 'permissionstatus', 'clockin', 'clockinstatus',
        'clockout', 'clockoutstatus', 'attendanceauto', 'daystatus', 'appliedthrough', 'isweekoff', 'isholiday', 'lopcalculation', 'modetarget', 'paidpresent', 'lopday', 'paidpresentday',];

    // print...
    const componentRefUserShiftSummaryHier = useRef();
    const handleprintUserShiftSummaryHier = useReactToPrint({
        content: () => componentRefUserShiftSummaryHier.current,
        documentTitle: "Team Attendance Summary Report - Hierarchy",
        pageStyle: "print",
    });

    const componentRefView = useRef();
    const handleprintView = useReactToPrint({
        content: () => componentRefView.current,
        documentTitle: `${tableNameHier}`,
        pageStyle: "print",
    });

    // image
    const handleCaptureImageUserShiftSummaryHier = () => {
        if (gridRefImageUserShiftSummaryHier.current) {
            domtoimage.toBlob(gridRefImageUserShiftSummaryHier.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Summary Report - Hierarchy.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    const handleCaptureImageView = () => {
        if (gridRefTableImgView.current) {
            domtoimage.toBlob(gridRefTableImgView.current)
                .then((blob) => {
                    saveAs(blob, `${tableNameHier}.png`);
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // image view
    const handleCaptureImageViewPopupHier = () => {
        if (gridRefImageUserShiftSummaryViewPopupHier.current) {
            domtoimage.toBlob(gridRefImageUserShiftSummaryViewPopupHier.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Summary Report - Hierarchy.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    const addSerialNumberView = (datas) => {
        setItemsViewHier(datas);
    };

    useEffect(() => {
        addSerialNumberView(viewDataHier);
    }, [viewDataHier]);

    const handlePageSizeChangeView = (event) => {
        setPageSizeViewHier(Number(event.target.value));
        setPageViewHier(1);
    };

    // Pagination for outer filter
    const filteredDataUserShiftSummaryHier = filteredDataItemsUserShiftSummaryHier?.slice((pageUserShiftSummaryHier - 1) * pageSizeUserShiftSummaryHier, pageUserShiftSummaryHier * pageSizeUserShiftSummaryHier);
    const totalPagesUserShiftSummaryHierOuter = Math.ceil(filteredDataItemsUserShiftSummaryHier?.length / pageSizeUserShiftSummaryHier);
    const visiblePages = Math.min(totalPagesUserShiftSummaryHierOuter, 3);
    const firstVisiblePage = Math.max(1, pageUserShiftSummaryHier - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesUserShiftSummaryHierOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageUserShiftSummaryHier * pageSizeUserShiftSummaryHier;
    const indexOfFirstItem = indexOfLastItem - pageSizeUserShiftSummaryHier;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

    // Split the search query into individual terms
    const searchTermsView = searchQueryViewHier.toLowerCase().split(" ");
    // Modify the filtering logic to check each term
    const filteredDatasView = itemsViewHier?.filter((item) => {
        return searchTermsView.every((term) =>
            Object.values(item).join(" ").toLowerCase().includes(term)
        );
    });

    const filteredDataView = filteredDatasView?.slice((pageViewHier - 1) * pageSizeViewHier, pageViewHier * pageSizeViewHier);
    const totalPagesView = Math.ceil(filteredDatasView.length / pageSizeViewHier);
    const visiblePagesView = Math.min(totalPagesView, 3);
    const firstVisiblePageView = Math.max(1, pageViewHier - 1);
    const lastVisiblePageView = Math.min(firstVisiblePageView + visiblePagesView - 1, totalPagesView);
    const pageNumbersView = [];
    const indexOfLastItemView = pageViewHier * pageSizeViewHier;
    const indexOfFirstItemView = indexOfLastItemView - pageSizeViewHier;
    for (let i = firstVisiblePageView; i <= lastVisiblePageView; i++) {
        pageNumbersView.push(i);
    }

    const rowDataTableView = filteredDataView.map((item, index) => {
        return {
            ...item,
        };
    });

    return (
        <Box>
            {isUserRoleCompare?.includes("lteamattendanceoverallreport") && (
                <>
                    {/* ****** Table Start ****** */}
                    {filterUser.attmode === 'Attendance Summary Report - Hierarchy' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <ScrollingText text="Total counts may mismatch if employees have a double shift." />
                            </Grid>
                            <Grid container spacing={1} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeUserShiftSummaryHier}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeUserShiftSummaryHier}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsUserShiftSummaryHier?.length}>  All </MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}  >
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenUserShiftSummaryHier(true)
                                                    setFormat("xl")
                                                }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenUserShiftSummaryHier(true)
                                                    setFormat("csv")
                                                }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintUserShiftSummaryHier}> &ensp;  <FaPrint /> &ensp;Print&ensp; </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenUserShiftSummaryHier(true)
                                                    }}
                                                ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleCaptureImageUserShiftSummaryHier}> <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp; </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterUserShiftSummaryHier && (
                                                        <IconButton onClick={handleResetSearchUserShiftSummaryHier}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchUserShiftSummaryHier} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayUserShiftSummaryHier()}
                                            onChange={handleSearchChange}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterUserShiftSummaryHier}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid><br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsUserShiftSummaryHier}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsUserShiftSummaryHier}> Manage Columns  </Button><br /><br />
                            {loader ?
                                <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box> :
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageUserShiftSummaryHier} >
                                        <AgGridReact
                                            rowData={filteredDataItemsUserShiftSummaryHier}
                                            columnDefs={columnDataTableUserShiftSummaryHier.filter((column) => columnVisibilityUserShiftSummaryHier[column.field])}
                                            ref={gridRefTableUserShiftSummaryHier}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSizeSelector={[]}
                                            paginationPageSize={pageSizeUserShiftSummaryHier}
                                            onPaginationChanged={onPaginationChanged}
                                            onGridReady={onGridReadyUserShiftSummaryHier}
                                            onColumnMoved={handleColumnMovedUserShiftSummaryHier}
                                            onColumnVisible={handleColumnVisibleUserShiftSummaryHier}
                                            onFilterChanged={onFilterChangedUserShiftSummaryHier}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            } {/* ****** Table End ****** */}
                        </Box>
                    ) : null}
                </>
            )
            }

            {/* View model */}
            <Dialog
                open={openviewHier}
                onClose={handleClickOpenviewHier}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="lg" fullWidth
                scroll="paper"
                sx={{ marginTop: '95px' }}
            >
                <Box sx={{ padding: "20px 20px" }}>
                    <Grid container spacing={2}>
                        <Grid item xs={11}>
                            <ScrollingTextView text="Total counts may mismatch if employees have a double shift." tableNameHier={tableNameHier} />
                        </Grid>
                        <Grid item md={1} sx={6} xs={12}>
                            <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseviewHier}>{" "}Back{" "}</Button>
                        </Grid>
                    </Grid><br />
                    <Box>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSizeViewHier}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeView}
                                        sx={{ width: "77px" }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={viewDataHier?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                <Box>
                                    {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenViewHier(true); setFormat("xl"); }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("csvteamattendanceoverallreport") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenViewHier(true); setFormat("csv"); }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintView}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={() => { setIsPdfFilterOpenViewHier(true); }}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImageView}><ImageIcon sx={{ fontSize: "15px" }} />{" "}&ensp;Image&ensp;</Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <Box>
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTableView}
                                        setItems={setItemsViewHier}
                                        addSerialNumber={addSerialNumberView}
                                        setPage={setPageViewHier}
                                        maindatas={viewDataHier}
                                        setSearchedString={setSearchedStringViewHier}
                                        searchQuery={searchQueryViewHier}
                                        setSearchQuery={setSearchQueryViewHier}
                                        paginated={false}
                                        totalDatas={viewDataHier}
                                    />
                                </Box>
                            </Grid>
                        </Grid><br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsView}>Show All Columns</Button>&ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsViewHier}>Manage Columns</Button><br /><br />
                        {loaderViewHier ? (
                            <>
                                <Box sx={{ display: "flex", justifyContent: "center" }}>
                                    <ThreeDots
                                        height="80"
                                        width="80"
                                        radius="9"
                                        color="#1976d2"
                                        ariaLabel="three-dots-loading"
                                        wrapperStyle={{}}
                                        wrapperClassName=""
                                        visible={true}
                                    />
                                </Box>
                            </>
                        ) : (
                            <>
                                <AggridTable
                                    rowDataTable={rowDataTableView}
                                    columnDataTable={columnDataTableView}
                                    columnVisibility={columnVisibilityView}
                                    page={pageViewHier}
                                    setPage={setPageViewHier}
                                    pageSize={pageSizeViewHier}
                                    totalPages={totalPagesView}
                                    setColumnVisibility={setColumnVisibilityView}
                                    isHandleChange={isHandleChangeViewHier}
                                    items={itemsViewHier}
                                    gridRefTable={gridRefTableView}
                                    paginated={false}
                                    filteredDatas={filteredDatasView}
                                    // totalDatas={totalDatasView}
                                    selectedRows={selectedRowsViewHier}
                                    setSelectedRows={setSelectedRowsViewHier}
                                    searchQuery={searchedStringViewHier}
                                    handleShowAllColumnsUserShiftSummaryHier={handleShowAllColumnsView}
                                    setFilteredRowData={setFilteredRowDataViewHier}
                                    filteredRowData={filteredRowDataViewHier}
                                    setFilteredChanges={setFilteredChangesViewHier}
                                    filteredChanges={filteredChangesViewHier}
                                    gridRefTableImg={gridRefTableImgView}
                                    itemsList={viewDataHier}
                                />
                            </>
                        )}
                    </Box>
                </Box>
            </Dialog>

            {/* History model */}
            <Dialog
                open={openHistoryviewHier}
                onClose={handleClickOpenHistoryviewHier}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="lg" fullWidth
                scroll="paper"
                sx={{ marginTop: '95px' }}
            >
                <Box sx={{ padding: "20px 20px" }}>
                    <Grid container spacing={2}>
                        <Grid item xs={10}>
                            <Typography sx={userStyle.HeaderText}><b>{'Attendance Status History'}</b></Typography>
                        </Grid>
                        <Grid item md={1} sm={6} xs={12} >
                            <Button sx={{
                                display: 'flex', justifyContent: 'center',
                                background: 'rgb(60 181 170)',
                                color: "white",
                                boxShadow: "none",
                                borderRadius: "3px",
                                padding: "4px 6px",
                                height: '38px',
                                "&:hover": {
                                    backgroundColor: "rgb(60 181 170)", color: "white",
                                },
                            }} onClick={handleCaptureImageViewPopupHier}> <ImageIcon sx={{ fontSize: "14px" }} />Copy</Button>
                        </Grid>
                        <Grid item md={1} sx={6} xs={12}>
                            <Button variant="contained" sx={buttonStyles.btncancel} onClick={handleCloseHistoryviewHier}>{" "}Back{" "}</Button>
                        </Grid>
                    </Grid><br />
                    <Box ref={gridRefImageUserShiftSummaryViewPopupHier}>
                        <Grid container spacing={2}>
                            <Grid item xs={12}>
                                <Typography sx={userStyle.SubHeaderText}><b>{`Attendance Status As On (${formatCustomDateTime(currentServerTimeHier)})`}</b></Typography>
                            </Grid>
                            <Grid item md={12} sm={12} xs={12}>
                                <Typography sx={userStyle.SubHeaderText}><b>{`Attendance summary of: Date: ${historyViewDataHier.date}`}</b></Typography>
                            </Grid>
                        </Grid><br />
                        <Grid container spacing={2}>
                            <Grid item md={1}></Grid>
                            {/* left side */}
                            <Grid item md={4} sm={12} xs={12}>
                                <Grid container spacing={1}>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.totalemployees}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Strength"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.totalcurrentshift}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Current Shift"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.paidpresentday}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.lopcount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.totalin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Total In"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #397bd4',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.totalout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#397bd4' }}>{"Total No. Total Out"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#397bd4',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.totalpending}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Pending"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.facilitypresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Facility Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.wfhpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. WFH Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.facilityabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Facility Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.wfhabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. WFH Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.earlyclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#84c358' }}>{"Total No. Early-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.onpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. On-Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.graceclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Grace-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.lateclockin}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Late-Clockin"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.weekoff}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Week Off"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={1}></Grid>
                            {/* rigth side */}
                            <Grid item md={4} sm={12} xs={12} >
                                <Grid container spacing={1}>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.holidayCount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Holiday"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.permissionCount}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Permission"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.clsl}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. CL/SL"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.onclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. On-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.earlyclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Early-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.overclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Over-Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.autoclockout}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Auto-Mis Clockout"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.shiftnotstarted}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. Shift Not Started"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.nostatus}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. No Status"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.notallotted}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Not Allotted"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #86c257',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.weekoffpresent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#86c257' }}>{"Total No. Weekoff Present"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#86c257',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ffa32c',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.longleaveabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ffa32c' }}>{"Total No. Long Leave & Long Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ffa32c',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #ff5c4b',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.blabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#ff5c4b' }}>{"Total No. BL-Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#ff5c4b',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #8a69fe',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.doubledayabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#8a69fe' }}>{"Total No. Double Day Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#8a69fe',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                    <Grid item md={12} sm={12} xs={12}>
                                        <Box sx={overallBoxStyle}>
                                            <Box sx={{
                                                position: 'absolute',
                                                top: '50%',
                                                left: 0,
                                                transform: 'translate(-50%, -50%)',
                                                width: 50,
                                                height: 50,
                                                borderRadius: '50%',
                                                border: '6px solid #00bbce',
                                                backgroundColor: '#fff',
                                                display: 'flex',
                                                alignItems: 'center',
                                                justifyContent: 'center',
                                                fontSize: 18,
                                                fontWeight: 'bold',
                                                color: '#333',
                                                zIndex: 1,
                                            }}>{historyViewDataHier.weekoffabsent}</Box>
                                            <Box><Typography variant="subtitle1" sx={{ fontWeight: 'bold', color: '#00bbce' }}>{"Total No. Weekoff Absent"}</Typography></Box>
                                            <Box sx={{
                                                width: 8,
                                                height: '70%',
                                                backgroundColor: '#00bbce',
                                                position: 'absolute',
                                                right: '-8px',
                                                top: '15%',
                                                borderTopRightRadius: '6px',
                                                borderBottomRightRadius: '6px',
                                            }} />
                                        </Box>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={2}></Grid>
                        </Grid>
                    </Box>
                </Box>
            </Dialog>

            {/* Manage Column */}
            <Popover
                id={idManageColumnsUserShiftSummaryHier}
                open={isManageColumnsOpenUserShiftSummaryHier}
                anchorEl={anchorElUserShiftSummaryHier}
                onClose={handleCloseManageColumnsUserShiftSummaryHier}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsUserShiftSummaryHier}
                    searchQuery={searchQueryManageUserShiftSummaryHier}
                    setSearchQuery={setSearchQueryManageUserShiftSummaryHier}
                    filteredColumns={filteredColumns}
                    columnVisibility={columnVisibilityUserShiftSummaryHier}
                    toggleColumnVisibility={toggleColumnVisibilityUserShiftSummaryHier}
                    setColumnVisibility={setColumnVisibilityUserShiftSummaryHier}
                    initialColumnVisibility={initialColumnVisibilityUserShiftSummaryHier}
                    columnDataTable={columnDataTableUserShiftSummaryHier}
                />
            </Popover>

            {/* Manage Column */}
            <Popover
                id={idViewHier}
                open={isManageColumnsOpenViewHier}
                anchorEl={anchorElViewHier}
                onClose={handleCloseManageColumnsViewHier}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsViewHier}
                    searchQuery={searchQueryManageViewHier}
                    setSearchQuery={setSearchQueryManageViewHier}
                    filteredColumns={filteredColumnsView}
                    columnVisibility={columnVisibilityView}
                    toggleColumnVisibility={toggleColumnVisibilityView}
                    setColumnVisibility={setColumnVisibilityView}
                    initialColumnVisibility={initialColumnVisibilityView}
                    columnDataTable={columnDataTableView}
                />
            </Popover>

            {/* Search Bar */}
            <Popover
                id={idSearchUserShiftSummaryHier}
                open={openSearchUserShiftSummaryHier}
                anchorEl={anchorElSearchUserShiftSummaryHier}
                onClose={handleCloseSearchUserShiftSummaryHier}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <AdvancedSearchBar columns={columnDataTableUserShiftSummaryHier} onSearch={applyAdvancedFilterUserShiftSummaryHier} initialSearchValue={searchQueryUserShiftSummaryHier} handleCloseSearch={handleCloseSearchUserShiftSummaryHier} />
            </Popover>

            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenUserShiftSummaryHier}
                handleCloseFilterMod={handleCloseFilterModUserShiftSummaryHier}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenUserShiftSummaryHier}
                isPdfFilterOpen={isPdfFilterOpenUserShiftSummaryHier}
                setIsPdfFilterOpen={setIsPdfFilterOpenUserShiftSummaryHier}
                handleClosePdfFilterMod={handleClosePdfFilterModUserShiftSummaryHier}
                filteredDataTwo={(filteredRowDataUserShiftSummaryHier.length > 0 ? filteredRowDataUserShiftSummaryHier : filteredDataUserShiftSummaryHier) ?? []}
                itemsTwo={itemsAttSummaryHier ?? []}
                filename={"Team Attendance Summary Report - Hierarchy"}
                exportColumnNames={exportColumnNamescrtUserShiftSummaryHier}
                exportRowValues={exportRowValuescrtUserShiftSummaryHier}
                componentRef={componentRefUserShiftSummaryHier}
            />
            <ExportData
                isFilterOpen={isFilterOpenViewHier}
                handleCloseFilterMod={handleCloseFilterModViewHier}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenViewHier}
                isPdfFilterOpen={isPdfFilterOpenViewHier}
                setIsPdfFilterOpen={setIsPdfFilterOpenViewHier}
                handleClosePdfFilterMod={handleClosePdfFilterModViewHier}
                filteredDataTwo={(filteredChangesViewHier !== null ? filteredRowDataViewHier : rowDataTableView) ?? []}
                itemsTwo={viewDataHier ?? []}
                filename={tableNameHier}
                exportColumnNames={exportColumnNamesView}
                exportRowValues={exportRowValuesView}
                componentRef={componentRefView}
            />
        </Box >
    );
}

export default TeamAttSummaryHierarchyList;