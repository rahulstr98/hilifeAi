import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from 'react';
import { FaFileExcel, FaFileCsv, FaPrint, FaFilePdf, FaUndoAlt, FaSearch } from 'react-icons/fa';
import { Box, Typography, OutlinedInput, Select, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Button, Popover, IconButton, InputAdornment, Tooltip } from '@mui/material';
import { userStyle, colourStyles } from '../../../pageStyle';
import { StyledTableCell } from '../../../components/Table';
import jsPDF from 'jspdf';
import 'jspdf-autotable';

import axios from '../../../axiosInstance';
import { SERVICE } from '../../../services/Baseservice';
import { handleApiError } from '../../../components/Errorhandling';
import { useReactToPrint } from 'react-to-print';
import moment from 'moment';
import { UserRoleAccessContext, AuthContext } from '../../../context/Appcontext';
import { ThreeDots } from 'react-loader-spinner';
import Selects from 'react-select';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import NavigateBeforeIcon from '@mui/icons-material/NavigateBefore';
import LastPageIcon from '@mui/icons-material/LastPage';
import FirstPageIcon from '@mui/icons-material/FirstPage';
import { saveAs } from 'file-saver';
import Switch from '@mui/material/Switch';
import CloseIcon from '@mui/icons-material/Close';
import ImageIcon from '@mui/icons-material/Image';
import { DeleteConfirmation } from '../../../components/DeleteConfirmation.js';
import { IoMdOptions } from 'react-icons/io';
import { MdClose } from 'react-icons/md';
import domtoimage from 'dom-to-image';
import { AgGridReact } from 'ag-grid-react';
import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import ExportData from '../../../components/ExportData';
import MessageAlert from '../../../components/MessageAlert';
import AlertDialog from '../../../components/Alert';
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from '../../../components/ManageColumn';
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function AttendanceModeBulkUpdateRemoveListTable({ allUsersBulkUpdateRemove, bulkUpdateRemoveApply, fetchFilteredUsersStatus, filteredDataItemsBulkUpdateRemoveList, setFilteredDataItemsBulkUpdateRemoveList }) {
    const gridRefTableBulkUpdateRemoveList = useRef(null);
    const gridRefImageBulkUpdateRemoveList = useRef(null);
    const { auth } = useContext(AuthContext);
    const { isUserRoleCompare, pageName, setPageName, buttonStyles } = useContext(UserRoleAccessContext);
    const [itemsSetTable, setItemsSetTable] = useState([]);
    const [shiftRoasterAdjStatusEdit, setShiftRoasterAdjStatusEdit] = useState({});

    // State to track advanced filter
    const [advancedFilterBulkUpdateRemoveList, setAdvancedFilterBulkUpdateRemoveList] = useState(null);
    const [gridApiBulkUpdateRemoveList, setGridApiBulkUpdateRemoveList] = useState(null);
    const [columnApiBulkUpdateRemoveList, setColumnApiBulkUpdateRemoveList] = useState(null);
    const [filteredRowDataBulkUpdateRemoveList, setFilteredRowDataBulkUpdateRemoveList] = useState([]);

    // Datatable Set Table
    const [pageBulkUpdateRemoveList, setPageBulkUpdateRemoveList] = useState(1);
    const [pageSizeBulkUpdateRemoveList, setPageSizeBulkUpdateRemoveList] = useState(10);
    const [searchQueryBulkUpdateRemoveList, setSearchQuerBulkUpdateRemoveList] = useState('');
    const [totalPagesBulkUpdateRemoveList, setTotalPagesBulkUpdateRemoveList] = useState(1);

    const [isFilterOpenBulkUpdateRemoveList, setIsFilterOpenBulkUpdateRemoveList] = useState(false);
    const [isPdfFilterOpenBulkUpdateRemoveList, setIsPdfFilterOpenBulkUpdateRemoveList] = useState(false);
    // page refersh reload
    const handleCloseFilterModBulkUpdateRemoveList = () => {
        setIsFilterOpenBulkUpdateRemoveList(false);
    };
    const handleClosePdfFilterModBulkUpdateRemoveList = () => {
        setIsPdfFilterOpenBulkUpdateRemoveList(false);
    };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState('');
    const [popupSeverityMalert, setPopupSeverityMalert] = useState('');
    const handleClickOpenPopupMalert = () => {
        setOpenPopupMalert(true);
    };
    const handleClosePopupMalert = () => {
        setOpenPopupMalert(false);
    };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState('');
    const [popupSeverity, setPopupSeverity] = useState('');
    const handleClickOpenPopup = () => {
        setOpenPopup(true);
    };
    const handleClosePopup = () => {
        setOpenPopup(false);
    };

    //Delete model
    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    const handleClickOpen = () => {
        setIsDeleteOpen(true);
    };
    const handleCloseMod = () => {
        setIsDeleteOpen(false);
    };

    // Manage Columns
    const [searchQueryManageBulkUpdateRemoveList, setSearchQueryManageBulkUpdateRemoveList] = useState('');
    const [isManageColumnsOpenBulkUpdateRemoveList, setManageColumnsOpenBulkUpdateRemoveList] = useState(false);
    const [anchorElBulkUpdateRemoveList, setAnchorElBulkUpdateRemoveList] = useState(null);

    const handleOpenManageColumnsBulkUpdateRemoveList = (event) => {
        setAnchorElBulkUpdateRemoveList(event.currentTarget);
        setManageColumnsOpenBulkUpdateRemoveList(true);
    };
    const handleCloseManageColumnsBulkUpdateRemoveList = () => {
        setManageColumnsOpenBulkUpdateRemoveList(false);
        setSearchQueryManageBulkUpdateRemoveList('');
    };

    const openBulkUpdateRemoveList = Boolean(anchorElBulkUpdateRemoveList);
    const idBulkUpdateRemoveList = openBulkUpdateRemoveList ? 'simple-popover' : undefined;

    // Search bar
    const [anchorElSearchBulkUpdateRemoveList, setAnchorElSearchBulkUpdateRemoveList] = React.useState(null);
    const handleClickSearchBulkUpdateRemoveList = (event) => {
        setAnchorElSearchBulkUpdateRemoveList(event.currentTarget);
    };
    const handleCloseSearchBulkUpdateRemoveList = () => {
        setAnchorElSearchBulkUpdateRemoveList(null);
        setSearchQuerBulkUpdateRemoveList('');
    };

    const openSearchBulkUpdateRemoveList = Boolean(anchorElSearchBulkUpdateRemoveList);
    const idSearchBulkUpdateRemoveList = openSearchBulkUpdateRemoveList ? 'simple-popover' : undefined;

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    };

    // Show All Columns & Manage Columns
    const initialColumnVisibilityBulkUpdateRemoveList = {
        serialNumber: true,
        empcode: true,
        username: true,
        fromdate: true,
        todate: true,
        mode: true,
        updatedusername: true,
        updateddatetime: true,
        actions: true,
    };

    const [columnVisibilityBulkUpdateRemoveList, setColumnVisibilityBulkUpdateRemoveList] = useState(initialColumnVisibilityBulkUpdateRemoveList);

    useEffect(() => {
        setFilteredDataItemsBulkUpdateRemoveList(allUsersBulkUpdateRemove);
    }, []);

    // page refersh reload code
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ''; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener('beforeunload', beforeUnloadHandler);
        return () => {
            window.removeEventListener('beforeunload', beforeUnloadHandler);
        };
    }, []);

    const [userOuterId, setUserOuterId] = useState('');
    const [bulkUpdateRemoveListInnerId, setBulkUpdateRemoveListInnterId] = useState('');
    const getCodeForDelete = (e, attModeId) => {
        setUserOuterId(e);
        setBulkUpdateRemoveListInnterId(attModeId);
        handleClickOpen();
    };

    const deleteShiftMode = async () => {
        setPageName(!pageName);
        try {
            await axios.post(SERVICE.USERS_ATTENDANCE_MODE_DELETE, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                outerId: userOuterId,
                innerId: bulkUpdateRemoveListInnerId,
            });
            await fetchFilteredUsersStatus();
            handleCloseMod();
            setPageBulkUpdateRemoveList(1);
            setPopupContent('Undone Successfully');
            setPopupSeverity('success');
            handleClickOpenPopup();
        } catch (err) {
            handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
        }
    };

    const addSerialNumberSetTable = () => {
        const itemsWithSerialNumber = allUsersBulkUpdateRemove?.map((item, index) => ({
            ...item,
            serialNumber: index + 1,
            id: item._id,
            bulkUpdateRemoveApplydate: item.adjstatus === 'Not Allotted' ? moment(item.removedondate).format('DD-MM-YYYY') + ' ' + item.removedontime : moment(item.bulkUpdateRemoveApplydate).format('DD-MM-YYYY') + ' ' + item.bulkUpdateRemoveApplytime,
            reason: item.adjchangereason,
            adjustmenttype: item.adjstatus === 'Not Allotted' ? 'Not Allotted' : item.adjustmenttype,
            adjstatus: item.adjstatus === 'Not Allotted' ? 'Not Allotted' : item.adjstatus === 'Approved' ? 'Approved' : item.adjstatus === 'Reject' ? 'Reject' : 'Not Approved',
            request:
                item.adjstatus === 'Not Allotted'
                    ? `Not Allotted : ${item.adjdate}`
                    : item.adjustmenttype === 'Shift Weekoff Swap'
                        ? `Allot Weekoff Date : ${item.adjdate} Swap To : ${item.todate} Shift : Weekoff Request Shift 1st : ${item.adjchangeshiftime}`
                        : item.adjustmenttype === 'WeekOff Adjustment'
                            ? `Week off Date : ${item.adjdate} Adjustment For : ${item.todate} Shift : ${item.selectedShifTime} Request Shift 1st : ${item.adjchangeshiftime}`
                            : item.adjustmenttype === 'Shift Adjustment'
                                ? `Date : ${item.selectedDate} Shift : ${item.selectedShifTime} Adjustment to : ${item.adjdate} 2nd : ${item.pluseshift}`
                                : `${item.adjustmenttype} : ${item.adjdate}`,
        }));
        setItemsSetTable(itemsWithSerialNumber);
        setFilteredDataItemsBulkUpdateRemoveList(itemsWithSerialNumber);
    };

    useEffect(() => {
        addSerialNumberSetTable();
    }, [allUsersBulkUpdateRemove]);

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ['apply', 'reset', 'cancel'],
            },
        };
    }, []);

    const onGridReadyBulkUpdateRemoveList = useCallback((params) => {
        setGridApiBulkUpdateRemoveList(params.api);
        setColumnApiBulkUpdateRemoveList(params.columnApiBulkUpdateRemoveList);
    }, []);

    // Function to handle filter changes
    const onFilterChangedBulkUpdateRemoveList = () => {
        if (gridApiBulkUpdateRemoveList) {
            const filterModel = gridApiBulkUpdateRemoveList.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataBulkUpdateRemoveList([]);
            } else {
                // Filters are active, capture filtered data
                const filteredDataBulkUpdateRemoveList = [];
                gridApiBulkUpdateRemoveList.forEachNodeAfterFilterAndSort((node) => {
                    filteredDataBulkUpdateRemoveList.push(node.data); // Collect filtered row data
                });
                setFilteredRowDataBulkUpdateRemoveList(filteredDataBulkUpdateRemoveList);
            }
        }
    };

    const onPaginationChangedBulkUpdateRemoveList = useCallback(() => {
        if (gridRefTableBulkUpdateRemoveList.current) {
            const gridApiBulkUpdateRemoveList = gridRefTableBulkUpdateRemoveList.current.api;
            const currentPage = gridApiBulkUpdateRemoveList.paginationGetCurrentPage() + 1;
            const totalPagesBulkUpdateRemoveList = gridApiBulkUpdateRemoveList.paginationGetTotalPages();
            setPageBulkUpdateRemoveList(currentPage);
            setTotalPagesBulkUpdateRemoveList(totalPagesBulkUpdateRemoveList);
        }
    }, []);

    const columnDataTableBulkUpdateRemoveList = [
        { field: 'serialNumber', headerName: 'SNo', flex: 0, width: 80, hide: !columnVisibilityBulkUpdateRemoveList.serialNumber, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'empcode', headerName: 'Emp Code', flex: 0, width: 150, hide: !columnVisibilityBulkUpdateRemoveList.empcode, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'username', headerName: 'Employee Name', flex: 0, width: 150, hide: !columnVisibilityBulkUpdateRemoveList.username, headerClassName: 'bold-header', pinned: 'left', lockPinned: true },
        { field: 'fromdate', headerName: 'From Date', flex: 0, width: 150, hide: !columnVisibilityBulkUpdateRemoveList.fromdate, headerClassName: 'bold-header' },
        { field: 'todate', headerName: 'To Date', flex: 0, width: 200, hide: !columnVisibilityBulkUpdateRemoveList.todate, headerClassName: 'bold-header' },
        { field: 'mode', headerName: 'Mode', flex: 0, width: 120, hide: !columnVisibilityBulkUpdateRemoveList.mode, headerClassName: 'bold-header' },
        { field: 'updatedusername', headerName: 'Updated User Name', flex: 0, width: 120, hide: !columnVisibilityBulkUpdateRemoveList.updatedusername, headerClassName: 'bold-header' },
        { field: 'updateddatetime', headerName: 'Updated Date Time', flex: 0, width: 120, hide: !columnVisibilityBulkUpdateRemoveList.updateddatetime, headerClassName: 'bold-header' },
        {
            field: 'actions',
            headerName: 'Action',
            flex: 0,
            width: 95,
            minHeight: '40px !important',
            filter: false,
            sortable: false,
            hide: !columnVisibilityBulkUpdateRemoveList.actions,
            headerClassName: 'bold-header',
            cellRenderer: (params) => {
                return (
                    <Grid sx={{ display: 'flex' }}>
                        {
                            isUserRoleCompare?.includes('dattendancemodebulkupdate') && (
                                <Button
                                    sx={{ marginTop: '10px' }}
                                    onClick={() => {
                                        getCodeForDelete(params.data.userid, params.data.id);
                                    }}
                                >
                                    <FaUndoAlt style={{ fontsize: 'large', marginLeft: '-12px' }} />
                                </Button>
                            )
                        }
                    </Grid>
                )
            },
        },
    ];

    // Datatable
    const handleSearchChangeBulkUpdateRemoveList = (e) => {
        const value = e.target.value;
        setSearchQuerBulkUpdateRemoveList(value);
        applyNormalFilterBulkUpdateRemoveList(value);
        setFilteredRowDataBulkUpdateRemoveList([]);
    };

    const applyNormalFilterBulkUpdateRemoveList = (searchValue) => {
        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(' ');

        // Modify the filtering logic to check each term
        const filtered = itemsSetTable?.filter((item) => {
            return searchTerms.every((term) => Object.values(item).join(' ').toLowerCase().includes(term));
        });
        setFilteredDataItemsBulkUpdateRemoveList(filtered);
        setPageBulkUpdateRemoveList(1);
    };

    const applyAdvancedFilterBulkUpdateRemoveList = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsSetTable?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case 'Contains':
                        match = itemValue.includes(filterValue);
                        break;
                    case 'Does Not Contain':
                        match = !itemValue?.includes(filterValue);
                        break;
                    case 'Equals':
                        match = itemValue === filterValue;
                        break;
                    case 'Does Not Equal':
                        match = itemValue !== filterValue;
                        break;
                    case 'Begins With':
                        match = itemValue.startsWith(filterValue);
                        break;
                    case 'Ends With':
                        match = itemValue.endsWith(filterValue);
                        break;
                    case 'Blank':
                        match = !itemValue;
                        break;
                    case 'Not Blank':
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === 'AND') {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsBulkUpdateRemoveList(filtered); // Update filtered data
        setAdvancedFilterBulkUpdateRemoveList(filters);
        // handleCloseSearchBulkUpdateRemoveList(); // Close the popover after search
    };

    // Undo filter funtion
    const handleResetSearchBulkUpdateRemoveList = () => {
        setAdvancedFilterBulkUpdateRemoveList(null);
        setSearchQuerBulkUpdateRemoveList('');
        setFilteredDataItemsBulkUpdateRemoveList(itemsSetTable);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayBulkUpdateRemoveList = () => {
        if (advancedFilterBulkUpdateRemoveList && advancedFilterBulkUpdateRemoveList.length > 0) {
            return advancedFilterBulkUpdateRemoveList
                .map((filter, index) => {
                    let showname = columnDataTableBulkUpdateRemoveList.find((col) => col.field === filter.column)?.headerName;
                    return `${showname} ${filter.condition} "${filter.value}"`;
                })
                .join(' ' + (advancedFilterBulkUpdateRemoveList.length > 1 ? advancedFilterBulkUpdateRemoveList[1].condition : '') + ' ');
        }
        return searchQueryBulkUpdateRemoveList;
    };

    const handlePageChangeBulkUpdateRemoveList = (newPage) => {
        if (newPage >= 1 && newPage <= totalPagesBulkUpdateRemoveList) {
            setPageBulkUpdateRemoveList(newPage);
            gridRefTableBulkUpdateRemoveList.current.api.paginationGoToPage(newPage - 1);
        }
    };

    const handlePageSizeChangeBulkUpdateRemoveList = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeBulkUpdateRemoveList(newSize);
        if (gridApiBulkUpdateRemoveList) {
            gridApiBulkUpdateRemoveList.paginationGetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsBulkUpdateRemoveList = () => {
        const updatedVisibility = { ...columnVisibilityBulkUpdateRemoveList };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityBulkUpdateRemoveList(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem('columnVisibilityBulkUpdateRemoveList');
        if (savedVisibility) {
            setColumnVisibilityBulkUpdateRemoveList(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem('columnVisibilityBulkUpdateRemoveList', JSON.stringify(columnVisibilityBulkUpdateRemoveList));
    }, [columnVisibilityBulkUpdateRemoveList]);

    // // Function to filter columns based on search query
    const filteredColumns = columnDataTableBulkUpdateRemoveList.filter((column) => column.headerName.toLowerCase().includes(searchQueryManageBulkUpdateRemoveList.toLowerCase()));

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibilityBulkUpdateRemoveList = (field) => {
        if (!gridApiBulkUpdateRemoveList) return;

        setColumnVisibilityBulkUpdateRemoveList((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiBulkUpdateRemoveList.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedBulkUpdateRemoveList = useCallback(
        debounce((event) => {
            if (!event.columnApiBulkUpdateRemoveList) return;

            const visible_columns = event.columnApiBulkUpdateRemoveList
                .getAllColumns()
                .filter((col) => {
                    const colState = event.columnApiBulkUpdateRemoveList.getColumnState().find((state) => state.colId === col.colId);
                    return colState && !colState.hide;
                })
                .map((col) => col.colId);

            setColumnVisibilityBulkUpdateRemoveList((prevVisibility) => {
                const updatedVisibility = { ...prevVisibility };

                // Ensure columns that are visible stay visible
                Object.keys(updatedVisibility).forEach((colId) => {
                    updatedVisibility[colId] = visible_columns.includes(colId);
                });

                return updatedVisibility;
            });
        }, 300),
        []
    );

    const handleColumnVisibleBulkUpdateRemoveList = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityBulkUpdateRemoveList((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormatBulkUpdateRemoveList, setFormatBulkUpdateRemoveList] = useState('');
    let exportColumnNamescrt = ['Emp Code', 'Employee Name', 'From Date', 'To Date', 'Mode', 'Updated User Name', 'Updated Date Time',];
    let exportRowValuescrt = ['username', 'empcode', 'fromdate', 'todate', 'mode', 'updatedusername', 'updateddatetime',];

    // print...
    const componentRefBulkUpdateRemoveList = useRef();
    const handleprintBulkUpdateRemoveList = useReactToPrint({
        content: () => componentRefBulkUpdateRemoveList.current,
        documentTitle: 'Attendance Mode Updated List',
        pageStyle: 'print',
    });

    // image
    const handleCaptureImageBulkUpdateRemoveList = () => {
        if (gridRefImageBulkUpdateRemoveList.current) {
            domtoimage
                .toBlob(gridRefImageBulkUpdateRemoveList.current)
                .then((blob) => {
                    saveAs(blob, 'Attendance Mode Updated List.png');
                })
                .catch((error) => {
                    console.error('dom-to-image error: ', error);
                });
        }
    };

    // Pagination for innter filter
    const getVisiblePageNumbers = () => {
        const pageNumbers = [];
        const maxVisiblePages = 3;

        const startPage = Math.max(1, pageSizeBulkUpdateRemoveList - 1);
        const endPage = Math.min(totalPagesBulkUpdateRemoveList, startPage + maxVisiblePages - 1);

        // Loop through and add visible pageSizeBulkUpdateRemoveList numbers
        for (let i = startPage; i <= endPage; i++) {
            pageNumbers.push(i);
        }

        // If there are more pages after the last visible pageSizeBulkUpdateRemoveList, show ellipsis
        if (endPage < totalPagesBulkUpdateRemoveList) {
            pageNumbers.push('...');
        }

        return pageNumbers;
    };

    // Pagination for outer filter
    const filteredDataBulkUpdateRemoveList = filteredDataItemsBulkUpdateRemoveList?.slice((pageBulkUpdateRemoveList - 1) * pageSizeBulkUpdateRemoveList, pageBulkUpdateRemoveList * pageSizeBulkUpdateRemoveList);
    const totalPagesBulkUpdateRemoveListOuter = Math.ceil(filteredDataItemsBulkUpdateRemoveList?.length / pageSizeBulkUpdateRemoveList);
    const visiblePages = Math.min(totalPagesBulkUpdateRemoveListOuter, 3);
    const firstVisiblePage = Math.max(1, pageBulkUpdateRemoveList - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesBulkUpdateRemoveListOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageBulkUpdateRemoveList * pageSizeBulkUpdateRemoveList;
    const indexOfFirstItem = indexOfLastItem - pageSizeBulkUpdateRemoveList;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
        pageNumbers.push(i);
    }

    return (
        <Box>
            {/* ****** Header Content ****** */}
            <Typography sx={userStyle.HeaderText}>Attendance Mode Updated List</Typography>

            {/* ****** Table Start ****** */}
            {isUserRoleCompare?.includes('lattendancemodebulkupdate') && (
                <>
                    <Box sx={userStyle.container}>
                        <Grid item xs={8}>
                            <Typography sx={userStyle.importheadtext}> Attendance Mode Updated List </Typography>
                        </Grid>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid container style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        size="small"
                                        id="pageSizeSelect"
                                        value={pageSizeBulkUpdateRemoveList}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeBulkUpdateRemoveList}
                                        sx={{ width: '77px' }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={allUsersBulkUpdateRemove?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                                <Box>
                                    {isUserRoleCompare?.includes('excelattendancemodebulkupdate') && (
                                        <>
                                            <Button
                                                onClick={(e) => {
                                                    setIsFilterOpenBulkUpdateRemoveList(true);
                                                    setFormatBulkUpdateRemoveList('xl');
                                                }}
                                                sx={userStyle.buttongrp}
                                            >
                                                <FaFileExcel />
                                                &ensp;Export to Excel&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('csvattendancemodebulkupdate') && (
                                        <>
                                            <Button
                                                onClick={(e) => {
                                                    setIsFilterOpenBulkUpdateRemoveList(true);
                                                    setFormatBulkUpdateRemoveList('csv');
                                                }}
                                                sx={userStyle.buttongrp}
                                            >
                                                <FaFileCsv />
                                                &ensp;Export to CSV&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('printattendancemodebulkupdate') && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintBulkUpdateRemoveList}>
                                                &ensp;
                                                <FaPrint />
                                                &ensp;Print&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('pdfattendancemodebulkupdate') && (
                                        <>
                                            <Button
                                                sx={userStyle.buttongrp}
                                                onClick={() => {
                                                    setIsPdfFilterOpenBulkUpdateRemoveList(true);
                                                }}
                                            >
                                                <FaFilePdf />
                                                &ensp;Export to PDF&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes('imageattendancemodebulkupdate') && (
                                        <Button sx={userStyle.buttongrp} onClick={handleCaptureImageBulkUpdateRemoveList}>
                                            {' '}
                                            <ImageIcon sx={{ fontSize: '15px' }} /> &ensp;Image&ensp;{' '}
                                        </Button>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <FormControl fullWidth size="small">
                                    <OutlinedInput
                                        size="small"
                                        id="outlined-adornment-weight"
                                        startAdornment={
                                            <InputAdornment position="start">
                                                <FaSearch />
                                            </InputAdornment>
                                        }
                                        endAdornment={
                                            <InputAdornment position="end">
                                                {advancedFilterBulkUpdateRemoveList && (
                                                    <IconButton onClick={handleResetSearchBulkUpdateRemoveList}>
                                                        <MdClose />
                                                    </IconButton>
                                                )}
                                                <Tooltip title="Show search options">
                                                    <span>
                                                        <IoMdOptions style={{ cursor: 'pointer' }} onClick={handleClickSearchBulkUpdateRemoveList} />
                                                    </span>
                                                </Tooltip>
                                            </InputAdornment>
                                        }
                                        aria-describedby="outlined-weight-helper-text"
                                        inputProps={{ 'aria-label': 'weight' }}
                                        type="text"
                                        value={getSearchDisplayBulkUpdateRemoveList()}
                                        onChange={handleSearchChangeBulkUpdateRemoveList}
                                        placeholder="Type to search..."
                                        disabled={!!advancedFilterBulkUpdateRemoveList}
                                    />
                                </FormControl>
                            </Grid>
                        </Grid>{' '}
                        <br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsBulkUpdateRemoveList}>
                            {' '}
                            Show All Columns{' '}
                        </Button>
                        &ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsBulkUpdateRemoveList}>
                            {' '}
                            Manage Columns{' '}
                        </Button>
                        <br />
                        <br />
                        {bulkUpdateRemoveApply ? (
                            <>
                                <Box sx={{ display: 'flex', justifyContent: 'center' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box>
                            </>
                        ) : (
                            <>
                                <Box sx={{ width: '100%' }} className={'ag-theme-quartz'} ref={gridRefImageBulkUpdateRemoveList}>
                                    <AgGridReact
                                        rowData={filteredDataItemsBulkUpdateRemoveList}
                                        columnDefs={columnDataTableBulkUpdateRemoveList.filter((column) => columnVisibilityBulkUpdateRemoveList[column.field])}
                                        ref={gridRefTableBulkUpdateRemoveList}
                                        defaultColDef={defaultColDef}
                                        domLayout={'autoHeight'}
                                        getRowStyle={getRowStyle}
                                        pagination={true}
                                        paginationPageSize={pageSizeBulkUpdateRemoveList}
                                        onPaginationChanged={onPaginationChangedBulkUpdateRemoveList}
                                        onGridReady={onGridReadyBulkUpdateRemoveList}
                                        onColumnMoved={handleColumnMovedBulkUpdateRemoveList}
                                        onColumnVisible={handleColumnVisibleBulkUpdateRemoveList}
                                        onFilterChanged={onFilterChangedBulkUpdateRemoveList}
                                        // suppressPaginationPanel={true}
                                        suppressSizeToFit={true}
                                        suppressAutoSize={true}
                                        suppressColumnVirtualisation={true}
                                        colResizeDefault={'shift'}
                                        cellSelection={true}
                                        copyHeadersToClipboard={true}
                                    />
                                </Box>
                                {/* show and hide based on the inner filter and outer filter */}
                                {/* <Box style={userStyle.dataTablestyle}>
                                    <Box>
                                        Showing{" "}
                                        {
                                            gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                                                (filteredDataItemsBulkUpdateRemoveList.length > 0 ? (pageBulkUpdateRemoveList - 1) * pageSizeBulkUpdateRemoveList + 1 : 0)
                                            ) : (
                                                filteredRowDataBulkUpdateRemoveList.length > 0 ? (pageBulkUpdateRemoveList - 1) * pageSizeBulkUpdateRemoveList + 1 : 0
                                            )
                                        }{" "}to{" "}
                                        {
                                            gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                                                Math.min(pageBulkUpdateRemoveList * pageSizeBulkUpdateRemoveList, filteredDataItemsBulkUpdateRemoveList.length)
                                            ) : (
                                                filteredRowDataBulkUpdateRemoveList.length > 0 ? Math.min(pageBulkUpdateRemoveList * pageSizeBulkUpdateRemoveList, filteredRowDataBulkUpdateRemoveList.length) : 0
                                            )
                                        }{" "}of{" "}
                                        {
                                            gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                                                filteredDataItemsBulkUpdateRemoveList.length
                                            ) : (
                                                filteredRowDataBulkUpdateRemoveList.length
                                            )
                                        } entries
                                    </Box>
                                    <Box>
                                        <Button onClick={() => handlePageChangeBulkUpdateRemoveList(1)} disabled={pageBulkUpdateRemoveList === 1} sx={userStyle.paginationbtn}  > <FirstPageIcon /> </Button>
                                        <Button onClick={() => handlePageChangeBulkUpdateRemoveList(pageBulkUpdateRemoveList - 1)} disabled={pageBulkUpdateRemoveList === 1} sx={userStyle.paginationbtn}  > <NavigateBeforeIcon />  </Button>
                                        {getVisiblePageNumbersBulkUpdateRemoveList().map((pageNumber, index) => (
                                            <Button
                                                key={index}
                                                onClick={() => pageNumber !== "..." && handlePageChangeBulkUpdateRemoveList(pageNumber)}
                                                sx={{
                                                    ...userStyle.paginationbtn,
                                                    ...(pageNumber === "..." && {
                                                        cursor: "default",
                                                        color: "black",
                                                        fontSize: '12px',
                                                        fontWeight: 'bold',
                                                        backgroundColor: "transparent",
                                                        border: "none",
                                                        "&:hover": {
                                                            backgroundColor: "transparent",
                                                            boxShadow: "none",
                                                        },
                                                    }),
                                                }}
                                                className={pageBulkUpdateRemoveList === pageNumber ? "active" : ""}
                                                disabled={pageBulkUpdateRemoveList === pageNumber}
                                            >
                                                {pageNumber}
                                            </Button>
                                        ))}
                                        <Button onClick={() => handlePageChangeBulkUpdateRemoveList(pageBulkUpdateRemoveList + 1)} disabled={pageBulkUpdateRemoveList === totalPagesBulkUpdateRemoveList} sx={userStyle.paginationbtn} > <NavigateNextIcon /> </Button>
                                        <Button onClick={() => handlePageChangeBulkUpdateRemoveList(totalPagesBulkUpdateRemoveList)} disabled={pageBulkUpdateRemoveList === totalPagesBulkUpdateRemoveList} sx={userStyle.paginationbtn} ><LastPageIcon /> </Button>
                                    </Box>
                                </Box> */}
                            </>
                        )}
                    </Box>
                </>
            )}
            <br />

            {/* Manage Column */}
            <Popover id={idBulkUpdateRemoveList} open={isManageColumnsOpenBulkUpdateRemoveList} anchorEl={anchorElBulkUpdateRemoveList} onClose={handleCloseManageColumnsBulkUpdateRemoveList} anchorOrigin={{ vertical: 'bottom', horizontal: 'left' }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsBulkUpdateRemoveList}
                    searchQuery={searchQueryManageBulkUpdateRemoveList}
                    setSearchQuery={setSearchQueryManageBulkUpdateRemoveList}
                    filteredColumns={filteredColumns}
                    columnVisibility={columnVisibilityBulkUpdateRemoveList}
                    toggleColumnVisibility={toggleColumnVisibilityBulkUpdateRemoveList}
                    setColumnVisibility={setColumnVisibilityBulkUpdateRemoveList}
                    initialColumnVisibility={initialColumnVisibilityBulkUpdateRemoveList}
                    columnDataTable={columnDataTableBulkUpdateRemoveList}
                />
            </Popover>

            {/* Search Bar */}
            <Popover id={idSearchBulkUpdateRemoveList} open={openSearchBulkUpdateRemoveList} anchorEl={anchorElSearchBulkUpdateRemoveList} onClose={handleCloseSearchBulkUpdateRemoveList} anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}>
                <AdvancedSearchBar columns={columnDataTableBulkUpdateRemoveList.filter((data) => data.field !== 'actions')} onSearch={applyAdvancedFilterBulkUpdateRemoveList} initialSearchValue={searchQueryBulkUpdateRemoveList} handleCloseSearch={handleCloseSearchBulkUpdateRemoveList} />
            </Popover>

            <MessageAlert openPopup={openPopupMalert} handleClosePopup={handleClosePopupMalert} popupContent={popupContentMalert} popupSeverity={popupSeverityMalert} />
            {/* SUCCESS */}
            <AlertDialog openPopup={openPopup} handleClosePopup={handleClosePopup} popupContent={popupContent} popupSeverity={popupSeverity} />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenBulkUpdateRemoveList}
                handleCloseFilterMod={handleCloseFilterModBulkUpdateRemoveList}
                fileFormat={fileFormatBulkUpdateRemoveList}
                setIsFilterOpen={setIsFilterOpenBulkUpdateRemoveList}
                isPdfFilterOpen={isPdfFilterOpenBulkUpdateRemoveList}
                setIsPdfFilterOpen={setIsPdfFilterOpenBulkUpdateRemoveList}
                handleClosePdfFilterMod={handleClosePdfFilterModBulkUpdateRemoveList}
                filteredDataTwo={(filteredRowDataBulkUpdateRemoveList.length > 0 ? filteredRowDataBulkUpdateRemoveList : filteredDataBulkUpdateRemoveList) ?? []}
                itemsTwo={itemsSetTable ?? []}
                filename={'Attendance Mode Updated List'}
                exportColumnNames={exportColumnNamescrt}
                exportRowValues={exportRowValuescrt}
                componentRef={componentRefBulkUpdateRemoveList}
            />
            {/*SINGLE DELETE ALERT DIALOG ARE YOU SURE? */}
            <DeleteConfirmation open={isDeleteOpen} onClose={handleCloseMod} onConfirm={deleteShiftMode} title="Are you sure?" confirmButtonText="Yes" cancelButtonText="Cancel" />

        </Box>
    );
}

export default AttendanceModeBulkUpdateRemoveListTable;
