import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import { FaFileExcel, FaFileCsv, FaSearch, FaEdit, FaPrint, FaFilePdf } from "react-icons/fa";
import { Box, Typography, Chip, OutlinedInput, TableCell, Select, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Button, Popover, TextField, IconButton, InputAdornment, Tooltip, Table, TableContainer, Paper, TableHead, TableRow, TableBody, } from "@mui/material";
import { userStyle, colourStyles } from "../../../pageStyle.js";
import { handleApiError } from "../../../components/Errorhandling.js";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from '../../../axiosInstance';
import { SERVICE } from "../../../services/Baseservice.js";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import { useReactToPrint } from "react-to-print";
import { UserRoleAccessContext } from "../../../context/Appcontext.js";
import { AuthContext } from "../../../context/Appcontext.js";
import Headtitle from "../../../components/Headtitle.js";
import { ThreeDots } from "react-loader-spinner";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import ImageIcon from "@mui/icons-material/Image";
import CloseIcon from "@mui/icons-material/Close";
import { saveAs } from "file-saver";
import Selects from "react-select";
import moment from "moment";
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import domtoimage from 'dom-to-image';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import ExportData from "../../../components/ExportData.js";
import MessageAlert from "../../../components/MessageAlert.js";
import PageHeading from "../../../components/PageHeading.js";
import AlertDialog from "../../../components/Alert.js";
import AdvancedSearchBar from '../../../components/SearchbarEbList.js';
import ManageColumnsContent from "../../../components/ManageColumn.js";
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function TeamAttOverallShortAndMonthList({ userShiftsAttShort, userShiftsAttMonth, loader, filterUser,
    setSearchQueryAttShort, setPageAttShort, setTotalPagesAttShort, pageAttShort, pageSizeAttShort, setPageSizeAttShort, searchQueryAttShort,
    setSearchQueryAttMonth, setPageAttMonth, setTotalPagesAttMonth, pageAttMonth, pageSizeAttMonth, setPageSizeAttMonth, searchQueryAttMonth,
}) {

    const gridRefTableAttShort = useRef(null);
    const gridRefImageAttShort = useRef(null);
    const gridRefTableAttMonth = useRef(null);
    const gridRefImageAttMonth = useRef(null);

    const headerStyle = { wrapHeaderText: true, autoHeaderHeight: true, headerClassName: 'bold-header' };
    const { isUserRoleCompare } = useContext(UserRoleAccessContext);

    const [itemsAttShort, setItemsAttShort] = useState([]);
    const [itemsAttMonth, setItemsAttMonth] = useState([]);
    const [showAlert, setShowAlert] = useState();

    const [advancedFilterAttShort, setAdvancedFilterAttShort] = useState(null);
    const [gridApiAttShort, setGridApiAttShort] = useState(null);
    const [columnApiAttShort, setColumnApiAttShort] = useState(null);
    const [filteredDataItemsAttShort, setFilteredDataItemsAttShort] = useState(userShiftsAttShort);
    const [filteredRowDataAttShort, setFilteredRowDataAttShort] = useState([]);

    const [advancedFilterAttMonth, setAdvancedFilterAttMonth] = useState(null);
    const [gridApiAttMonth, setGridApiAttMonth] = useState(null);
    const [columnApiAttMonth, setColumnApiAttMonth] = useState(null);
    const [filteredDataItemsAttMonth, setFilteredDataItemsAttMonth] = useState(userShiftsAttMonth);
    const [filteredRowDataAttMonth, setFilteredRowDataAttMonth] = useState([]);

    // Error Popup model
    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const handleClickOpenerr = () => { setIsErrorOpen(true); };
    const handleCloseerr = () => { setIsErrorOpen(false); };

    // Exports
    const [isFilterOpenAttShort, setIsFilterOpenAttShort] = useState(false);
    const [isPdfFilterOpenAttShort, setIsPdfFilterOpenAttShort] = useState(false);
    // pageAttShort refersh reload
    const handleCloseFilterModAttShort = () => { setIsFilterOpenAttShort(false); };
    const handleClosePdfFilterModAttShort = () => { setIsPdfFilterOpenAttShort(false); };

    const [isFilterOpenAttMonth, setIsFilterOpenAttMonth] = useState(false);
    const [isPdfFilterOpenAttMonth, setIsPdfFilterOpenAttMonth] = useState(false);
    // pageAttShort refersh reload
    const handleCloseFilterModAttMonth = () => { setIsFilterOpenAttMonth(false); };
    const handleClosePdfFilterModAttMonth = () => { setIsPdfFilterOpenAttMonth(false); };

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); }

    // pageAttShort refersh reload
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    // Manage Columns
    const [isManageColumnsOpenAttShort, setManageColumnsOpenAttShort] = useState(false);
    const [anchorElAttShort, setAnchorElAttShort] = useState(null);
    const [searchQueryManageAttShort, setSearchQueryManageAttShort] = useState("");
    const handleOpenManageColumnsAttShort = (event) => {
        setAnchorElAttShort(event.currentTarget);
        setManageColumnsOpenAttShort(true);
    };
    const handleCloseManageColumnsAttShort = () => {
        setManageColumnsOpenAttShort(false);
        setSearchQueryManageAttShort("");
    };
    const openAttShort = Boolean(anchorElAttShort);
    const idAttShort = openAttShort ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttShort, setAnchorElSearchAttShort] = React.useState(null);
    const handleClickSearchAttShort = (event) => {
        setAnchorElSearchAttShort(event.currentTarget);
    };
    const handleCloseSearchAttShort = () => {
        setAnchorElSearchAttShort(null);
        setSearchQueryAttShort("");
    };

    const openSearchAttShort = Boolean(anchorElSearchAttShort);
    const idSearchAttShort = openSearchAttShort ? 'simple-popover' : undefined;

    // Manage Columns
    const [isManageColumnsOpenAttMonth, setManageColumnsOpenAttMonth] = useState(false);
    const [anchorElAttMonth, setAnchorElAttMonth] = useState(null);
    const [searchQueryManageAttMonth, setSearchQueryManageAttMonth] = useState("");
    const handleOpenManageColumnsAttMonth = (event) => {
        setAnchorElAttMonth(event.currentTarget);
        setManageColumnsOpenAttMonth(true);
    };
    const handleCloseManageColumnsAttMonth = () => {
        setManageColumnsOpenAttMonth(false);
        setSearchQueryManageAttMonth("");
    };
    const openAttMonth = Boolean(anchorElAttMonth);
    const idAttMonth = openAttMonth ? "simple-popover" : undefined;

    // Search bar
    const [anchorElSearchAttMonth, setAnchorElSearchAttMonth] = React.useState(null);
    const handleClickSearchAttMonth = (event) => {
        setAnchorElSearchAttMonth(event.currentTarget);
    };
    const handleCloseSearchAttMonth = () => {
        setAnchorElSearchAttMonth(null);
        setSearchQueryAttMonth("");
    };

    const openSearchAttMonth = Boolean(anchorElSearchAttMonth);
    const idSearchAttMonth = openSearchAttMonth ? 'simple-popover' : undefined;

    // Table row color
    const getRowStyle = (params) => {
        if (params.node.rowIndex % 2 === 0) {
            return { background: '#f0f0f0' }; // Even row
        } else {
            return { background: '#ffffff' }; // Odd row
        }
    }

    // Show All Columns & Manage Columns
    const initialColumnVisibilityAttShort = {
        serialNumber: true,
        empcode: true,
        prodshift: true,
        prodstartdate: true,
        prodstarttime: true,
        prodenddate: true,
        prodendtime: true,
        nextshift: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        date: true,
        shiftmode: true,
        shift: true,
        leavestatus: true,
        permissionstatus: true,
        shiftworkinghours: true,
        shiftbeforeshorthours: true,
        shiftaftershorthours: true,
        totalshorthours: true,
        clockin: true,
        clockout: true,
        clockinstatus: true,
        clockoutstatus: true,
        attendanceauto: true,
        daystatus: true,
        appliedthrough: true,
        lopcalculation: true,
        modetarget: true,
        paidpresent: true,
        lopday: true,
        paidpresentday: true,
    };

    const [columnVisibilityAttShort, setColumnVisibilityAttShort] = useState(initialColumnVisibilityAttShort);

    // Show All Columns & Manage Columns
    const initialColumnVisibilityAttMonth = {
        serialNumber: true,
        empcode: true,
        username: true,
        company: true,
        branch: true,
        unit: true,
        team: true,
        department: true,
        totalnumberofdays: true,
        empshiftdays: true,
        totalcounttillcurrendate: true,
        shift: true,
        totalshift: true,
        clsl: true,
        totalpresentdays: true,
        weekoff: true,
        holidayCount: true,
        doublelopcount: true,
        doublehalflopcount: true,
        lopcount: true,
        totalabsentleave: true,
        totalpaiddays: true,
        paidpresentday: true,
        nostatuscount: true,
    };
    const [columnVisibilityAttMonth, setColumnVisibilityAttMonth] = useState(initialColumnVisibilityAttMonth);

    //serial no for listing itemsAttShort
    const addSerialNumberAttShort = async (datas) => {
        setItemsAttShort(datas);
    };

    useEffect(() => {
        addSerialNumberAttShort(userShiftsAttShort);
        setFilteredDataItemsAttShort(userShiftsAttShort);
        setColumnVisibilityAttShort({
            serialNumber: true,
            empcode: true,
            prodshift: true,
            prodstartdate: true,
            prodstarttime: true,
            prodenddate: true,
            prodendtime: true,
            nextshift: true,
            username: true,
            company: true,
            branch: true,
            unit: true,
            team: true,
            department: true,
            date: true,
            shiftmode: true,
            shift: true,
            leavestatus: true,
            permissionstatus: true,
            shiftworkinghours: true,
            shiftbeforeshorthours: true,
            shiftaftershorthours: true,
            totalshorthours: true,
            clockin: true,
            clockout: true,
            clockinstatus: true,
            clockoutstatus: true,
            attendanceauto: true,
            daystatus: true,
            appliedthrough: true,
            lopcalculation: true,
            modetarget: true,
            paidpresent: true,
            lopday: true,
            paidpresentday: true,
        })
    }, [userShiftsAttShort]);

    const addSerialNumberAttMonth = async (datas) => {
        setItemsAttMonth(datas);
    };

    useEffect(() => {
        addSerialNumberAttMonth(userShiftsAttMonth);
        setFilteredDataItemsAttMonth(userShiftsAttMonth);
    }, [userShiftsAttMonth]);

    const defaultColDef = useMemo(() => {
        return {
            filter: true,
            resizable: true,
            filterParams: {
                buttons: ["apply", "reset", "cancel"],
            },
        };
    }, []);

    const onGridReadyAttShort = useCallback((params) => {
        setGridApiAttShort(params.api);
        setColumnApiAttShort(params.columnApiAttShort);
    }, []);

    // Function to handle filter changes
    const onFilterChangedAttShort = () => {
        if (gridApiAttShort) {
            const filterModel = gridApiAttShort.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataAttShort([]);
            } else {
                // Filters are active, capture filtered data
                const filteredData = [];
                gridApiAttShort.forEachNodeAfterFilterAndSort((node) => {
                    filteredData.push(node.data); // Collect filtered row data
                });
                setFilteredRowDataAttShort(filteredData);
            }
        }
    };

    const onPaginationChangedAttShort = useCallback(() => {
        if (gridRefTableAttShort.current) {
            const gridApiAttShort = gridRefTableAttShort.current.api;
            const currentPage = gridApiAttShort.paginationGetCurrentPage() + 1;
            const totalPagesAttShort = gridApiAttShort.paginationGetTotalPages();
            setPageAttShort(currentPage);
            setTotalPagesAttShort(totalPagesAttShort);
        }
    }, []);

    const columnDataTableAttShort = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityAttShort.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityAttShort.empcode, pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityAttShort.username, pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 150, hide: !columnVisibilityAttShort.company, },
        { field: "branch", headerName: "Branch", flex: 0, width: 150, hide: !columnVisibilityAttShort.branch, },
        { field: "unit", headerName: "Unit", flex: 0, width: 150, hide: !columnVisibilityAttShort.unit, },
        { field: "team", headerName: "Team", flex: 0, width: 150, hide: !columnVisibilityAttShort.team, },
        { field: "department", headerName: "Department", flex: 0, width: 200, hide: !columnVisibilityAttShort.department, },
        { field: "date", headerName: "Date", flex: 0, width: 170, hide: !columnVisibilityAttShort.date, },
        { field: "shiftmode", headerName: "Shift Mode", flex: 0, width: 110, hide: !columnVisibilityAttShort.shiftmode, },
        { field: "shift", headerName: "Shift", flex: 0, width: 170, hide: !columnVisibilityAttShort.shift, },
        { field: "leavestatus", headerName: "Leave Status", flex: 0, width: 150, hide: !columnVisibilityAttShort.leavestatus, },
        { field: "permissionstatus", headerName: "Permission Status", flex: 0, width: 150, hide: !columnVisibilityAttShort.permissionstatus, },
        { field: "shiftworkinghours", headerName: "Shift Working Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttShort.shiftworkinghours, ...headerStyle, },
        { field: "prodstartdate", headerName: "Production Shift Start Date", flex: 0, width: 200, hide: !columnVisibilityAttShort.prodstartdate, ...headerStyle, },
        { field: "prodstarttime", headerName: "Production Shift Start Time", flex: 0, width: 200, hide: !columnVisibilityAttShort.prodstarttime, ...headerStyle, },
        { field: "prodenddate", headerName: "Production Shift End Date", flex: 0, width: 200, hide: !columnVisibilityAttShort.prodenddate, ...headerStyle, },
        { field: "prodendtime", headerName: "Production Shift End Time", flex: 0, width: 200, hide: !columnVisibilityAttShort.prodendtime, ...headerStyle, },
        { field: "clockin", headerName: "Clock In Time", flex: 0, width: 200, hide: !columnVisibilityAttShort.clockin, ...headerStyle, },
        { field: "clockout", headerName: "Clock Out Time", flex: 0, width: 200, hide: !columnVisibilityAttShort.clockout, ...headerStyle, },
        { field: "shiftbeforeshorthours", headerName: "Shift Before Short Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttShort.shiftbeforeshorthours, ...headerStyle, },
        { field: "shiftaftershorthours", headerName: "Shift After Short Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttShort.shiftaftershorthours, ...headerStyle, },
        { field: "totalshorthours", headerName: "Total Short Hours (HH:MM:SS)", flex: 0, width: 200, hide: !columnVisibilityAttShort.totalshorthours, ...headerStyle, },
    ];

    const columnDataTableAttMonth = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 80, hide: !columnVisibilityAttMonth.serialNumber, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "empcode", headerName: "Emp Code", flex: 0, width: 150, hide: !columnVisibilityAttMonth.empcode, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "username", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityAttMonth.username, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
        { field: "company", headerName: "Company", flex: 0, width: 130, hide: !columnVisibilityAttMonth.company, headerClassName: "bold-header", },
        { field: "branch", headerName: "Branch", flex: 0, width: 130, hide: !columnVisibilityAttMonth.branch, headerClassName: "bold-header", },
        { field: "unit", headerName: "Unit", flex: 0, width: 130, hide: !columnVisibilityAttMonth.unit, headerClassName: "bold-header", },
        { field: "team", headerName: "Team", flex: 0, width: 130, hide: !columnVisibilityAttMonth.team, headerClassName: "bold-header", },
        { field: "department", headerName: "Department", flex: 0, width: 130, hide: !columnVisibilityAttMonth.department, headerClassName: "bold-header", },
        { field: "totalnumberofdays", headerName: "Total No. Of Days", flex: 0, width: 110, hide: !columnVisibilityAttMonth.totalnumberofdays, headerClassName: "bold-header", },
        { field: "empshiftdays", headerName: "Employee Shift Days", flex: 0, width: 110, hide: !columnVisibilityAttMonth.empshiftdays, headerClassName: "bold-header", },
        { field: "totalcounttillcurrendate", headerName: "Till Current Date Count", flex: 0, width: 110, hide: !columnVisibilityAttMonth.totalcounttillcurrendate, headerClassName: "bold-header", },
        { field: "shift", headerName: "Till Current Shift", flex: 0, width: 150, hide: !columnVisibilityAttMonth.shift, headerClassName: "bold-header", },
        { field: "clsl", headerName: "C.L. / S.L.", flex: 0, width: 120, hide: !columnVisibilityAttMonth.clsl, headerClassName: "bold-header", },
        { field: "weekoff", headerName: "Week Off", flex: 0, width: 130, hide: !columnVisibilityAttMonth.weekoff, headerClassName: "bold-header", },
        { field: "holidayCount", headerName: "Holiday", flex: 0, width: 130, hide: !columnVisibilityAttMonth.holidayCount, headerClassName: "bold-header", },
        { field: "doublelopcount", headerName: "Double Lop", flex: 0, width: 130, hide: !columnVisibilityAttMonth.doublelopcount, headerClassName: "bold-header", },
        { field: "doublehalflopcount", headerName: "Double Half Lop", flex: 0, width: 130, hide: !columnVisibilityAttMonth.doublehalflopcount, headerClassName: "bold-header", },
        { field: "paidpresentday", headerName: "Total Present Shift", flex: 0, width: 130, hide: !columnVisibilityAttMonth.paidpresentday, headerClassName: "bold-header", },
        { field: "lopcount", headerName: "Total Absent / LOP", flex: 0, width: 120, hide: !columnVisibilityAttMonth.lopcount, headerClassName: "bold-header", },
        { field: "totalpaiddays", headerName: "Total Paid Shift", flex: 0, width: 130, hide: !columnVisibilityAttMonth.totalpaiddays, headerClassName: "bold-header", },
        { field: "nostatuscount", headerName: "Total No Status Shift", flex: 0, width: 130, hide: !columnVisibilityAttMonth.nostatuscount, headerClassName: "bold-header", },
    ];

    //Datatable
    const handleSearchChangeAttShort = (e) => {
        const value = e.target.value;
        setSearchQueryAttShort(value);
        applyNormalFilterAttShort(value);
        setFilteredRowDataAttShort([]);
    };

    const applyNormalFilterAttShort = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttShort?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsAttShort(filtered);
        setPageAttShort(1);
    };

    const applyAdvancedFilterAttShort = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttShort?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsAttShort(filtered); // Update filtered data
        setAdvancedFilterAttShort(filters);
        // handleCloseSearchAttShort(); // Close the popover after search
    };

    // Undo filter funtion
    const handleResetSearchAttShort = () => {
        setAdvancedFilterAttShort(null);
        setSearchQueryAttShort("");
        setFilteredDataItemsAttShort(userShiftsAttShort);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayAttShort = () => {
        if (advancedFilterAttShort && advancedFilterAttShort.length > 0) {
            return advancedFilterAttShort.map((filter, index) => {
                let showname = columnDataTableAttShort.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterAttShort.length > 1 ? advancedFilterAttShort[1].condition : '') + ' ');
        }
        return searchQueryAttShort;
    };

    const handlePageSizeChangeAttShort = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttShort(newSize);
        if (gridApiAttShort) {
            gridApiAttShort.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsAttShort = () => {
        const updatedVisibility = { ...columnVisibilityAttShort };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityAttShort(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibility");
        if (savedVisibility) {
            setColumnVisibilityAttShort(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibility", JSON.stringify(columnVisibilityAttShort));
    }, [columnVisibilityAttShort]);

    // Function to filter columns based on search query
    const filteredColumnsAttShort = columnDataTableAttShort?.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageAttShort.toLowerCase())
    );

    function debounce(func, wait) {
        let timeout;
        return function (...args) {
            clearTimeout(timeout);
            timeout = setTimeout(() => func.apply(this, args), wait);
        };
    }

    // Manage Columns functionality
    const toggleColumnVisibilityAttShort = (field) => {
        if (!gridApiAttShort) return;

        setColumnVisibilityAttShort((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiAttShort.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedAttShort = useCallback(debounce((event) => {
        if (!event.columnApiAttShort) return;

        const visible_columns = event.columnApiAttShort.getAllColumns().filter(col => {
            const colState = event.columnApiAttShort.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityAttShort((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleAttShort = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityAttShort((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    const [fileFormat, setFormat] = useState("");
    let exportColumnNamescrtAttShort = [
        "Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department",
        "Date", "Shift Mode", "Shift", "Leave Status", "Permission Status", "Shift Working Hours (HH:MM:SS)", "Production Shift Start Date", "Production Shift Start Time",
        "Production Shift End Date", "Production Shift End Time", "Clock In Time", "Clock Out Time", "Shift Before Short Hours (HH:MM:SS)", "Shift After Short Hours (HH:MM:SS)", "Total Short Hours (HH:MM:SS)"
    ]
    let exportRowValuescrtAttShort = [
        'empcode', 'username', 'company', 'branch', 'unit', 'team',
        'department', 'date', 'shiftmode', 'shift', 'leavestatus', 'permissionstatus', 'shiftworkinghours', 'prodstartdate', 'prodstarttime', 'prodenddate', 'prodendtime', 'clockin', 'clockout', 'shiftbeforeshorthours', 'shiftaftershorthours', 'totalshorthours'
    ]

    // print...
    const componentRefAttShort = useRef();
    const handleprintAttShort = useReactToPrint({
        content: () => componentRefAttShort.current,
        documentTitle: "Team Attendance Short Time",
        pageStyle: "print",
    });

    // image
    const handleCaptureImageAttShort = () => {
        if (gridRefImageAttShort.current) {
            domtoimage.toBlob(gridRefImageAttShort.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Short Time.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredDataAttShort = filteredDataItemsAttShort?.slice((pageAttShort - 1) * pageSizeAttShort, pageAttShort * pageSizeAttShort);
    const totalPagesAttShortOuter = Math.ceil(filteredDataItemsAttShort?.length / pageSizeAttShort);
    const visiblePages = Math.min(totalPagesAttShortOuter, 3);
    const firstVisiblePage = Math.max(1, pageAttShort - 1);
    const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesAttShortOuter);
    const pageNumbers = [];
    const indexOfLastItem = pageAttShort * pageSizeAttShort;
    const indexOfFirstItem = indexOfLastItem - pageSizeAttShort;
    for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

    //Attendance Day Shift
    const onGridReadyAttMonth = useCallback((params) => {
        setGridApiAttMonth(params.api);
        setColumnApiAttMonth(params.columnApiAttMonth);
    }, []);

    // Function to handle filter changes
    const onFilterChangedAttMonth = () => {
        if (gridApiAttMonth) {
            const filterModel = gridApiAttMonth.getFilterModel(); // Get the current filter model

            // Check if filters are active
            if (Object.keys(filterModel).length === 0) {
                // No filters active, clear the filtered data state
                setFilteredRowDataAttMonth([]);
            } else {
                // Filters are active, capture filtered data
                const filteredData = [];
                gridApiAttMonth.forEachNodeAfterFilterAndSort((node) => {
                    filteredData.push(node.data); // Collect filtered row data
                });
                setFilteredRowDataAttMonth(filteredData);
            }
        }
    };

    const onPaginationChangedAttMonth = useCallback(() => {
        if (gridRefTableAttMonth.current) {
            const gridApiAttMonth = gridRefTableAttMonth.current.api;
            const currentPage = gridApiAttMonth.paginationGetCurrentPage() + 1;
            const totalPagesAttMonth = gridApiAttMonth.paginationGetTotalPages();
            setPageAttMonth(currentPage);
            setTotalPagesAttMonth(totalPagesAttMonth);
        }
    }, []);

    //Datatable
    const handleSearchChangeAttMonth = (e) => {
        const value = e.target.value;
        setSearchQueryAttMonth(value);
        applyNormalFilterAttMonth(value);
        setFilteredRowDataAttShort([]);
    };

    const applyNormalFilterAttMonth = (searchValue) => {

        // Split the search query into individual terms
        const searchTerms = searchValue.toLowerCase().split(" ");

        // Modify the filtering logic to check each term
        const filtered = itemsAttMonth?.filter((item) => {
            return searchTerms.every((term) =>
                Object.values(item).join(" ").toLowerCase().includes(term)
            );
        });
        setFilteredDataItemsAttMonth(filtered);
        setPageAttMonth(1);
    };

    const applyAdvancedFilterAttMonth = (filters, logicOperator) => {
        // Apply filtering logic with multiple conditions
        const filtered = itemsAttMonth?.filter((item) => {
            return filters.reduce((acc, filter, index) => {
                const { column, condition, value } = filter;
                const itemValue = String(item[column])?.toLowerCase();
                const filterValue = String(value).toLowerCase();

                let match;
                switch (condition) {
                    case "Contains":
                        match = itemValue.includes(filterValue);
                        break;
                    case "Does Not Contain":
                        match = !itemValue?.includes(filterValue);
                        break;
                    case "Equals":
                        match = itemValue === filterValue;
                        break;
                    case "Does Not Equal":
                        match = itemValue !== filterValue;
                        break;
                    case "Begins With":
                        match = itemValue.startsWith(filterValue);
                        break;
                    case "Ends With":
                        match = itemValue.endsWith(filterValue);
                        break;
                    case "Blank":
                        match = !itemValue;
                        break;
                    case "Not Blank":
                        match = !!itemValue;
                        break;
                    default:
                        match = true;
                }

                // Combine conditions with AND/OR logic
                if (index === 0) {
                    return match; // First filter is applied directly
                } else if (logicOperator === "AND") {
                    return acc && match;
                } else {
                    return acc || match;
                }
            }, true);
        });

        setFilteredDataItemsAttMonth(filtered);
        setAdvancedFilterAttMonth(filters);
        // handleCloseSearchAttMonth(); 
    };

    // Undo filter funtion
    const handleResetSearchAttMonth = () => {
        setAdvancedFilterAttMonth(null);
        setSearchQueryAttMonth("");
        setFilteredDataItemsAttMonth(userShiftsAttMonth);
    };

    // Show filtered combination in the search bar
    const getSearchDisplayAttMonth = () => {
        if (advancedFilterAttMonth && advancedFilterAttMonth.length > 0) {
            return advancedFilterAttMonth.map((filter, index) => {
                let showname = columnDataTableAttMonth.find(col => col.field === filter.column)?.headerName;
                return `${showname} ${filter.condition} "${filter.value}"`;
            }).join(' ' + (advancedFilterAttMonth.length > 1 ? advancedFilterAttMonth[1].condition : '') + ' ');
        }
        return searchQueryAttMonth;
    };

    const handlePageSizeChangeAttMonth = (e) => {
        const newSize = Number(e.target.value);
        setPageSizeAttMonth(newSize);
        if (gridApiAttMonth) {
            gridApiAttMonth.paginationSetPageSize(newSize);
        }
    };

    // Show All Columns functionality
    const handleShowAllColumnsAttMonth = () => {
        const updatedVisibility = { ...columnVisibilityAttMonth };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityAttMonth(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibilityAttMonth");
        if (savedVisibility) {
            setColumnVisibilityAttMonth(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibilityAttMonth", JSON.stringify(columnVisibilityAttMonth));
    }, [columnVisibilityAttMonth]);

    // Function to filter columns based on search query
    const filteredColumnsAttMonth = columnDataTableAttMonth.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageAttMonth.toLowerCase())
    );

    // Manage Columns functionality
    const toggleColumnVisibilityAttMonth = (field) => {
        if (!gridApiAttMonth) return;

        setColumnVisibilityAttMonth((prevVisibility) => {
            const newVisibility = !prevVisibility[field];

            // Update the visibility in the grid
            gridApiAttMonth.setColumnVisible(field, newVisibility);

            return {
                ...prevVisibility,
                [field]: newVisibility,
            };
        });
    };

    const handleColumnMovedAttMonth = useCallback(debounce((event) => {
        if (!event.columnApiAttMonth) return;

        const visible_columns = event.columnApiAttMonth.getAllColumns().filter(col => {
            const colState = event.columnApiAttMonth.getColumnState().find(state => state.colId === col.colId);
            return colState && !colState.hide;
        }).map(col => col.colId);

        setColumnVisibilityAttMonth((prevVisibility) => {
            const updatedVisibility = { ...prevVisibility };

            // Ensure columns that are visible stay visible
            Object.keys(updatedVisibility).forEach(colId => {
                updatedVisibility[colId] = visible_columns.includes(colId);
            });

            return updatedVisibility;
        });
    }, 300), []);

    const handleColumnVisibleAttMonth = useCallback((event) => {
        const colId = event.column.getColId();

        // Update visibility based on event, but only when explicitly triggered by grid
        setColumnVisibilityAttMonth((prevVisibility) => ({
            ...prevVisibility,
            [colId]: event.visible, // Set visibility directly from the event
        }));
    }, []);

    // Excel
    let exportColumnNamescrtAttMonth = [
        "Emp Code", "Employee Name", "Company", "Branch", "Unit", "Team", "Department", 'Total No. of Days', 'Employee Shift Days', 'Till Current Date Count',
        'Till Current Shift', 'C.L. / S.L.', 'Week Off', 'Holiday', 'Double Lop', 'Double Half Lop', 'Total Present Shift', 'Total Absent / LOP', 'Total Paid Shift', 'Total No Status Shift',
    ]
    let exportRowValuescrtAttMonth = [
        "empcode", "username", "company", "branch", "unit", "team", "department", "totalnumberofdays", "empshiftdays", "totalcounttillcurrendate",
        "shift", "clsl", "weekoff", "holidayCount", "doublelopcount", "doublehalflopcount", "paidpresentday", "lopcount", "totalpaiddays", "nostatuscount",
    ]

    // print...
    const componentRefAttMonth = useRef();
    const handleprintAttMonth = useReactToPrint({
        content: () => componentRefAttMonth.current,
        documentTitle: "Team Attendance Month Status",
        pageStyle: "print",
    });

    // image
    const handleCaptureImageAttMonth = () => {
        if (gridRefImageAttMonth.current) {
            domtoimage.toBlob(gridRefImageAttMonth.current)
                .then((blob) => {
                    saveAs(blob, "Team Attendance Month Status.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    // Pagination for outer filter
    const filteredDataAttMonth = filteredDataItemsAttMonth?.slice((pageAttMonth - 1) * pageSizeAttMonth, pageAttMonth * pageSizeAttMonth);
    const totalPagesAttMonthOuter = Math.ceil(filteredDataItemsAttMonth?.length / pageSizeAttMonth);
    const visiblePagesAttMonth = Math.min(totalPagesAttMonthOuter, 3);
    const firstVisiblePageAttMonth = Math.max(1, pageAttMonth - 1);
    const lastVisiblePageAttMonth = Math.min(firstVisiblePageAttMonth + visiblePagesAttMonth - 1, totalPagesAttMonthOuter);
    const pageNumbersAttMonth = [];
    const indexOfLastItemAttMonth = pageAttMonth * pageSizeAttMonth;
    const indexOfFirstItemAttMonth = indexOfLastItemAttMonth - pageSizeAttMonth;
    for (let i = firstVisiblePageAttMonth; i <= lastVisiblePageAttMonth; i++) { pageNumbersAttMonth.push(i); }

    return (
        <Box>
            {isUserRoleCompare?.includes("lteamattendanceoverallreport") && (
                <>
                    {/* ****** Table Start ****** */}
                    {filterUser.attmode === 'Attendance Short Time' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}>Team Attendance Short Time</Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttShort}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeAttShort}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsAttShort?.length}>All</MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenAttShort(true);
                                                        setFormat("xl");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileExcel />
                                                    &ensp;Export to Excel&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendancestatus") && (
                                            <>
                                                <Button
                                                    onClick={(e) => {
                                                        setIsFilterOpenAttShort(true);
                                                        setFormat("csv");
                                                    }}
                                                    sx={userStyle.buttongrp}
                                                >
                                                    <FaFileCsv />
                                                    &ensp;Export to CSV&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintAttShort}>
                                                    {" "}
                                                    &ensp; <FaPrint /> &ensp;Print&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenAttShort(true);
                                                    }}
                                                >
                                                    <FaFilePdf />
                                                    &ensp;Export to PDF&ensp;
                                                </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button
                                                    sx={userStyle.buttongrp}
                                                    onClick={handleCaptureImageAttShort}
                                                >
                                                    {" "}
                                                    <ImageIcon sx={{ fontSize: "15px" }} />{" "}
                                                    &ensp;Image&ensp;{" "}
                                                </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterAttShort && (
                                                        <IconButton onClick={handleResetSearchAttShort}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttShort} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayAttShort()}
                                            onChange={handleSearchChangeAttShort}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterAttShort}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>{" "}  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsAttShort}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsAttShort}> Manage Columns  </Button><br /> <br />
                            {loader ?
                                <Box sx={{ display: 'flex', justifyContent: 'center', minHeight: '350px' }}>
                                    <ThreeDots height="80" width="80" radius="9" color="#1976d2" ariaLabel="three-dots-loading" wrapperStyle={{}} wrapperClassName="" visible={true} />
                                </Box> :
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttShort} >
                                        <AgGridReact
                                            rowData={filteredDataItemsAttShort}
                                            columnDefs={columnDataTableAttShort.filter((column) => columnVisibilityAttShort[column.field])}
                                            ref={gridRefTableAttShort}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttShort}
                                            onPaginationChanged={onPaginationChangedAttShort}
                                            onGridReady={onGridReadyAttShort}
                                            onColumnMoved={handleColumnMovedAttShort}
                                            onColumnVisible={handleColumnVisibleAttShort}
                                            onFilterChanged={onFilterChangedAttShort}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            }
                        </Box>
                    ) : null}
                    {filterUser.attmode === 'Attendance Month Status' ? (
                        <Box sx={userStyle.container}>
                            {/* ******************************************************EXPORT Buttons****************************************************** */}
                            <Grid item xs={8}>
                                <Typography sx={userStyle.importheadtext}> Team Attendance Month Status </Typography>
                            </Grid>
                            <Grid container spacing={2} style={userStyle.dataTablestyle}>
                                <Grid item md={2} xs={12} sm={12}>
                                    <Box>
                                        <label>Show entries:</label>
                                        <Select
                                            id="pageSizeSelect"
                                            value={pageSizeAttMonth}
                                            MenuProps={{
                                                PaperProps: {
                                                    style: {
                                                        maxHeight: 180,
                                                        width: 80,
                                                    },
                                                },
                                            }}
                                            onChange={handlePageSizeChangeAttMonth}
                                            sx={{ width: "77px" }}
                                        >
                                            <MenuItem value={1}>1</MenuItem>
                                            <MenuItem value={5}>5</MenuItem>
                                            <MenuItem value={10}>10</MenuItem>
                                            <MenuItem value={25}>25</MenuItem>
                                            <MenuItem value={50}>50</MenuItem>
                                            <MenuItem value={100}>100</MenuItem>
                                            <MenuItem value={userShiftsAttMonth?.length}>  All </MenuItem>
                                        </Select>
                                    </Box>
                                </Grid>
                                <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}  >
                                    <Box>
                                        {isUserRoleCompare?.includes("excelteamattendanceoverallreport") && (
                                            <>
                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttMonth(true)
                                                    // fetchUsersStatus()
                                                    setFormat("xl")
                                                }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("csvteamattendanceoverallreport") && (
                                            <>

                                                <Button onClick={(e) => {
                                                    setIsFilterOpenAttMonth(true)
                                                    // fetchUsersStatus()
                                                    setFormat("csv")
                                                }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("printteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleprintAttMonth}> &ensp;  <FaPrint /> &ensp;Print&ensp; </Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("pdfteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp}
                                                    onClick={() => {
                                                        setIsPdfFilterOpenAttMonth(true)
                                                    }}
                                                ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                            </>
                                        )}
                                        {isUserRoleCompare?.includes("imageteamattendanceoverallreport") && (
                                            <>
                                                <Button sx={userStyle.buttongrp} onClick={handleCaptureImageAttMonth}> <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp; </Button>
                                            </>
                                        )}
                                    </Box>
                                </Grid>
                                <Grid item md={2} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <OutlinedInput size="small"
                                            id="outlined-adornment-weight"
                                            startAdornment={
                                                <InputAdornment position="start">
                                                    <FaSearch />
                                                </InputAdornment>
                                            }
                                            endAdornment={
                                                <InputAdornment position="end">
                                                    {advancedFilterAttMonth && (
                                                        <IconButton onClick={handleResetSearchAttMonth}>
                                                            <MdClose />
                                                        </IconButton>
                                                    )}
                                                    <Tooltip title="Show search options">
                                                        <span>
                                                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchAttMonth} />
                                                        </span>
                                                    </Tooltip>
                                                </InputAdornment>}
                                            aria-describedby="outlined-weight-helper-text"
                                            inputProps={{ 'aria-label': 'weight', }}
                                            type="text"
                                            value={getSearchDisplayAttMonth()}
                                            onChange={handleSearchChangeAttMonth}
                                            placeholder="Type to search..."
                                            disabled={!!advancedFilterAttMonth}
                                        />
                                    </FormControl>
                                </Grid>
                            </Grid>  <br />
                            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsAttMonth}>  Show All Columns </Button>&ensp;
                            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsAttMonth}> Manage Columns  </Button> <br /><br />
                            {loader ? (
                                <>
                                    <Box sx={{ display: "flex", justifyContent: "center" }}>
                                        <ThreeDots
                                            height="80"
                                            width="80"
                                            radius="9"
                                            color="#1976d2"
                                            ariaLabel="three-dots-loading"
                                            wrapperStyle={{}}
                                            wrapperClassName=""
                                            visible={true}
                                        />
                                    </Box>
                                </>
                            ) : (
                                <>
                                    <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageAttMonth} >
                                        <AgGridReact
                                            rowData={filteredDataItemsAttMonth}
                                            columnDefs={columnDataTableAttMonth.filter((column) => columnVisibilityAttMonth[column.field])}
                                            ref={gridRefTableAttMonth}
                                            defaultColDef={defaultColDef}
                                            domLayout={"autoHeight"}
                                            getRowStyle={getRowStyle}
                                            pagination={true}
                                            paginationPageSize={pageSizeAttMonth}
                                            onPaginationChanged={onPaginationChangedAttMonth}
                                            onGridReady={onGridReadyAttMonth}
                                            onColumnMoved={handleColumnMovedAttMonth}
                                            onColumnVisible={handleColumnVisibleAttMonth}
                                            onFilterChanged={onFilterChangedAttMonth}
                                            // suppressPaginationPanel={true}
                                            suppressSizeToFit={true}
                                            suppressAutoSize={true}
                                            suppressColumnVirtualisation={true}
                                            colResizeDefault={"shift"}
                                            cellSelection={true}
                                            copyHeadersToClipboard={true}
                                        />
                                    </Box>
                                </>
                            )}
                        </Box>
                    ) : null}
                    {/* ****** Table End ****** */}
                </>
            )}

            {/* Manage Column */}
            <Popover
                id={idAttShort}
                open={isManageColumnsOpenAttShort}
                anchorEl={anchorElAttShort}
                onClose={handleCloseManageColumnsAttShort}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsAttShort}
                    searchQuery={searchQueryManageAttShort}
                    setSearchQuery={setSearchQueryManageAttShort}
                    filteredColumns={filteredColumnsAttShort}
                    columnVisibility={columnVisibilityAttShort}
                    toggleColumnVisibility={toggleColumnVisibilityAttShort}
                    setColumnVisibility={setColumnVisibilityAttShort}
                    initialColumnVisibility={initialColumnVisibilityAttShort}
                    columnDataTable={columnDataTableAttShort}
                />
            </Popover>

            {/* Search Bar */}
            <Popover
                id={idSearchAttShort}
                open={openSearchAttShort}
                anchorEl={anchorElSearchAttShort}
                onClose={handleCloseSearchAttShort}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <AdvancedSearchBar columns={columnDataTableAttShort.filter(data => data.field !== "actions")} onSearch={applyAdvancedFilterAttShort} initialSearchValue={searchQueryAttShort} handleCloseSearch={handleCloseSearchAttShort} />
            </Popover>

            {/* Manage Column */}
            <Popover
                id={idAttMonth}
                open={isManageColumnsOpenAttMonth}
                anchorEl={anchorElAttMonth}
                onClose={handleCloseManageColumnsAttMonth}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
            >
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsAttMonth}
                    searchQuery={searchQueryManageAttMonth}
                    setSearchQuery={setSearchQueryManageAttMonth}
                    filteredColumns={filteredColumnsAttMonth}
                    columnVisibility={columnVisibilityAttMonth}
                    toggleColumnVisibility={toggleColumnVisibilityAttMonth}
                    setColumnVisibility={setColumnVisibilityAttMonth}
                    initialColumnVisibility={initialColumnVisibilityAttMonth}
                    columnDataTable={columnDataTableAttMonth}
                />
            </Popover>

            <Popover
                id={idSearchAttMonth}
                open={openSearchAttMonth}
                anchorEl={anchorElSearchAttMonth}
                onClose={handleCloseSearchAttMonth}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
            >
                <Box sx={{ padding: '10px' }}>
                    <AdvancedSearchBar columns={columnDataTableAttMonth} onSearch={applyAdvancedFilterAttMonth} initialSearchValue={searchQueryAttMonth} handleCloseSearch={handleCloseSearchAttMonth} />
                </Box>
            </Popover>

            {/* Alert  */}
            <Box>
                <Dialog open={isErrorOpen} onClose={handleCloseerr} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <Typography variant="h6">{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button variant="contained" color="error" onClick={handleCloseerr}>
                            ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenAttShort}
                handleCloseFilterMod={handleCloseFilterModAttShort}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenAttShort}
                isPdfFilterOpen={isPdfFilterOpenAttShort}
                setIsPdfFilterOpen={setIsPdfFilterOpenAttShort}
                handleClosePdfFilterMod={handleClosePdfFilterModAttShort}
                filteredDataTwo={(filteredRowDataAttShort.length > 0 ? filteredRowDataAttShort : filteredDataAttShort) ?? []}
                itemsTwo={itemsAttShort ?? []}
                filename={"Team Attendance Short Time"}
                exportColumnNames={exportColumnNamescrtAttShort}
                exportRowValues={exportRowValuescrtAttShort}
                componentRef={componentRefAttShort}
            />

            <ExportData
                isFilterOpen={isFilterOpenAttMonth}
                handleCloseFilterMod={handleCloseFilterModAttMonth}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenAttMonth}
                isPdfFilterOpen={isPdfFilterOpenAttMonth}
                setIsPdfFilterOpen={setIsPdfFilterOpenAttMonth}
                handleClosePdfFilterMod={handleClosePdfFilterModAttMonth}
                filteredDataTwo={(filteredRowDataAttMonth.length > 0 ? filteredRowDataAttMonth : filteredDataAttMonth) ?? []}
                itemsTwo={userShiftsAttMonth ?? []}
                filename={"Team Attendance Month Status"}
                exportColumnNames={exportColumnNamescrtAttMonth}
                exportRowValues={exportRowValuescrtAttMonth}
                componentRef={componentRefAttMonth}
            />

        </Box>
    );
}

export default TeamAttOverallShortAndMonthList;