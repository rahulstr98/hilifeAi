import { Outlet, useLocation } from 'react-router-dom';
import { useEffect, useRef, useState, useContext } from 'react';
import Header from './Header';
import { FormControlLabel, Box, Button, CircularProgress, Dialog, DialogTitle, DialogContent, Typography, DialogActions } from '@mui/material';
import { alpha, styled } from '@mui/material/styles';
import Switch from '@mui/material/Switch';
import { UserRoleAccessContext, AuthContext } from '../context/Appcontext';
import KeyboardArrowUpTwoToneIcon from '@mui/icons-material/KeyboardArrowUpTwoTone';
import Tooltip from '@mui/material/Tooltip';
import { BASE_URL } from '../services/Authservice';
import axios from 'axios';
import ScreenShot from './Screenshot';
import { SERVICE } from '../services/Baseservice';
import MeetingRoomIcon from '@mui/icons-material/MeetingRoom';
import AccessTimeIcon from '@mui/icons-material/AccessTime';
import Servertime from '../components/Servertime';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';
import EventIcon from '@mui/icons-material/Event';
import moment from 'moment-timezone';
import { handleApiError } from "../components/Errorhandling";
import { getCurrentServerTime } from '../components/getCurrentServerTime';

const StatusSwitch = styled((props) => <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} onClick={props.onClick} />)(() => ({
  cursor: 'default',
  width: 80,
  padding: 8,
  '& .MuiSwitch-switchBase': {
    cursor: 'default',
  },
  '& .MuiSwitch-track': {
    borderRadius: 22 / 2,
    backgroundColor: '#e00404', // dark red by default (OFF)
    opacity: 1, // <- ensures solid color
    position: 'relative',
    '&::before, &::after': {
      content: '""',
      position: 'absolute',
      top: '50%',
      transform: 'translateY(-50%)',
      width: 'auto',
      height: 16,
      fontSize: 12,
      color: '#fff',
      display: 'flex',
      alignItems: 'center',
    },
    '&::before': {
      content: `"Online"`,
      left: 10,
      opacity: 0,
    },
    '&::after': {
      content: `"Offline"`,
      right: 10,
      opacity: 1,
    },
  },
  '& .MuiSwitch-thumb': {
    boxShadow: 'none',
    width: 16,
    height: 16,
    margin: 2,
    backgroundColor: '#fff',
  },
  '& .MuiSwitch-switchBase.Mui-checked': {
    transform: 'translateX(44px)',
    color: '#fff',
    // removed hover transparency
    '&:hover': {
      backgroundColor: 'transparent',
    },
  },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
    backgroundColor: '#0c9621', // dark green when ON
    opacity: 1, // ensure no transparency
    '&::before': {
      opacity: 1,
    },
    '&::after': {
      opacity: 0,
    },
  },
}));

const NavbarSwitch = styled((props) => <Switch focusVisibleClassName=".Mui-focusVisible" disableRipple {...props} onClick={props.onClick} />)(({ theme, buttonStyles }) => ({
  padding: 8,
  '& .MuiSwitch-track': {
    borderRadius: 22 / 2,
    backgroundColor: buttonStyles?.navbar?.backgroundColor,
    '&::before, &::after': {
      content: '""',
      position: 'absolute',
      top: '50%',
      transform: 'translateY(-50%)',
      width: 16,
      height: 16,
    },
    '&::before': {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(
        theme.palette.getContrastText(theme.palette.primary.main)
      )}" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z"/></svg>')`,
      left: 12,
    },
    '&::after': {
      backgroundImage: `url('data:image/svg+xml;utf8,<svg xmlns="http://www.w3.org/2000/svg" height="16" width="16" viewBox="0 0 24 24"><path fill="${encodeURIComponent(theme.palette.getContrastText(theme.palette.primary.main))}" d="M19,13H5V11H19V13Z" /></svg>')`,
      right: 12,
    },
  },
  '& .MuiSwitch-thumb': {
    boxShadow: 'none',
    width: 16,
    height: 16,
    margin: 2,
    backgroundColor: buttonStyles?.navbar?.backgroundColor,
  },
  '& .MuiSwitch-switchBase.Mui-checked': {
    color: buttonStyles?.navbar?.color,
    '&:hover': {
      backgroundColor: alpha(buttonStyles?.navbar?.backgroundColor, theme.palette.action.hoverOpacity),
    },
  },
  '& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track': {
    backgroundColor: buttonStyles?.navbar?.backgroundColor,
  },
}));

const Layout = () => {
  const { isUserRoleCompare, buttonStyles, isUserRoleAccess, isAssignBranch, isServerCurrentdatetime } = useContext(UserRoleAccessContext);
  const location = useLocation();
  const headerRef = useRef(null);
  const [headerHeight, setHeaderHeight] = useState(64);
  const { auth } = useContext(AuthContext);

  // Error Popup model
  const [isErrorOpen, setIsErrorOpen] = useState(false);
  const [showAlert, setShowAlert] = useState();
  const handleClickOpenerr = () => {
    setIsErrorOpen(true);
  };
  const handleCloseerr = () => {
    setIsErrorOpen(false);
  };

  // const contentStyle = location.pathname === "/dashboard" || location.pathname === "/"
  // ? {
  //   maxWidth: "100%",
  //   margin: "0 auto",
  //   padding: "2px 0px"
  // } // Override styles for specific page
  // : {
  //   maxWidth: "1600px",
  //   margin: "0 auto",
  //   padding: "3px 20px"
  // }

  // servertime add code
  const [serverTimeNew, setServerTimeNew] = useState(null);
  useEffect(() => {
    const fetchTime = async () => {
      const time = await getCurrentServerTime();
      setServerTimeNew(time);
    };
    fetchTime();
  }, []);


  useEffect(() => {
    if (headerRef.current) {
      setHeaderHeight(headerRef.current.offsetHeight); // Get the header height
    }

    // Update the height on window resize to ensure responsiveness
    const handleResize = () => {
      if (headerRef.current) {
        setHeaderHeight(headerRef.current.offsetHeight);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
    };
  }, []);

  const [showNavbar, setShowNavbar] = useState(true);

  const [showStatus, setStatus] = useState(true);

  const toggleStatus = () => {
    setStatus((prev) => !prev);
  };

  useEffect(() => {
    let isMounted = true;

    const fetchData = async () => {
      try {
        const response = await fetch(`${BASE_URL}/api/connectionstatus?t=${Date.now()}`, {
          cache: 'no-store',
        });
        const data = await response.json();
        if (isMounted) {
          setStatus(data.status);
        }
      } catch (error) {
        console.error('❌ Fetch Error:', error);
        if (isMounted) {
          setStatus(false);
        }
      } finally {
        if (isMounted) {
          setTimeout(fetchData, 30000);
        }
      }
    };

    fetchData(); // Initial call

    return () => {
      isMounted = false;
    };
  }, []);

  // Handle navbar hide/show
  const toggleNavbar = () => {
    setShowNavbar((prev) => !prev);
  };

  const [showScroll, setShowScroll] = useState(false);
  // Scroll-to-top functionality
  const handleScroll = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  // Show Scroll-to-top button when scrolled down
  useEffect(() => {
    const checkScrollTop = () => {
      if (window.pageYOffset > 300) {
        setShowScroll(true);
      } else {
        setShowScroll(false);
      }
    };
    window.addEventListener('scroll', checkScrollTop);
    return () => window.removeEventListener('scroll', checkScrollTop);
  }, []);



  // This is a schedule meeting functionality Start

  const accessbranch = isUserRoleAccess?.role?.includes("Manager")
    ? isAssignBranch?.map((data) => ({
      branch: data.branch,
      company: data.company,
      unit: data.unit,
    }))
    : isAssignBranch
      ?.filter((data) => {
        let fetfinalurl = [];

        if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 &&
          data?.subpagenameurl?.length !== 0 &&
          data?.subsubpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.subsubpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 &&
          data?.subpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.subpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 &&
          data?.mainpagenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.mainpagenameurl;
        } else if (
          data?.modulenameurl?.length !== 0 &&
          data?.submodulenameurl?.length !== 0 && data?.subsubpagenameurl?.includes(window.location.pathname)
        ) {
          fetfinalurl = data.submodulenameurl;
        } else if (data?.modulenameurl?.length !== 0) {
          fetfinalurl = data.modulenameurl;
        } else {
          fetfinalurl = [];
        }

        const remove = [
          window.location.pathname?.substring(1),
          window.location.pathname,
        ];
        return fetfinalurl?.some((item) => remove?.includes(item));
      })
      ?.map((data) => ({
        branch: data.branch,
        company: data.company,
        unit: data.unit,
      }));

  const [meetingArray, setMeetingArray] = useState([]);

  //get all data.
  const fetchMeetingAll = async () => {
    try {
      let res_status = await axios.post(SERVICE.ALL_MEETING, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
        assignbranch: accessbranch,
      });

      const { company, branch, department, team, companyname, _id, username } =
        isUserRoleAccess;

      const result = res_status?.data?.schedulemeeting.filter((data) => {
        const participantsIncludesAll = data?.participants?.includes("ALL");
        const interviewerIncludesAll = data?.interviewer?.includes("ALL");

        if (participantsIncludesAll || interviewerIncludesAll) {
          const companyMatch =
            data?.company?.includes(company) ||
            data?.hostcompany?.includes(company);
          const branchMatch =
            data?.branch?.includes(branch) ||
            data?.hostbranch?.includes(branch);
          const departmentMatch =
            data?.department?.includes(department) ||
            data?.hostdepartment?.includes(department);
          const teamMatch =
            data?.team?.includes(team) || data?.hostteam?.includes(team);
          const participantsOrInterviewerIncludes =
            data?.participants?.includes(companyname) ||
            data?.interviewer?.includes(companyname);

          if (
            (companyMatch &&
              branchMatch &&
              departmentMatch &&
              teamMatch &&
              (participantsIncludesAll || participantsOrInterviewerIncludes)) ||
            interviewerIncludesAll ||
            participantsOrInterviewerIncludes ||
            data?.addedby?.some((item) => item?.name === username)
          ) {
            return true;
          }
        }

        return (
          data?.participantsid?.includes(_id) ||
          data?.participants?.includes(companyname) ||
          data?.meetinghostid?.includes(_id) ||
          data?.interviewer?.includes(companyname) ||
          data?.interviewscheduledby === _id ||
          data?.addedby?.some((item) => item?.name === username)
        );
      });
      if (isUserRoleAccess.role.includes("Manager")) {
        setMeetingArray(
          res_status?.data?.schedulemeeting?.map((t) => {
            const dateParts = t.date.split("-");
            const timeParts = t.time.split(":");
            const durationParts = t.duration.split(":");

            const year = parseInt(dateParts[0]);
            const month = parseInt(dateParts[1]) - 1; // Months are zero-based
            const day = parseInt(dateParts[2]);
            const hours = parseInt(timeParts[0]);
            const minutes = parseInt(timeParts[1]);
            const durationHours = parseInt(durationParts[0]);
            const durationMinutes = parseInt(durationParts[1]);

            const start = new Date(year, month, day, hours, minutes, 0);
            const end = new Date(start);
            end.setHours(end.getHours() + durationHours);
            end.setMinutes(end.getMinutes() + durationMinutes);
            return {
              id: t._id,
              title: t.title,
              start: start,
              end: end,
            };
          })
        );
      } else {
        setMeetingArray(
          result?.map((t) => {
            const dateParts = t.date.split("-");
            const timeParts = t.time.split(":");
            const durationParts = t.duration.split(":");

            const year = parseInt(dateParts[0]);
            const month = parseInt(dateParts[1]) - 1; // Months are zero-based
            const day = parseInt(dateParts[2]);
            const hours = parseInt(timeParts[0]);
            const minutes = parseInt(timeParts[1]);
            const durationHours = parseInt(durationParts[0]);
            const durationMinutes = parseInt(durationParts[1]);

            const start = new Date(year, month, day, hours, minutes, 0);
            const end = new Date(start);
            end.setHours(end.getHours() + durationHours);
            end.setMinutes(end.getMinutes() + durationMinutes);
            return {
              id: t._id,
              title: t.title,
              start: start,
              end: end,
            };
          })
        );
      }
    } catch (err) {
      console.log(err, 'rreej')
      handleApiError(err, setShowAlert, handleClickOpenerr);
    }

  };

  useEffect(() => {
    fetchMeetingAll();
  }, []);

  const [showMeetingDialog, setShowMeetingDialog] = useState(false);
  const [currentMeetings, setCurrentMeetings] = useState([]);

  const monitorTodayMeetings = () => {
    const checkMeetingsToday = async () => {
      // const now = isServerCurrentdatetime?.currentNewDate;
      const time = await getCurrentServerTime();
      const now = new Date(time);

      // Filter all meetings happening today and within the time range
      const matchingMeetings = meetingArray.filter((meeting) => {
        const isToday =
          meeting.start?.getFullYear() === now?.getFullYear() &&
          meeting.start.getMonth() === now.getMonth() &&
          meeting.start.getDate() === now.getDate();

        const isWithinTime = now >= meeting.start && now <= meeting.end;

        return isToday && isWithinTime;
      });

      if (matchingMeetings.length > 0) {
        setCurrentMeetings(matchingMeetings); // Array of meetings
        setShowMeetingDialog(true);
      } else {
        setCurrentMeetings([]);
        setShowMeetingDialog(false);
      }
    };

    checkMeetingsToday();
    const intervalId = setInterval(() => {
      checkMeetingsToday();
    }, 5 * 60 * 1000); // Check every 1 minu
    return () => clearInterval(intervalId);
  };

  useEffect(() => {
    const stop = monitorTodayMeetings();
    return () => stop();
  }, [meetingArray]);


  // This is a schedule meeting functionality End 



  // This event pages wise functionality start ***************************************************************

  const [eventArray, setEventArray] = useState([]);
  // console.log(eventArray, 'eventArray')

  // Fetch all events
  const fetchEventsAll = async () => {
    try {
      let res_status = await axios.post(SERVICE.ALL_EVENT, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
        assignbranch: accessbranch,
      });

      const events = res_status?.data?.scheduleevent || [];

      const filteredEvents = isUserRoleAccess.role.includes("Manager")
        ? events
        : events.filter(
          (event) =>
            event.company.includes(isUserRoleAccess.company) &&
            event.branch.includes(isUserRoleAccess.branch) &&
            event.unit.includes(isUserRoleAccess.unit) &&
            event.team.includes(isUserRoleAccess.team) &&
            (event.participants.includes(isUserRoleAccess.companyname) ||
              event.participants.includes("ALL"))
        );

      const formatted = filteredEvents.map((t) => {
        const dateParts = t.date.split("-");
        const timeParts = t.time.split(":");
        const durationParts = t.duration.split(":");

        const year = parseInt(dateParts[0]);
        const month = parseInt(dateParts[1]) - 1;
        const day = parseInt(dateParts[2]);
        const hours = parseInt(timeParts[0]);
        const minutes = parseInt(timeParts[1]);
        const durationHours = parseInt(durationParts[0]);
        const durationMinutes = parseInt(durationParts[1]);

        const start = new Date(year, month, day, hours, minutes, 0);
        const end = new Date(start);
        end.setHours(end.getHours() + durationHours);
        end.setMinutes(end.getMinutes() + durationMinutes);

        return {
          id: t._id,
          title: t.eventname,
          start,
          end,
        };
      });

      setEventArray(formatted);
    } catch (err) {
      console.log(err, 'err')
      handleApiError(err, setShowAlert, handleClickOpenerr);
    }
  };

  // Initial load
  useEffect(() => {
    fetchEventsAll();
  }, []);


  const [showEventDialog, setShowEventDialog] = useState(false);
  const [currentEvents, setCurrentEvents] = useState([]);

  const monitorTodayEvents = () => {
    const checkEventsToday = async () => {
      // const now = isServerCurrentdatetime?.currentNewDate;
      const time = await getCurrentServerTime();
      const now = new Date(time);


      const matchingEvents = eventArray.filter((event) => {
        const isToday =
          event.start?.getFullYear() === now?.getFullYear() &&
          event.start.getMonth() === now.getMonth() &&
          event.start.getDate() === now.getDate();

        const isWithinTime = now >= event.start && now <= event.end;

        return isToday && isWithinTime;
      });

      if (matchingEvents.length > 0) {
        setCurrentEvents(matchingEvents); // Array of events
        setShowEventDialog(true);
      } else {
        setCurrentEvents([]);
        setShowEventDialog(false);
      }
    };

    checkEventsToday();
    const intervalId = setInterval(() => {
      checkEventsToday();
    }, 5 * 60 * 1000); // Check every 1 minu
    return () => clearInterval(intervalId);
  };

  useEffect(() => {
    const stop = monitorTodayEvents();
    return () => stop();
  }, [eventArray]);

  // This event pages wise functionality End ***************************************************************

  // This is compare server time to internet time functionality start ******************************************

  const [serverTime, setServerTime] = useState(null);
  const [timeDiff, setTimeDiff] = useState(0);

  const [internetTime, setInternetTime] = useState('');
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const intervalRef = useRef(null);
  const timeoutRef = useRef(null);

  const formatDiff = (seconds) => {
    const min = Math.floor(seconds / 60);
    const sec = seconds % 60;
    return `${min} min ${sec} sec`;
  };

  const stopPolling = () => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
  };

  const startPolling = () => {
    if (!intervalRef.current) {
      intervalRef.current = setInterval(fetchAndCompareTime, 10 * 60 * 1000);

    }
  };

  // server time difference functionality
  const fetchAndCompareTime = async () => {
    try {
      const { data } = await axios.get(SERVICE.GET_SERVER_TIME_DIFFERENCE);
      const diff = data.diffInSeconds;

      setServerTime(data.serverFormatted);
      setInternetTime(data.internetFormatted);
      setTimeDiff(diff);

      if (diff > 10) {
        setOpen(true);
        stopPolling();
      } else {
        setOpen(false);
      }

      setError(false);
    } catch (err) {
      setError(true);
      stopPolling();
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAndCompareTime();
    startPolling();

    return () => {
      stopPolling();
      if (timeoutRef.current) clearTimeout(timeoutRef.current);
    };
  }, []);

  const handleDialogClose = () => {
    setOpen(false);


    stopPolling();


    timeoutRef.current = setTimeout(async () => {
      setLoading(true);
      setError(false);
      await fetchAndCompareTime();

      if (timeDiff <= 10) {
        startPolling();
      }
      setLoading(false);
    }, 10 * 60 * 1000);
  };




  // This is compare server time to internet time functionality end **************************************


  return (
    <div>
      {showNavbar && (
        <div
          ref={headerRef}
          style={{
            position: 'fixed',
            top: 0,
            left: 0,
            width: '100%',
            zIndex: 1500,
            opacity: showNavbar ? 1 : 0,
            transition: 'transform 1s ease, opacity 1s ease, width 1s, height 1s',
          }}
        >
          <Header />
        </div>
      )}
      <Box
        className="content"
        sx={{
          position: 'relative',
          marginTop: {
            lg: showNavbar ? `100px` : '20px',
            md: showNavbar ? `100px` : '20px',
            sm: showNavbar ? `125px` : '20px',
            xs: showNavbar ? `125px` : '20px',
          },
          transition: 'margin-top 1s ease',
        }}
      >
        <Outlet />
      </Box>
      <Box
        sx={{
          position: 'fixed',
          top: showNavbar ? 85 : 20,
          right: showNavbar ? 300 : 50,
          zIndex: 1499,
          transition: 'margin-top 1s ease, right 1s ease',
        }}
      >
        <Tooltip title={showStatus ? 'Server Online' : 'Server Offline'} arrow placement="left">
          <span>
            {' '}
            {/* Ensures tooltip shows on hover, especially if disabled */}
            <FormControlLabel
              control={
                <StatusSwitch
                  defaultChecked
                  checked={showStatus}
                  buttonStyles={buttonStyles}
                // onClick={toggleStatus}
                />
              }
            />
          </span>
        </Tooltip>
      </Box>
      <Box>
        <FormControlLabel
          sx={{
            position: 'fixed',
            top: showNavbar ? 85 : 20,
            right: showNavbar ? 252 : 0,
            zIndex: 1499,
            transition: 'margin-top 1s ease, right 1s ease',
          }}
          control={<NavbarSwitch defaultChecked checked={showNavbar} buttonStyles={buttonStyles} onClick={toggleNavbar} />}
        />
      </Box>
      {isUserRoleCompare?.includes('araiseproblem') && <ScreenShot showScroll={showScroll} />}
      {/* Scroll-to-top button */}
      {showScroll && (
        <Button
          onClick={handleScroll}
          sx={{
            position: 'fixed',
            bottom: 30,
            right: 30,
            // zIndex: 2000,
            color: 'black',
            minWidth: '50px',
            height: '3rem',
            width: '3rem',
            fontSize: '5rem',
            borderRadius: '50%',
            cursor: 'pointer',
            backgroundColor: 'transparent',
            boxShadow: '0px 3px 8px #aaa, inset 0px 2px 3px #fff',
            '&. hover': {
              backgroundColor: 'transparent',
              boxShadow: '0px 3px 8px #aaa, inset 0px 2px 3px #fff',
            },
          }}
        >
          <KeyboardArrowUpTwoToneIcon style={{ fontSize: '30px' }} />
        </Button>
      )}


      {/* Dialog for meeting alert start */}
      <Dialog
        open={showMeetingDialog}
        onClose={() => setShowMeetingDialog(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          style: {
            borderRadius: 24,
            width: 400, // 👈 add this line to reduce size
            padding: 0,
            background: "linear-gradient(145deg, #ffffff 0%, #f8faff 100%)",
            boxShadow: "0 12px 40px rgba(0, 0, 0, 0.18)",
            overflow: "hidden",
          },
        }}
      >
        {/* Header with gradient background */}
        <Box
          sx={{
            background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
            color: "white",
            p: 3,
            textAlign: "center",
          }}
        >
          <MeetingRoomIcon sx={{ fontSize: 28, mb: 1, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.2))" }} />
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            Today's Ongoing Meetings
          </Typography>
          <Typography variant="subtitle2" sx={{ opacity: 0.9 }}>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </Typography>
        </Box>

        <DialogContent sx={{ pt: 3, pb: 1 }}>
          {currentMeetings.length > 0 &&
            currentMeetings.map((meeting, idx) => (
              <Box
                key={meeting.id}
                sx={{
                  mb: 2,
                  p: 2.5,
                  borderRadius: 3,
                  backgroundColor: "white",
                  boxShadow: "0 4px 12px rgba(25, 118, 210, 0.08)",
                  border: "1px solid rgba(25, 118, 210, 0.1)",
                  transition: "all 0.3s cubic-bezier(.25,.8,.25,1)",
                  "&:hover": {
                    transform: "translateY(-2px)",
                    boxShadow: "0 6px 16px rgba(25, 118, 210, 0.12)",
                  },
                }}
              >
                <Box display="flex" alignItems="flex-start">
                  <Box
                    sx={{
                      background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
                      color: "white",
                      borderRadius: "50%",
                      width: 18,
                      height: 18,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      mr: 2,
                      mt: 0.5,
                      fontSize: 12,
                      fontWeight: "bold",
                    }}
                  >
                    {idx + 1}
                  </Box>
                  <Box flexGrow={1}>
                    <Typography variant="subtitle1" fontWeight={400} gutterBottom>
                      {meeting.title}
                    </Typography>

                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      📅{" "}
                      {meeting.start.toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </Typography>

                    <Box display="flex" alignItems="center" mt={0.5}>
                      <AccessTimeIcon sx={{ fontSize: 12, mr: 0.5, color: "#1976d2" }} />
                      <Typography variant="body2" color="text.secondary">
                        {meeting.start.toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                          hour12: true,
                        })}{" "}
                        –{" "}
                        {meeting.end.toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                          hour12: true,
                        })}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            ))}
        </DialogContent>

        <DialogActions sx={{ justifyContent: "center", p: 3, pt: 0 }}>
          <Button
            onClick={() => setShowMeetingDialog(false)}
            variant="contained"
            sx={{
              borderRadius: 50,
              px: 4,
              py: 1.2,
              background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
              fontWeight: "bold",
              textTransform: "none",
              fontSize: "15px",
              boxShadow: "0 4px 12px rgba(25, 118, 210, 0.3)",
              "&:hover": {
                background: "linear-gradient(135deg, #1565c0 0%, #4a9ed8 100%)",
                boxShadow: "0 6px 16px rgba(25, 118, 210, 0.4)",
              },
            }}
          >
            Got it!
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog for meeting alert end*/}

      {/* Dialog for event alert start */}
      <Dialog
        open={showEventDialog}
        onClose={() => setShowEventDialog(false)}
        maxWidth="sm"
        fullWidth
        PaperProps={{
          style: {
            borderRadius: 24,
            width: 400, // 👈 add this line to reduce size
            padding: 0,
            background: "linear-gradient(145deg, #ffffff 0%, #f8faff 100%)",
            boxShadow: "0 12px 40px rgba(0, 0, 0, 0.18)",
            overflow: "hidden",
          },
        }}
      >
        {/* Header with gradient background */}
        <Box
          sx={{
            background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
            color: "white",
            p: 3,
            textAlign: "center",
          }}
        >
          <EventIcon sx={{ fontSize: 28, mb: 1, filter: "drop-shadow(0 2px 4px rgba(0,0,0,0.2))" }} />
          <Typography variant="h5" fontWeight="bold" gutterBottom>
            Today's Ongoing Events
          </Typography>
          <Typography variant="subtitle2" sx={{ opacity: 0.9 }}>
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </Typography>
        </Box>

        <DialogContent sx={{ pt: 3, pb: 1 }}>
          {currentEvents.length > 0 &&
            currentEvents.map((event, idx) => (
              <Box
                key={event.id}
                sx={{
                  mb: 2,
                  p: 2.5,
                  borderRadius: 3,
                  backgroundColor: "white",
                  boxShadow: "0 4px 12px rgba(25, 118, 210, 0.08)",
                  border: "1px solid rgba(25, 118, 210, 0.1)",
                  transition: "all 0.3s cubic-bezier(.25,.8,.25,1)",
                  "&:hover": {
                    transform: "translateY(-2px)",
                    boxShadow: "0 6px 16px rgba(25, 118, 210, 0.12)",
                  },
                }}
              >
                <Box display="flex" alignItems="flex-start">
                  <Box
                    sx={{
                      background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
                      color: "white",
                      borderRadius: "50%",
                      width: 18,
                      height: 18,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "center",
                      mr: 2,
                      mt: 0.5,
                      fontSize: 12,
                      fontWeight: "bold",
                    }}
                  >
                    {idx + 1}
                  </Box>
                  <Box flexGrow={1}>
                    <Typography variant="subtitle1" fontWeight={400} gutterBottom>
                      {event.title}
                    </Typography>

                    <Typography variant="body2" color="text.secondary" gutterBottom>
                      📅{" "}
                      {event.start.toLocaleDateString("en-US", {
                        year: "numeric",
                        month: "long",
                        day: "numeric",
                      })}
                    </Typography>

                    <Box display="flex" alignItems="center" mt={0.5}>
                      <AccessTimeIcon sx={{ fontSize: 12, mr: 0.5, color: "#1976d2" }} />
                      <Typography variant="body2" color="text.secondary">
                        {event.start.toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                          hour12: true,
                        })}{" "}
                        –{" "}
                        {event.end.toLocaleTimeString("en-US", {
                          hour: "2-digit",
                          minute: "2-digit",
                          hour12: true,
                        })}
                      </Typography>
                    </Box>
                  </Box>
                </Box>
              </Box>
            ))}
        </DialogContent>

        <DialogActions sx={{ justifyContent: "center", p: 3, pt: 0 }}>
          <Button
            onClick={() => setShowEventDialog(false)}
            variant="contained"
            sx={{
              borderRadius: 50,
              px: 4,
              py: 1.2,
              background: "linear-gradient(135deg, #1976d2 0%, #5ab1f4 100%)",
              fontWeight: "bold",
              textTransform: "none",
              fontSize: "15px",
              boxShadow: "0 4px 12px rgba(25, 118, 210, 0.3)",
              "&:hover": {
                background: "linear-gradient(135deg, #1565c0 0%, #4a9ed8 100%)",
                boxShadow: "0 6px 16px rgba(25, 118, 210, 0.4)",
              },
            }}
          >
            Got it!
          </Button>
        </DialogActions>
      </Dialog>

      {/* Dialog for event alert end*/}

      {/* Dialog for time mismatch alert Start*/}



      <Dialog
        open={open}
        onClose={handleDialogClose}
        PaperProps={{
          sx: {
            borderRadius: 4,
            p: 2,
            width: '100%',
            maxWidth: 500,
            boxShadow: 24,
            backgroundColor: '#fffefc',
          },
        }}
      >
        <DialogTitle
          sx={{
            display: 'flex',
            alignItems: 'center',
            gap: 1,
            fontWeight: 700,
            fontSize: '1.3rem',
            color: '#d32f2f',
          }}
        >
          ⚠️ Time Mismatch Alert
        </DialogTitle>

        <DialogContent dividers>
          <Box sx={{ mb: 2 }}>
            <Typography variant="body1" sx={{ mb: 1 }}>
              <strong>🔍 We've detected a mismatch between your system's time and the official IST:</strong>
            </Typography>

            <Typography variant="body2" sx={{ mb: 0.5 }}>
              <strong>🕒 Time Difference:</strong>{' '}
              <span style={{ color: '#ff5722', fontWeight: 'bold', fontSize: '1rem' }}>
                {formatDiff(timeDiff)}
              </span>
            </Typography>

            <Typography variant="body2" sx={{ mb: 0.5 }}>
              <strong>🌐 Official IST Time:</strong> {internetTime}
            </Typography>

            <Typography variant="body2" sx={{ mb: 1 }}>
              <strong>🖥️ Your Server Time:</strong> {serverTime}
            </Typography>
          </Box>
        </DialogContent>

        <DialogActions sx={{ px: 3, py: 2, justifyContent: 'flex-end' }}>
          <Button
            onClick={handleDialogClose}
            variant="contained"
            color="primary"
            sx={{ textTransform: 'none', fontWeight: 'bold' }}
          >
            Continue Anyway
          </Button>
        </DialogActions>
      </Dialog>


      {/* Dialog for time mismatch alert End*/}

    </div>
  );
};

export default Layout;
