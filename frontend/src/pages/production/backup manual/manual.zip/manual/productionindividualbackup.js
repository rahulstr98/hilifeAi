import React, { useState, useEffect, useRef, useContext } from "react";
import { Box, Typography, OutlinedInput, TextareaAutosize, TableBody, TableRow, Chip, TableCell, Select, Paper, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Table, TableHead, TableContainer, Button, List, ListItem, ListItemText, Popover, Checkbox, TextField, IconButton } from "@mui/material";
import { userStyle, colourStyles } from "../../../pageStyle";
import { FaPrint, FaFilePdf, FaTrash } from "react-icons/fa";
import { ExportXL, ExportCSV } from "../../../components/Export";
import { StyledTableRow, StyledTableCell } from "../../../components/Table";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from "axios";
import Selects from "react-select";
import { SERVICE } from "../../../services/Baseservice";
import { handleApiError } from "../../../components/Errorhandling";
import StyledDataGrid from "../../../components/TableStyle";
import ErrorOutlineOutlinedIcon from "@mui/icons-material/ErrorOutlineOutlined";
import DeleteOutlineOutlinedIcon from "@mui/icons-material/DeleteOutlineOutlined";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import moment from "moment-timezone";
import { useReactToPrint } from "react-to-print";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import { makeStyles } from "@material-ui/core";
import { UserRoleAccessContext } from "../../../context/Appcontext";
import { AuthContext } from "../../../context/Appcontext";
import Headtitle from "../../../components/Headtitle";
import { ThreeDots } from "react-loader-spinner";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import { DataGrid } from "@mui/x-data-grid";
import { styled } from "@mui/system";
import Resizable from "react-resizable";
import ExcelJS from "exceljs";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import Switch from "@mui/material/Switch";
import CloseIcon from "@mui/icons-material/Close";
import ContentPasteIcon from "@mui/icons-material/ContentPaste";
import html2canvas from "html2canvas";
import ImageIcon from "@mui/icons-material/Image";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import * as FileSaver from 'file-saver';
import * as XLSX from 'xlsx';
import PictureAsPdfIcon from '@mui/icons-material/PictureAsPdf';
import { FaFileExcel, FaFileCsv } from 'react-icons/fa';
import Pagination from '../../../components/Pagination';
import PageHeading from "../../../components/PageHeading";
import AggregatedSearchBar from "../../../components/AggregatedSearchBar";
import AggridTable from "../../../components/AggridTable";
import domtoimage from 'dom-to-image';
import ExportData from "../../../components/ExportData";



function ProductionIndividual() {
    const [isHandleChange, setIsHandleChange] = useState(false);
    const [searchedString, setSearchedString] = useState("");
    const gridRefTable = useRef(null);
    const gridRefTableImg = useRef(null);

    const gridRef = useRef(null);
    const [pageNumbers, setPageNumbers] = useState([]);
    const [visiblePages, setVisiblePages] = useState(3);

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => {
        setOpenPopupMalert(true);
    };
    const handleClosePopupMalert = () => {
        setOpenPopupMalert(false);
    };
    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => {
        setOpenPopup(true);
    };
    const handleClosePopup = () => {
        setOpenPopup(false);
    };



    const status = [
        { label: "Completed", value: "Completed" },
        { label: "In Complete", value: "In Complete" },
        { label: "Partial Complete", value: "Partial Complete" },
    ];


    const statuschange = [
        { label: "Completed", value: "Completed" },
        { label: "In Complete", value: "In Complete" },
        { label: "Partial Complete", value: "Partial Complete" },
        { label: " Pause", value: "Pause" },
        { label: "Reject", value: "Reject" },
        { label: "Cancel", value: "Cancel" },
    ];



    //    today date fetching
    let today = new Date();
    var dd = String(today.getDate()).padStart(2, "0");
    var mm = String(today.getMonth() + 1).padStart(2, "0");
    var yyyy = today.getFullYear();
    // today = yyyy + "-" + mm + "-" + dd;
    const formattedToday = `${yyyy}-${mm}-${dd}`;

    // Calculate the date two months ago
    // const twoMonthsAgo = new Date(today.setMonth(today.getMonth() - 2));
    // const ddPast = String(twoMonthsAgo.getDate()).padStart(2, "0");
    // const mmPast = String(twoMonthsAgo.getMonth() + 1).padStart(2, "0");
    // const yyyyPast = twoMonthsAgo.getFullYear();
    // const formattedTwoMonthsAgo = `${yyyyPast}-${mmPast}-${ddPast}`;

    const [isFilterOpen, setIsFilterOpen] = useState(false);
    const [isPdfFilterOpen, setIsPdfFilterOpen] = useState(false);

    // page refersh reload
    const handleCloseFilterMod = () => {
        setIsFilterOpen(false);
    };

    const handleClosePdfFilterMod = () => {
        setIsPdfFilterOpen(false);
    };

    const [projmasterDup, setProjmasterDup] = useState([])


    // Calculate the date two months ago
    const twoMonthsAgo = new Date();
    twoMonthsAgo.setMonth(today.getMonth() - 2);
    const ddPast = String(twoMonthsAgo.getDate()).padStart(2, "0");
    const mmPast = String(twoMonthsAgo.getMonth() + 1).padStart(2, "0");
    const yyyyPast = twoMonthsAgo.getFullYear();
    const formattedTwoMonthsAgo = `${yyyyPast}-${mmPast}-${ddPast}`;

    const handleDateChange = (e) => {
        const selectedDate = new Date(e.target.value);
        const minDate = new Date(formattedTwoMonthsAgo);
        const maxDate = new Date(formattedToday);

        if (ProducionIndividual.datemode === 'Manual') {
            if (selectedDate >= minDate && selectedDate <= maxDate) {
                setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
            } else {
                // alert('Please select a date within the past two months and not in the future.');
                setShowAlert(
                    <>
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "100px", color: "orange" }}
                        />
                        <p style={{ fontSize: "20px", fontWeight: 900 }}>
                            {"Please select a date within the past two months and not in the future."}
                        </p>
                    </>
                );
                handleClickOpenerr();

            }
        } else {
            setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
        }
    };


    const handleDateChangeEdit = (e) => {
        const selectedDate = new Date(e.target.value);
        const minDate = new Date(formattedTwoMonthsAgo);
        const maxDate = new Date(formattedToday);

        if (ProducionIndividualChange.datemode === 'Manual') {
            if (selectedDate >= minDate && selectedDate <= maxDate) {
                setProducionIndividualChange({ ...ProducionIndividualChange, fromdate: e.target.value });
            } else {
                // alert('Please select a date within the past two months and not in the future.');
                setShowAlert(
                    <>
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "100px", color: "orange" }}
                        />
                        <p style={{ fontSize: "20px", fontWeight: 900 }}>
                            {"Please select a date within the past two months and not in the future."}
                        </p>
                    </>
                );
                handleClickOpenerr();

            }
        } else {
            setProducionIndividualChange({ ...ProducionIndividualChange, fromdate: e.target.value });
        }
    };


    const handleDateChangeStart = (e) => {
        const selectedDate = new Date(e.target.value);
        const minDate = new Date(formattedTwoMonthsAgo);
        const maxDate = new Date(formattedToday);

        if (ProducionIndividual.datemode === 'Manual') {
            if (selectedDate >= minDate && selectedDate <= maxDate) {
                setProducionIndividual({ ...ProducionIndividual, startdate: e.target.value });
            } else {
                // alert('Please select a date within the past two months and not in the future.');
                setShowAlert(
                    <>
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "100px", color: "orange" }}
                        />
                        <p style={{ fontSize: "20px", fontWeight: 900 }}>
                            {"Please select a date within the past two months and not in the future."}
                        </p>
                    </>
                );
                handleClickOpenerr();

            }
        } else {
            setProducionIndividual({ ...ProducionIndividual, startdate: e.target.value });
        }
    };



    let now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    let currtime = `${hours}:${minutes}`;


    const [selectedRows, setSelectedRows] = useState([]);

    const [searchQueryManage, setSearchQueryManage] = useState("");

    const [ProducionIndividual, setProducionIndividual] = useState({
        vendor: "Please Select Vendor", fromdate: formattedToday, time: currtime, datemode: "Auto", datetimezone: "", category: "Please Select Subcategory",
        filename: "Please Select Category", unitid: "", alllogin: "Please Select AllLogin", user: "Please Select Loginid", mode: "", docnumber: "", doclink: "",


        statusmode: "Please Select Status", flagcount: 0, section: "1", addedby: "", updatedby: "", pendingpages: "", notes: "",
        totalpages: 0, completepages: 0, startpage: "Please Select Start Page", reason: "", startdate: formattedToday, starttime: currtime, startdatemode: "Auto",


    });


    const [ProducionIndividualChange, setProducionIndividualChange] = useState({
        vendor: "Please Select Vendor", fromdate: formattedToday, time: currtime, datemode: "Auto", datetimezone: "", category: "Please Select Subcategory",
        filename: "Please Select Category", unitid: "", alllogin: "Please Select AllLogin", user: "Please Select Loginid", mode: "", docnumber: "", doclink: "",
        statusmode: "Please Select Status", flagcount: "", section: "1", pendingpages: "",
        // addedby: "", updatedby: "", 
        totalpages: "", completepages: "", startpage: "Please Select Start Page", reason: "", startdate: formattedToday, starttime: currtime, startdatemode: "Auto",


    });

    //change form
    const handleChangephonenumber = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers
        // const regex = /^\d*\.?\d*$/;

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            // Update the state with the valid numeric value
            setProducionIndividual({ ...ProducionIndividual, section: inputValue });
        }
    };

    // const handleChangephonenumberflag = (e) => {
    //     // Regular expression to match only positive numeric values
    //     const regex = /^[0-9]+$/; // Only allows positive integers
    //     // const regex = /^\d*\.?\d*$/;

    //     const inputValue = e.target.value;

    //     // Check if the input value matches the regex or if it's empty (allowing backspace)
    //     if (regex.test(inputValue) || inputValue === "") {
    //         // Update the state with the valid numeric value
    //         setProducionIndividual({ ...ProducionIndividual, flagcount: inputValue });
    //     }
    // };


    const handleChangephonenumberflag = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            // Check if the input value exceeds totalpages

            // Update the state with the valid numeric value
            setProducionIndividual({ ...ProducionIndividual, flagcount: inputValue });

        }
    };



    const handleChangephonenumberflagCompleted = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            let difference = Number(ProducionIndividual.totalpages) - Number(inputValue)
            // Check if the input value exceeds totalpages
            if (parseInt(inputValue) > parseInt(ProducionIndividual.totalpages)) {
                // alert("Completed pages cannot be greater than total pages.");
                setShowAlert(
                    <>
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "100px", color: "orange" }}
                        />
                        <p style={{ fontSize: "20px", fontWeight: 900 }}>
                            {"Completed pages cannot be greater than total pages"}
                        </p>
                    </>
                );
                handleClickOpenerr();
            } else {
                // Update the state with the valid numeric value
                setProducionIndividual({ ...ProducionIndividual, flagcount: inputValue, startpage: "Please Select Start Page", pendingpages: difference });
            }
        }
    };

    const handleChangephonenumberflagChange = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            let difference = Number(ProducionIndividualChange.totalpages) - Number(inputValue)
            // Check if the input value exceeds totalpages
            if (parseInt(inputValue) > parseInt(ProducionIndividualChange.totalpages)) {
                // alert("Completed pages cannot be greater than total pages.");
                setShowAlert(
                    <>
                        <ErrorOutlineOutlinedIcon
                            sx={{ fontSize: "100px", color: "orange" }}
                        />
                        <p style={{ fontSize: "20px", fontWeight: 900 }}>
                            {"Completed pages cannot be greater than total pages"}
                        </p>
                    </>
                );
                handleClickOpenerr();
            } else {
                // Update the state with the valid numeric value
                setProducionIndividualChange({ ...ProducionIndividualChange, flagcount: inputValue, startpage: "Please Select Start Page", pendingpages: difference });
            }
        }
    };






    const handleChangephonenumbertotal = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers
        // const regex = /^\d*\.?\d*$/;

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            // Update the state with the valid numeric value
            let difference = Number(inputValue) - Number(0)
            setProducionIndividual({ ...ProducionIndividual, totalpages: inputValue, startpage: "Please Select Start Page", flagcount: 0, pendingpages: difference });
        }
    };


    const handleChangephonenumbertotalChange = (e) => {
        // Regular expression to match only positive numeric values
        const regex = /^[0-9]+$/; // Only allows positive integers
        // const regex = /^\d*\.?\d*$/;

        const inputValue = e.target.value;

        // Check if the input value matches the regex or if it's empty (allowing backspace)
        if (regex.test(inputValue) || inputValue === "") {
            // Update the state with the valid numeric value
            let difference = Number(inputValue) - Number(0)
            setProducionIndividualChange({ ...ProducionIndividualChange, totalpages: inputValue, startpage: "Please Select Start Page", flagcount: 0, pendingpages: difference });
        }
    };





    const [vendors, setVendors] = useState([]);

    const [productionedit, setProductionEdit] = useState({
        vendor: "Please Select Vendor", fromdate: "", time: "", datemode: "", datetimezone: "", category: "Please Select Subcategory",
        filename: "Please Select Category", unitid: "", alllogin: "Please Select AllLogin", user: "Please Select Loginid", docnumber: "", doclink: "",
        flagcount: "", section: "",
    });
    const [projmaster, setProjmaster] = useState([]);
    const { isUserRoleCompare, isUserRoleAccess, pageName, setPageName, buttonStyles,
    } = useContext(UserRoleAccessContext);
    const { auth } = useContext(AuthContext);
    const [projectCheck, setProjectCheck] = useState(false);

    //Datatable
    const [page, setPage] = useState(1);
    const [pageSize, setPageSize] = useState(10);

    const [isErrorOpen, setIsErrorOpen] = useState(false);
    const [showAlert, setShowAlert] = useState();

    const [openview, setOpenview] = useState(false);
    const [openInfo, setOpeninfo] = useState(false);

    const [isDeleteOpen, setIsDeleteOpen] = useState(false);
    const [deleteproject, setDeleteproject] = useState({});
    const [isEditOpen, setIsEditOpen] = useState(false);

    const [projectData, setProjectData] = useState([]);
    const [items, setItems] = useState([]);
    const [searchQuery, setSearchQuery] = useState("");

    const [allProjectedit, setAllProjectedit] = useState([]);

    const [checkvendor, setCheckvendor] = useState();
    const [checkcategory, setCheckcategory] = useState();
    const [checksubcategory, setChecksubcategory] = useState();
    const [checktimepoints, setChecktimepoints] = useState();

    const [copiedData, setCopiedData] = useState("");

    const [canvasState, setCanvasState] = useState(false);



    let datemodes = isUserRoleCompare.includes("lproductionindividualusers") ||
        isUserRoleAccess.role.includes("Manager")
        || isUserRoleAccess.role.includes("Director")
        || isUserRoleAccess.role.includes("Admin")
        || isUserRoleAccess.role.includes("SuperAdmin") ||
        isUserRoleAccess.role.includes("ADMIN")
        ? [{ label: "Auto", value: "Auto" }, { label: "Manual", value: "Manual" }] : [{ label: "Auto", value: "Auto" }]


    //image

    const handleCaptureImage = () => {
        if (gridRef.current) {
            html2canvas(gridRef.current).then((canvas) => {
                canvas.toBlob((blob) => {
                    saveAs(blob, 'Production Manual Entry.png');
                });
            });
        }
    };

    const handleSelectionChange = (newSelection) => {
        setSelectedRows(newSelection.selectionModel);
    };

    // Error Popup model

    const handleClickOpenerr = () => {
        setIsErrorOpen(true);
    };
    const handleCloseerr = () => {
        setIsErrorOpen(false);
    };

    // view model
    const handleClickOpenview = () => {
        setOpenview(true);
    };

    const handleCloseview = () => {
        setOpenview(false);
    };

    //check delete model
    const [isCheckOpen, setisCheckOpen] = useState(false);
    const handleClickOpenCheck = () => {
        setisCheckOpen(true);
    };
    const handleCloseCheck = () => {
        setisCheckOpen(false);
    };

    // info model
    const handleClickOpeninfo = () => {
        setOpeninfo(true);
    };

    const handleCloseinfo = () => {
        setOpeninfo(false);
    };

    //Delete model
    const handleClickOpen = () => {
        setIsDeleteOpen(true);
    };
    const handleCloseMod = () => {
        setIsDeleteOpen(false);
    };

    //Delete model
    const [isDeleteOpenalert, setIsDeleteOpenalert] = useState(false);

    const handleClickOpenalert = () => {
        if (selectedRows.length == 0) {
            setIsDeleteOpenalert(true);
        } else {
            setIsDeleteOpencheckbox(true);
        }
    };
    const handleCloseModalert = () => {
        setIsDeleteOpenalert(false);
    };

    //Delete model
    const [isDeleteOpencheckbox, setIsDeleteOpencheckbox] = useState(false);

    const handleClickOpencheckbox = () => {
        setIsDeleteOpencheckbox(true);
    };
    const handleCloseModcheckbox = () => {
        setIsDeleteOpencheckbox(false);
    };

    // Error Popup model
    const [isErrorOpenpop, setIsErrorOpenpop] = useState(false);
    const [showAlertpop, setShowAlertpop] = useState();
    const handleClickOpenerrpop = () => {
        setIsErrorOpenpop(true);
    };
    const handleCloseerrpop = () => {
        setIsErrorOpenpop(false);
    };

    // page refersh reload code
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    const username = isUserRoleAccess.username;
    const userData = {
        name: username,
        date: new Date(),
    };

    // Manage Columns
    const [isManageColumnsOpen, setManageColumnsOpen] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null);

    const handleOpenManageColumns = (event) => {
        setAnchorEl(event.currentTarget);
        setManageColumnsOpen(true);
    };
    const handleCloseManageColumns = () => {
        setManageColumnsOpen(false);
        setSearchQueryManage("");
    };

    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;



    const getRowClassName = (params) => {
        if (selectedRows.includes(params.data.id)) {
            return "custom-id-row"; // This is the custom class for rows with item.tat === 'ago'
        }
        return ""; // Return an empty string for other rows
    };

    // Show All Columns & Manage Columns
    const initialColumnVisibility = {
        serialNumber: true,
        checkbox: true,
        vendor: true,
        datemode: true,
        fromdate: true,
        time: true,
        filename: true,
        category: true,

        unitid: true,
        user: true,
        section: true,
        flagcount: true,
        alllogin: true,
        docnumber: true,
        doclink: true,
        approvalstatus: true,
        lateentrystatus: true,


        startmode: true,
        startdate: true,
        starttime: true,
        status: true,
        totalpages: true,
        flagcount: true,
        pendingpages: true,
        startpage: true,
        reason: true,
        statusmode: true,
        enddate: true,
        endtime: true,
        notes: true,

        actions: true,
        actionsstatus: true,
    };

    const [columnVisibility, setColumnVisibility] = useState(initialColumnVisibility);

    //set function to get particular row
    const rowData = async (id, name) => {
        try {
            let res = await axios.get(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${id}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setDeleteproject(res?.data?.sProductionIndividual);
            handleClickOpen();

        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    // Alert delete popup
    let projectid = deleteproject._id;
    const delProject = async () => {
        try {
            await axios.delete(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${projectid}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            await fetchEmployee();
            await fetchProductionIndividual();
            handleCloseMod();
            setSelectedRows([]);
            setPage(1);
            setIsHandleChange(false)
            setPopupContent("Deleted Successfully");
            setPopupSeverity("success");
            handleClickOpenPopup();
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    const delProjectcheckbox = async () => {
        try {

            const deletePromises = selectedRows?.map((item) => {
                return axios.delete(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${item}`, {
                    headers: {
                        Authorization: `Bearer ${auth.APIToken}`,
                    },
                });
            });

            // Wait for all delete requests to complete
            await Promise.all(deletePromises);

            await fetchEmployee();
            await fetchProductionIndividual();
            handleCloseModcheckbox();
            setSelectedRows([]);
            setSelectAllChecked(false);
            setIsHandleChange(false)
            setPage(1);
            setPopupContent("Deleted Successfully");
            setPopupSeverity("success");
            handleClickOpenPopup();
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };



    //add function
    const sendRequest = async () => {
        setPageName(!pageName)

        try {
            const fromDate = new Date(`${ProducionIndividual.fromdate}T${ProducionIndividual.time}:00`);
            const fromDatePlus48Hours = new Date(fromDate.getTime() + 48 * 60 * 60 * 1000);

            let projectscreate = await axios.post(SERVICE.PRODUCTION_INDIVIDUAL_CREATE, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                vendor: String(ProducionIndividual.vendor),
                datemode: String(ProducionIndividual.datemode),


                fromdate: String(ProducionIndividual.fromdate),
                time: String(ProducionIndividual.time),



                filename: String(ProducionIndividual.filename),
                category: String(ProducionIndividual.category),
                unitid: String(ProducionIndividual.unitid),
                user: String(ProducionIndividual.user),
                mode: "Manual",
                section: String(ProducionIndividual.section),
                flagcount: String(ProducionIndividual.flagcount),
                alllogin: String(ProducionIndividual.alllogin),
                docnumber: String(ProducionIndividual.docnumber),
                doclink: String(ProducionIndividual.doclink),

                startmode: projectmaster ? String(ProducionIndividual.startdatemode) : "",
                startdate: String(ProducionIndividual.startdate),
                starttime: String(ProducionIndividual.starttime),
                statusmode: String(ProducionIndividual.statusmode),
                totalpages: String(ProducionIndividual.totalpages),
                pendingpages: Number(ProducionIndividual.pendingpages),
                startpage: String(ProducionIndividual.startpage),
                reason: String(ProducionIndividual.reason),
                notes: String(ProducionIndividual.notes),



                approvalstatus: "",
                approvaldate: "",
                lateentrystatus: (new Date() > fromDatePlus48Hours) ? "Late Entry" : "On Entry",

                addedby: [
                    {
                        name: String(isUserRoleAccess.companyname),
                        date: String(new Date()),
                    },
                ],
            });
            setProducionIndividual(projectscreate.data);
            await fetchEmployee();
            await fetchProductionIndividual();
            setProducionIndividual({
                ...ProducionIndividual, fromdate: formattedToday, time: currtime, datetimezone: "",
                unitid: "", docnumber: "", doclink: "", section: 1, datemode: "Auto",
                flagcount: 1
            });
            setPopupContent("Added Successfully");
            setPopupSeverity("success");
            handleClickOpenPopup()
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    //submit option for saving
    const handleSubmit = (e) => {
        setPageName(!pageName)
        e.preventDefault();
        const isNameMatch = projmasterDup?.some((item) =>
            item.vendor?.toLowerCase() === ProducionIndividual.vendor?.toLowerCase() &&
            item.filename?.toLowerCase() === ProducionIndividual.filename?.toLowerCase() &&
            item.category?.toLowerCase() === ProducionIndividual.category?.toLowerCase() &&
            item.unitid?.toLowerCase() === ProducionIndividual.unitid?.toLowerCase() &&
            item.user?.toLowerCase() === ProducionIndividual.user?.toLowerCase() &&
            item.alllogin?.toLowerCase() === ProducionIndividual.alllogin?.toLowerCase()
        );

        if (ProducionIndividual.vendor === "Please Select Vendor") {

            setPopupContentMalert("Please Select Vendor!");
            setPopupSeverityMalert("info");
            handleClickOpenPopupMalert();
        }
        else if (ProducionIndividual.datemode === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Date Mode"}</p>l
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.datemode === "Manual" && ProducionIndividual.fromdate === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Date"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.datemode === "Manual" && ProducionIndividual.time === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Time"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.filename === "Please Select Category") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Category"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.category === "Please Select Subcategory") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select SubCategory"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.unitid === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Identifier"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.user === "Please Select Loginid") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Login Id"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.section === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Section"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (!projectmaster && (ProducionIndividual.flagcount === "" || ProducionIndividual.flagcount === 0)) {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Flagcount"}</p>
                </>
            );
            handleClickOpenerr();
        }

        else if (projectmaster && (ProducionIndividual.totalpages === "" || ProducionIndividual.totalpages === 0)) {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Total Pages"}</p>
                </>
            );
            handleClickOpenerr();
        }

        else if (projectmaster && (ProducionIndividual.flagcount === "" || ProducionIndividual.flagcount === 0)) {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Completed Pages"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.pendingpages === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Pending Pages"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividual.alllogin === "Please Select AllLogin") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select AllLogin"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.statusmode === "Please Select Status") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Status"}</p>
                </>
            );
            handleClickOpenerr();
        }


        else if (projectmaster && ProducionIndividual.startdatemode === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Start Date Mode"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.startdatemode === "Manual" && ProducionIndividual.fromdate === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Date"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.startdatemode === "Manual" && ProducionIndividual.time === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Time"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.pendingpages > 0 && ProducionIndividual.startpage === "Please Select Start Page") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Start Page"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.startdatemode === "Manual" && ProducionIndividual.fromdate === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Date"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (projectmaster && ProducionIndividual.startdatemode === "Manual" && ProducionIndividual.time === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Time"}</p>
                </>
            );
            handleClickOpenerr();
        }

        else if (projectmaster && ProducionIndividual.notes === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Notes/Remarks"}</p>
                </>
            );
            handleClickOpenerr();
        }


        else if (isNameMatch) {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Data Already exists"}</p>
                </>
            );
            handleClickOpenerr();
        }
        // else if (ProducionIndividual.docnumber === "") {
        //     setShowAlert(
        //         <>
        //             <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
        //             <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Docnumber"}</p>
        //         </>
        //     );
        //     handleClickOpenerr();
        // }
        // else if (ProducionIndividual.doclink === "") {
        //     setShowAlert(
        //         <>
        //             <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
        //             <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Doclink"}</p>
        //         </>
        //     );
        //     handleClickOpenerr();
        // }
        // else if (isNameMatch) {
        //     setShowAlert(
        //         <>
        //             <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
        //             <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Name already exits!"}</p>
        //         </>
        //     );
        //     handleClickOpenerr();
        // } 
        else {
            sendRequest();
        }
    };

    const handleclear = (e) => {
        e.preventDefault();
        setProducionIndividual({
            vendor: "Please Select Vendor", fromdate: formattedToday, time: currtime, datemode: "Auto", datetimezone: "", category: "Please Select Subcategory",
            filename: "Please Select Category", unitid: "", alllogin: "Please Select AllLogin", user: "Please Select Loginid", docnumber: "", doclink: "",
            flagcount: 1, section: 1, statusmode: "Please Select Status", flagcount: 0, section: "1", addedby: "", updatedby: "", pendingpages: "",
            totalpages: 0, completepages: 0, startpage: "Please Select Start Page", reason: "", startdate: formattedToday, starttime: currtime, startdatemode: "Auto",
        });
        setSubcategories([])
        setCategories([]);
        setClientUserIDArray([])
        setShowAlert(
            <>
                <ErrorOutlineOutlinedIcon
                    sx={{ fontSize: "100px", color: "orange" }}
                />
                <p style={{ fontSize: "20px", fontWeight: 900 }}>
                    {"Cleared Successfully"}
                </p>
            </>
        );
        handleClickOpenerr();
    };

    //Edit model...
    const handleClickOpenEdit = () => {
        setIsEditOpen(true);
    };
    const handleCloseModEdit = (e, reason) => {
        if (reason && reason === "backdropClick") return;
        setIsEditOpen(false);
    };


    const editSubmit = async () => {
        if (ProducionIndividualChange.statusmode === "Please Select Status") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Status"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.fromdate === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Date"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.time === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select End Time"}</p>
                </>
            );
            handleClickOpenerr();
        }

        else if (ProducionIndividualChange.totalpages === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Total Pages"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.flagcount === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Flagcount"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.flagcount === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Flagcount"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.pendingpages === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Pending Pages"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if (ProducionIndividualChange.status === "Please Select Status") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Status"}</p>
                </>
            );
            handleClickOpenerr();
        }


        else if (ProducionIndividualChange.startdatemode === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Start Date Mode"}</p>
                </>
            );
            handleClickOpenerr();
        }

        else if ((ProducionIndividualChange.statusmode === "Completed" || ProducionIndividualChange.statusmode === "In Complete" || ProducionIndividualChange.statusmode === "Partial Complete" || ProducionIndividualChange.statusmode === "Pause") && ProducionIndividualChange.pendingpages > 0 && ProducionIndividualChange.startpage === "Please Select Start Page") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Select Start Page"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else if ((ProducionIndividualChange.statusmode === "Reject" || ProducionIndividualChange.statusmode === "Cancel") && ProducionIndividualChange.reason === "") {
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "100px", color: "orange" }} />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>{"Please Enter Reason"}</p>
                </>
            );
            handleClickOpenerr();
        }
        else {
            sendEditRequest()
        }
    }



    // get single row to view....
    const getviewCode = async (e) => {
        try {
            let res = await axios.get(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${e}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setProductionEdit(res?.data?.sProductionIndividual);
            handleClickOpenview();
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };


    const getCode = async (e) => {
        try {
            let res = await axios.get(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${e}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setProducionIndividualChange(res?.data?.sProductionIndividual);
            handleClickOpenEdit();
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    // get single row to view....
    const getinfoCode = async (e) => {
        try {
            let res = await axios.get(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${e}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setProducionIndividualChange(res?.data?.sProductionIndividual);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    //Project updateby edit page...
    let updateby = ProducionIndividualChange?.updatedby;
    let addedby = ProducionIndividualChange?.addedby;

    let projectsid = ProducionIndividualChange._id;

    //editing the single data...
    const sendEditRequest = async () => {
        try {
            let res = await axios.put(`${SERVICE.PRODUCTION_INDIVIDUAL_SINGLE}/${projectsid}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                fromdate: String(ProducionIndividualChange.fromdate),
                time: String(ProducionIndividualChange.time),
                statusmode: String(ProducionIndividualChange.statusmode),
                totalpages: String(ProducionIndividualChange.totalpages),
                flagcount: String(ProducionIndividualChange.flagcount),
                pendingpages: Number(ProducionIndividualChange.pendingpages),
                startpage: String(ProducionIndividualChange.startpage),
                reason: String(ProducionIndividualChange.reason),


                // updatedby: [
                //     ...updateby,
                //     {
                //         name: String(isUserRoleAccess.companyname),
                //         date: String(new Date()),
                //     },
                // ],
            });
            await fetchEmployee();
            fetchProductionIndividual();
            handleCloseModEdit();
            setShowAlert(
                <>
                    <ErrorOutlineOutlinedIcon
                        sx={{ fontSize: "100px", color: "orange" }}
                    />
                    <p style={{ fontSize: "20px", fontWeight: 900 }}>
                        {"Changed Successfully"}
                    </p>
                </>
            );
            handleClickOpenerr();
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    //get all project.
    const fetchProductionIndividual = async () => {
        setPageName(!pageName)
        setProjectCheck(true);
        try {

            let res_project = await axios.post(SERVICE.PRODUCTION_INDIVIDUAL_LIMITED, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                username: isUserRoleAccess.username,
                access: isUserRoleAccess.role
            });

            setProjmasterDup(res_project?.data?.result);
            setProjectCheck(false);
        } catch (err) { setProjectCheck(false); handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    const [loading, setLoading] = useState(false)

    const [overallFilterdata, setOverallFilterdata] = useState([]);
    const [totalProjects, setTotalProjects] = useState(0);
    const [totalPages, setTotalPages] = useState(0);
    const [subcategoriesCount, setSubcategoriesCount] = useState(0);

    const fetchEmployee = async () => {
        setPageName(!pageName)
        setLoading(true)
        try {
            let res_employee = await axios.post(SERVICE.PRODUCTION_INDIVIDUAL_SORT, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                page: Number(page),
                pageSize: Number(pageSize),
                searchTerm: searchQuery,
                companyname: isUserRoleAccess.companyname,
                role: isUserRoleAccess.role,

            });

            const ans = res_employee?.data?.result?.length > 0 ? res_employee?.data?.result : []

            let res1 = await axios.get(SERVICE.GET_ATTENDANCE_CONTROL_CRITERIA_LAST_INDEX);
            let dataFromControlPanel = res1?.data?.attendancecontrolcriteria;


            const itemsWithSerialNumber = ans?.map((item, index) => {
                // console.log(item.createdAt, "createdat")

                const fromDate = new Date(item.createdAt);

                const fromDaten = new Date(`${item.fromdate}T${item.time}:00`);

                let approvaldays = Number(dataFromControlPanel.approvalstatusDays) > 0 ? Number(dataFromControlPanel.approvalstatusDays) * 24 : 1
                let approvalhours = Number(dataFromControlPanel.approvalstatusHour) > 0 ? Number(dataFromControlPanel.approvalstatusHour) * 60 : 1
                let approvalmins = Number(dataFromControlPanel.approvalstatusMin) > 0 ? Number(dataFromControlPanel.approvalstatusMin) * 60 : 1

                let entrydays = Number(dataFromControlPanel.entrystatusDays) > 0 ? Number(dataFromControlPanel.entrystatusDays) * 24 : 1
                let entryhours = Number(dataFromControlPanel.entrystatusHour) > 0 ? Number(dataFromControlPanel.entrystatusHour) * 60 : 1
                let entrymins = Number(dataFromControlPanel.entrystatusMin) > 0 ? Number(dataFromControlPanel.entrystatusMin) * 60 : 1





                const fromDatePlus48Hours = new Date(fromDaten.getTime() + approvaldays * approvalhours * approvalmins * 1000);


                // console.log(time, "time")
                const currentDateTime = new Date();

                const fromDatePlus24Hours = new Date(fromDate.getTime() + entrydays * entryhours * entrymins * 1000);

                return {
                    ...item,
                    serialNumber: (page - 1) * pageSize + index + 1,
                    fromdate: moment(item.fromdate).format("DD/MM/YYYY"),
                    startdate: moment(item.startdate).format("DD/MM/YYYY"),
                    statusmode: item.statusmode === "Please Select Status" ? "" : item.statusmode,
                    startpage: item.startpage === "Please Select Start Page" ? "" : item.startpage,

                    // approvalstatus: (item.approvaldate === item.createdAt.split("T")[0]) ? "" : "Late Approval",
                    lateentrystatus: (fromDate > fromDatePlus48Hours) ? "Late Entry" : "On Entry",
                    approvalstatus: (item.approvaldate === "" || item.approvaldate === null || item.approvaldate === undefined) && item.status === "Approved" ? "" :
                        ((new Date() <= fromDatePlus24Hours) && (item.approvaldate === "" || item.approvaldate === null || item.approvaldate === undefined)) ? "Pending" :
                            ((new Date() > fromDatePlus24Hours) && (item.approvaldate === "" || item.approvaldate === null || item.approvaldate === undefined)) ? "Late Not Approval" :
                                ((new Date(item.approvaldate) > fromDatePlus24Hours) && item.approvaldate) ? "Late Approval" :
                                    "On Approval"
                }
            });
            setProjmaster(itemsWithSerialNumber);


            setOverallFilterdata(itemsWithSerialNumber);
            // setTotalProjects(ans?.length > 0 ? res_employee?.data?.totalProjects : 0);
            let subcatescount = res_employee?.data?.totalProjects;
            setSubcategoriesCount(subcatescount);
            setTotalProjects(Math.ceil(subcatescount / pageSize));
            // setTotalPages(ans?.length > 0 ? res_employee?.data?.totalPages : 0);
            let total = Math.ceil(subcatescount / pageSize)
            const firstVisiblePage = Math.max(1, page - 1);
            const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, total);
            const newPageNumbers = [];
            for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
                newPageNumbers.push(i);
            }
            setPageNumbers(newPageNumbers);
            setPageSize((data) => { return ans?.length > 0 ? data : 10 });
            setPage((data) => { return ans?.length > 0 ? data : 1 });
            setLoading(false)
        } catch (err) { setLoading(false); handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    useEffect(() => {
        fetchEmployee();
    }, [page, pageSize, searchQuery]);

    const [projmasterArray, setProjmasterArray] = useState([])

    const fetchProductionIndividualArray = async () => {
        setPageName(!pageName)
        try {

            let res_project = await axios.post(SERVICE.PRODUCTION_INDIVIDUAL_LIMITED, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                username: isUserRoleAccess.username,
                access: isUserRoleAccess.role
            });

            setProjmasterArray(res_project?.data?.result);
        } catch (err) { setProjectCheck(false); handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    useEffect(() => {
        fetchProductionIndividualArray()
    }, [isFilterOpen])

    //get all project.

    const fetchProductionIndividualAll = async () => {
        setPageName(!pageName)
        try {
            let res_project = await axios.get(SERVICE.PRODUCTION_INDIVIDUAL, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            setAllProjectedit(res_project?.data?.productionIndividual.filter((item) => item._id !== productionedit._id));
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    // pdf.....
    const columns = [
        { title: "Vendor", field: "vendor" },
        { title: "From Date", field: "datemode" },
        { title: "Date", field: "fromdate" },
        { title: "Time", field: "time" },
        { title: "Category", field: "filename" },
        { title: "SubCategory", field: "category" },
        { title: "Identifier", field: "unitid" },
        { title: "Login Id", field: "user" },
        { title: "Section", field: "section" },
        { title: "Flag Count", field: "flagcount" },
        { title: "Doc Number", field: "docnumber" },
        { title: "Doc Link", field: "doclink" },
        { title: "Start Date Mode", field: "startmode" },
        { title: "Start Date", field: "startdate" },
        { title: "Start Time", field: "starttime" },
        { title: "Status Mode", field: "statusmode" },
        { title: "Total Pages", field: "totalpages" },
        { title: "Pending Pages", field: "pendingpages" },
        { title: "Start Page", field: "startpage" },
        { title: "Remarks/Notes", field: "notes" },

        { title: "Approval Status", field: "approvalstatus" },
        { title: "Late Entry Status", field: "lateentrystatus" },

    ];



    // Excel

    const downloadPdf = (isfilter) => {
        const doc = new jsPDF();

        // Initialize serial number counter
        let serialNumberCounter = 1;

        // Modify columns to include serial number column
        const columnsWithSerial = [
            { title: "SNo", dataKey: "serialNumber" }, // Serial number column
            ...columns.map((col) => ({ ...col, dataKey: col.field })),
        ];

        axios.post(SERVICE.PRODUCTION_INDIVIDUAL_EXCEL_OVERALL, {
            headers: {
                Authorization: `Bearer ${auth.APIToken}`,
            },
            companyname: isUserRoleAccess.companyname,
            role: isUserRoleAccess.role,
        })
            .then(response => {
                const result = response.data.result.map((t, index) => ({
                    serialNumber: index + 1,
                    vendor: t.vendor,
                    datemode: t.datemode,
                    fromdate: moment(t.fromdate).format("DD/MM/YYYY"),
                    time: t.time,
                    filename: t.filename,
                    category: t.category,
                    unitid: t.unitid,
                    user: t.user,
                    section: t.section,
                    flagcount: t.flagcount,
                    docnumber: t.docnumber,
                    doclink: t.doclink,
                    approvalstatus: t.approvalstatus,
                    lateentrystatus: t.lateentrystatus,


                    startmode: t.startmode,
                    startdate: moment(t.startdate).format("DD/MM/YYYY"),
                    starttime: t.starttime,
                    statusmode: t.statusmode === "Please Select Status" ? "" : t.statusmode,
                    totalpages: t.totalpages,
                    flagcount: t.flagcount,
                    startpage: t.startpage === "Please Select Start Page" ? "" : t.startpage,
                    pendingpages: t.pendingpages,
                    reason: t.reason,
                    notes: t.notes,

                }));

                // Modify row data to include serial number
                const dataWithSerial = isfilter === "filtered"
                    ? rowDataTable.map(row => ({ ...row, serialNumber: serialNumberCounter++ }))
                    : result;

                // Generate PDF
                doc.autoTable({
                    theme: "grid",
                    styles: {
                        fontSize: 4,
                        cellWidth: "auto"
                    },
                    columns: columnsWithSerial,
                    body: dataWithSerial,
                });

                doc.save("Production Manual Entry.pdf");
            })
            .catch(error => {
                console.error('Error:', error);
            });
    };


    const fileName = "Production Manual Entry";


    //print...
    const componentRef = useRef();
    const handleprint = useReactToPrint({
        content: () => componentRef.current,
        documentTitle: "Production_Individual",
        pageStyle: "print",
    });

    //serial no for listing items
    const addSerialNumber = (datas) => {
        const fromDate = new Date(`${ProducionIndividual.fromdate}T${ProducionIndividual.time}:00`);
        const fromDatePlus48Hours = new Date(fromDate.getTime() + 48 * 60 * 60 * 1000);
        const itemsWithSerialNumber = datas?.map((item, index) => ({
            ...item, serialNumber: index + 1,
            fromdate: moment(item.fromdate).format("DD/MM/YYYY"),
            startdate: moment(item.startdate).format("DD/MM/YYYY"),
            statusmode: item.statusmode === "Please Select Status" ? "" : item.statusmode,
            startpage: item.startpage === "Please Select Start Page" ? "" : item.startpage,
            // approvalstatus: (item.approvaldate === item.createdAt.split("T")[0]) ? "" : "Late Approval",
            // lateentrystatus: (item.createdAt > fromDatePlus48Hours) ? "Late Entry" : "On Entry",

        }));
        setItems(itemsWithSerialNumber);
    };
    useEffect(() => {
        addSerialNumber(projmaster);
    }, [projmaster]);


    //Datatable
    const handlePageChange = (newPage) => {
        setPage(newPage);
        setSelectedRows([]);
        setSelectAllChecked(false);
    };

    const handlePageSizeChange = (event) => {
        setPageSize(Number(event.target.value));
        setSelectedRows([]);
        setSelectAllChecked(false);
        // setPage(1);
    };

    //datatable....
    const handleSearchChange = (event) => {
        setSearchQuery(event.target.value);
        // setPage(1);
    };

    // Split the search query into individual terms
    const searchTerms = searchQuery.toLowerCase().split(" ");

    // Modify the filtering logic to check each term
    const filteredDatas = overallFilterdata?.filter((item) => {
        return searchTerms.every((term) => Object.values(item).join(" ").toLowerCase().includes(term));
    });

    const filteredData = filteredDatas?.slice((page - 1) * pageSize, page * pageSize);

    // const totalPages = Math.ceil(filteredDatas?.length / pageSize);

    // const visiblePages = Math.min(totalPages, 3);

    // const firstVisiblePage = Math.max(1, page - 1);
    // const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPages);

    // const pageNumbers = [];

    // const indexOfLastItem = page * pageSize;
    // const indexOfFirstItem = indexOfLastItem - pageSize;

    // for (let i = firstVisiblePage; i <= lastVisiblePage; i++) {
    //     pageNumbers.push(i);
    // }


    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    const [selectAllChecked, setSelectAllChecked] = useState(false);

    const CheckboxHeader = ({ selectAllChecked, onSelectAll }) => (
        <div>
            <Checkbox checked={selectAllChecked} onChange={onSelectAll} />
        </div>
    );

    const columnDataTable = [
        // {
        //     field: "checkbox",
        //     headerName: "Checkbox", // Default header name
        //     headerStyle: {
        //         fontWeight: "bold", // Apply the font-weight style to make the header text bold
        //         // Add any other CSS styles as needed
        //     },
        //     renderHeader: (params) => (
        //         <CheckboxHeader
        //             selectAllChecked={selectAllChecked}
        //             onSelectAll={() => {
        //                 if (rowDataTable.length === 0) {
        //                     // Do not allow checking when there are no rows
        //                     return;
        //                 }

        //                 if (selectAllChecked) {
        //                     setSelectedRows([]);
        //                 } else {
        //                     const allRowIds = rowDataTable.map((row) => row.id);
        //                     setSelectedRows(allRowIds);
        //                 }
        //                 setSelectAllChecked(!selectAllChecked);
        //             }}
        //         />
        //     ),

        //     renderCell: (params) => (
        //         <Checkbox
        //             checked={selectedRows.includes(params.data.id)}
        //             onChange={() => {
        //                 let updatedSelectedRows;
        //                 if (selectedRows.includes(params.data.id)) {
        //                     updatedSelectedRows = selectedRows.filter((selectedId) => selectedId !== params.data.id);
        //                 } else {
        //                     updatedSelectedRows = [...selectedRows, params.data.id];
        //                 }

        //                 setSelectedRows(updatedSelectedRows);

        //                 // Update the "Select All" checkbox based on whether all rows are selected
        //                 setSelectAllChecked(updatedSelectedRows.length === filteredDatas.length);
        //             }}
        //         />
        //     ),
        //     sortable: false, // Optionally, you can make this column not sortable
        //     width: 90,

        //     hide: !columnVisibility.checkbox,
        //     headerClassName: "bold-header",
        // },
        {
            field: "checkbox",
            headerName: "", // Default header name
            headerStyle: {
                fontWeight: "bold",
            },
            sortable: false,
            width: 90,
            filter: false,
            headerCheckboxSelection: true,
            checkboxSelection: true,
            hide: !columnVisibility.checkbox,
            headerClassName: "bold-header",
            pinned: "left",
        },
        {
            field: "serialNumber",
            headerName: "SNo",
            flex: 0,
            width: 100,
            hide: !columnVisibility.serialNumber,
            headerClassName: "bold-header",
        },
        { field: "vendor", headerName: "Vendor", flex: 0, width: 150, hide: !columnVisibility.vendor, headerClassName: "bold-header" },
        { field: "datemode", headerName: "Date Mode", flex: 0, width: 150, hide: !columnVisibility.datemode, headerClassName: "bold-header" },
        { field: "fromdate", headerName: "Date", flex: 0, width: 150, hide: !columnVisibility.fromdate, headerClassName: "bold-header" },
        { field: "time", headerName: "Time", flex: 0, width: 150, hide: !columnVisibility.time, headerClassName: "bold-header" },
        { field: "filename", headerName: "Category", flex: 0, width: 150, hide: !columnVisibility.filename, headerClassName: "bold-header" },
        { field: "category", headerName: "SubCategory", flex: 0, width: 150, hide: !columnVisibility.category, headerClassName: "bold-header" },
        { field: "unitid", headerName: "Identifier", flex: 0, width: 150, hide: !columnVisibility.unitid, headerClassName: "bold-header" },
        { field: "user", headerName: "Login Id", flex: 0, width: 150, hide: !columnVisibility.user, headerClassName: "bold-header" },
        { field: "section", headerName: "Section", flex: 0, width: 150, hide: !columnVisibility.section, headerClassName: "bold-header" },
        { field: "flagcount", headerName: "Flag Count", flex: 0, width: 150, hide: !columnVisibility.flagcount, headerClassName: "bold-header" },
        { field: "alllogin", headerName: "All Login", flex: 0, width: 150, hide: !columnVisibility.alllogin, headerClassName: "bold-header" },
        { field: "docnumber", headerName: "Doc Number", flex: 0, width: 150, hide: !columnVisibility.docnumber, headerClassName: "bold-header" },
        { field: "doclink", headerName: "Doc Link", flex: 0, width: 150, hide: !columnVisibility.doclink, headerClassName: "bold-header" },


        { field: "startmode", headerName: "Start Mode", flex: 0, width: 150, hide: !columnVisibility.startmode, headerClassName: "bold-header" },
        { field: "startdate", headerName: "Start Date", flex: 0, width: 150, hide: !columnVisibility.startdate, headerClassName: "bold-header" },
        { field: "starttime", headerName: "Start Time", flex: 0, width: 150, hide: !columnVisibility.starttime, headerClassName: "bold-header" },
        { field: "statusmode", headerName: "Status Mode", flex: 0, width: 150, hide: !columnVisibility.statusmode, headerClassName: "bold-header" },

        { field: "totalpages", headerName: "Total Pages", flex: 0, width: 150, hide: !columnVisibility.totalpages, headerClassName: "bold-header" },
        { field: "pendingpages", headerName: "Pending Pages", flex: 0, width: 150, hide: !columnVisibility.pendingpages, headerClassName: "bold-header" },
        { field: "startpage", headerName: "Start Page", flex: 0, width: 150, hide: !columnVisibility.startpage, headerClassName: "bold-header" },
        { field: "notes", headerName: "Remark/Notes", flex: 0, width: 150, hide: !columnVisibility.notes, headerClassName: "bold-header" },


        {
            field: "actionsstatus",
            headerName: "Status",
            flex: 0,
            width: 250,
            minHeight: "40px !important",
            sortable: false,
            hide: !columnVisibility.actionsstatus,
            headerClassName: "bold-header",
            cellRenderer: (params) => (
                <Grid sx={{ display: "flex" }}>
                    <Chip
                        sx={{ height: "25px", borderRadius: "0px" }}
                        color={"warning"}
                        variant="outlined"
                        label={params.data.approvalstatus}
                    />
                    &ensp;
                    <Chip
                        sx={{ height: "25px", borderRadius: "0px" }}
                        color={"success"}
                        variant="outlined"
                        label={params.data.lateentrystatus}
                    />
                </Grid>
            ),
        },



        {
            field: "actions",
            headerName: "Action",
            flex: 0,
            width: 350,
            minHeight: "40px !important",
            sortable: false,
            hide: !columnVisibility.actions,
            headerClassName: "bold-header",
            cellRenderer: (params) => (
                <Grid sx={{ display: "flex" }}>


                    {(params.data.statusmode === "In Complete" || params.data.statusmode === "Partial Complete") ?
                        <Button
                            variant="contained"
                            color="primary"
                            onClick={() => {
                                getCode(params.data.id);
                            }}
                        >
                            Change </Button>
                        :
                        params.data.statusmode === "Pause" ?
                            <Button
                                variant="contained"
                                color="primary"
                                onClick={() => {
                                    getCode(params.data.id);
                                }}
                            >
                                Restart </Button> :
                            ""

                    }


                    {isUserRoleCompare?.includes("dproductionmanualentry") && (
                        <Button
                            sx={userStyle.buttondelete}
                            onClick={(e) => {
                                rowData(params.data.id, params.data.name);
                            }}
                        >
                            <DeleteOutlineOutlinedIcon sx={buttonStyles.buttondelete} />
                        </Button>
                    )}
                    {isUserRoleCompare?.includes("vproductionmanualentry") && (
                        <Button
                            sx={userStyle.buttonedit}
                            onClick={() => {
                                getviewCode(params.data.id);
                            }}
                        >
                            <VisibilityOutlinedIcon sx={buttonStyles.buttonview} />
                        </Button>
                    )}
                    {isUserRoleCompare?.includes("iproductionmanualentry") && (
                        <Button
                            sx={userStyle.buttonedit}
                            onClick={() => {
                                handleClickOpeninfo();
                                getinfoCode(params.data.id);
                            }}
                        >
                            <InfoOutlinedIcon sx={buttonStyles.buttoninfo} />
                        </Button>
                    )}
                </Grid>
            ),
        },
    ];

    const rowDataTable = filteredDatas.map((item, index) => {

        return {
            id: item._id,
            serialNumber: item.serialNumber,
            vendor: item.vendor,
            datemode: item.datemode,
            fromdate: item.fromdate,
            time: item.time,
            filename: item.filename,
            category: item.category,
            unitid: item.unitid,
            user: item.user,
            section: item.section,
            flagcount: item.flagcount,
            alllogin: item.alllogin,
            docnumber: item.docnumber,
            doclink: item.doclink,
            approvalstatus: item.approvalstatus,
            lateentrystatus: item.lateentrystatus,
            startmode: item.startmode,
            startdate: item.startdate,
            starttime: item.starttime,
            statusmode: item.statusmode,
            totalpages: item.totalpages,
            flagcount: item.flagcount,
            startpage: item.startpage,
            pendingpages: item.pendingpages,
            reason: item.reason,
            enddate: item.enddate,
            endtime: item.endtime,
            notes: item.notes,

        };
    });
    const rowsWithCheckboxes = rowDataTable.map((row) => ({
        ...row,
        // Create a custom field for rendering the checkbox
        checkbox: selectedRows.includes(row.id),
    }));

    // Show All Columns functionality
    const handleShowAllColumns = () => {
        const updatedVisibility = { ...columnVisibility };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibility(updatedVisibility);
    };

    useEffect(() => {
        // Retrieve column visibility from localStorage (if available)
        const savedVisibility = localStorage.getItem("columnVisibility");
        if (savedVisibility) {
            setColumnVisibility(JSON.parse(savedVisibility));
        }
    }, []);

    useEffect(() => {
        // Save column visibility to localStorage whenever it changes
        localStorage.setItem("columnVisibility", JSON.stringify(columnVisibility));
    }, [columnVisibility]);

    // // Function to filter columns based on search query
    const filteredColumns = columnDataTable.filter((column) => column.headerName.toLowerCase().includes(searchQueryManage.toLowerCase()));
    // Manage Columns functionality
    const toggleColumnVisibility = (field) => {
        setColumnVisibility((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    // JSX for the "Manage Columns" popover content
    const manageColumnsContent = (
        <Box style={{ padding: "10px", minWidth: "325px", "& .MuiDialogContent-root": { padding: "10px 0" } }}>
            <Typography variant="h6">Manage Columns</Typography>
            <IconButton
                aria-label="close"
                onClick={handleCloseManageColumns}
                sx={{
                    position: "absolute",
                    right: 8,
                    top: 8,
                    color: (theme) => theme.palette.grey[500],
                }}
            >
                <CloseIcon />
            </IconButton>
            <Box sx={{ position: "relative", margin: "10px" }}>
                <TextField label="Find column" variant="standard" fullWidth value={searchQueryManage} onChange={(e) => setSearchQueryManage(e.target.value)} sx={{ marginBottom: 5, position: "absolute" }} />
            </Box>
            <br />
            <br />
            <DialogContent sx={{ minWidth: "auto", height: "200px", position: "relative" }}>
                <List sx={{ overflow: "auto", height: "100%" }}>
                    {filteredColumns.map((column) => (
                        <ListItem key={column.field}>
                            <ListItemText
                                sx={{ display: "flex" }}
                                primary={<Switch sx={{ marginTop: "-5px" }} size="small" checked={columnVisibility[column.field]} onChange={() => toggleColumnVisibility(column.field)} />}
                                secondary={column.field === "checkbox" ? "Checkbox" : column.headerName}
                            // secondary={column.headerName }
                            />
                        </ListItem>
                    ))}
                </List>
            </DialogContent>
            <DialogActions>
                <Grid container>
                    <Grid item md={4}>
                        <Button variant="text" sx={{ textTransform: "none" }} onClick={() => setColumnVisibility(initialColumnVisibility)}>
                            Show All
                        </Button>
                    </Grid>
                    <Grid item md={4}></Grid>
                    <Grid item md={4}>
                        <Button
                            variant="text"
                            sx={{ textTransform: "none" }}
                            onClick={() => {
                                const newColumnVisibility = {};
                                columnDataTable.forEach((column) => {
                                    newColumnVisibility[column.field] = false; // Set hide property to true
                                });
                                setColumnVisibility(newColumnVisibility);
                            }}
                        >
                            Hide All
                        </Button>
                    </Grid>
                </Grid>
            </DialogActions>
        </Box>
    );

    const [projectmaster, setProjectMaster] = useState(false)

    const fetchVendors = async () => {
        try {
            let res_vendor = await axios.get(SERVICE.VENDORMASTER, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            let vendorall = res_vendor?.data?.vendormaster.map((d) => ({
                ...d,
                label: d.projectname + "-" + d.name,
                value: d.projectname + "-" + d.name,
            }));


            setVendors(vendorall);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    const fetchProjMaster = async (e) => {
        try {
            let res_project = await axios.post(SERVICE.PROJECTMASTER_INDIVIDUAL, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                name: e.split("-")[0]
            });
            setProjectMaster(res_project?.data?.projmaster.enablepage);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };

    const [categories, setCategories] = useState([]);
    const [subcategories, setSubcategories] = useState([]);
    const [loginAllotFilter, setLoginAllotFilter] = useState([]);
    const [clientUserIDArray, setClientUserIDArray] = useState([]);

    const fetchAllCategory = async (provendoe) => {
        try {
            let res_vendor = await axios.get(SERVICE.CATEGORYPROD, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });
            let resvendor = provendoe.split("-");
            let vendorall = res_vendor?.data?.categoryprod.filter((data, index) => {
                return data.project === resvendor[0]
            })
            let resall = vendorall.map((d) => ({
                ...d,
                label: d.name,
                value: d.name,
            }));
            const uniqueArray = resall.filter((item, index, self) => {
                return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
            });
            setCategories(uniqueArray);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };


    const fetchAllSubCategory = async (e) => {
        try {
            let res_vendor = await axios.get(SERVICE.SUBCATEGORYPROD_LIST_LIMITED, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            let result = res_vendor?.data?.subcategoryprod.filter((d) => d.categoryname === e);


            let subbrandid = result.map((d) => ({
                ...d,
                label: d.name,
                value: d.name,
            }));

            const uniqueArray = subbrandid.filter((item, index, self) => {
                return self.findIndex((i) => i.label === item.label && i.value === item.value) === index;
            });
            setSubcategories(uniqueArray);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };




    //get all Sub vendormasters.
    const fetchAllLogins = async () => {
        try {
            let res_vendor = await axios.get(SERVICE.ALL_CLIENTUSERIDDATA, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            let alluseridNames = res_vendor?.data?.clientuserid
                .filter((item) => item.empname == isUserRoleAccess.companyname)
                .map((d) => ({
                    ...d,
                    label: d.userid,
                    value: d.userid,
                }));
            let alluseridNamesadmin = res_vendor?.data?.clientuserid
                .map((d) => ({
                    ...d,
                    label: d.userid,
                    value: d.userid,
                }));

            let rolebylist =
                isUserRoleAccess.role.includes("Manager")
                    || isUserRoleAccess.role.includes("Director")
                    || isUserRoleAccess.role.includes("Admin")
                    || isUserRoleAccess.role.includes("SuperAdmin") ||
                    isUserRoleAccess.role.includes("ADMIN") ? alluseridNamesadmin : alluseridNames
            setLoginAllotFilter(rolebylist);

        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };


    const fetchClientUserID = async (e) => {
        try {
            let res_vendor = await axios.get(SERVICE.ALL_CLIENTUSERIDDATA, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
            });

            let result = res_vendor?.data?.clientuserid.filter((d) => d.projectvendor === e);


            let vendorall = result.map((d) => ({
                ...d,
                label: d.userid,
                value: d.userid,
            }));
            setClientUserIDArray(vendorall);
        } catch (err) { handleApiError(err, setShowAlert, handleClickOpenerr); }
    };


    useEffect(() => {
        fetchEmployee();
        fetchProductionIndividual();
        fetchProductionIndividualAll();
        fetchVendors();
        fetchAllLogins();
        // fetchProjMaster();
    }, []);

    const [fileFormat, setFormat] = useState('')

    let exportColumnNames = ['Vendor', 'From Date',
        'Date', 'Time',
        'Category', 'SubCategory',
        'Identifier', 'Login Id',
        'Section', 'Flag Count',
        'Doc Number', 'Doc Link',
        'Start Date Mode', 'Start Date',
        'Start Time', 'Status Mode',
        'Total Pages', 'Pending Pages',
        'Start Page', 'Remarks/Notes',
        'Approval Status', 'Late Entry Status'];


    let exportRowValues = ['vendor', 'datemode',
        'fromdate', 'time',
        'filename', 'category',
        'unitid', 'user',
        'section', 'flagcount',
        'docnumber', 'doclink',
        'startmode', 'startdate',
        'starttime', 'statusmode',
        'totalpages', 'pendingpages',
        'startpage', 'notes',
        'approvalstatus', 'lateentrystatus'];





    return (
        <Box>
            <Headtitle title={"Production Manual Entry"} />
            {/* ****** Header Content ****** */}
            {/* <Typography sx={userStyle.HeaderText}>Production Manual Entry</Typography> */}
            <PageHeading
                title="Production Manual Entry"
                modulename="Production"
                submodulename="Manual Entry"
                mainpagename="Production Manual Entry"
                subpagename=""
                subsubpagename=""
            />
            {isUserRoleCompare?.includes("aproductionmanualentry") && (
                <>
                    <Box sx={userStyle.selectcontainer}>
                        <>
                            <Grid container spacing={2}>
                                <Grid item xs={8}>
                                    <Typography sx={userStyle.importheadtext}>Add Production Manual Entry</Typography>
                                </Grid>
                            </Grid>
                            <br />
                            <Grid container spacing={2}>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Vendor <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={vendors}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividual.vendor, value: ProducionIndividual.vendor }}
                                            onChange={(e) => {
                                                fetchAllCategory(e.value);
                                                setProducionIndividual({ ...ProducionIndividual, vendor: e.value, alllogin: "Please Select AllLogin", filename: "Please Select Category", category: "Please Select Subcategory" });
                                                fetchClientUserID(e.value)
                                                fetchProjMaster(e.value)
                                                setSubcategories([])
                                            }}
                                        />
                                    </FormControl>
                                </Grid>

                                {!projectmaster && (
                                    <>
                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Date Mode <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <Selects
                                                    options={datemodes}
                                                    value={{ label: ProducionIndividual.datemode, value: ProducionIndividual.datemode }}
                                                    onChange={(e) => {
                                                        setProducionIndividual({
                                                            ...ProducionIndividual, datemode: e.value,
                                                            fromdate: e.value === 'Auto' ? formattedToday : "",
                                                            time: e.value === 'Auto' ? currtime : ""
                                                        });
                                                    }}
                                                >


                                                </Selects>
                                            </FormControl>
                                        </Grid>



                                        <Grid item md={4} sm={6} xs={12}>
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            Date <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="date"
                                                            disabled={ProducionIndividual.datemode === 'Auto'}
                                                            value={ProducionIndividual.fromdate}
                                                            // onChange={(e) => {
                                                            //     setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
                                                            // }}
                                                            onChange={handleDateChange}
                                                            inputProps={{
                                                                max: ProducionIndividual.datemode === 'Manual' ? formattedToday : undefined,
                                                                min: ProducionIndividual.datemode === 'Manual' ? formattedTwoMonthsAgo : undefined
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            Time <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="time"
                                                            disabled={ProducionIndividual.datemode === 'Auto'}
                                                            value={
                                                                ProducionIndividual.time}
                                                            onChange={(e) => {
                                                                setProducionIndividual({ ...ProducionIndividual, time: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </>
                                )}


                                {projectmaster && (
                                    <>

                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Start Date Mode <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <Selects
                                                    options={datemodes}
                                                    value={{ label: ProducionIndividual.startdatemode, value: ProducionIndividual.startdatemode }}
                                                    onChange={(e) => {
                                                        setProducionIndividual({
                                                            ...ProducionIndividual, startdatemode: e.value,
                                                            fromdate: e.value === 'Auto' ? formattedToday : "",
                                                            time: e.value === 'Auto' ? currtime : ""
                                                        });
                                                    }}
                                                >


                                                </Selects>
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} sm={6} xs={12}>
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            Start  Date <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="date"
                                                            disabled={ProducionIndividual.startdatemode === 'Auto'}
                                                            value={ProducionIndividual.startdate}
                                                            // onChange={(e) => {
                                                            //     setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
                                                            // }}
                                                            onChange={handleDateChangeStart}
                                                            inputProps={{
                                                                max: ProducionIndividual.datemode === 'Manual' ? formattedToday : undefined,
                                                                min: ProducionIndividual.datemode === 'Manual' ? formattedTwoMonthsAgo : undefined
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            Start  Time <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="time"
                                                            disabled={ProducionIndividual.startdatemode === 'Auto'}
                                                            value={
                                                                ProducionIndividual.starttime}
                                                            onChange={(e) => {
                                                                setProducionIndividual({ ...ProducionIndividual, starttime: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>
                                        </Grid>
                                    </>

                                )}


                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Category <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={categories}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividual.filename, value: ProducionIndividual.filename }}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, filename: e.value, category: "Please Select Subcategory" });
                                                fetchAllSubCategory(e.value);
                                                setSubcategories([])

                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Sub Category <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={subcategories}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividual.category, value: ProducionIndividual.category }}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, category: e.value });
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Identifier <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <OutlinedInput
                                            id="component-outlinedname"
                                            type="text"
                                            placeholder="Please Enter Identifier"
                                            value={ProducionIndividual.unitid}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, unitid: e.target.value });
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Login Id <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={loginAllotFilter}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividual.user, value: ProducionIndividual.user }}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, user: e.value });
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Section <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <OutlinedInput
                                            id="component-outlinedname"
                                            type="text"
                                            placeholder="Please Enter Section"
                                            value={ProducionIndividual.section}
                                            onChange={(e) => handleChangephonenumber(e)} />

                                    </FormControl>
                                </Grid>
                                {!projectmaster && (
                                    <>
                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Flag Count<b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Completed Pages"
                                                    value={ProducionIndividual.flagcount}
                                                    onChange={(e) => handleChangephonenumberflag(e)} />
                                            </FormControl>
                                        </Grid>
                                    </>
                                )}
                                {projectmaster && (
                                    <>
                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Total Pages <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Total Pages"
                                                    value={ProducionIndividual.totalpages}
                                                    onChange={(e) => handleChangephonenumbertotal(e)} />
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Completed Pages <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Completed Pages"
                                                    value={ProducionIndividual.flagcount}
                                                    onChange={(e) => handleChangephonenumberflagCompleted(e)} />
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Pending  Pages  <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    value={ProducionIndividual.pendingpages} />
                                            </FormControl>
                                        </Grid>



                                        <Grid item md={4} sm={6} xs={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Start Page
                                                    <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <Selects
                                                    // options={startpage}
                                                    options={
                                                        Array.from(
                                                            { length: ProducionIndividual.totalpages - ProducionIndividual.flagcount },
                                                            (_, index) => {
                                                                const startPageNumber = Number(ProducionIndividual.flagcount) + 1 + index;
                                                                return { label: startPageNumber, value: startPageNumber };
                                                            }
                                                        )
                                                    }
                                                    styles={colourStyles}
                                                    value={{ label: ProducionIndividual.startpage, value: ProducionIndividual.startpage }}
                                                    onChange={(e) => {
                                                        setProducionIndividual({ ...ProducionIndividual, startpage: e.value });


                                                    }}
                                                />
                                            </FormControl>
                                        </Grid>
                                    </>
                                )}

                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            All Login <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={clientUserIDArray}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividual.alllogin, value: ProducionIndividual.vendor }}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, alllogin: e.value });

                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Doc Number
                                            {/* <b style={{ color: "red" }}>*</b> */}
                                        </Typography>
                                        <OutlinedInput
                                            id="component-outlinedname"
                                            type="text"
                                            placeholder="Please Enter Doc Number"
                                            value={ProducionIndividual.docnumber}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, docnumber: e.target.value });
                                            }}
                                        />
                                    </FormControl>
                                </Grid>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Doc Link
                                            {/* <b style={{ color: "red" }}>*</b> */}
                                        </Typography>
                                        <OutlinedInput
                                            id="component-outlinedname"
                                            type="text"
                                            placeholder="Please Enter Doc Link"
                                            value={ProducionIndividual.doclink}
                                            onChange={(e) => {
                                                setProducionIndividual({ ...ProducionIndividual, doclink: e.target.value });
                                            }}
                                        />
                                    </FormControl>
                                </Grid>

                                {projectmaster && (
                                    <>
                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>

                                                    Status <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <Selects
                                                    options={status}
                                                    styles={colourStyles}
                                                    value={{ label: ProducionIndividual.statusmode, value: ProducionIndividual.statusmode }}
                                                    onChange={(e) => {
                                                        setProducionIndividual({ ...ProducionIndividual, statusmode: e.value });


                                                    }}
                                                />
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} sm={6} xs={12}>
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            End Date <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="date"
                                                            disabled={ProducionIndividual.startdatemode === 'Auto'}
                                                            value={ProducionIndividual.fromdate}
                                                            // onChange={(e) => {
                                                            //     setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
                                                            // }}
                                                            onChange={handleDateChange}
                                                            inputProps={{
                                                                max: ProducionIndividual.datemode === 'Manual' ? formattedToday : undefined,
                                                                min: ProducionIndividual.datemode === 'Manual' ? formattedTwoMonthsAgo : undefined
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            End  Time <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="time"
                                                            disabled={ProducionIndividual.startdatemode === 'Auto'}
                                                            value={
                                                                ProducionIndividual.time}
                                                            onChange={(e) => {
                                                                setProducionIndividual({ ...ProducionIndividual, time: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>



                                        </Grid>

                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth>
                                                <Typography>Notes/Remarks<b style={{ color: "red" }}>*</b></Typography>
                                                <TextareaAutosize
                                                    aria-label="minimum height"
                                                    minRows={5}
                                                    value={ProducionIndividual.notes}
                                                    onChange={(e) => {
                                                        setProducionIndividual({ ...ProducionIndividual, notes: e.target.value });
                                                    }}
                                                />
                                            </FormControl>
                                        </Grid>

                                    </>

                                )}
                            </Grid>
                            <br />
                            <br />

                            <Grid container>
                                <Grid item md={3} xs={12} sm={6}>
                                    <Button variant="contained" sx={buttonStyles.buttonsubmit} onClick={handleSubmit}>
                                        Submit
                                    </Button>
                                </Grid>
                                <Grid item md={3} xs={12} sm={6}>
                                    <Button sx={buttonStyles.btncancel} onClick={handleclear}>
                                        Clear
                                    </Button>
                                </Grid>
                            </Grid>
                        </>
                    </Box>
                </>
            )}

            <br />

            {/* ****** Table Start ****** */}
            {isUserRoleCompare?.includes("lproductionmanualentry") && (
                <>
                    <Box sx={userStyle.container}>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid item xs={8}>
                            <Typography sx={userStyle.importheadtext}>Production Manual Entry List</Typography>
                        </Grid>
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSize}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChange}
                                        sx={{ width: "77px" }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={projmaster?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center" }}>
                                <Box>
                                    {isUserRoleCompare?.includes("excelproductionmanualentry") && (
                                        <>
                                            <Button onClick={(e) => {
                                                setIsFilterOpen(true)
                                                setFormat("xl")
                                            }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("csvproductionmanualentry") && (
                                        <>
                                            <Button onClick={(e) => {
                                                setIsFilterOpen(true)
                                                setFormat("csv")
                                            }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("printproductionmanualentry") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprint}>
                                                &ensp;
                                                <FaPrint />
                                                &ensp;Print&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("pdfproductionmanualentry") && (
                                        <>
                                            <Button
                                                sx={userStyle.buttongrp}
                                                onClick={() => {
                                                    setIsPdfFilterOpen(true)
                                                }}
                                            >
                                                <FaFilePdf />
                                                &ensp;Export to PDF&ensp;
                                            </Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("imageproductionmanualentry") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImage}>
                                                {" "}
                                                <ImageIcon sx={{ fontSize: "15px" }} /> &ensp;Image&ensp;{" "}
                                            </Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    {/* <FormControl fullWidth size="small">
                                        <Typography>Search</Typography>
                                        <OutlinedInput id="component-outlined" type="text" value={searchQuery} onChange={handleSearchChange} />
                                    </FormControl> */}
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTable}
                                        // setItems={setItems}
                                        addSerialNumber={addSerialNumber}
                                        setPage={setPage}
                                        maindatas={projmaster}
                                        setSearchedString={setSearchedString}
                                    />
                                </Box>
                            </Grid>
                        </Grid>
                        <br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumns}>
                            Show All Columns
                        </Button>
                        &ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumns}>
                            Manage Columns
                        </Button>
                        &ensp;
                        {isUserRoleCompare?.includes("bdproductionmanualentry") && (
                            <Button variant="contained" color="error" onClick={handleClickOpenalert}>
                                Bulk Delete
                            </Button>
                        )}
                        <br />
                        <br />

                        {loading ? (
                            <>
                                <Box sx={{ display: "flex", justifyContent: "center" }}>

                                    <ThreeDots
                                        height="80"
                                        width="80"
                                        radius="9"
                                        color="#1976d2"
                                        ariaLabel="three-dots-loading"
                                        wrapperStyle={{}}
                                        wrapperClassName=""
                                        visible={true}
                                    />
                                </Box>
                            </>
                        ) : (
                            <>
                                {/* <Box
                                    style={{
                                        width: "100%",
                                        overflowY: "hidden", // Hide the y-axis scrollbar
                                    }}
                                >
                                    <StyledDataGrid onClipboardCopy={(copiedString) => setCopiedData(copiedString)} rows={rowsWithCheckboxes} columns={columnDataTable.filter((column) => columnVisibility[column.field])} onSelectionModelChange={handleSelectionChange} selectionModel={selectedRows} autoHeight={true} ref={gridRef} density="compact" hideFooter getRowClassName={getRowClassName} disableRowSelectionOnClick />
                                </Box>

                               
                                <Box style={userStyle.dataTablestyle}>
                                    <Box>
                                        Showing {items.length > 0 ? (page - 1) * pageSize + 1 : 0} to {Math.min(page * pageSize, subcategoriesCount)} of {subcategoriesCount} entries
                                    </Box>
                                    <Box>
                                        <Button onClick={() => setPage(1)} disabled={page === 1} sx={userStyle.paginationbtn}>
                                            <FirstPageIcon />
                                        </Button>
                                        <Button onClick={() => handlePageChange(page - 1)} disabled={page === 1} sx={userStyle.paginationbtn}>
                                            <NavigateBeforeIcon />
                                        </Button>
                                        {pageNumbers.map((pageNumber) => (
                                            <Button key={pageNumber} onClick={() => handlePageChange(pageNumber)} className={page === pageNumber ? "active" : ""} disabled={page === pageNumber} sx={userStyle.paginationbtn}>
                                                {pageNumber}
                                            </Button>
                                        ))}
                                        <Button onClick={() => handlePageChange(page + 1)} disabled={page === totalProjects} sx={userStyle.paginationbtn}>
                                            <NavigateNextIcon />
                                        </Button>
                                        <Button onClick={() => setPage(totalProjects)} disabled={page === totalProjects} sx={userStyle.paginationbtn}>
                                            <LastPageIcon />
                                        </Button>
                                    </Box>
                                </Box> */}

                                <AggridTable
                                    rowDataTable={rowDataTable}
                                    columnDataTable={columnDataTable}
                                    columnVisibility={columnVisibility}
                                    page={page}
                                    setPage={setPage}
                                    pageSize={pageSize}
                                    totalPages={totalPages}
                                    setColumnVisibility={setColumnVisibility}
                                    isHandleChange={isHandleChange}
                                    items={items}
                                    selectedRows={selectedRows}
                                    setSelectedRows={setSelectedRows}
                                    gridRefTable={gridRefTable}
                                    gridRefTableImg={gridRefTableImg}

                                    paginated={true}
                                    filteredDatas={filteredDatas}
                                    totalDatas={totalProjects}
                                    searchQuery={searchedString}
                                    handleShowAllColumns={handleShowAllColumns}
                                />

                            </>
                        )}
                        {/* ****** Table End ****** */}
                    </Box>
                </>
            )}
            {/* ****** Table End ****** */}

            {/* Manage Column */}
            <Popover
                id={id}
                open={isManageColumnsOpen}
                anchorEl={anchorEl}
                onClose={handleCloseManageColumns}
                anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "left",
                }}
            >
                {manageColumnsContent}
            </Popover>

            {/* Delete Modal */}
            <Box>
                {/* ALERT DIALOG */}
                <Dialog open={isDeleteOpen} onClose={handleCloseMod} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: "orange" }} />
                        <Typography variant="h5" sx={{ color: "red", textAlign: "center" }}>
                            Are you sure?
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button
                            onClick={handleCloseMod}
                            style={{
                                backgroundColor: "#f4f4f4",
                                color: "#444",
                                boxShadow: "none",
                                borderRadius: "3px",
                                border: "1px solid #0000006b",
                                "&:hover": {
                                    "& .css-bluauu-MuiButtonBase-root-MuiButton-root": {
                                        backgroundColor: "#f4f4f4",
                                    },
                                },
                            }}
                        >
                            Cancel
                        </Button>
                        <Button autoFocus variant="contained" color="error" onClick={(e) => delProject(projectid)}>
                            {" "}
                            OK{" "}
                        </Button>
                    </DialogActions>
                </Dialog>

                {/* this is info view details */}
                <Dialog open={openInfo} onClose={handleCloseinfo} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <Box sx={{ width: "550px", padding: "20px 50px" }}>
                        <>
                            <Typography sx={userStyle.HeaderText}>Production Manual Entry Info</Typography>
                            <br />
                            <br />
                            <Grid container spacing={2}>
                                <Grid item md={12} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography variant="h6">addedby</Typography>
                                        <br />
                                        <Table>
                                            <TableHead>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}>{"SNO"}.</StyledTableCell>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}> {"UserName"}</StyledTableCell>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}> {"Date"}</StyledTableCell>
                                            </TableHead>
                                            <TableBody>
                                                {addedby?.map((item, i) => (
                                                    <StyledTableRow>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}>{i + 1}.</StyledTableCell>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}> {item.name}</StyledTableCell>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}> {moment(item.date).format("DD-MM-YYYY hh:mm:ss a")}</StyledTableCell>
                                                    </StyledTableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </FormControl>
                                </Grid>
                                <Grid item md={12} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography variant="h6">Updated by</Typography>
                                        <br />
                                        <Table>
                                            <TableHead>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}>{"SNO"}.</StyledTableCell>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}> {"UserName"}</StyledTableCell>
                                                <StyledTableCell sx={{ padding: "5px 10px !important" }}> {"Date"}</StyledTableCell>
                                            </TableHead>
                                            <TableBody>
                                                {updateby?.map((item, i) => (
                                                    <StyledTableRow>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}>{i + 1}.</StyledTableCell>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}> {item.name}</StyledTableCell>
                                                        <StyledTableCell sx={{ padding: "5px 10px !important" }}> {moment(item.date).format("DD-MM-YYYY hh:mm:ss a")}</StyledTableCell>
                                                    </StyledTableRow>
                                                ))}
                                            </TableBody>
                                        </Table>
                                    </FormControl>
                                </Grid>
                            </Grid>
                            <br /> <br />
                            <br />
                            <Grid container spacing={2}>
                                <Button variant="contained" onClick={handleCloseinfo}>
                                    {" "}
                                    Back{" "}
                                </Button>
                            </Grid>
                        </>
                    </Box>
                </Dialog>

                {/* print layout */}

                <TableContainer component={Paper} sx={userStyle.printcls}>
                    <Table sx={{ minWidth: 700 }} aria-label="customized table" id="usertable" ref={componentRef}>
                        <TableHead>
                            <TableRow>
                                <TableCell> SI.No</TableCell>
                                <TableCell>Vendor</TableCell>
                                <TableCell>Date Mode</TableCell>
                                <TableCell>Date</TableCell>
                                <TableCell>Time</TableCell>
                                <TableCell>Category</TableCell>
                                <TableCell>SubCategory</TableCell>
                                <TableCell>Identifier</TableCell>
                                <TableCell>Login ID</TableCell>
                                <TableCell>Section</TableCell>
                                <TableCell>Flag Count</TableCell>
                                <TableCell>All Login</TableCell>
                                <TableCell>Doc Number</TableCell>
                                <TableCell>Doc Link</TableCell>


                                <TableCell>Start Mode</TableCell>
                                <TableCell>Start Date</TableCell>
                                <TableCell>Start Time</TableCell>
                                <TableCell>Status Mode</TableCell>
                                <TableCell>Total Pages</TableCell>
                                <TableCell>Pending Pages</TableCell>
                                <TableCell>Start Page</TableCell>
                                <TableCell>Remarks/Notes</TableCell>


                                <TableCell>Approval Status</TableCell>
                                <TableCell>Late Entry Status</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody align="left">
                            {rowDataTable &&
                                rowDataTable.map((row, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{index + 1}</TableCell>
                                        <TableCell>{row.vendor}</TableCell>
                                        <TableCell>{row.datemode}</TableCell>
                                        <TableCell>{moment(row.fromdate).format("DD/MM/YYYY")}</TableCell>
                                        <TableCell>{row.time}</TableCell>
                                        <TableCell>{row.filename}</TableCell>
                                        <TableCell>{row.category}</TableCell>
                                        <TableCell>{row.unitid}</TableCell>
                                        <TableCell>{row.user}</TableCell>
                                        <TableCell>{row.section}</TableCell>
                                        <TableCell>{row.flagcount}</TableCell>
                                        <TableCell>{row.alllogin}</TableCell>
                                        <TableCell>{row.docnumber}</TableCell>
                                        <TableCell>{row.doclink}</TableCell>
                                        <TableCell>{row.startmode}</TableCell>
                                        <TableCell>{row.startdate}</TableCell>
                                        <TableCell>{row.starttime}</TableCell>
                                        <TableCell>{row.statusmode}</TableCell>
                                        <TableCell>{row.totalpages}</TableCell>
                                        <TableCell>{row.pendingpages}</TableCell>
                                        <TableCell>{row.startpage}</TableCell>
                                        <TableCell>{row.notes}</TableCell>
                                        <TableCell>{row.approvalstatus}</TableCell>
                                        <TableCell>{row.lateentrystatus}</TableCell>
                                    </TableRow>
                                ))}
                        </TableBody>
                    </Table>
                </TableContainer>

                <TableContainer
                    component={Paper}
                    style={{
                        display: canvasState === false ? "none" : "block",
                    }}
                >
                    <Table sx={{ minWidth: 700 }} aria-label="customized table" id="excelcanvastable" ref={gridRef}>
                        <TableHead>
                            <TableRow>
                                <TableCell> SI.No</TableCell>
                                <TableCell>Project Name</TableCell>
                            </TableRow>
                        </TableHead>
                        <TableBody align="left">
                            {rowDataTable &&
                                rowDataTable.map((row, index) => (
                                    <TableRow key={index}>
                                        <TableCell>{index + 1}</TableCell>
                                        <TableCell>{row.name}</TableCell>
                                    </TableRow>
                                ))}
                        </TableBody>
                    </Table>
                </TableContainer>
            </Box>

            {/* view model */}
            <Dialog
                open={openview}
                onClose={handleClickOpenview}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
                maxWidth="lg"
            >
                <Box sx={{ width: "650px", padding: '20px 50px' }}>
                    <>
                        <Typography sx={userStyle.HeaderText}> View Production Manual Entry</Typography>
                        <br /> <br />
                        <Grid container spacing={2}>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>   Vendor</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.vendor}
                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>   Date Mode</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.datemode}
                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sm={6} xs={12}>
                                <Grid container spacing={2}>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <Typography>
                                            <b>    Date</b>
                                        </Typography>
                                        <Typography>
                                            {moment(productionedit.fromdate).format("DD/MM/YYYY")}

                                        </Typography>
                                    </Grid>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <FormControl fullWidth size="small">
                                            <Typography>
                                                <b>    Time</b>
                                            </Typography>
                                            <Typography>
                                                {productionedit.time}

                                            </Typography>
                                        </FormControl>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>   Category</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.filename}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>    Sub Category</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.category}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>    Identifier</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.unitid}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>    Login Id</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.user}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>    Section</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.section}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>Total Pages</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.totalpages}

                                    </Typography>
                                </FormControl>
                            </Grid>

                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>Completed Pages</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.flagcount}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>Pending Pages</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.pendingpages}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>    All Login</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.alllogin}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>   Doc Number</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.docnumber}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>       Doc Link</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.doclink}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>Status</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.statusmode}

                                    </Typography>
                                </FormControl>
                            </Grid>
                            <Grid item md={4} sm={6} xs={12}>
                                <Grid container spacing={2}>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <Typography>
                                            <b>  End  Date</b>
                                        </Typography>
                                        <Typography>
                                            {moment(productionedit.fromdate).format("DD/MM/YYYY")}

                                        </Typography>
                                    </Grid>
                                    <Grid item md={6} sm={6} xs={12}>
                                        <FormControl fullWidth size="small">
                                            <Typography>
                                                <b>  End  Time</b>
                                            </Typography>
                                            <Typography>
                                                {productionedit.time}

                                            </Typography>
                                        </FormControl>
                                    </Grid>
                                </Grid>
                            </Grid>
                            <Grid item md={4} xs={12} sm={12}>
                                <FormControl fullWidth size="small">
                                    <Typography>
                                        <b>Start Page</b>
                                    </Typography>
                                    <Typography>
                                        {productionedit.startpage}

                                    </Typography>
                                </FormControl>
                            </Grid>
                        </Grid>
                        <br /> <br /> <br />
                        <Grid container spacing={2}>
                            <Button variant="contained" color="primary" onClick={handleCloseview}>
                                {" "}
                                Back{" "}
                            </Button>
                        </Grid>
                    </>
                </Box>
            </Dialog>

            {/* ALERT DIALOG */}
            <Box>
                <Dialog open={isErrorOpenpop} onClose={handleCloseerrpop} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <Typography variant="h6">{showAlertpop}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button
                            variant="contained"
                            style={{ padding: "7px 13px", color: "white", background: "rgb(25, 118, 210)" }}
                            onClick={() => {
                                sendEditRequest();
                                handleCloseerrpop();
                            }}
                        >
                            ok
                        </Button>
                        <Button
                            style={{
                                backgroundColor: "#f4f4f4",
                                color: "#444",
                                boxShadow: "none",
                                borderRadius: "3px",
                                padding: "7px 13px",
                                border: "1px solid #0000006b",
                                "&:hover": {
                                    "& .css-bluauu-MuiButtonBase-root-MuiButton-root": {
                                        backgroundColor: "#f4f4f4",
                                    },
                                },
                            }}
                            onClick={handleCloseerrpop}
                        >
                            Cancel
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            {/* ALERT DIALOG */}
            <Box>
                <Dialog open={isErrorOpen} onClose={handleCloseerr} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <Typography variant="h6">{showAlert}</Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button
                            variant="contained"
                            style={{
                                padding: "7px 13px",
                                color: "white",
                                background: "rgb(25, 118, 210)",
                            }}
                            onClick={handleCloseerr}
                        >
                            ok
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>

            {/* ALERT DIALOG */}
            <Dialog open={isCheckOpen} onClose={handleCloseCheck} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                    <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: "orange" }} />
                    <Typography variant="h6" sx={{ color: "black", textAlign: "center" }}>
                        {checkvendor?.length > 0 && checkcategory?.length > 0 && checksubcategory?.length > 0 && checktimepoints?.length > 0 ? (
                            <>
                                <span style={{ fontWeight: "700", color: "#777" }}>{`${deleteproject.name} `}</span>was linked in <span style={{ fontWeight: "700" }}>Vendor, Category, Subcategory & Time and points </span>
                            </>
                        ) : checkvendor?.length > 0 || checkcategory?.length > 0 || checksubcategory?.length > 0 || checktimepoints?.length > 0 ? (
                            <>
                                <span style={{ fontWeight: "700", color: "#777" }}>{`${deleteproject.name} `}</span>
                                was linked in{" "}
                                <span style={{ fontWeight: "700" }}>
                                    {checkvendor?.length ? " Vendor" : ""}
                                    {checkcategory?.length ? " Category" : ""}
                                    {checksubcategory?.length ? " Subcategory" : ""}
                                    {checktimepoints?.length ? " Time and points" : ""}
                                </span>
                            </>
                        ) : (
                            ""
                        )}
                    </Typography>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseCheck} autoFocus variant="contained" color="error">
                        {" "}
                        OK{" "}
                    </Button>
                </DialogActions>
            </Dialog>

            <Box>
                <Dialog open={isDeleteOpencheckbox} onClose={handleCloseModcheckbox} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <ErrorOutlineOutlinedIcon sx={{ fontSize: "80px", color: "orange" }} />
                        <Typography variant="h5" sx={{ color: "red", textAlign: "center" }}>
                            Are you sure?
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button onClick={handleCloseModcheckbox} sx={userStyle.btncancel}>
                            Cancel
                        </Button>
                        <Button autoFocus variant="contained" color="error" onClick={delProjectcheckbox}>
                            {" "}
                            OK{" "}
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>
            <Box>
                {/* ALERT DIALOG */}
                <Dialog open={isDeleteOpenalert} onClose={handleCloseModalert} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description">
                    <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}>
                        <ErrorOutlineOutlinedIcon sx={{ fontSize: "70px", color: "orange" }} />
                        <Typography variant="h6" sx={{ color: "black", textAlign: "center" }}>
                            Please Select any Row
                        </Typography>
                    </DialogContent>
                    <DialogActions>
                        <Button autoFocus variant="contained" color="error" onClick={handleCloseModalert}>
                            {" "}
                            OK{" "}
                        </Button>
                    </DialogActions>
                </Dialog>
            </Box>


            <Box>
                {/* Edit DIALOG */}
                <Dialog open={isEditOpen} onClose={handleCloseModEdit} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description"
                    fullWidth={true}
                    maxWidth="lg"
                    sx={{
                        overflow: "auto",
                        "& .MuiPaper-root": {
                            overflow: "auto",
                        },
                    }}

                >
                    <Box sx={{ padding: "20px" }}>
                        <>
                            <Grid container spacing={2}>
                                <Typography sx={userStyle.HeaderText}>Change Status</Typography>
                            </Grid>
                            <br />
                            <Grid container spacing={2}>
                                <Grid item md={4} xs={12} sm={12}>
                                    <FormControl fullWidth size="small">
                                        <Typography>
                                            Status <b style={{ color: "red" }}>*</b>
                                        </Typography>
                                        <Selects
                                            options={statuschange}
                                            styles={colourStyles}
                                            value={{ label: ProducionIndividualChange.statusmode, value: ProducionIndividualChange.statusmode }}
                                            onChange={(e) => {
                                                setProducionIndividualChange({ ...ProducionIndividualChange, statusmode: e.value });

                                            }}
                                        />
                                    </FormControl>
                                </Grid>

                                {(ProducionIndividualChange.statusmode === "Completed" || ProducionIndividualChange.statusmode === "Pause" || ProducionIndividualChange.statusmode === "In Complete" || ProducionIndividualChange.statusmode === "Partial Complete") && (
                                    <>

                                        <Grid item md={4} sm={6} xs={12}>
                                            <Grid container spacing={2}>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            End Date <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="date"
                                                            // disabled={ProducionIndividualChange.datemode === 'Auto'}
                                                            value={ProducionIndividualChange.fromdate}
                                                            // onChange={(e) => {
                                                            //     setProducionIndividual({ ...ProducionIndividual, fromdate: e.target.value });
                                                            // }}
                                                            onChange={handleDateChangeEdit}
                                                            inputProps={{
                                                                max: ProducionIndividualChange.datemode === 'Manual' ? formattedToday : undefined,
                                                                min: ProducionIndividualChange.datemode === 'Manual' ? formattedTwoMonthsAgo : undefined
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                                <Grid item md={6} sm={6} xs={12}>
                                                    <FormControl fullWidth size="small">
                                                        <Typography>
                                                            End  Time <b style={{ color: "red" }}>*</b>
                                                        </Typography>
                                                        <OutlinedInput
                                                            id="component-outlinedname"
                                                            type="time"
                                                            // disabled={ProducionIndividualChange.datemode === 'Auto'}
                                                            value={
                                                                ProducionIndividualChange.time}
                                                            onChange={(e) => {
                                                                setProducionIndividualChange({ ...ProducionIndividualChange, time: e.target.value });
                                                            }}
                                                        />
                                                    </FormControl>
                                                </Grid>
                                            </Grid>
                                        </Grid>

                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Total Pages <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Total Pages"
                                                    value={ProducionIndividualChange.totalpages}
                                                    onChange={(e) => handleChangephonenumbertotalChange(e)} />
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Completed Pages <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Completed Pages"
                                                    value={ProducionIndividualChange.flagcount}
                                                    onChange={(e) => handleChangephonenumberflagChange(e)} />
                                            </FormControl>
                                        </Grid>


                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Pending  Pages  <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <OutlinedInput
                                                    id="component-outlinedname"
                                                    type="text"
                                                    placeholder="Please Enter Flag Count"
                                                    value={ProducionIndividualChange.pendingpages} />
                                            </FormControl>
                                        </Grid>

                                        <Grid item md={4} sm={6} xs={12}>
                                            <FormControl fullWidth size="small">
                                                <Typography>
                                                    Start Page  <b style={{ color: "red" }}>*</b>
                                                </Typography>
                                                <Selects
                                                    // options={startpage}
                                                    options={
                                                        Array.from(
                                                            { length: ProducionIndividualChange.totalpages - ProducionIndividualChange.flagcount },
                                                            (_, index) => {
                                                                const startPageNumber = Number(ProducionIndividualChange.flagcount) + 1 + index;
                                                                return { label: startPageNumber, value: startPageNumber };
                                                            }
                                                        )
                                                    }
                                                    styles={colourStyles}
                                                    value={{ label: ProducionIndividualChange.startpage, value: ProducionIndividual.startpage }}
                                                    onChange={(e) => {
                                                        setProducionIndividualChange({ ...ProducionIndividualChange, startpage: e.value });


                                                    }}
                                                />
                                            </FormControl>
                                        </Grid>
                                    </>
                                )}



                                {(ProducionIndividualChange.statusmode === "Reject" || ProducionIndividualChange.statusmode === "Cancel") && (
                                    <>
                                        <Grid item md={4} xs={12} sm={12}>
                                            <FormControl fullWidth>
                                                <Typography>Reason<b style={{ color: "red" }}>*</b></Typography>
                                                <TextareaAutosize
                                                    aria-label="minimum height"
                                                    minRows={5}
                                                    value={ProducionIndividualChange.reason}
                                                    onChange={(e) => {
                                                        setProducionIndividualChange({ ...ProducionIndividualChange, reason: e.value });


                                                    }}
                                                />
                                            </FormControl>
                                        </Grid>
                                    </>
                                )}



                            </Grid>
                            <br /> <br />
                            <Grid container spacing={2}>
                                <Grid item md={6} xs={12} sm={12}>
                                    <Button variant="contained" sx={buttonStyles.buttonsubmit}
                                        onClick={editSubmit}
                                    >
                                        {" "}
                                        Update
                                    </Button>
                                </Grid>
                                <Grid item md={6} xs={12} sm={12}>
                                    <Button sx={buttonStyles.btncancel} onClick={handleCloseModEdit}>
                                        {" "}
                                        Cancel{" "}
                                    </Button>
                                </Grid>
                            </Grid>
                        </>
                    </Box>
                </Dialog>
            </Box>


            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpen}
                handleCloseFilterMod={handleCloseFilterMod}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpen}
                isPdfFilterOpen={isPdfFilterOpen}
                setIsPdfFilterOpen={setIsPdfFilterOpen}
                handleClosePdfFilterMod={handleClosePdfFilterMod}
                filteredDataTwo={filteredDatas ?? []}
                itemsTwo={items ?? []}
                filename={"Production Individual"}
                exportColumnNames={exportColumnNames}
                exportRowValues={exportRowValues}
                componentRef={componentRef}
            />


        </Box>
    );
}

export default ProductionIndividual;