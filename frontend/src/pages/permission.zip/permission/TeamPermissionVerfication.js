import React, { useState, useEffect, useRef, useContext, useMemo, useCallback } from "react";
import { FaFileExcel, FaFileCsv, FaPrint, FaFilePdf, FaEdit, FaSearch } from 'react-icons/fa';
import { handleApiError } from "../../components/Errorhandling";
import { Box, Typography, OutlinedInput, TableBody, TableRow, TableCell, Select, MenuItem, Dialog, DialogContent, DialogActions, FormControl, Grid, Paper, Table, TableHead, TableContainer, Button, Popover, Checkbox, IconButton, TextareaAutosize, InputLabel, InputAdornment, Tooltip } from "@mui/material";
import { userStyle } from "../../pageStyle";
import jsPDF from "jspdf";
import "jspdf-autotable";
import axios from "axios";
import { SERVICE } from "../../services/Baseservice";
import VisibilityOutlinedIcon from "@mui/icons-material/VisibilityOutlined";
import { useReactToPrint } from "react-to-print";
import moment, { invalid } from "moment-timezone";
import { UserRoleAccessContext, AuthContext } from "../../context/Appcontext";
import Headtitle from "../../components/Headtitle";
import { ThreeDots } from "react-loader-spinner";
import Selects from "react-select";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import NavigateBeforeIcon from "@mui/icons-material/NavigateBefore";
import LastPageIcon from "@mui/icons-material/LastPage";
import FirstPageIcon from "@mui/icons-material/FirstPage";
import { saveAs } from "file-saver";
import ImageIcon from "@mui/icons-material/Image";
import CheckCircleIcon from '@mui/icons-material/CheckCircle';
import Webcamimage from "../hr/webcamprofile";
import FormControlLabel from '@mui/material/FormControlLabel';
import CameraAltIcon from "@mui/icons-material/CameraAlt";
import DeleteIcon from "@mui/icons-material/Delete";
import Stack from '@mui/material/Stack';
import Radio from '@mui/material/Radio';
import RadioGroup from '@mui/material/RadioGroup';
import { IoMdOptions } from "react-icons/io";
import { MdClose } from "react-icons/md";
import domtoimage from 'dom-to-image';
import { AgGridReact } from "ag-grid-react";
import "ag-grid-community/styles/ag-grid.css";
import "ag-grid-community/styles/ag-theme-quartz.css";
import ExportData from "../../components/ExportData";
import MessageAlert from "../../components/MessageAlert";
import PageHeading from "../../components/PageHeading";
import AlertDialog from "../../components/Alert";
import AdvancedSearchBar from '../../components/SearchbarEbList';
import ManageColumnsContent from "../../components/ManageColumn";
import ResizeObserver from 'resize-observer-polyfill';
window.ResizeObserver = ResizeObserver;

function TeamPermissionVerification() {

  let today = new Date();
  var dd = String(today.getDate()).padStart(2, "0");
  var mm = String(today.getMonth() + 1).padStart(2, "0");
  var yyyy = today.getFullYear();
  let formattedDate = yyyy + "-" + mm + "-" + dd;

  const gridRefTableApprovedPerm = useRef(null);
  const gridRefImageApprovedPerm = useRef(null);

  const [minDate, setMinDate] = useState("");

  // Calculate the minimum date as today
  useEffect(() => {
    const today = new Date();

    // Format the date as 'YYYY-MM-DD' for the input element
    const formattedToday = today.toISOString().split("T")[0];
    setMinDate(formattedToday);
  }, []);

  const [permissions, setPermissions] = useState([]);
  const [isPermissions, setIsPermissions] = useState([]);
  const [Accessdrop, setAccesDrop] = useState("Employee");
  const [AccessdropEdit, setAccesDropEdit] = useState("Employee");
  const { isUserRoleCompare, isUserRoleAccess, pageName, setPageName, buttonStyles } = useContext(UserRoleAccessContext);
  const [selectStatus, setSelectStatus] = useState({});
  const [permissionSelf, setPermissionSelf] = useState([]);

  // State to track advanced filter
  const [advancedFilter, setAdvancedFilter] = useState(null);
  const [gridApi, setGridApi] = useState(null);
  const [columnApi, setColumnApi] = useState(null);
  const [filteredDataItems, setFilteredDataItems] = useState(permissions);
  const [filteredRowData, setFilteredRowData] = useState([]);

  const [applypermission, setApplyPermission] = useState({
    companyname: "Please Select Company",
    branch: "Please Select Branch",
    unit: "Please Select Branch",
    team: "Please Select Team",
    employeename: "Please Select Employee Name",
    employeeid: "",
    permissiontype: "Hours",
    date: "",
    fromtime: "",
    endtime: "",
    reasonforpermission: "",
    reportingto: "",
    shifttiming: "",
    requesthours: "",
    time: "",
  });
  const [getTiming, setGetTiming] = useState("");
  const [permissionedit, setPermissionEdit] = useState([]);
  const [applyleaves, setApplyleaves] = useState([]);
  const [leaveId, setLeaveId] = useState("");
  const [allApplyleaveedit, setAllApplyleaveedit] = useState([]);

  const [type, settype] = useState("Hours");
  const [leaveEdit, setLeaveEdit] = useState("Hours");
  const [applytype, setApplytype] = useState("Please Select ApplyType");
  const [applytypeEdit, setApplytypeEdit] = useState("Please Select ApplyType");

  const [statusOpen, setStatusOpen] = useState(false);
  const handleStatusOpen = () => { setStatusOpen(true); };
  const handleStatusClose = () => { setStatusOpen(false); };

  const { auth } = useContext(AuthContext);

  const [applyleaveCheck, setApplyleavecheck] = useState(false);

  const username = isUserRoleAccess.username;

  const [isFilterOpen, setIsFilterOpen] = useState(false);
  const [isPdfFilterOpen, setIsPdfFilterOpen] = useState(false);
  // page refersh reload
  const handleCloseFilterMod = () => { setIsFilterOpen(false); };
  const handleClosePdfFilterMod = () => { setIsPdfFilterOpen(false); }

  const [openPopupMalert, setOpenPopupMalert] = useState(false);
  const [popupContentMalert, setPopupContentMalert] = useState("");
  const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
  const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
  const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

  const [openPopup, setOpenPopup] = useState(false);
  const [popupContent, setPopupContent] = useState("");
  const [popupSeverity, setPopupSeverity] = useState("");
  const handleClickOpenPopup = () => { setOpenPopup(true); };
  const handleClosePopup = () => { setOpenPopup(false); }

  //Datatable
  const [pageApprovedPerm, setPageApprovedPerm] = useState(1);
  const [pageSizeApprovedPerm, setPageSizeApprovedPerm] = useState(10);
  const [searchQueryApprovedPerm, setSearchQueryApprovedPerm] = useState("");
  const [totalPagesApprovedPerm, setTotalPagesApprovedPerm] = useState(1);

  // view model
  const [openview, setOpenview] = useState(false);
  const handleClickOpenview = () => { setOpenview(true); };
  const handleCloseview = () => { setOpenview(false); };

  // Error Popup model
  const [isErrorOpen, setIsErrorOpen] = useState(false);
  const [showAlert, setShowAlert] = useState();
  const handleClickOpenerr = () => { setIsErrorOpen(true); };
  const handleCloseerr = () => { setIsErrorOpen(false); };

  //Delete model
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const handleClickOpen = () => { setIsDeleteOpen(true); };
  const handleCloseMod = () => { setIsDeleteOpen(false); };

  //Delete model
  const [isDeleteOpencheckbox, setIsDeleteOpencheckbox] = useState(false);
  const handleClickOpencheckbox = () => { setIsDeleteOpencheckbox(true); };
  const handleCloseModcheckbox = () => { setIsDeleteOpencheckbox(false); };

  // Manage Columns
  const [isManageColumnsOpenApprovedPerm, setManageColumnsOpenApprovedPerm] = useState(false);
  const [anchorElApprovedPerm, setAnchorElApprovedPerm] = useState(null);
  const [searchQueryManageApprovedPerm, setSearchQueryManageApprovedPerm] = useState("");

  const handleOpenManageColumnsApprovedPerm = (event) => {
    setAnchorElApprovedPerm(event.currentTarget);
    setManageColumnsOpenApprovedPerm(true);
  };
  const handleCloseManageColumnsApprovedPerm = () => {
    setManageColumnsOpenApprovedPerm(false);
    setSearchQueryManageApprovedPerm("");
  };

  const openApprovedPerm = Boolean(anchorElApprovedPerm);
  const idApprovedPerm = openApprovedPerm ? "simple-popover" : undefined;

  // Search bar
  const [anchorElSearchApprovedPerm, setAnchorElSearchApprovedPerm] = React.useState(null);
  const handleClickSearchApprovedPerm = (event) => {
    setAnchorElSearchApprovedPerm(event.currentTarget);
  };
  const handleCloseSearchApprovedPerm = () => {
    setAnchorElSearchApprovedPerm(null);
    setSearchQueryApprovedPerm("");
  };

  const openSearchApprovedPerm = Boolean(anchorElSearchApprovedPerm);
  const idSearchApprovedPerm = openSearchApprovedPerm ? 'simple-popover' : undefined;

  // Table row color
  const getRowStyle = (params) => {
    if (params.node.rowIndex % 2 === 0) {
      return { background: '#f0f0f0' }; // Even row
    } else {
      return { background: '#ffffff' }; // Odd row
    }
  }

  useEffect(() => {
    getapi();
  }, []);

  const getapi = async () => {
    let userchecks = axios.post(`${SERVICE.CREATE_USERCHECKS}`, {
      headers: {
        'Authorization': `Bearer ${auth.APIToken}`,
      },
      empcode: String(isUserRoleAccess?.empcode),
      companyname: String(isUserRoleAccess?.companyname),
      pagename: String("Team Permission Verification"),
      commonid: String(isUserRoleAccess?._id),
      date: String(new Date()),
      addedby: [
        {
          name: String(isUserRoleAccess?.username),
          date: String(new Date()),
        },
      ],
    });
  }

  const [isEditOpenCheckList, setIsEditOpenCheckList] = useState(false);
  const handleClickOpenEditCheckList = () => {
    setIsEditOpenCheckList(true);
  };
  const handleCloseModEditCheckList = (e, reason) => {
    if (reason && reason === "backdropClick") return;
    setIsEditOpenCheckList(false);
  };

  const [isCheckedList, setIsCheckedList] = useState([]);
  const [isCheckedListOverall, setIsCheckedListOverall] = useState(false);
  const overallCheckListChange = () => {
    let newArrayChecked = isCheckedList.map((item) => item = !isCheckedListOverall);

    let returnOverall = groupDetails.map((row) => {

      {
        if (row.checklist === "DateTime") {
          if ((((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16)) {
            return true;
          } else {
            return false;
          }
        }
        else if (row.checklist === "Date Multi Span") {
          if ((((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 21)) {
            return true;
          } else {
            return false;
          }
        }
        else if (row.checklist === "Date Multi Span Time") {
          if ((((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 33)) {
            return true;
          } else {
            return false;
          }
        }
        else if (row.checklist === "Date Multi Random Time") {
          if ((((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16)) {
            return true;
          } else {
            return false;
          }

        }
        else if (((row.data !== undefined && row.data !== "") || (row.files !== undefined))) {
          return true;
        } else {
          return false;
        }

      }

    })

    let allcondition = returnOverall.every((item) => item == true);

    if (allcondition) {
      setIsCheckedList(newArrayChecked);
      setIsCheckedListOverall(!isCheckedListOverall);
    } else {
      setPopupContentMalert("Please Fill all the Fields");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }


  }
  const handleCheckboxChange = (index) => {
    const newCheckedState = [...isCheckedList];
    newCheckedState[index] = !newCheckedState[index];

    let currentItem = groupDetails[index];

    let data = () => {
      if (currentItem.checklist === "DateTime") {
        if ((((currentItem.data !== undefined && currentItem.data !== "") || (currentItem.files !== undefined)) && currentItem.data.length === 16)) {
          return true;
        } else {
          return false;
        }
      }
      else if (currentItem.checklist === "Date Multi Span") {
        if ((((currentItem.data !== undefined && currentItem.data !== "") || (currentItem.files !== undefined)) && currentItem.data.length === 21)) {
          return true;
        } else {
          return false;
        }
      }
      else if (currentItem.checklist === "Date Multi Span Time") {
        if ((((currentItem.data !== undefined && currentItem.data !== "") || (currentItem.files !== undefined)) && currentItem.data.length === 33)) {
          return true;
        } else {
          return false;
        }
      }
      else if (currentItem.checklist === "Date Multi Random Time") {
        if ((((currentItem.data !== undefined && currentItem.data !== "") || (currentItem.files !== undefined)) && currentItem.data.length === 16)) {
          return true;
        } else {
          return false;
        }

      }
      else if (((currentItem.data !== undefined && currentItem.data !== "") || (currentItem.files !== undefined))) {
        return true;
      } else {
        return false;
      }
    }

    if (data()) {
      setIsCheckedList(newCheckedState);
      handleDataChange(newCheckedState[index], index, "Check Box");
      let overallChecked = newCheckedState.every((item) => item === true);

      if (overallChecked) {
        setIsCheckedListOverall(true);
      } else {
        setIsCheckedListOverall(false);
      }
    } else {
      setPopupContentMalert("Please Fill the Field");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    }
  };

  let name = "create";

  //webcam
  const [isWebcamOpen, setIsWebcamOpen] = useState(false);
  const [getImg, setGetImg] = useState(null);
  const [isWebcamCapture, setIsWebcamCapture] = useState(false);
  const [selectedFile, setSelectedFile] = useState(null);
  const [capturedImages, setCapturedImages] = useState([]);
  const [valNum, setValNum] = useState(0);

  const webcamOpen = () => {
    setIsWebcamOpen(true);
  };
  const webcamClose = () => {
    setIsWebcamOpen(false);
  };
  const webcamDataStore = () => {
    setIsWebcamCapture(true);
    //popup close
    webcamClose();
  };

  //add webcamera popup
  const showWebcam = () => {
    webcamOpen();
  };

  const renderFilePreviewEdit = async (file) => {
    const response = await fetch(file.preview);
    const blob = await response.blob();
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    window.open(link, "_blank");
  };
  const handleFileDeleteEdit = (index) => {
    let getData = groupDetails[index];
    delete getData.files;
    let finalData = getData;

    let updatedTodos = [...groupDetails];
    updatedTodos[index] = finalData;
    setGroupDetails(updatedTodos);
  };

  const [assignDetails, setAssignDetails] = useState();
  const [groupDetails, setGroupDetails] = useState();
  const [datasAvailedDB, setDatasAvailedDB] = useState();
  const [disableInput, setDisableInput] = useState([]);
  const [getDetails, setGetDetails] = useState();


  const [dateValue, setDateValue] = useState([]);
  const [timeValue, setTimeValue] = useState([]);

  const [dateValueRandom, setDateValueRandom] = useState([]);
  const [timeValueRandom, setTimeValueRandom] = useState([]);

  const [dateValueMultiFrom, setDateValueMultiFrom] = useState([]);
  const [dateValueMultiTo, setDateValueMultiTo] = useState([]);
  const [postID, setPostID] = useState();
  const [pagesDetails, setPagesDetails] = useState({});
  const [fromWhere, setFromWhere] = useState("");

  const [firstDateValue, setFirstDateValue] = useState([]);
  const [firstTimeValue, setFirstTimeValue] = useState([]);
  const [secondDateValue, setSecondDateValue] = useState([]);
  const [secondTimeValue, setSecondTimeValue] = useState([]);

  const [isCheckList, setIsCheckList] = useState(true);

  let completedbyName = isUserRoleAccess.companyname;

  const updateIndividualData = async (index) => {
    setPageName(!pageName)
    let searchItem = datasAvailedDB.find((item) => item.commonid == postID && item.module == "Leave&Permission" && item.submodule == "Permission" && item.mainpage == "Apply Permission" && item.status.toLowerCase() !== "completed");

    let combinedGroups = groupDetails?.map((data) => {
      let check = (data.data !== undefined && data.data !== "") || data.files !== undefined;

      if (check) {
        return {
          ...data, completedby: completedbyName, completedat: new Date()
        }
      } else {
        return {
          ...data, completedby: "", completedat: ""
        }
      }

    })

    try {
      let objectID = combinedGroups[index]?._id;
      let objectData = combinedGroups[index];
      if (searchItem) {
        let assignbranches = await axios.put(
          `${SERVICE.MYCHECKLIST_SINGLEBYOBJECTID}/${objectID}`,
          {
            headers: {
              Authorization: `Bearer ${auth.APIToken}`,
            },
            data: String(objectData?.data),
            lastcheck: objectData?.lastcheck,
            newFiles: objectData?.files,
            completedby: objectData?.completedby,
            completedat: objectData?.completedat
          }
        );
        await fecthDBDatas();
      } else {
        let assignbranches = await axios.post(
          `${SERVICE.MYCHECKLIST_CREATE}`,
          {
            headers: {
              Authorization: `Bearer ${auth.APIToken}`,
            },
            commonid: postID,
            module: pagesDetails?.module,
            submodule: pagesDetails?.submodule,
            mainpage: pagesDetails?.mainpage,
            subpage: pagesDetails?.subpage,
            subsubpage: pagesDetails?.subsubpage,
            category: assignDetails?.category,
            subcategory: assignDetails?.subcategory,
            candidatename: assignDetails?.fullname,
            status: "progress",
            groups: combinedGroups,
            addedby: [
              {
                name: String(username),
                date: String(new Date()),
              },
            ],
          }
        );
        await fecthDBDatas();
      }
      setPopupContent("Updated Successfully");
      setPopupSeverity("success");
      handleClickOpenPopup();

    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  }

  async function fecthDBDatas() {
    setPageName(!pageName)
    try {
      let res = await axios.get(SERVICE.MYCHECKLIST);
      setDatasAvailedDB(res?.data?.mychecklist);

      let foundData = res?.data?.mychecklist.find((item) => item.commonid == postID)
      setGroupDetails(foundData?.groups);
    }
    catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  }


  const updateDateValuesAtIndex = (value, index) => {

    setDateValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "DateTime", "date")
  };

  const updateTimeValuesAtIndex = (value, index) => {

    setTimeValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "DateTime", "time")
  };
  //---------------------------------------------------------------------------------------------------------------

  const updateFromDateValueAtIndex = (value, index) => {

    setDateValueMultiFrom(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span", "fromdate")
  };

  const updateToDateValueAtIndex = (value, index) => {

    setDateValueMultiTo(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span", "todate")
  };
  //---------------------------------------------------------------------------------------------------------------------------------
  const updateDateValueAtIndex = (value, index) => {

    setDateValueRandom(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Random Time", "date")
  };

  const updateTimeValueAtIndex = (value, index) => {

    setTimeValueRandom(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Random Time", "time")
  };
  //---------------------------------------------------------------------------------------------------------------------------------------



  const updateFirstDateValuesAtIndex = (value, index) => {

    setFirstDateValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span Time", "fromdate")
  };

  const updateFirstTimeValuesAtIndex = (value, index) => {

    setFirstTimeValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span Time", "fromtime")
  };

  const updateSecondDateValuesAtIndex = (value, index) => {

    setSecondDateValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span Time", "todate")
  };

  const updateSecondTimeValuesAtIndex = (value, index) => {

    setSecondTimeValue(prevArray => {
      const newArray = [...prevArray]; // Create a copy of the array
      newArray[index] = value; // Update value at the specified index
      return newArray; // Return the updated array
    });
    handleDataChange(value, index, "Date Multi Span Time", "totime")
  };

  //------------------------------------------------------------------------------------------------------------

  const handleDataChange = (e, index, from, sub) => {

    let getData;
    let finalData;
    let updatedTodos;
    switch (from) {
      case 'Check Box':
        getData = groupDetails[index];
        finalData = {
          ...getData, lastcheck: e
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Text Box':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Text Box-number':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Text Box-alpha':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Text Box-alphanumeric':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Attachments':
        getData = groupDetails[index];
        finalData = {
          ...getData, files: e
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Pre-Value':
        break;
      case 'Date':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Time':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'DateTime':
        if (sub == "date") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${e} ${timeValue[index]}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        } else {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${dateValue[index]} ${e}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        }

        break;
      case 'Date Multi Span':
        if (sub == "fromdate") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${e} ${dateValueMultiTo[index]}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        } else {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${dateValueMultiFrom[index]} ${e}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        }
        break;
      case 'Date Multi Span Time':
        if (sub == "fromdate") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${e} ${firstTimeValue[index]}/${secondDateValue[index]} ${secondTimeValue[index]}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        } else if (sub == "fromtime") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${firstDateValue[index]} ${e}/${secondDateValue[index]} ${secondTimeValue[index]}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        }
        else if (sub == "todate") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${firstDateValue[index]} ${firstTimeValue[index]}/${e} ${secondTimeValue[index]}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        } else {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${firstDateValue[index]} ${firstTimeValue[index]}/${secondDateValue[index]} ${e}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        }
        break;
      case 'Date Multi Random':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
      case 'Date Multi Random Time':

        if (sub == "date") {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${e} ${timeValueRandom[index]}`
          }


          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        } else {
          getData = groupDetails[index];
          finalData = {
            ...getData, data: `${dateValueRandom[index]} ${e}`
          }

          updatedTodos = [...groupDetails];
          updatedTodos[index] = finalData;
          setGroupDetails(updatedTodos);
        }
        break;
      case 'Radio':
        getData = groupDetails[index];
        finalData = {
          ...getData, data: e.target.value
        }

        updatedTodos = [...groupDetails];
        updatedTodos[index] = finalData;
        setGroupDetails(updatedTodos);
        break;
    }
  }

  const handleChangeImage = (event, index) => {

    const resume = event.target.files;


    const reader = new FileReader();
    const file = resume[0];
    reader.readAsDataURL(file);

    reader.onload = () => {
      handleDataChange(
        {
          name: file.name,
          preview: reader.result,
          data: reader.result.split(",")[1],
          remark: "resume file",
        }, index, "Attachments")

    };

  };

  const getCodeNew = async (details) => {
    setPageName(!pageName)
    setGetDetails(details);
    try {
      let res = await axios.get(SERVICE.MYCHECKLIST);
      setDatasAvailedDB(res?.data?.mychecklist);
      let searchItem = res?.data?.mychecklist.find((item) => item.commonid == details?.id && item.module == "Leave&Permission" && item.submodule == "Permission" && item.mainpage == "Apply Permission" && item.status.toLowerCase() !== "completed");

      if (searchItem) {
        setAssignDetails(searchItem);

        setPostID(searchItem?.commonid);

        setGroupDetails(
          searchItem?.groups?.map((data) => ({
            ...data,
            lastcheck: false,
          }))
        );

        setIsCheckedList(searchItem?.groups?.map((data) => data.lastcheck));


        let forFillDetails = searchItem?.groups?.map((data) => {
          if (data.checklist === "Date Multi Random Time") {
            if (data?.data && data?.data !== "") {
              const [date, time] = data?.data?.split(" ");
              return { date, time };
            }

          } else {
            return { date: "0", time: "0" };
          }
        });

        let forDateSpan = searchItem?.groups?.map((data) => {
          if (data.checklist === "Date Multi Span") {
            if (data?.data && data?.data !== "") {
              const [fromdate, todate] = data?.data?.split(" ");
              return { fromdate, todate };
            }
          } else {
            return { fromdate: "0", todate: "0" };
          }
        })


        let forDateTime = searchItem?.groups?.map((data) => {
          if (data.checklist === "DateTime") {
            if (data?.data && data?.data !== "") {
              const [date, time] = data?.data?.split(" ");
              return { date, time };
            }
          } else {
            return { date: "0", time: "0" };
          }
        })

        let forDateMultiSpanTime = searchItem?.groups?.map((data) => {
          if (data.checklist === "Date Multi Span Time") {
            if (data?.data && data?.data !== "") {
              const [from, to] = data?.data?.split("/");
              const [fromdate, fromtime] = from?.split(" ");
              const [todate, totime] = to?.split(" ");
              return { fromdate, fromtime, todate, totime };
            }
          } else {
            return { fromdate: "0", fromtime: "0", todate: "0", totime: "0" };
          }
        })

        setDateValueMultiFrom(forDateSpan.map((item) => item?.fromdate))
        setDateValueMultiTo(forDateSpan.map((item) => item?.todate))

        setDateValueRandom(forFillDetails.map((item) => item?.date))
        setTimeValueRandom(forFillDetails.map((item) => item?.time))

        setDateValue(forDateTime.map((item) => item?.date))
        setTimeValue(forDateTime.map((item) => item?.time))

        setFirstDateValue(forDateMultiSpanTime.map((item) => item?.fromdate))
        setFirstTimeValue(forDateMultiSpanTime.map((item) => item?.fromtime))
        setSecondDateValue(forDateMultiSpanTime.map((item) => item?.todate))
        setSecondTimeValue(forDateMultiSpanTime.map((item) => item?.totime))

        setDisableInput(new Array(details?.groups?.length).fill(true))
      }
      else {
        setIsCheckList(false);
      }
      // else {
      //     setAssignDetails(details);
      //     setPostID(details?.id);
      //     let datasNew = details.groups.map((item) => {
      //         switch (item.details) {
      //             case 'LEGALNAME':
      //                 return {
      //                     ...item, data: details.fullname
      //                 }
      //                 break;
      //             case 'USERNAME':
      //                 return {
      //                     ...item, data: details.username
      //                 }
      //                 break;
      //             case 'PASSWORD':
      //                 return {
      //                     ...item, data: details.password
      //                 }
      //                 break;
      //             case 'DATE OF BIRTH':
      //                 return {
      //                     ...item, data: details.dateofbirth
      //                 }
      //                 break;
      //             case 'EMAIL':
      //                 return {
      //                     ...item, data: details.email
      //                 }
      //                 break;
      //             case 'PHONE NUMBER':
      //                 return {
      //                     ...item, data: details.mobile
      //                 }
      //                 break;
      //             case 'FIRST NAME':
      //                 return {
      //                     ...item, data: details.firstname
      //                 }
      //                 break;
      //             case 'LAST NAME':
      //                 return {
      //                     ...item, data: details.lastname
      //                 }
      //                 break;
      //             case 'AADHAAR NUMBER':
      //                 return {
      //                     ...item, data: details.adharnumber
      //                 }
      //                 break;
      //             case 'PAN NUMBER':
      //                 return {
      //                     ...item, data: details.pannumber
      //                 }
      //                 break;
      //             case 'CURRENT ADDRESS':
      //                 return {
      //                     ...item, data: details.address
      //                 }
      //                 break;
      //             default:
      //                 return {
      //                     ...item
      //                 }
      //         }
      //     })
      //     setGroupDetails(
      //         datasNew?.map((data) => ({
      //             ...data,
      //             lastcheck: false,
      //         }))
      //     );

      //     setDateValueRandom(new Array(details.groups.length).fill(0))
      //     setTimeValueRandom(new Array(details.groups.length).fill(0))

      //     setDateValueMultiFrom(new Array(details.groups.length).fill(0))
      //     setDateValueMultiTo(new Array(details.groups.length).fill(0))

      //     setDateValue(new Array(details.groups.length).fill(0))
      //     setTimeValue(new Array(details.groups.length).fill(0))

      //     setFirstDateValue(new Array(details.groups.length).fill(0))
      //     setFirstTimeValue(new Array(details.groups.length).fill(0))
      //     setSecondDateValue(new Array(details.groups.length).fill(0))
      //     setSecondTimeValue(new Array(details.groups.length).fill(0))

      //     setDisableInput(new Array(details.groups.length).fill(true))
      // }

    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }

  };


  const handleCheckListSubmit = async () => {
    let nextStep = isCheckedList.every((item) => item == true);

    if (!nextStep) {
      setPopupContentMalert("Please Fill all the Fields");
      setPopupSeverityMalert("warning");
      handleClickOpenPopupMalert();
    } else {
      sendRequestCheckList();
    }
  }



  const sendRequestCheckList = async () => {
    setPageName(!pageName)
    let combinedGroups = groupDetails?.map((data) => {
      let check = (data.data !== undefined && data.data !== "") || data.files !== undefined;

      if (check) {
        return {
          ...data, completedby: completedbyName, completedat: new Date()
        }
      } else {
        return {
          ...data, completedby: "", completedat: ""
        }
      }

    })

    try {

      let assignbranches = await axios.put(
        `${SERVICE.MYCHECKLIST_SINGLE}/${assignDetails?._id}`,
        {
          headers: {
            Authorization: `Bearer ${auth.APIToken}`,
          },
          commonid: assignDetails?.commonid,
          module: assignDetails?.module,
          submodule: assignDetails?.submodule,
          mainpage: assignDetails?.mainpage,
          subpage: assignDetails?.subpage,
          subsubpage: assignDetails?.subsubpage,
          category: assignDetails?.category,
          subcategory: assignDetails?.subcategory,
          candidatename: assignDetails?.fullname,
          status: "Completed",
          groups: combinedGroups,
          updatedby: [
            ...assignDetails?.updatedby,
            {
              name: String(username),
              date: String(new Date()),
            },
          ],
        }
      );
      handleCloseModEditCheckList()
      setIsCheckedListOverall(false);
      sendEditStatus();

    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // Show All Columns & Manage Columns
  const initialColumnVisibilityApprovedPerm = {
    serialNumber: true,
    checkbox: true,
    requesthours: true,
    fromtime: true,
    endtime: true,
    employeename: true,
    employeeid: true,
    date: true,
    reasonforpermission: true,
    reportingto: true,
    status: true,
    actions: true,
  };

  const [columnVisibilityApprovedPerm, setColumnVisibilityApprovedPerm] = useState(initialColumnVisibilityApprovedPerm);

  // page refersh reload code
  const handleBeforeUnload = (event) => {
    event.preventDefault();
    event.returnValue = ""; // This is required for Chrome support
  };




  const [empnames, setEmpname] = useState([]);
  const [empnamesEdit, setEmpnameEdit] = useState([]);
  const [company, setCompany] = useState([]);
  const [branchOptions, setBranchOptions] = useState([]);
  const [unitOptions, setUnitOptions] = useState([]);
  const [teamOptions, setTeamOptions] = useState([]);
  const [userOptions, setUserOptions] = useState([]);

  const fetchCategoryTicket = async () => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.USER, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      const empall = [
        ...res_emp?.data?.users
          .filter((data) => data.companyname !== isUserRoleAccess.companyname)
          .map((d) => ({
            ...d,
            label: d.companyname,
            value: d.companyname,
          })),
      ];

      setEmpname(empall);
      setEmpnameEdit(empall);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching company for optionsd
  const fetchCompany = async () => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.COMPANY, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      const getCompany = [
        ...res_emp?.data?.companies.map((d) => ({
          ...d,
          label: d.name,
          value: d.name,
        })),
      ];

      setCompany(getCompany);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching branch for options
  const fetchBranch = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.BRANCH, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let getCompanyBranch = res_emp.data.branch.filter(
        (data) => data.company == e.value
      );
      const getBranch = [
        ...getCompanyBranch.map((d) => ({
          ...d,
          label: d.name,
          value: d.name,
        })),
      ];

      setBranchOptions(getBranch);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching branch for options
  const fetchUnit = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.UNIT, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let getCompanyBranch = res_emp.data.units.filter(
        (data) => data.branch == e.value
      );
      const getUnit = [
        ...getCompanyBranch.map((d) => ({
          ...d,
          label: d.name,
          value: d.name,
        })),
      ];
      setUnitOptions(getUnit);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching team for options
  const fetchTeam = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.TEAMS, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let getCompanyBranch = res_emp.data.teamsdetails.filter(
        (data) => data.unit == e.value
      );
      const getTeam = [
        ...getCompanyBranch.map((d) => ({
          ...d,
          label: d.teamname,
          value: d.teamname,
        })),
      ];
      setTeamOptions(getTeam);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching users  for options
  const fetchUsers = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.USER, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let getCompanyBranch = res_emp.data.users.filter(
        (data) => data.team == e.value
      );

      const getUser = [
        ...getCompanyBranch.map((d) => ({
          ...d,
          label: d.companyname,
          value: d.companyname,
        })),
      ];
      setUserOptions(getUser);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching shift for optionsd
  const fetchShift = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.SHIFT, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let filterShit = res_emp.data.shifts.find(
        (data) => data.name == e.shifttiming
      );
      setApplyPermission({
        ...applypermission,
        employeename: e.value,
        employeeid: e.empcode,
        reportingto: e.reportingto,
        shifttiming: e.shifttiming,
        time: `${filterShit?.fromhour}:${filterShit?.frommin}:${filterShit?.fromtime} to ${filterShit?.tohour}:${filterShit?.tomin}:${filterShit?.totime}`,
      });
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching shift for optionsd
  const fetchShiftEdit = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.SHIFT, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      let filterShit = res_emp.data.shifts.find(
        (data) => data.name == e.shifttiming
      );
      setPermissionEdit({
        ...permissionedit,
        employeename: e.value,
        employeeid: e.empcode,
        reportingto: e.reportingto,
        shifttiming: e.shifttiming,
        time: `${filterShit?.fromhour}:${filterShit?.frommin}:${filterShit?.fromtime} to ${filterShit?.tohour}:${filterShit?.tomin}:${filterShit?.totime}`,
      });
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // fetching shift for optionsd
  const fetchShiftuser = async (e) => {
    setPageName(!pageName)
    try {
      let res_emp = await axios.get(SERVICE.SHIFT, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      let filterShit = res_emp.data.shifts.find(
        (data) => data.name == isUserRoleAccess.shifttiming
      );
      setGetTiming(
        `${filterShit?.fromhour}:${filterShit?.frommin}:${filterShit?.fromtime} to ${filterShit?.tohour}:${filterShit?.tomin}:${filterShit?.totime}`
      );
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  useEffect(() => {
    fetchShiftuser();
  }, []);

  const [maxTime, setTimeMax] = useState("");
  const [minTime, setTimeMin] = useState("");
  const [showMinTime, setShowMinTime] = useState("");
  const [showMaxTime, setShowMaxTime] = useState("");
  const getTypeofHours = (e) => {
    let timingShift = Accessdrop === "HR" ? applypermission.time : getTiming;

    let splitedTime = timingShift.split("to");
    let setTimeBefore = splitedTime[0].trim();
    let setLastTime = splitedTime[1].trim();

    let isAMlast = setLastTime.includes("PM");
    let [hoursl, minutesl] = setLastTime.split(":").map(Number);

    let isAM = setTimeBefore.includes("AM");
    let [hours, minutes] = setTimeBefore.split(":").map(Number);

    if (!isAM && hoursl !== 12) {
      hours += 12;
    }

    if (!isAMlast && hours !== 12) {
      hours += 12;
    }
    const startTime = new Date(yyyy, 0, 1, hours, minutes);

    const endTime = new Date(yyyy, 0, 1, hoursl, minutesl);

    if (e === "beforeshift") {
      const beforeShiftTime = new Date(startTime.getTime());
      const formattedEndTime = beforeShiftTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTime(
        beforeShiftTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMin(formattedEndTime);
      const inBetweenTime = new Date(startTime.getTime() + 4 * 60 * 60 * 1000);
      const formattedEnd = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTime(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMax(formattedEnd);
    } else if (e === "endshift") {
      const inBetweenTime = new Date(startTime.getTime() + 4 * 60 * 60 * 1000);
      const formattedEndTime = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTime(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMin(formattedEndTime);
      const maxBetween = new Date(inBetweenTime.getTime() + 4 * 60 * 60 * 1000);
      const formatMaxTime = maxBetween.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTime(
        maxBetween.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMax(formatMaxTime);
    } else {
      const beforeShiftTime = new Date(startTime.getTime());
      const formattedEndTime = beforeShiftTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTime(
        beforeShiftTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMin(formattedEndTime);
      const inBetweenTime = new Date(endTime.getTime());
      const formattedEnd = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTime(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMax(formattedEnd);
    }
  };

  const [maxTimeEdit, setTimeMaxEdit] = useState("");
  const [minTimeEdit, setTimeMinEdit] = useState("");
  const [showMinTimeEdit, setShowMinTimeEdit] = useState("");
  const [showMaxTimeEdit, setShowMaxTimeEdit] = useState("");

  const getTypeofHoursEdit = (e) => {
    let timingShift = AccessdropEdit === "HR" ? permissionedit.time : getTiming;

    let splitedTime = timingShift.split("to");
    let setTimeBefore = splitedTime[0].trim();
    let setLastTime = splitedTime[1].trim();

    let isAMlast = setLastTime.includes("PM");
    let [hoursl, minutesl] = setLastTime.split(":").map(Number);

    let isAM = setTimeBefore.includes("AM");
    let [hours, minutes] = setTimeBefore.split(":").map(Number);

    if (!isAM && hoursl !== 12) {
      hours += 12;
    }

    if (!isAMlast && hours !== 12) {
      hours += 12;
    }
    const startTime = new Date(yyyy, 0, 1, hours, minutes);

    const endTime = new Date(yyyy, 0, 1, hoursl, minutesl);

    if (e === "beforeshift") {
      const beforeShiftTime = new Date(startTime.getTime());
      const formattedEndTime = beforeShiftTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTimeEdit(
        beforeShiftTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMinEdit(formattedEndTime);
      const inBetweenTime = new Date(startTime.getTime() + 4 * 60 * 60 * 1000);
      const formattedEnd = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTimeEdit(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMaxEdit(formattedEnd);
    } else if (e === "endshift") {
      const inBetweenTime = new Date(startTime.getTime() + 4 * 60 * 60 * 1000);
      const formattedEndTime = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTimeEdit(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMinEdit(formattedEndTime);
      const maxBetween = new Date(inBetweenTime.getTime() + 4 * 60 * 60 * 1000);
      const formatMaxTime = maxBetween.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTimeEdit(
        maxBetween.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMaxEdit(formatMaxTime);
    } else {
      const beforeShiftTime = new Date(startTime.getTime());
      const formattedEndTime = beforeShiftTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMinTimeEdit(
        beforeShiftTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMinEdit(formattedEndTime);
      const inBetweenTime = new Date(endTime.getTime());
      const formattedEnd = inBetweenTime.toLocaleTimeString("en-US", {
        hour12: false,
        hour: "2-digit",
        minute: "2-digit",
      });
      setShowMaxTimeEdit(
        inBetweenTime.toLocaleTimeString([], {
          hour: "2-digit",
          minute: "2-digit",
        })
      );
      setTimeMaxEdit(formattedEnd);
    }
  };

  const getRequestHours = (e) => {
    const requestedHours = e.target.value;

    const time = applypermission.fromtime;

    const startTime = new Date(`${yyyy}-01-01T${time}:00`);

    const endTime = new Date(
      startTime.getTime() + requestedHours * 60 * 60 * 1000
    );

    const formattedEndTime = endTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    setApplyPermission({
      ...applypermission,
      requesthours: requestedHours,
      endtime: formattedEndTime,
    });
  };

  const getRequestHoursEdit = (e) => {
    const requestedHours = e.target.value;
    const time = permissionedit.fromtime;

    const startTime = new Date(`${yyyy}-01-01T${time}:00`);

    const endTime = new Date(
      startTime.getTime() + requestedHours * 60 * 60 * 1000
    );

    const formattedEndTime = endTime.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    });

    setPermissionEdit({
      ...permissionedit,
      requesthours: requestedHours,
      endtime: formattedEndTime,
    });
  };

  const getRequestFormat = (e) => {
    if (applypermission.requesthours.length > 0) {
      const requestedHours = applypermission.requesthours;
      const time = e.target.value;

      const startTime = new Date(`${yyyy}-01-01T${time}:00`);

      const endTime = new Date(
        startTime.getTime() + requestedHours * 60 * 60 * 1000
      );

      const formattedEndTime = endTime.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });

      setApplyPermission({
        ...applypermission,
        fromtime: e.target.value,
        endtime: formattedEndTime,
      });
    } else {
      setApplyPermission({ ...applypermission, fromtime: e.target.value });
    }
  };

  const getRequestFormatEdit = (e) => {
    if (permissionedit.requesthours.length > 0) {
      const requestedHours = permissionedit.requesthours;
      const time = e.target.value;

      const startTime = new Date(`${yyyy}-01-01T${time}:00`);

      const endTime = new Date(
        startTime.getTime() + requestedHours * 60 * 60 * 1000
      );

      const formattedEndTime = endTime.toLocaleTimeString([], {
        hour: "2-digit",
        minute: "2-digit",
      });

      setPermissionEdit({
        ...permissionedit,
        fromtime: e.target.value,
        endtime: formattedEndTime,
      });
    } else {
      setPermissionEdit({ ...permissionedit, fromtime: e.target.value });
    }
  };

  let dateselect = new Date();
  dateselect.setDate(dateselect.getDate() + 3);
  var ddt = String(dateselect.getDate()).padStart(2, "0");
  var mmt = String(dateselect.getMonth() + 1).padStart(2, "0");
  var yyyyt = dateselect.getFullYear();
  let formattedDatet = yyyyt + "-" + mmt + "-" + ddt;

  let datePresent = new Date();
  var ddp = String(datePresent.getDate());
  var mmp = String(datePresent.getMonth() + 1);
  var yyyyp = datePresent.getFullYear();
  let formattedDatePresent = yyyyp + "-" + mmp + "-" + ddp;




  //Edit model...
  const [isEditOpen, setIsEditOpen] = useState(false);
  const handleClickOpenEdit = () => {
    setIsEditOpen(true);
  };
  const handleCloseModEdit = (e, reason) => {
    if (reason && reason === "backdropClick") return;
    setIsEditOpen(false);
  };

  //check delete model
  const [isCheckOpen, setisCheckOpen] = useState(false);
  const handleClickOpenCheck = () => {
    setisCheckOpen(true);
  };
  const handleCloseCheck = () => {
    setisCheckOpen(false);
  };

  // info model
  const [openInfo, setOpeninfo] = useState(false);

  const handleClickOpeninfo = () => {
    setOpeninfo(true);
  };

  const handleCloseinfo = () => {
    setOpeninfo(false);
  };

  //get single row to edit....
  const getCode = async (e, name) => {
    setPageName(!pageName)
    try {
      let res = await axios.get(`${SERVICE.PERMISSION_SINGLE}/${e}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });

      setPermissionEdit(res?.data?.sPermission);
      setLeaveId(res?.data?.sPermission._id);
      setAccesDropEdit(res?.data?.sPermission.access);
      setLeaveEdit(res?.data?.sPermission.permissiontype);
      setApplytypeEdit(res?.data?.sPermission.applytype);
      setPermissionSelf(res?.data?.sPermission);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  // get single row to view....
  const getviewCode = async (e) => {
    setPageName(!pageName)
    try {
      let res = await axios.get(`${SERVICE.PERMISSION_SINGLE}/${e}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setPermissionEdit(res?.data?.sPermission);
      setApplytypeEdit(res?.data?.sPermission.applytype);
      setLeaveEdit(res?.data?.sPermission.permissiontype);
      setAccesDropEdit(res?.data?.sPermission.access);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };
  // get single row to view....
  const getinfoCode = async (e) => {
    setPageName(!pageName)
    try {
      let res = await axios.get(`${SERVICE.PERMISSION_SINGLE}/${e}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setPermissionEdit(res?.data?.sPermission);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const getinfoCodeStatus = async (e) => {
    setPageName(!pageName)
    try {
      let res = await axios.get(`${SERVICE.PERMISSION_SINGLE}/${e}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setSelectStatus(res?.data?.sPermission);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };
  useEffect(() => {
    fetchCategoryTicket();
    fetchCompany();
  }, []);

  //Project updateby edit page...
  let updateby = permissionedit?.updatedby;
  let addedby = permissionedit?.addedby;
  let updatedByStatus = selectStatus.updatedby;

  let subprojectsid = permissionedit?._id;

  const sendEditRequest = async () => {
    setPageName(!pageName)
    try {
      let res = await axios.put(`${SERVICE.PERMISSION_SINGLE}/${leaveId}`, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
        employeename:
          AccessdropEdit === "HR"
            ? String(permissionedit.employeename)
            : isUserRoleAccess.companyname,
        employeeid:
          AccessdropEdit === "HR"
            ? String(permissionedit.employeeid)
            : isUserRoleAccess.empcode,
        permissiontype: String(leaveEdit),
        applytype: String(applytypeEdit),
        date: String(permissionedit.date),
        shifttiming: String(
          Accessdrop === "HR"
            ? permissionedit.shifttiming
            : isUserRoleAccess.shifttiming
        ),
        time: String(Accessdrop === "HR" ? permissionedit.time : getTiming),
        reasonforpermission: String(permissionedit.reasonforpermission),
        reportingto:
          AccessdropEdit === "HR"
            ? String(permissionedit.reportingto)
            : isUserRoleAccess.reportingto,
        companyname: String(
          AccessdropEdit === "HR" ? permissionedit.companyname : ""
        ),
        branch: String(AccessdropEdit === "HR" ? permissionedit.branch : ""),
        unit: String(AccessdropEdit === "HR" ? permissionedit.unit : ""),
        team: String(AccessdropEdit === "HR" ? permissionedit.team : ""),
        access: AccessdropEdit,
        fromtime: String(permissionedit.fromtime),
        requesthours: String(permissionedit.requesthours),
        endtime: String(permissionedit.endtime),
        updatedby: [
          ...updateby,
          {
            name: String(isUserRoleAccess.companyname),
            date: String(new Date()),
          },
        ],
      });
      await fetchApplyPermissions(permissionVerification);
      handleCloseModEdit();
      setPopupContent("Updated Successfully");
      setPopupSeverity("success");
      handleClickOpenPopup();
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const sendEditStatus = async () => {
    setPageName(!pageName)
    try {
      let res = await axios.put(
        `${SERVICE.PERMISSION_SINGLE}/${selectStatus._id}`,
        {
          headers: {
            Authorization: `Bearer ${auth.APIToken}`,
          },
          status: String(selectStatus.status),
          rejectedreason: String(
            selectStatus.status == "Rejected" ? selectStatus.rejectedreason : ""
          ),
          actionby: String(isUserRoleAccess.companyname),
          updatedby: [
            ...updatedByStatus,
            {
              name: String(isUserRoleAccess.companyname),
              date: String(new Date()),
            },
          ],
        }
      );
      await fetchApplyPermissions(permissionVerification);
      handleStatusClose();
      setPopupContent("Updated Successfully");
      setPopupSeverity("success");
      handleClickOpenPopup();
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const editStatus = () => {
    if (selectStatus.status == "Rejected") {
      if (selectStatus.rejectedreason == "") {
        setPopupContentMalert("Please Enter Rejected Reason");
        setPopupSeverityMalert("warning");
        handleClickOpenPopupMalert();
      } else {
        sendEditStatus();
      }
    }
    else if (selectStatus.status == "Approved") {
      if (isCheckList) {
        handleClickOpenEditCheckList();
      } else {
        setPopupContentMalert(<>
          Please Fill the Checklist. Click this link:{" "}
          <a href="/interview/myinterviewchecklist" target="_blank" rel="noopener noreferrer">
            My Checklist
          </a>
        </>);
        setPopupSeverityMalert("warning");
        handleClickOpenPopupMalert();
      }

    }
    else {
      sendEditStatus();
    }
  };


  //get all Sub vendormasters.
  const fetchApplyleave = async () => {
    setPageName(!pageName)
    try {
      let res_vendor = await axios.get(SERVICE.APPLYLEAVE, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setApplyleavecheck(true);
      let answer =
        isUserRoleAccess?.role?.includes("Manager") ||
          isUserRoleAccess?.role?.includes("HiringManager") ||
          isUserRoleAccess?.role?.includes("HR") ||
          isUserRoleAccess?.role?.includes("Superadmin")
          ? res_vendor?.data?.applyleaves
          : res_vendor?.data?.applyleaves.filter(
            (data) => data.employeename === isUserRoleAccess.companyname
          );
      setApplyleaves(answer);
    } catch (err) { setApplyleavecheck(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const fetchApplyPermissions = async (permissionverificationdata) => {
    setPageName(!pageName)
    try {
      let res_vendor = await axios.get(SERVICE.PERMISSIONS, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      setApplyleavecheck(true);
      let answer =
        isUserRoleAccess?.role?.includes("Manager") ||
          isUserRoleAccess?.role?.includes("HiringManager") ||
          isUserRoleAccess?.role?.includes("HR") ||
          isUserRoleAccess?.role?.includes("Superadmin")
          ? res_vendor?.data?.permissions
          : res_vendor?.data?.permissions.filter((data) =>
            permissionverificationdata?.includes(data.employeename)
          );
      const itemsWithSerialNumber = answer?.map((item, index) => {
        const militaryTime = item.fromtime;
        const militaryTimeArray = militaryTime.split(":");
        const hours = parseInt(militaryTimeArray[0], 10);
        const minutes = militaryTimeArray[1];

        const convertedTime = new Date(
          yyyy,
          0,
          1,
          hours,
          minutes
        ).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

        return {
          id: item._id,
          serialNumber: index + 1,
          employeeid: item.employeeid,
          employeename: item.employeename,
          date: moment(item.date).format("DD-MM-YYYY"),
          fromtime: convertedTime,
          requesthours: item.requesthours,
          endtime: item.endtime,
          reasonforpermission: item.reasonforpermission,
          status: item.status,
        };
      });
      setPermissions(itemsWithSerialNumber);
      setFilteredDataItems(itemsWithSerialNumber);
      setTotalPagesApprovedPerm(Math.ceil(itemsWithSerialNumber.length / pageSizeApprovedPerm));
      let Approve =
        isUserRoleAccess?.role?.includes("Manager") ||
          isUserRoleAccess?.role?.includes("HiringManager") ||
          isUserRoleAccess?.role?.includes("HR") ||
          isUserRoleAccess?.role?.includes("Superadmin")
          ? res_vendor?.data?.permissions.filter(
            (data) => data.status === "Approved"
          )
          : res_vendor?.data?.permissions.filter(
            (data) =>
              data.employeename === isUserRoleAccess.companyname &&
              data.status === "Approved"
          );
      setIsPermissions(Approve);
    } catch (err) { setApplyleavecheck(true); handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  const [permissionVerification, setPermissionVerification] = useState([]);
  //get all Sub vendormasters.
  const fetchLeaveVerification = async () => {
    setPageName(!pageName)
    try {
      let res_team = await axios.get(SERVICE.LEAVEVERIFICATION, {
        headers: {
          Authorization: `Bearer ${auth.APIToken}`,
        },
      });
      let filteredData = res_team?.data?.teamgroupings?.filter(
        (item) =>
          item?.employeenameto?.includes(isUserRoleAccess.companyname) &&
          item?.type?.includes("Permission")
      );
      let mapEmployeeNames = filteredData?.flatMap(
        (data) => data?.employeenamefrom
      );
      setPermissionVerification(mapEmployeeNames);
      await fetchApplyPermissions(mapEmployeeNames);
    } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
  };

  useEffect(() => {
    fetchLeaveVerification();
  }, []);


  //id for login...
  let loginid = localStorage.LoginUserId;
  let authToken = localStorage.APIToken;

  useEffect(() => {
    // getexcelDatas();
  }, [permissionedit, applypermission, applyleaves]);

  useEffect(() => {
    fetchApplyleave();
  }, []);

  useEffect(() => {
    const beforeUnloadHandler = (event) => handleBeforeUnload(event);
    window.addEventListener("beforeunload", beforeUnloadHandler);
    return () => {
      window.removeEventListener("beforeunload", beforeUnloadHandler);
    };
  }, []);

  const [items, setItems] = useState([]);

  const addSerialNumber = (datas) => {
    setItems(datas);
  };

  useEffect(() => {
    addSerialNumber(permissions);
  }, [permissions]);

  const defaultColDef = useMemo(() => {
    return {
      filter: true,
      resizable: true,
      filterParams: {
        buttons: ["apply", "reset", "cancel"],
      },
    };
  }, []);

  const onGridReady = useCallback((params) => {
    setGridApi(params.api);
    setColumnApi(params.columnApi);
  }, []);

  // Function to handle filter changes
  const onFilterChanged = () => {
    if (gridApi) {
      const filterModel = gridApi.getFilterModel(); // Get the current filter model

      // Check if filters are active
      if (Object.keys(filterModel).length === 0) {
        // No filters active, clear the filtered data state
        setFilteredRowData([]);
      } else {
        // Filters are active, capture filtered data
        const filteredData = [];
        gridApi.forEachNodeAfterFilterAndSort((node) => {
          filteredData.push(node.data); // Collect filtered row data
        });
        setFilteredRowData(filteredData);
      }
    }
  };

  const onPaginationChanged = useCallback(() => {
    if (gridRefTableApprovedPerm.current) {
      const gridApi = gridRefTableApprovedPerm.current.api;
      const currentPage = gridApi.paginationGetCurrentPage() + 1;
      const totalPagesApprovedPerm = gridApi.paginationGetTotalPages();
      setPageApprovedPerm(currentPage);
      setTotalPagesApprovedPerm(totalPagesApprovedPerm);
    }
  }, []);

  const columnDataTableApprovedPerm = [
    {
      field: "serialNumber",
      headerName: "SNo",
      flex: 0,
      width: 80,
      hide: !columnVisibilityApprovedPerm.serialNumber,
      headerClassName: "bold-header", pinned: 'left', lockPinned: true,
    },
    { field: "employeeid", headerName: "Employee Id", flex: 0, width: 150, hide: !columnVisibilityApprovedPerm.employeeid, headerClassName: "bold-header", pinned: 'left', lockPinned: true, },
    {
      field: "employeename",
      headerName: "Employee Name",
      flex: 0,
      width: 200,
      hide: !columnVisibilityApprovedPerm.employeename,
      headerClassName: "bold-header", pinned: 'left', lockPinned: true,
    },
    {
      field: "date",
      headerName: "Date",
      flex: 0,
      width: 120,
      hide: !columnVisibilityApprovedPerm.date,
      headerClassName: "bold-header",
    },
    {
      field: "fromtime",
      headerName: "From Time",
      flex: 0,
      width: 120,
      hide: !columnVisibilityApprovedPerm.fromtime,
      headerClassName: "bold-header",
    },
    {
      field: "requesthours",
      headerName: "Request Hours",
      flex: 0,
      width: 100,
      hide: !columnVisibilityApprovedPerm.requesthours,
      headerClassName: "bold-header",
    },
    {
      field: "endtime",
      headerName: "End Time",
      flex: 0,
      width: 120,
      hide: !columnVisibilityApprovedPerm.endtime,
      headerClassName: "bold-header",
    },
    {
      field: "reasonforpermission",
      headerName: "Reason for Permission",
      flex: 0,
      width: 180,
      hide: !columnVisibilityApprovedPerm.reasonforpermission,
      headerClassName: "bold-header",
    },
    {
      field: "status",
      headerName: "Status",
      flex: 0,
      width: 150,
      hide: !columnVisibilityApprovedPerm.status,
      headerClassName: "bold-header",
      cellRenderer: (params) => (
        <Grid sx={{ display: 'flex' }}>
          <Button
            variant="contained"
            style={{
              margin: '5px',
              cursor: 'default',
              padding: "5px",
              backgroundColor:
                params.value === "Applied"
                  ? "#FFC300"
                  : params.value === "Rejected"
                    ? "red"
                    : params.value === "Approved"
                      ? "green"
                      : "inherit",
              color:
                params.value === "Applied"
                  ? "black"
                  : params.value === "Rejected"
                    ? "white"
                    : "white",
              fontSize: "10px",
              width: "90px",
              fontWeight: "bold",
            }}
          >
            {params.value}
          </Button>
        </Grid>
      ),
    },
    {
      field: "actions",
      headerName: "Action",
      flex: 0,
      width: 150,
      minHeight: "40px !important",
      filter: false,
      sortable: false,
      hide: !columnVisibilityApprovedPerm.actions,
      headerClassName: "bold-header",
      cellRenderer: (params) => (
        <Grid sx={{ display: "flex" }}>
          {isUserRoleCompare?.includes("iteampermissionverification") && (
            <Button
              variant="contained"
              style={{
                margin: '5px',
                backgroundColor: "red",
                minWidth: "15px",
                padding: "6px 5px",
              }}
              onClick={(e) => {
                getinfoCodeStatus(params.data.id);
                handleStatusOpen();
                getCodeNew(params.data);
              }}
            >
              <FaEdit style={{ color: "white", fontSize: "17px" }} />
            </Button>
          )}
        </Grid>
      ),
    },
  ];

  const DateFrom =
    (isUserRoleAccess.role.includes("HiringManager") ||
      isUserRoleAccess.role.includes("HR") ||
      isUserRoleAccess.role.includes("Manager") ||
      isUserRoleCompare.includes("lteampermissionverification")) &&
      Accessdrop === "HR"
      ? formattedDatePresent
      : formattedDatet;

  // Datatable
  const handleSearchChange = (e) => {
    const value = e.target.value;
    setSearchQueryApprovedPerm(value);
    applyNormalFilter(value);
    setFilteredRowData([]);
  };

  const applyNormalFilter = (searchValue) => {

    // Split the search query into individual terms
    const searchTerms = searchValue.toLowerCase().split(" ");

    // Modify the filtering logic to check each term
    const filtered = items?.filter((item) => {
      return searchTerms.every((term) =>
        Object.values(item).join(" ").toLowerCase().includes(term)
      );
    });
    setFilteredDataItems(filtered);
    setPageApprovedPerm(1);
  };

  const applyAdvancedFilter = (filters, logicOperator) => {
    // Apply filtering logic with multiple conditions
    const filtered = items?.filter((item) => {
      return filters.reduce((acc, filter, index) => {
        const { column, condition, value } = filter;
        const itemValue = String(item[column])?.toLowerCase();
        const filterValue = String(value).toLowerCase();

        let match;
        switch (condition) {
          case "Contains":
            match = itemValue.includes(filterValue);
            break;
          case "Does Not Contain":
            match = !itemValue?.includes(filterValue);
            break;
          case "Equals":
            match = itemValue === filterValue;
            break;
          case "Does Not Equal":
            match = itemValue !== filterValue;
            break;
          case "Begins With":
            match = itemValue.startsWith(filterValue);
            break;
          case "Ends With":
            match = itemValue.endsWith(filterValue);
            break;
          case "Blank":
            match = !itemValue;
            break;
          case "Not Blank":
            match = !!itemValue;
            break;
          default:
            match = true;
        }

        // Combine conditions with AND/OR logic
        if (index === 0) {
          return match; // First filter is applied directly
        } else if (logicOperator === "AND") {
          return acc && match;
        } else {
          return acc || match;
        }
      }, true);
    });

    setFilteredDataItems(filtered); // Update filtered data
    setAdvancedFilter(filters);
    // handleCloseSearchApprovedPerm(); // Close the popover after search
  };

  // Undo filter funtion
  const handleResetSearch = () => {
    setAdvancedFilter(null);
    setSearchQueryApprovedPerm("");
    setFilteredDataItems(permissions);
  };

  // Show filtered combination in the search bar
  const getSearchDisplay = () => {
    if (advancedFilter && advancedFilter.length > 0) {
      return advancedFilter.map((filter, index) => {
        let showname = columnDataTableApprovedPerm.find(col => col.field === filter.column)?.headerName;
        return `${showname} ${filter.condition} "${filter.value}"`;
      }).join(' ' + (advancedFilter.length > 1 ? advancedFilter[1].condition : '') + ' ');
    }
    return searchQueryApprovedPerm;
  };

  const handlePageChange = (newPage) => {
    if (newPage >= 1 && newPage <= totalPagesApprovedPerm) {
      setPageApprovedPerm(newPage);
      gridRefTableApprovedPerm.current.api.paginationGoToPage(newPage - 1);
    }
  };

  const handlePageSizeChange = (e) => {
    const newSize = Number(e.target.value);
    setPageSizeApprovedPerm(newSize);
    if (gridApi) {
      gridApi.paginationSetPageSize(newSize);
    }
  };

  // Show All Columns functionality
  const handleShowAllColumns = () => {
    const updatedVisibility = { ...columnVisibilityApprovedPerm };
    for (const columnKey in updatedVisibility) {
      updatedVisibility[columnKey] = true;
    }
    setColumnVisibilityApprovedPerm(updatedVisibility);
  };

  useEffect(() => {
    // Retrieve column visibility from localStorage (if available)
    const savedVisibility = localStorage.getItem("columnVisibilityApprovedPerm");
    if (savedVisibility) {
      setColumnVisibilityApprovedPerm(JSON.parse(savedVisibility));
    }
  }, []);

  useEffect(() => {
    // Save column visibility to localStorage whenever it changes
    localStorage.setItem("columnVisibilityApprovedPerm", JSON.stringify(columnVisibilityApprovedPerm));
  }, [columnVisibilityApprovedPerm]);

  // // Function to filter columns based on search query
  const filteredColumns = columnDataTableApprovedPerm.filter((column) =>
    column.headerName.toLowerCase().includes(searchQueryManageApprovedPerm.toLowerCase())
  );


  function debounce(func, wait) {
    let timeout;
    return function (...args) {
      clearTimeout(timeout);
      timeout = setTimeout(() => func.apply(this, args), wait);
    };
  }

  // Manage Columns functionality
  const toggleColumnVisibility = (field) => {
    if (!gridApi) return;

    setColumnVisibilityApprovedPerm((prevVisibility) => {
      const newVisibility = !prevVisibility[field];

      // Update the visibility in the grid
      gridApi.setColumnVisible(field, newVisibility);

      return {
        ...prevVisibility,
        [field]: newVisibility,
      };
    });
  };

  const handleColumnMoved = useCallback(debounce((event) => {
    if (!event.columnApi) return;

    const visible_columns = event.columnApi.getAllColumns().filter(col => {
      const colState = event.columnApi.getColumnState().find(state => state.colId === col.colId);
      return colState && !colState.hide;
    }).map(col => col.colId);

    setColumnVisibilityApprovedPerm((prevVisibility) => {
      const updatedVisibility = { ...prevVisibility };

      // Ensure columns that are visible stay visible
      Object.keys(updatedVisibility).forEach(colId => {
        updatedVisibility[colId] = visible_columns.includes(colId);
      });

      return updatedVisibility;
    });
  }, 300), []);

  const handleColumnVisible = useCallback((event) => {
    const colId = event.column.getColId();

    // Update visibility based on event, but only when explicitly triggered by grid
    setColumnVisibilityApprovedPerm((prevVisibility) => ({
      ...prevVisibility,
      [colId]: event.visible, // Set visibility directly from the event
    }));
  }, []);

  // Excel
  const [fileFormat, setFormat] = useState('');
  let exportColumnNamescrt = ["Employee Name", "Employee Id", "Date", "From Time", "Request Hours", "End Time", "Reason For Permission", "Status",]
  let exportRowValuescrt = ["employeename", "employeeid", "date", "fromtime", "requesthours", "endtime", "reasonforpermission", "status",]

  //print...
  const componentRef = useRef();
  const handleprint = useReactToPrint({
    content: () => componentRef.current,
    documentTitle: "Team Permission Verification",
    pageStyle: "print",
  });

  // image
  const handleCaptureImage = () => {
    if (gridRefImageApprovedPerm.current) {
      domtoimage.toBlob(gridRefImageApprovedPerm.current)
        .then((blob) => {
          saveAs(blob, "Team Permission Verification.png");
        })
        .catch((error) => {
          console.error("dom-to-image error: ", error);
        });
    }
  };

  // Pagination for innter filter
  const getVisiblePageNumbers = () => {
    const pageNumbers = [];
    const maxVisiblePages = 3;

    const startPage = Math.max(1, pageApprovedPerm - 1);
    const endPage = Math.min(totalPagesApprovedPerm, startPage + maxVisiblePages - 1);

    // Loop through and add visible pageApprovedPerm numbers
    for (let i = startPage; i <= endPage; i++) {
      pageNumbers.push(i);
    }

    // If there are more pages after the last visible pageApprovedPerm, show ellipsis
    if (endPage < totalPagesApprovedPerm) {
      pageNumbers.push("...");
    }

    return pageNumbers;
  };

  // Pagination for outer filter
  const filteredData = filteredDataItems?.slice((pageApprovedPerm - 1) * pageSizeApprovedPerm, pageApprovedPerm * pageSizeApprovedPerm);
  const totalPagesApprovedPermOuter = Math.ceil(filteredDataItems?.length / pageSizeApprovedPerm);
  const visiblePages = Math.min(totalPagesApprovedPermOuter, 3);
  const firstVisiblePage = Math.max(1, pageApprovedPerm - 1);
  const lastVisiblePage = Math.min(firstVisiblePage + visiblePages - 1, totalPagesApprovedPermOuter);
  const pageNumbers = [];
  const indexOfLastItem = pageApprovedPerm * pageSizeApprovedPerm;
  const indexOfFirstItem = indexOfLastItem - pageSizeApprovedPerm;
  for (let i = firstVisiblePage; i <= lastVisiblePage; i++) { pageNumbers.push(i); }

  return (
    <Box>
      <Headtitle title={"TEAM PERMISSION VERIFICATION"} />
      {/* ****** Header Content ****** */}
      <PageHeading
        title="Team Permission Verification"
        modulename="Leave&Permission"
        submodulename="Permission"
        mainpagename="Team Permission Verification"
        subpagename=""
        subsubpagename=""
      />
      {/* ****** Table Start ****** */}
      {isUserRoleCompare?.includes("lteampermissionverification") && (
        <>
          <Box sx={userStyle.container}>
            {/* ******************************************************EXPORT Buttons****************************************************** */}
            <Grid item xs={8}>
              <Typography sx={userStyle.importheadtext}>
                Team Permission Verification List
              </Typography>
            </Grid>

            <Grid container spacing={2} style={userStyle.dataTablestyle}>
              <Grid item md={2} xs={12} sm={12}>
                <Box>
                  <label>Show entries:</label>
                  <Select
                    id="pageSizeSelect"
                    value={pageSizeApprovedPerm}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 180,
                          width: 80,
                        },
                      },
                    }}
                    onChange={handlePageSizeChange}
                    sx={{ width: "77px" }}
                  >
                    <MenuItem value={1}>1</MenuItem>
                    <MenuItem value={5}>5</MenuItem>
                    <MenuItem value={10}>10</MenuItem>
                    <MenuItem value={25}>25</MenuItem>
                    <MenuItem value={50}>50</MenuItem>
                    <MenuItem value={100}>100</MenuItem>
                    <MenuItem value={applyleaves?.length}>All</MenuItem>
                  </Select>
                </Box>
              </Grid>
              <Grid
                item
                md={8}
                xs={12}
                sm={12}
                sx={{
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Box>
                  {isUserRoleCompare?.includes(
                    "excelteampermissionverification"
                  ) && (
                      <>
                        <Button onClick={(e) => {
                          setIsFilterOpen(true)
                          setFormat("xl")
                        }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                      </>
                    )}
                  {isUserRoleCompare?.includes(
                    "csvteampermissionverification"
                  ) && (
                      <>
                        <Button onClick={(e) => {
                          setIsFilterOpen(true)
                          setFormat("csv")
                        }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                      </>
                    )}
                  {isUserRoleCompare?.includes(
                    "printteampermissionverification"
                  ) && (
                      <>
                        <Button sx={userStyle.buttongrp} onClick={handleprint}>
                          &ensp;
                          <FaPrint />
                          &ensp;Print&ensp;
                        </Button>
                      </>
                    )}
                  {isUserRoleCompare?.includes(
                    "pdfteampermissionverification"
                  ) && (
                      <>
                        <Button sx={userStyle.buttongrp}
                          onClick={() => {
                            setIsPdfFilterOpen(true)
                          }}
                        ><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                      </>
                    )}
                  {isUserRoleCompare?.includes(
                    "imageteampermissionverification"
                  ) && (
                      <Button
                        sx={userStyle.buttongrp}
                        onClick={handleCaptureImage}
                      >
                        {" "}
                        <ImageIcon
                          sx={{ fontSize: "15px" }}
                        /> &ensp;Image&ensp;{" "}
                      </Button>
                    )}
                </Box>
              </Grid>
              <Grid item md={2} xs={6} sm={6}>
                <FormControl fullWidth size="small">
                  <OutlinedInput size="small"
                    id="outlined-adornment-weight"
                    startAdornment={
                      <InputAdornment position="start">
                        <FaSearch />
                      </InputAdornment>
                    }
                    endAdornment={
                      <InputAdornment position="end">
                        {advancedFilter && (
                          <IconButton onClick={handleResetSearch}>
                            <MdClose />
                          </IconButton>
                        )}
                        <Tooltip title="Show search options">
                          <span>
                            <IoMdOptions style={{ cursor: 'pointer', }} onClick={handleClickSearchApprovedPerm} />
                          </span>
                        </Tooltip>
                      </InputAdornment>}
                    aria-describedby="outlined-weight-helper-text"
                    inputProps={{ 'aria-label': 'weight', }}
                    type="text"
                    value={getSearchDisplay()}
                    onChange={handleSearchChange}
                    placeholder="Type to search..."
                    disabled={!!advancedFilter}
                  />
                </FormControl>
              </Grid>
            </Grid>  <br />
            <Button sx={userStyle.buttongrp} onClick={handleShowAllColumns}>  Show All Columns </Button>&ensp;
            <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsApprovedPerm}> Manage Columns  </Button><br /><br />
            {!applyleaveCheck ? (
              <>
                <Box sx={{ display: "flex", justifyContent: "center" }}>
                  <ThreeDots
                    height="80"
                    width="80"
                    radius="9"
                    color="#1976d2"
                    ariaLabel="three-dots-loading"
                    wrapperStyle={{}}
                    wrapperClassName=""
                    visible={true}
                  />
                </Box>
              </>
            ) : (
              <>
                <Box sx={{ width: "100%", }} className={"ag-theme-quartz"} ref={gridRefImageApprovedPerm} >
                  <AgGridReact
                    rowData={filteredDataItems}
                    columnDefs={columnDataTableApprovedPerm.filter((column) => columnVisibilityApprovedPerm[column.field])}
                    ref={gridRefTableApprovedPerm}
                    defaultColDef={defaultColDef}
                    domLayout={"autoHeight"}
                    getRowStyle={getRowStyle}
                    pagination={true}
                    paginationPageSize={pageSizeApprovedPerm}
                    onPaginationChanged={onPaginationChanged}
                    onGridReady={onGridReady}
                    onColumnMoved={handleColumnMoved}
                    onColumnVisible={handleColumnVisible}
                    onFilterChanged={onFilterChanged}
                    // suppressPaginationPanel={true}
                    suppressSizeToFit={true}
                    suppressAutoSize={true}
                    suppressColumnVirtualisation={true}
                    colResizeDefault={"shift"}
                    cellSelection={true}
                    copyHeadersToClipboard={true}
                  />
                </Box>
                {/* show and hide based on the inner filter and outer filter */}
                {/* <Box style={userStyle.dataTablestyle}>
                  <Box>
                    Showing{" "}
                    {
                      gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                        (filteredDataItems.length > 0 ? (pageApprovedPerm - 1) * pageSizeApprovedPerm + 1 : 0)
                      ) : (
                        filteredRowData.length > 0 ? (pageApprovedPerm - 1) * pageSizeApprovedPerm + 1 : 0
                      )
                    }{" "}to{" "}
                    {
                      gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                        Math.min(pageApprovedPerm * pageSizeApprovedPerm, filteredDataItems.length)
                      ) : (
                        filteredRowData.length > 0 ? Math.min(pageApprovedPerm * pageSizeApprovedPerm, filteredRowData.length) : 0
                      )
                    }{" "}of{" "}
                    {
                      gridApi && gridApi.getFilterModel() && Object.keys(gridApi.getFilterModel()).length === 0 ? (
                        filteredDataItems.length
                      ) : (
                        filteredRowData.length
                      )
                    } entries
                  </Box>
                  <Box>
                    <Button onClick={() => handlePageChange(1)} disabled={pageApprovedPerm === 1} sx={userStyle.paginationbtn}  > <FirstPageIcon /> </Button>
                    <Button onClick={() => handlePageChange(pageApprovedPerm - 1)} disabled={pageApprovedPerm === 1} sx={userStyle.paginationbtn}  > <NavigateBeforeIcon />  </Button>
                    {getVisiblePageNumbers().map((pageNumber, index) => (
                      <Button
                        key={index}
                        onClick={() => pageNumber !== "..." && handlePageChange(pageNumber)}
                        sx={{
                          ...userStyle.paginationbtn,
                          ...(pageNumber === "..." && {
                            cursor: "default",
                            color: "black",
                            fontSize: '12px',
                            fontWeight: 'bold',
                            backgroundColor: "transparent",
                            border: "none",
                            "&:hover": { backgroundColor: "transparent", boxShadow: "none", },
                          }),
                        }}
                        className={pageApprovedPerm === pageNumber ? "active" : ""}
                        disabled={pageApprovedPerm === pageNumber}
                      >
                        {pageNumber}
                      </Button>
                    ))}
                    <Button onClick={() => handlePageChange(pageApprovedPerm + 1)} disabled={pageApprovedPerm === totalPagesApprovedPerm} sx={userStyle.paginationbtn} > <NavigateNextIcon /> </Button>
                    <Button onClick={() => handlePageChange(totalPagesApprovedPerm)} disabled={pageApprovedPerm === totalPagesApprovedPerm} sx={userStyle.paginationbtn} ><LastPageIcon /> </Button>
                  </Box>
                </Box> */}
              </>
            )}
          </Box>
        </>
      )}

      {/* Manage Column */}
      <Popover
        id={idApprovedPerm}
        open={isManageColumnsOpenApprovedPerm}
        anchorEl={anchorElApprovedPerm}
        onClose={handleCloseManageColumnsApprovedPerm}
        anchorOrigin={{ vertical: "bottom", horizontal: "left", }}
      >
        <ManageColumnsContent
          handleClose={handleCloseManageColumnsApprovedPerm}
          searchQuery={searchQueryManageApprovedPerm}
          setSearchQuery={setSearchQueryManageApprovedPerm}
          filteredColumns={filteredColumns}
          columnVisibility={columnVisibilityApprovedPerm}
          toggleColumnVisibility={toggleColumnVisibility}
          setColumnVisibility={setColumnVisibilityApprovedPerm}
          initialColumnVisibility={initialColumnVisibilityApprovedPerm}
          columnDataTable={columnDataTableApprovedPerm}
        />
      </Popover>

      {/* Search Bar */}
      <Popover
        id={idSearchApprovedPerm}
        open={openSearchApprovedPerm}
        anchorEl={anchorElSearchApprovedPerm}
        onClose={handleCloseSearchApprovedPerm}
        anchorOrigin={{ vertical: 'bottom', horizontal: 'right', }}
      >
        <AdvancedSearchBar columns={columnDataTableApprovedPerm.filter(data => data.field !== 'actions')} onSearch={applyAdvancedFilter} initialSearchValue={searchQueryApprovedPerm} handleCloseSearch={handleCloseSearchApprovedPerm} />
      </Popover>

      {/* dialog status change */}
      <Dialog
        maxWidth="lg"
        open={statusOpen}
        onClose={handleStatusClose}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent
          sx={{
            width: "600px",
            height: selectStatus.status == "Rejected" ? "260px" : "220px",
            overflow: "visible",
            "& .MuiPaper-root": {
              overflow: "visible",
            },
          }}
        >
          <Grid container spacing={2}>
            <Grid item md={12} xs={12} sm={12}>
              <Typography sx={userStyle.HeaderText}>
                Edit Apply Status
              </Typography>
            </Grid>
            <Grid item md={6} sm={6} xs={12}>
              <FormControl fullWidth size="small">
                <Typography>
                  Status<b style={{ color: "red" }}>*</b>
                </Typography>
                <Selects
                  fullWidth
                  options={[
                    { label: "Approved", value: "Approved" },
                    { label: "Rejected", value: "Rejected" },
                    { label: "Applied", value: "Applied" },
                  ]}
                  value={{
                    label: selectStatus.status,
                    value: selectStatus.value,
                  }}
                  onChange={(e) => {
                    setSelectStatus({ ...selectStatus, status: e.value });
                  }}
                />
              </FormControl>
            </Grid>
            <Grid item md={6} sm={6} xs={12}></Grid>
            <Grid item md={12} sm={12} xs={12}>
              {selectStatus.status == "Rejected" ? (
                <FormControl fullWidth size="small">
                  <Typography>
                    Reason for Rejected<b style={{ color: "red" }}>*</b>
                  </Typography>
                  <TextareaAutosize
                    aria-label="minimum height"
                    minRows={5}
                    value={selectStatus.rejectedreason}
                    onChange={(e) => {
                      setSelectStatus({
                        ...selectStatus,
                        rejectedreason: e.target.value,
                      });
                    }}
                  />
                </FormControl>
              ) : null}
            </Grid>
          </Grid>
        </DialogContent>
        {selectStatus.status == "Rejected" ? <br /> : null}
        <DialogActions>
          <Button
            variant="contained"
            // style={{
            //   padding: "7px 13px",
            //   color: "white",
            //   background: "rgb(25, 118, 210)",
            // }}
            sx={buttonStyles.buttonsubmit}
            onClick={() => {
              editStatus();
              // handleCloseerrpop();
            }}
          >
            Update
          </Button>
          <Button
            // style={{
            //   backgroundColor: "#f4f4f4",
            //   color: "#444",
            //   boxShadow: "none",
            //   borderRadius: "3px",
            //   padding: "7px 13px",
            //   border: "1px solid #0000006b",
            //   "&:hover": {
            //     "& .css-bluauu-MuiButtonBase-root-MuiButton-root": {
            //       backgroundColor: "#f4f4f4",
            //     },
            //   },
            // }}
            sx={buttonStyles.btncancel}
            onClick={() => {
              handleStatusClose();
              setSelectStatus({});
            }}
          >
            Cancel
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={isEditOpenCheckList} onClose={handleCloseModEditCheckList} aria-labelledby="alert-dialog-title" aria-describedby="alert-dialog-description" maxWidth="xl" fullWidth={true} sx={{
        overflow: 'visible',
        '& .MuiPaper-root': {
          overflow: 'auto',
        },
        marginTop: '50px'
      }}>
        <Box sx={{ padding: "20px 50px" }}>
          <>
            <Typography sx={userStyle.SubHeaderText} onClick={() => { console.log(groupDetails); console.log(assignDetails); console.log(datasAvailedDB); console.log(isCheckedList) }}>
              My Check List
            </Typography>
            <br />
            <br />
            <Grid container spacing={2} >
              <Grid item md={12} xs={12} sm={12} >
                <FormControl fullWidth size="small" sx={{ display: 'flex', justifyContent: 'center', border: '1px solid black', borderRadius: '20px' }} >
                  <Typography sx={{ fontSize: '1rem', textAlign: 'center' }} onClick={() => { console.log(dateValueRandom); console.log(timeValueRandom) }}>
                    Employee Name: <span style={{ fontWeight: '500', fontSize: '1.2rem', display: 'inline-block', textAlign: 'center' }}> {`${getDetails?.employeename}`}</span>
                  </Typography>
                </FormControl>
              </Grid>
            </Grid>
            <br />
            <TableContainer component={Paper}>
              <Table>
                <TableHead >
                  <TableRow>
                    <TableCell style={{ fontSize: '1.2rem' }}>
                      <Checkbox onChange={() => { overallCheckListChange() }} checked={isCheckedListOverall} />
                    </TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Details</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Field</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Allotted To</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Completed By</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Completed At</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Status</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Action</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Category</TableCell>
                    <TableCell style={{ fontSize: '1.2rem' }}>Sub Category</TableCell>
                    {/* Add more table headers as needed */}
                  </TableRow>
                </TableHead>
                <TableBody>
                  {groupDetails?.map((row, index) => (
                    <TableRow key={index}>
                      <TableCell style={{ fontSize: '1.2rem' }}>
                        <Checkbox onChange={() => { handleCheckboxChange(index) }} checked={isCheckedList[index]} />
                      </TableCell>

                      <TableCell>{row.details}</TableCell>
                      {
                        (() => {
                          switch (row.checklist) {
                            case "Text Box":

                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  value={row.data}
                                  // disabled={disableInput[index]}
                                  onChange={(e) => {
                                    handleDataChange(e, index, "Text Box")
                                  }}
                                />
                              </TableCell>;
                            case "Text Box-number":
                              return <TableCell>
                                <OutlinedInput value={row.data}
                                  style={{ height: '32px' }}
                                  type="text"
                                  onChange={(e) => {
                                    const inputValue = e.target.value;
                                    if (/^[0-9]*$/.test(inputValue)) {
                                      handleDataChange(e, index, "Text Box-number")
                                    }

                                  }}
                                />
                              </TableCell>;
                            case "Text Box-alpha":
                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  value={row.data}
                                  onChange={(e) => {
                                    const inputValue = e.target.value;
                                    if (/^[a-zA-Z]*$/.test(inputValue)) {
                                      handleDataChange(e, index, "Text Box-alpha")
                                    }
                                  }}

                                />
                              </TableCell>;
                            case "Text Box-alphanumeric":
                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  value={row.data}
                                  onChange={(e) => {
                                    const inputValue = e.target.value;
                                    if (/^[a-zA-Z0-9]*$/.test(inputValue)) {
                                      handleDataChange(e, index, "Text Box-alphanumeric")
                                    }
                                  }}
                                  inputProps={{ pattern: '[A-Za-z0-9]*' }}
                                />
                              </TableCell>;
                            case "Attachments":
                              return <TableCell>
                                <div>
                                  <InputLabel sx={{ m: 1 }}>File</InputLabel>


                                  <div>

                                    <Box
                                      sx={{ display: "flex", marginTop: "10px", gap: "10px" }}
                                    >

                                      <Box item md={4} sm={4}>
                                        <section>
                                          <input
                                            type="file"
                                            accept="*/*"
                                            id={index}
                                            onChange={(e) => {
                                              handleChangeImage(e, index);

                                            }}
                                            style={{ display: 'none' }}
                                          />
                                          <label htmlFor={index}>
                                            <Typography sx={userStyle.uploadbtn}>Upload</Typography>
                                          </label>
                                          <br />
                                        </section>
                                      </Box>

                                      <Box item md={4} sm={4}>
                                        <Button
                                          onClick={showWebcam}
                                          variant="contained"
                                          sx={userStyle.uploadbtn}
                                        >
                                          <CameraAltIcon />
                                        </Button>
                                      </Box>
                                      {row.files && <Grid container spacing={2}>
                                        <Grid item lg={8} md={8} sm={8} xs={8}>
                                          <Typography>{row.files.name}</Typography>
                                        </Grid>
                                        <Grid item lg={1.5} md={1} sm={1} xs={1} sx={{ cursor: 'pointer' }} onClick={() => renderFilePreviewEdit(row.files)}>
                                          <VisibilityOutlinedIcon
                                            style={{
                                              fontsize: "large",
                                              color: "#357AE8",
                                              cursor: "pointer",
                                            }}
                                            onClick={() => renderFilePreviewEdit(row.files)}
                                          />
                                        </Grid>
                                        <Grid item lg={1} md={1} sm={1} xs={1}>
                                          <Button
                                            style={{
                                              fontsize: "large",
                                              color: "#357AE8",
                                              cursor: "pointer",
                                              marginTop: "-5px",
                                            }}
                                            onClick={() => handleFileDeleteEdit(index)}
                                          >
                                            <DeleteIcon />
                                          </Button>
                                        </Grid>
                                      </Grid>}

                                    </Box>

                                  </div>
                                  <Dialog
                                    open={isWebcamOpen}
                                    onClose={webcamClose}
                                    aria-labelledby="alert-dialog-title"
                                    aria-describedby="alert-dialog-description"
                                  >
                                    <DialogContent sx={{ textAlign: "center", alignItems: "center" }}>
                                      <Webcamimage
                                        getImg={getImg}
                                        setGetImg={setGetImg}
                                        capturedImages={capturedImages}
                                        valNum={valNum}
                                        setValNum={setValNum}
                                        name={name}
                                      />
                                    </DialogContent>
                                    <DialogActions>
                                      <Button
                                        variant="contained"
                                        color="success"
                                        onClick={webcamDataStore}
                                      >
                                        OK
                                      </Button>
                                      <Button variant="contained" color="error" onClick={webcamClose}>
                                        CANCEL
                                      </Button>
                                    </DialogActions>
                                  </Dialog>

                                </div>


                              </TableCell>;
                            case "Pre-Value":
                              return <TableCell><Typography>{row?.data}</Typography>
                              </TableCell>;
                            case "Date":
                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  type='date'
                                  value={row.data}
                                  onChange={(e) => {

                                    handleDataChange(e, index, "Date")

                                  }}
                                />
                              </TableCell>;
                            case "Time":
                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  type='time'
                                  value={row.data}
                                  onChange={(e) => {

                                    handleDataChange(e, index, "Time")

                                  }}
                                />
                              </TableCell>;
                            case "DateTime":
                              return <TableCell>
                                <Stack direction="row" spacing={2}>
                                  <OutlinedInput
                                    style={{ height: '32px' }}
                                    type='date'
                                    value={dateValue[index]}
                                    onChange={(e) => {
                                      updateDateValuesAtIndex(e.target.value, index)


                                    }}
                                  />
                                  <OutlinedInput
                                    type='time'
                                    style={{ height: '32px' }}
                                    value={timeValue[index]}
                                    onChange={(e) => {
                                      updateTimeValuesAtIndex(e.target.value, index);

                                    }}
                                  />
                                </Stack>
                              </TableCell>;
                            case "Date Multi Span":
                              return <TableCell>
                                <Stack direction="row" spacing={2}>
                                  <OutlinedInput
                                    style={{ height: '32px' }}
                                    type='date'
                                    value={dateValueMultiFrom[index]}
                                    onChange={(e) => {
                                      updateFromDateValueAtIndex(e.target.value, index)


                                    }}
                                  />
                                  <OutlinedInput
                                    type='date'
                                    style={{ height: '32px' }}
                                    value={dateValueMultiTo[index]}
                                    onChange={(e) => {
                                      updateToDateValueAtIndex(e.target.value, index)


                                    }}
                                  />
                                </Stack>
                              </TableCell>;
                            case "Date Multi Span Time":
                              return <TableCell>
                                <div style={{ display: 'flex', flexDirection: 'column', gap: '10px' }}>
                                  <Stack direction="row" spacing={2}>
                                    <OutlinedInput
                                      style={{ height: '32px' }}
                                      type='date'
                                      value={firstDateValue[index]}
                                      onChange={(e) => {
                                        updateFirstDateValuesAtIndex(e.target.value, index)


                                      }}
                                    />
                                    <OutlinedInput
                                      type='time'
                                      style={{ height: '32px' }}
                                      value={firstTimeValue[index]}
                                      onChange={(e) => {
                                        updateFirstTimeValuesAtIndex(e.target.value, index);


                                      }}
                                    />
                                  </Stack>
                                  <Stack direction="row" spacing={2}>

                                    <OutlinedInput
                                      type='date'
                                      style={{ height: '32px' }}
                                      value={secondDateValue[index]}
                                      onChange={(e) => {
                                        updateSecondDateValuesAtIndex(e.target.value, index)


                                      }}
                                    />
                                    <OutlinedInput
                                      style={{ height: '32px' }}
                                      type='time'
                                      value={secondTimeValue[index]}
                                      onChange={(e) => {
                                        updateSecondTimeValuesAtIndex(e.target.value, index);


                                      }}
                                    />
                                  </Stack>
                                </div>

                              </TableCell>;
                            case "Date Multi Random":
                              return <TableCell>
                                <OutlinedInput
                                  style={{ height: '32px' }}
                                  type='date'
                                  value={row.data}
                                  onChange={(e) => {

                                    handleDataChange(e, index, "Date Multi Random")

                                  }}
                                />
                              </TableCell>;
                            case "Date Multi Random Time":
                              return <TableCell>
                                <Stack direction="row" spacing={2}>
                                  <OutlinedInput
                                    style={{ height: '32px' }}
                                    type='date'
                                    value={dateValueRandom[index]}
                                    onChange={(e) => {
                                      updateDateValueAtIndex(e.target.value, index)


                                    }}
                                  />
                                  <OutlinedInput
                                    type='time'
                                    style={{ height: '32px' }}
                                    value={timeValueRandom[index]}
                                    onChange={(e) => {
                                      updateTimeValueAtIndex(e.target.value, index);


                                    }}
                                  />
                                </Stack>
                              </TableCell>;
                            case "Radio":
                              return <TableCell>
                                <FormControl component="fieldset">
                                  <RadioGroup value={row.data} sx={{ display: 'flex', flexDirection: 'row !important' }} onChange={(e) => {
                                    handleDataChange(e, index, "Radio")
                                  }}>
                                    <FormControlLabel value="No" control={<Radio />} label="No" />
                                    <FormControlLabel value="Yes" control={<Radio />} label="Yes" />

                                  </RadioGroup>
                                </FormControl>
                              </TableCell>;

                            default:
                              return <TableCell></TableCell>; // Default case
                          }
                        })()
                      }
                      <TableCell><span>
                        {row?.employee && row?.employee?.map((data, index) => (
                          <Typography key={index} variant="body1">{`${index + 1}.${data}, `}</Typography>
                        ))}
                      </span></TableCell>
                      <TableCell>
                        <Typography>{row?.completedby}</Typography>
                      </TableCell>
                      <TableCell>{row.completedat && moment(row.completedat).format("DD-MM-YYYY hh:mm:ss A")}</TableCell>
                      <TableCell>
                        {row.checklist === "DateTime" ?
                          (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16) ?
                            <Typography>Completed</Typography>
                            : <Typography>Pending</Typography>
                          : row.checklist === "Date Multi Span" ?
                            (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 21) ?
                              <Typography>Completed</Typography>
                              : <Typography>Pending</Typography>
                            : row.checklist === "Date Multi Span Time" ?
                              (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 33) ?
                                <Typography>Completed</Typography>
                                : <Typography>Pending</Typography>
                              : row.checklist === "Date Multi Random Time" ?
                                (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16) ?
                                  <Typography>Completed</Typography>
                                  : <Typography>Pending</Typography>
                                : ((row.data !== undefined && row.data !== "") || (row.files !== undefined)) ?
                                  <Typography>Completed</Typography>
                                  : <Typography>Pending</Typography>
                        }
                      </TableCell>

                      <TableCell>
                        {row.checklist === "DateTime" ?
                          (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16) ?
                            <>
                              <IconButton
                                sx={{ color: 'green', cursor: 'pointer' }}
                                onClick={() => {
                                  updateIndividualData(index);
                                }}
                              >
                                <CheckCircleIcon />
                              </IconButton>
                            </>
                            : <IconButton
                              sx={{ color: '#1565c0', cursor: 'pointer' }}
                              onClick={() => {
                                let itemValue = disableInput[index];
                                itemValue = false;
                                let spreadData = [...disableInput];
                                spreadData[index] = false;
                                setDisableInput(spreadData);
                              }}
                            >
                              <CheckCircleIcon />
                            </IconButton>
                          : row.checklist === "Date Multi Span" ?
                            (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 21) ?
                              <>
                                <IconButton
                                  sx={{ color: 'green', cursor: 'pointer' }}
                                  onClick={() => {
                                    updateIndividualData(index);
                                  }}
                                >
                                  <CheckCircleIcon />
                                </IconButton>
                              </>
                              : <IconButton
                                sx={{ color: '#1565c0', cursor: 'pointer' }}
                                onClick={() => {
                                  let itemValue = disableInput[index];
                                  itemValue = false;
                                  let spreadData = [...disableInput];
                                  spreadData[index] = false;
                                  setDisableInput(spreadData);
                                }}
                              >
                                <CheckCircleIcon />
                              </IconButton>
                            : row.checklist === "Date Multi Span Time" ?
                              (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 33) ?
                                <>
                                  <IconButton
                                    sx={{ color: 'green', cursor: 'pointer' }}
                                    onClick={() => {
                                      updateIndividualData(index);
                                    }}
                                  >
                                    <CheckCircleIcon />
                                  </IconButton>
                                </>
                                : <IconButton
                                  sx={{ color: '#1565c0', cursor: 'pointer' }}
                                  onClick={() => {
                                    let itemValue = disableInput[index];
                                    itemValue = false;
                                    let spreadData = [...disableInput];
                                    spreadData[index] = false;
                                    setDisableInput(spreadData);
                                  }}
                                >
                                  <CheckCircleIcon />
                                </IconButton>
                              : row.checklist === "Date Multi Random Time" ?
                                (((row.data !== undefined && row.data !== "") || (row.files !== undefined)) && row.data.length === 16) ?
                                  <>
                                    <IconButton
                                      sx={{ color: 'green', cursor: 'pointer' }}
                                      onClick={() => {
                                        updateIndividualData(index);
                                      }}
                                    >
                                      <CheckCircleIcon />
                                    </IconButton>
                                  </>
                                  : <IconButton
                                    sx={{ color: '#1565c0', cursor: 'pointer' }}
                                    onClick={() => {
                                      let itemValue = disableInput[index];
                                      itemValue = false;
                                      let spreadData = [...disableInput];
                                      spreadData[index] = false;
                                      setDisableInput(spreadData);
                                    }}
                                  >
                                    <CheckCircleIcon />
                                  </IconButton>
                                : ((row.data !== undefined && row.data !== "") || (row.files !== undefined)) ?
                                  <>
                                    <IconButton
                                      sx={{ color: 'green', cursor: 'pointer' }}
                                      onClick={() => {
                                        updateIndividualData(index);
                                      }}
                                    >
                                      <CheckCircleIcon />
                                    </IconButton>
                                  </>
                                  : <IconButton
                                    sx={{ color: '#1565c0', cursor: 'pointer' }}
                                    onClick={() => {
                                      let itemValue = disableInput[index];
                                      itemValue = false;
                                      let spreadData = [...disableInput];
                                      spreadData[index] = false;
                                      setDisableInput(spreadData);
                                    }}
                                  >
                                    <CheckCircleIcon />
                                  </IconButton>
                        }
                      </TableCell>
                      {/* <TableCell><span>
                          {row?.employee && row?.employee?.map((data, index) => (
                            <Typography key={index} variant="body1">{`${index + 1}.${data}, `}</Typography>
                          ))}
                        </span></TableCell> */}
                      <TableCell>{row.category}</TableCell>
                      <TableCell>{row.subcategory}</TableCell>

                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <br /> <br /> <br />
            <Grid container>
              <Grid item md={1} sm={1}></Grid>
              <Button variant="contained" onClick={handleCheckListSubmit}>
                Submit
              </Button>
              <Grid item md={1} sm={1}></Grid>
              <Button sx={userStyle.btncancel} onClick={handleCloseModEditCheckList}>
                Cancel
              </Button>
            </Grid>
          </>
        </Box>
      </Dialog>

      {/* ALERT DIALOG */}
      <Dialog
        open={isErrorOpen}
        onClose={handleCloseerr}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogContent sx={{ width: "350px", textAlign: "center", alignItems: "center" }}  >
          <Typography variant="h6">{showAlert}</Typography>
        </DialogContent>
        <DialogActions>
          <Button variant="contained" color="error" onClick={handleCloseerr}>
            ok
          </Button>
        </DialogActions>
      </Dialog>
      <MessageAlert
        openPopup={openPopupMalert}
        handleClosePopup={handleClosePopupMalert}
        popupContent={popupContentMalert}
        popupSeverity={popupSeverityMalert}
      />
      {/* SUCCESS */}
      <AlertDialog
        openPopup={openPopup}
        handleClosePopup={handleClosePopup}
        popupContent={popupContent}
        popupSeverity={popupSeverity}
      />
      {/* EXTERNAL COMPONENTS -------------- END */}
      {/* PRINT PDF EXCEL CSV */}
      <ExportData
        isFilterOpen={isFilterOpen}
        handleCloseFilterMod={handleCloseFilterMod}
        fileFormat={fileFormat}
        setIsFilterOpen={setIsFilterOpen}
        isPdfFilterOpen={isPdfFilterOpen}
        setIsPdfFilterOpen={setIsPdfFilterOpen}
        handleClosePdfFilterMod={handleClosePdfFilterMod}
        filteredDataTwo={(filteredRowData.length > 0 ? filteredRowData : filteredData) ?? []}
        itemsTwo={items ?? []}
        filename={"Team Permission Verification"}
        exportColumnNames={exportColumnNamescrt}
        exportRowValues={exportRowValuescrt}
        componentRef={componentRef}
      />
    </Box>
  );
}

export default TeamPermissionVerification;