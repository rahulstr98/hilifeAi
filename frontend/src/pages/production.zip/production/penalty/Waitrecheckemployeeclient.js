import React, { useContext, useEffect, useRef, useState } from "react";
import { Box, Button, Grid, MenuItem, Popover, Select, Typography, } from "@mui/material";
import ImageIcon from "@mui/icons-material/Image";
import { saveAs } from "file-saver";
import "jspdf-autotable";
import { FaFileCsv, FaFileExcel, FaFilePdf, FaPrint } from "react-icons/fa";
import { useReactToPrint } from "react-to-print";
import Headtitle from "../../../components/Headtitle";
import { AuthContext, UserRoleAccessContext } from "../../../context/Appcontext";
import { userStyle } from "../../../pageStyle";
import { ThreeDots } from "react-loader-spinner";
import AlertDialog from "../../../components/Alert";
import ExportData from "../../../components/ExportData";
import MessageAlert from "../../../components/MessageAlert";
import AggregatedSearchBar from "../../../components/AggregatedSearchBar";
import AggridTable from "../../../components/AggridTable";
import domtoimage from 'dom-to-image';
import ManageColumnsContent from "../../../components/ManageColumn";

function WaitRecheckEmployeeClient({ clientErrorsFive, loader }) {

    const gridRefTableFive = useRef(null);
    const gridRefTableImgFive = useRef(null);

    const { auth } = useContext(AuthContext);
    const { isUserRoleCompare } = useContext(UserRoleAccessContext);

    const [itemsFive, setItemsFive] = useState([]);
    const [selectedRowsFive, setSelectedRowsFive] = useState([]);
    const [recheckReasonsFive, setRecheckReasonsFive] = useState({});
    const [forwardReasonsFive, setForwardReasonsFive] = useState({});
    const [rowModeFive, setRowModeFive] = useState({});
    const [btnSubmitFive, setBtnSubmitFive] = useState(false);
    const [rowIndexFive, setRowIndexFive] = useState();

    const [filteredRowDataFive, setFilteredRowDataFive] = useState([]);
    const [filteredChangesFive, setFilteredChangesFive] = useState(null);
    const [isHandleChangeFive, setIsHandleChangeFive] = useState(false);
    const [searchedStringFive, setSearchedStringFive] = useState("");

    //Datatable
    const [pageFive, setPageFive] = useState(1);
    const [pageSizeFive, setPageSizeFive] = useState(10);
    const [searchQueryFive, setSearchQueryFive] = useState("");

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); };

    const [isFilterOpenFive, setIsFilterOpenFive] = useState(false);
    const [isPdfFilterOpenFive, setIsPdfFilterOpenFive] = useState(false);
    // pageFive refersh reload
    const handleCloseFilterModFive = () => { setIsFilterOpenFive(false); };
    const handleClosePdfFilterModFive = () => { setIsPdfFilterOpenFive(false); };

    // Manage Columns
    const [searchQueryManageFive, setSearchQueryManageFive] = useState("");
    const [isManageColumnsOpenFive, setManageColumnsOpenFive] = useState(false);
    const [anchorElFive, setAnchorElFive] = useState(null);

    const handleOpenManageColumnsFive = (event) => {
        setAnchorElFive(event.currentTarget);
        setManageColumnsOpenFive(true);
    };
    const handleCloseManageColumnsFive = () => {
        setManageColumnsOpenFive(false);
        setSearchQueryManageFive("");
    };

    const openFive = Boolean(anchorElFive);
    const idFive = openFive ? "simple-popover" : undefined;

    const modeOption = [
        { label: "NaN", value: "NaN" },
        { label: "Approved", value: "Approved" },
        { label: "Reject", value: "Reject" },
    ]

    // Show All Columns & Manage Columns
    const initialColumnVisibilityFive = {
        serialNumber: true,
        level: true,
        vendor: true,
        branch: true,
        employeeid: true,
        employeename: true,
        loginid: true,
        date: true,
        category: true,
        subcategory: true,
        documentnumber: true,
        fieldname: true,
        line: true,
        errorvalue: true,
        correctvalue: true,
        clienterror: true,
        clientamount: true,
        percentage: true,
        amount: true,
        history: true,
        monthhistory: true,
        requestreason: true,
        forwardreason: true,
        recheck: true,
        approved: true,
        reject: true,
    };
    const [columnVisibilityFive, setColumnVisibilityFive] = useState(initialColumnVisibilityFive);

    // pageFive refersh reload code
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    const addSerialNumberFive = (datas) => {
        setItemsFive(datas);
    };

    useEffect(() => {
        addSerialNumberFive(clientErrorsFive);
    }, [clientErrorsFive]);

    //Datatable
    const handlePageSizeChangeFive = (event) => {
        setPageSizeFive(Number(event.target.value));
        setSelectedRowsFive([]);
        setPageFive(1);
    };

    // Split the search query into individual terms
    const searchTermsFive = searchQueryFive.toLowerCase().split(" ");
    // Modify the filtering logic to check each term
    const filteredDatasFive = itemsFive?.filter((item) => {
        return searchTermsFive.every((term) =>
            Object.values(item).join(" ").toLowerCase().includes(term)
        );
    });
    const filteredDataFive = filteredDatasFive?.slice((pageFive - 1) * pageSizeFive, pageFive * pageSizeFive);
    const totalPagesFive = Math.ceil(filteredDatasFive.length / pageSizeFive);
    const visiblePagesFive = Math.min(totalPagesFive, 3);
    const firstVisiblePageFive = Math.max(1, pageFive - 1);
    const lastVisiblePageFive = Math.min(firstVisiblePageFive + visiblePagesFive - 1, totalPagesFive);
    const pageNumbersFive = [];
    const indexOfLastItemFive = pageFive * pageSizeFive;
    const indexOfFirstItemFive = indexOfLastItemFive - pageSizeFive;
    for (let i = firstVisiblePageFive; i <= lastVisiblePageFive; i++) {
        pageNumbersFive.push(i);
    }

    const columnDataTableFive = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 75, hide: !columnVisibilityFive.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "level", headerName: "Level", flex: 0, width: 100, hide: !columnVisibilityFive.level, },
        { field: "vendor", headerName: "Vendor Name", flex: 0, width: 150, hide: !columnVisibilityFive.vendor, },
        { field: "branch", headerName: "Branch Name", flex: 0, width: 150, hide: !columnVisibilityFive.branch, headerClassName: "bold-header", },
        { field: "employeeid", headerName: "Employee Code", flex: 0, width: 150, hide: !columnVisibilityFive.employeeid, },
        { field: "employeename", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityFive.employeename, },
        { field: "loginid", headerName: "Login id", flex: 0, width: 120, hide: !columnVisibilityFive.loginid, },
        { field: "date", headerName: "Date", flex: 0, width: 120, hide: !columnVisibilityFive.date, headerClassName: "bold-header", },
        { field: "category", headerName: "Category", flex: 0, width: 250, hide: !columnVisibilityFive.category, },
        { field: "subcategory", headerName: "Subcategory", flex: 0, width: 250, hide: !columnVisibilityFive.subcategory, },
        { field: "documentnumber", headerName: "Document Number", flex: 0, width: 150, hide: !columnVisibilityFive.documentnumber, },
        { field: "fieldname", headerName: "Field Name", flex: 0, width: 150, hide: !columnVisibilityFive.fieldname, },
        { field: "line", headerName: "Line", flex: 0, width: 100, hide: !columnVisibilityFive.line, },
        { field: "errorvalue", headerName: "Error Value", flex: 0, width: 250, hide: !columnVisibilityFive.errorvalue, },
        { field: "correctvalue", headerName: "Correct Value", flex: 0, width: 250, hide: !columnVisibilityFive.correctvalue, },
        { field: "clienterror", headerName: "Client Error", flex: 0, width: 250, hide: !columnVisibilityFive.clienterror, },
        { field: "clientamount", headerName: "Client Amount", flex: 0, width: 100, hide: !columnVisibilityFive.clientamount, },
        { field: "percentage", headerName: "per%", flex: 0, width: 100, hide: !columnVisibilityFive.percentage, },
        { field: "amount", headerName: "Amount", flex: 0, width: 100, hide: !columnVisibilityFive.amount, },
        { field: "history", headerName: "History", flex: 0, width: 250, hide: !columnVisibilityFive.history, },
        { field: "monthhistory", headerName: "Month History", flex: 0, width: 250, hide: !columnVisibilityFive.monthhistory, },
        { field: "requestreason", headerName: "Request Reason", flex: 0, width: 250, hide: !columnVisibilityFive.requestreason, },
        { field: "forwardreason", headerName: "Forward Reason", flex: 0, width: 250, hide: !columnVisibilityFive.forwardreason, },
        { field: "recheck", headerName: "ReCheck", flex: 0, width: 250, hide: !columnVisibilityFive.recheck, },
        { field: "approved", headerName: "Approved", flex: 0, width: 250, hide: !columnVisibilityFive.approved, },
        { field: "reject", headerName: "Reject", flex: 0, width: 250, hide: !columnVisibilityFive.reject, },
    ];

    const rowDataTableFive = filteredDataFive?.map((item, index) => {
        return {
            ...item,
        };
    });

    // Show All Columns functionality
    const handleShowAllColumnsFive = () => {
        const updatedVisibility = { ...columnVisibilityFive };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityFive(updatedVisibility);
    };

    // Function to filter columns based on search query
    const filteredColumnsFive = columnDataTableFive.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageFive.toLowerCase())
    );

    // Manage Columns functionality
    const toggleColumnVisibilityFive = (field) => {
        setColumnVisibilityFive((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    const [fileFormat, setFormat] = useState("");
    let exportColumnNamesFive = ['Level', 'Ventor Name', 'Branch Name', 'Unit', 'Team', 'Employee Code', 'Employee Name', 'Login id', 'Date', 'Category', 'SubCategory', 'Document Number', 'Field Name',
        'Line', 'Error Value', 'Correct Value', 'Client Error', 'Client Amount', 'per%', 'Amount', 'History', 'Month History', 'Request Reason', 'Forward Reason', 'ReCheck', 'Approved', 'Reject'];
    let exportRowValuesFive = ['level', 'ventorname', 'branchname', 'unit', 'team', 'employeecode', 'employeename', 'loginid', 'date', 'category', 'subcategory', 'documentnumber', 'fieldname',
        'line', 'errorvalue', 'correctvalue', 'clienterror', 'clientamount', 'per', 'amount', 'requestreason', 'action', 'mode', 'action'];

    //print...
    const componentRefFive = useRef();
    const handleprintFive = useReactToPrint({
        content: () => componentRefFive.current,
        documentTitle: "Wait Recheck Employee Client Error Waiver Request List",
        pageStyle: "print",
    });

    //image
    const handleCaptureImageFive = () => {
        if (gridRefTableImgFive.current) {
            domtoimage.toBlob(gridRefTableImgFive.current)
                .then((blob) => {
                    saveAs(blob, "Wait Recheck Employee Client Error Waiver Request List.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    return (
        <Box>
            <Headtitle title={"Client Error Waiver Approval"} />
            {/* ****** Table Start ****** */}
            {isUserRoleCompare?.includes("lclienterrorwaiverapproval") && (
                <>
                    <Box sx={userStyle.container}>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid item xs={8}>
                            <Typography sx={userStyle.importheadtext}>Wait Recheck Employee Client Error Waiver Request List</Typography>
                        </Grid>
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSizeFive}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeFive}
                                        sx={{ width: "77px" }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={clientErrorsFive?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                <Box>
                                    {isUserRoleCompare?.includes("excelclienterrorwaiverapproval") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenFive(true); setFormat("xl"); }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("csvclienterrorwaiverapproval") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenFive(true); setFormat("csv"); }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("printclienterrorwaiverapproval") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintFive}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("pdfclienterrorwaiverapproval") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={() => { setIsPdfFilterOpenFive(true); }}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("imageclienterrorwaiverapproval") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImageFive}><ImageIcon sx={{ fontSize: "15px" }} />{" "} &ensp;Image&ensp;</Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <Box>
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTableFive}
                                        setItems={setItemsFive}
                                        addSerialNumber={addSerialNumberFive}
                                        setPage={setPageFive}
                                        maindatas={clientErrorsFive}
                                        setSearchedString={setSearchedStringFive}
                                        searchQuery={searchQueryFive}
                                        setSearchQuery={setSearchQueryFive}
                                        paginated={false}
                                        totalDatas={clientErrorsFive}
                                    />
                                </Box>
                            </Grid>
                        </Grid><br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsFive}>Show All Columns</Button>&ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsFive}>Manage Columns</Button><br /><br />
                        {loader ? (
                            <>
                                <Box sx={{ display: "flex", justifyContent: "center" }}>
                                    <ThreeDots
                                        height="80"
                                        width="80"
                                        radius="9"
                                        color="#1976d2"
                                        ariaLabel="Five-dots-loading"
                                        wrapperStyle={{}}
                                        wrapperClassName=""
                                        visible={true}
                                    />
                                </Box>
                            </>
                        ) : (
                            <>
                                <AggridTable
                                    rowDataTable={rowDataTableFive}
                                    columnDataTable={columnDataTableFive}
                                    columnVisibility={columnVisibilityFive}
                                    page={pageFive}
                                    setPage={setPageFive}
                                    pageSize={pageSizeFive}
                                    totalPages={totalPagesFive}
                                    setColumnVisibility={setColumnVisibilityFive}
                                    isHandleChange={isHandleChangeFive}
                                    items={itemsFive}
                                    selectedRows={selectedRowsFive}
                                    setSelectedRows={setSelectedRowsFive}
                                    gridRefTable={gridRefTableFive}
                                    paginated={false}
                                    filteredDatas={filteredDatasFive}
                                    // totalDatas={totalDatas}
                                    searchQuery={searchedStringFive}
                                    handleShowAllColumns={handleShowAllColumnsFive}
                                    setFilteredRowData={setFilteredRowDataFive}
                                    filteredRowData={filteredRowDataFive}
                                    setFilteredChanges={setFilteredChangesFive}
                                    filteredChanges={filteredChangesFive}
                                    gridRefTableImg={gridRefTableImgFive}
                                    itemsList={clientErrorsFive}
                                />
                            </>
                        )}
                    </Box>
                </>
            )}

            {/* Manage Column */}
            <Popover
                id={idFive}
                open={isManageColumnsOpenFive}
                anchorEl={anchorElFive}
                onClose={handleCloseManageColumnsFive}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsFive}
                    searchQuery={searchQueryManageFive}
                    setSearchQuery={setSearchQueryManageFive}
                    filteredColumns={filteredColumnsFive}
                    columnVisibility={columnVisibilityFive}
                    toggleColumnVisibility={toggleColumnVisibilityFive}
                    setColumnVisibility={setColumnVisibilityFive}
                    initialColumnVisibility={initialColumnVisibilityFive}
                    columnDataTable={columnDataTableFive}
                />
            </Popover>

            {/* EXTERNAL COMPONENTS -------------- START */}
            {/* VALIDATION */}
            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenFive}
                handleCloseFilterMod={handleCloseFilterModFive}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenFive}
                isPdfFilterOpen={isPdfFilterOpenFive}
                setIsPdfFilterOpen={setIsPdfFilterOpenFive}
                handleClosePdfFilterMod={handleClosePdfFilterModFive}
                filteredDataTwo={(filteredChangesFive !== null ? filteredRowDataFive : rowDataTableFive) ?? []}
                itemsTwo={clientErrorsFive ?? []}
                filename={"Wait Recheck Employee Client Error Waiver Request List"}
                exportColumnNames={exportColumnNamesFive}
                exportRowValues={exportRowValuesFive}
                componentRef={componentRefFive}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
        </Box>
    );
}

export default WaitRecheckEmployeeClient;