import React, { useContext, useEffect, useRef, useState } from "react";
import { Box, Button, FormControl, Grid, MenuItem, Popover, Select, Typography, TextareaAutosize } from "@mui/material";
import ImageIcon from "@mui/icons-material/Image";
import LoadingButton from "@mui/lab/LoadingButton";
import axios from "axios";
import { saveAs } from "file-saver";
import "jspdf-autotable";
import { FaFileCsv, FaFileExcel, FaFilePdf, FaPrint } from "react-icons/fa";
import { useReactToPrint } from "react-to-print";
import { handleApiError } from "../../../components/Errorhandling";
import Headtitle from "../../../components/Headtitle";
import { AuthContext, UserRoleAccessContext } from "../../../context/Appcontext";
import { userStyle } from "../../../pageStyle";
import { SERVICE } from "../../../services/Baseservice";
import { ThreeDots } from "react-loader-spinner";
import AlertDialog from "../../../components/Alert";
import ExportData from "../../../components/ExportData";
import MessageAlert from "../../../components/MessageAlert";
import AggregatedSearchBar from "../../../components/AggregatedSearchBar";
import AggridTable from "../../../components/AggridTable";
import domtoimage from 'dom-to-image';
import ManageColumnsContent from "../../../components/ManageColumn";

const RecheckReasonCellThree = ({ rowId, currentRecheckReasonThree, onSave, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert, setPopupContent, setPopupSeverity, handleClickOpenPopup, auth, fetchAllClient, rowData }) => {
    const [localRecheckReasonThree, setLocalRecheckReasonThree] = useState(currentRecheckReasonThree);

    const today = new Date();
    // Extracting date in 'YYYY-MM-DD' format
    const date = today.toISOString().split('T')[0];

    // Extracting time in 'HH:MM' format
    const time = today.toTimeString().split(' ')[0].slice(0, 5);

    const handleSaveClick = async () => {
        onSave(localRecheckReasonThree);
        if (localRecheckReasonThree === '') {
            setPopupContentMalert("Please Enter Recheck Reason");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else {
            try {
                let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                    headers: {
                        Authorization: `Bearer ${auth.APIToken}`,
                    },
                    history: [
                        ...rowData.history,
                        {
                            tablename: 'Client Error Forward_Resent',
                            date: date,
                            time: time,
                            status: "Recheck",
                            reason: localRecheckReasonThree,
                            mode: "",
                        }
                    ]
                });
                await fetchAllClient();
                setPopupContent("Request Sent Successfully");
                setPopupSeverity("success");
                handleClickOpenPopup();
            } catch (err) {
                handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
            }
        }
    };

    return (
        <Grid container>
            <Grid item xs={12} sm={12} md={12}>
                <FormControl size="small" fullWidth>
                    <TextareaAutosize fullWidth
                        aria-label="maximum height"
                        minRows={3}
                        maxRows={3}
                        value={localRecheckReasonThree}
                        placeholder="Recheck Reason"
                        onChange={(e) => {
                            setLocalRecheckReasonThree(e.target.value);
                        }}
                        onPaste={(e) => e.preventDefault()}
                        onCopy={(e) => e.preventDefault()}
                        style={{ resize: "none", fontSize: '1rem' }}
                    />
                </FormControl>
            </Grid>
            <Grid item xs={12} sm={9} md={9}>
                <Button sx={{ textTransform: 'capitalize' }} variant="contained" color="error" size="small" onClick={handleSaveClick}>Recheck</Button>
            </Grid>
        </Grid>
    );
};

const ForwardReasonCellThree = ({ rowId, currentForwardReasonThree, onSave, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert, setPopupContent, setPopupSeverity, handleClickOpenPopup, auth, fetchAllClient, rowData }) => {
    const [localForwardReasonThree, setLocalForwardReasonThree] = useState(currentForwardReasonThree);

    const today = new Date();
    // Extracting date in 'YYYY-MM-DD' format
    const date = today.toISOString().split('T')[0];

    // Extracting time in 'HH:MM' format
    const time = today.toTimeString().split(' ')[0].slice(0, 5);

    const handleSaveClick = async () => {
        onSave(localForwardReasonThree);
        if (localForwardReasonThree === '') {
            setPopupContentMalert("Please Enter Forward Reason");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else {
            try {
                let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                    headers: {
                        Authorization: `Bearer ${auth.APIToken}`,
                    },
                    history: [
                        ...rowData.history,
                        {
                            tablename: 'Client Error Forward_Resent',
                            date: date,
                            time: time,
                            status: "Forward",
                            reason: localForwardReasonThree,
                            mode: "",
                        }
                    ]
                });
                await fetchAllClient();
                setPopupContent("Request Sent Successfully");
                setPopupSeverity("success");
                handleClickOpenPopup();
            } catch (err) {
                handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
            }
        }
    };

    return (
        <Grid container>
            <Grid item xs={12} sm={12} md={12}>
                <FormControl size="small" fullWidth>
                    <TextareaAutosize fullWidth
                        aria-label="maximum height"
                        minRows={3}
                        maxRows={3}
                        value={localForwardReasonThree}
                        placeholder="Forward Reason"
                        onChange={(e) => {
                            setLocalForwardReasonThree(e.target.value);
                        }}
                        onPaste={(e) => e.preventDefault()}
                        onCopy={(e) => e.preventDefault()}
                        style={{ resize: "none", fontSize: '1rem' }}
                    />
                </FormControl>
            </Grid>
            <Grid item xs={12} sm={9} md={9}>
                <Button sx={{ textTransform: 'capitalize' }} variant="contained" color="error" size="small" onClick={handleSaveClick}>ForWard</Button>
            </Grid>
        </Grid>
    );
};

const RecheckReasonCellFour = ({ rowId, currentRecheckReasonFour, onSave, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert, setPopupContent, setPopupSeverity, handleClickOpenPopup, auth, fetchAllClient, rowData }) => {
    const [localRecheckReasonFour, setLocalRecheckReasonFour] = useState(currentRecheckReasonFour);

    const today = new Date();
    // Extracting date in 'YYYY-MM-DD' format
    const date = today.toISOString().split('T')[0];

    // Extracting time in 'HH:MM' format
    const time = today.toTimeString().split(' ')[0].slice(0, 5);

    const handleSaveClick = async () => {
        onSave(localRecheckReasonFour);
        if (localRecheckReasonFour === '') {
            setPopupContentMalert("Please Enter Recheck Reason");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else {
            try {
                let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                    headers: {
                        Authorization: `Bearer ${auth.APIToken}`,
                    },
                    history: [
                        ...rowData.history,
                        {
                            tablename: 'Client Error Forward_Recheck',
                            date: date,
                            time: time,
                            status: "Recheck",
                            reason: localRecheckReasonFour,
                            mode: "",
                        }
                    ]
                });
                await fetchAllClient();
                setPopupContent("Request Sent Successfully");
                setPopupSeverity("success");
                handleClickOpenPopup();
            } catch (err) {
                handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
            }
        }
    };

    return (
        <Grid container>
            <Grid item xs={12} sm={12} md={12}>
                <FormControl size="small" fullWidth>
                    <TextareaAutosize fullWidth
                        aria-label="maximum height"
                        minRows={3}
                        maxRows={3}
                        value={localRecheckReasonFour}
                        placeholder="Recheck Reason"
                        onChange={(e) => {
                            setLocalRecheckReasonFour(e.target.value);
                        }}
                        onPaste={(e) => e.preventDefault()}
                        onCopy={(e) => e.preventDefault()}
                        style={{ resize: "none", fontSize: '1rem' }}
                    />
                </FormControl>
            </Grid>
            <Grid item xs={12} sm={9} md={9}>
                <Button sx={{ textTransform: 'capitalize' }} variant="contained" color="error" size="small" onClick={handleSaveClick}>Recheck</Button>
            </Grid>
        </Grid>
    );
};

const ForwardReasonCellFour = ({ rowId, currentForwardReasonFour, onSave, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert, setPopupContent, setPopupSeverity, handleClickOpenPopup, auth, fetchAllClient, rowData }) => {
    const [localForwardReasonFour, setLocalForwardReasonFour] = useState(currentForwardReasonFour);

    const today = new Date();
    // Extracting date in 'YYYY-MM-DD' format
    const date = today.toISOString().split('T')[0];

    // Extracting time in 'HH:MM' format
    const time = today.toTimeString().split(' ')[0].slice(0, 5);

    const handleSaveClick = async () => {
        onSave(localForwardReasonFour);
        if (localForwardReasonFour === '') {
            setPopupContentMalert("Please Enter Forward Reason");
            setPopupSeverityMalert("warning");
            handleClickOpenPopupMalert();
        } else {
            try {
                let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                    headers: {
                        Authorization: `Bearer ${auth.APIToken}`,
                    },
                    history: [
                        ...rowData.history,
                        {
                            tablename: 'Client Error Forward_Recheck',
                            date: date,
                            time: time,
                            status: "Forward",
                            reason: localForwardReasonFour,
                            mode: "",
                        }
                    ]
                });
                await fetchAllClient();
                setPopupContent("Request Sent Successfully");
                setPopupSeverity("success");
                handleClickOpenPopup();
            } catch (err) {
                handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert);
            }
        }
    };

    return (
        <Grid container>
            <Grid item xs={12} sm={12} md={12}>
                <FormControl size="small" fullWidth>
                    <TextareaAutosize fullWidth
                        aria-label="maximum height"
                        minRows={3}
                        maxRows={3}
                        value={localForwardReasonFour}
                        placeholder="Forward Reason"
                        onChange={(e) => {
                            setLocalForwardReasonFour(e.target.value);
                        }}
                        onPaste={(e) => e.preventDefault()}
                        onCopy={(e) => e.preventDefault()}
                        style={{ resize: "none", fontSize: '1rem' }}
                    />
                </FormControl>
            </Grid>
            <Grid item xs={12} sm={9} md={9}>
                <Button sx={{ textTransform: 'capitalize' }} variant="contained" color="error" size="small" onClick={handleSaveClick}>ForWard</Button>
            </Grid>
        </Grid>
    );
};

function ResentForwardEmployee({ clientErrorsThree, clientErrorsFour, fetchAllClient, loader }) {

    const gridRefTableThree = useRef(null);
    const gridRefTableFour = useRef(null);
    const gridRefTableImgThree = useRef(null);
    const gridRefTableImgFour = useRef(null);

    const { auth } = useContext(AuthContext);
    const { isUserRoleCompare, buttonStyles } = useContext(UserRoleAccessContext);

    const [itemsThree, setItemsThree] = useState([]);
    const [selectedRowsThree, setSelectedRowsThree] = useState([]);
    const [recheckReasonsThree, setRecheckReasonsThree] = useState({});
    const [forwardReasonsThree, setForwardReasonsThree] = useState({});
    const [rowModeThree, setRowModeThree] = useState({});
    const [btnSubmitThree, setBtnSubmitThree] = useState(false);
    const [rowIndexThree, setRowIndexThree] = useState();

    const [itemsFour, setItemsFour] = useState([]);
    const [selectedRowsFour, setSelectedRowsFour] = useState([]);
    const [recheckReasonsFour, setRecheckReasonsFour] = useState({});
    const [forwardReasonsFour, setForwardReasonsFour] = useState({});
    const [rowModeFour, setRowModeFour] = useState({});
    const [btnSubmitFour, setBtnSubmitFour] = useState(false);
    const [rowIndexFour, setRowIndexFour] = useState();

    const [filteredRowDataThree, setFilteredRowDataThree] = useState([]);
    const [filteredChangesThree, setFilteredChangesThree] = useState(null);
    const [isHandleChangeThree, setIsHandleChangeThree] = useState(false);
    const [searchedStringThree, setSearchedStringThree] = useState("");

    const [filteredRowDataFour, setFilteredRowDataFour] = useState([]);
    const [filteredChangesFour, setFilteredChangesFour] = useState(null);
    const [isHandleChangeFour, setIsHandleChangeFour] = useState(false);
    const [searchedStringFour, setSearchedStringFour] = useState("");

    //Datatable
    const [pageThree, setPageThree] = useState(1);
    const [pageSizeThree, setPageSizeThree] = useState(10);
    const [searchQueryThree, setSearchQueryThree] = useState("");

    //Datatable second Table
    const [pageFour, setPageFour] = useState(1);
    const [pageSizeFour, setPageSizeFour] = useState(10);
    const [searchQueryFour, setSearchQueryFour] = useState("");

    const [openPopupMalert, setOpenPopupMalert] = useState(false);
    const [popupContentMalert, setPopupContentMalert] = useState("");
    const [popupSeverityMalert, setPopupSeverityMalert] = useState("");
    const handleClickOpenPopupMalert = () => { setOpenPopupMalert(true); };
    const handleClosePopupMalert = () => { setOpenPopupMalert(false); };

    const [openPopup, setOpenPopup] = useState(false);
    const [popupContent, setPopupContent] = useState("");
    const [popupSeverity, setPopupSeverity] = useState("");
    const handleClickOpenPopup = () => { setOpenPopup(true); };
    const handleClosePopup = () => { setOpenPopup(false); };

    const [isFilterOpenThree, setIsFilterOpenThree] = useState(false);
    const [isPdfFilterOpenThree, setIsPdfFilterOpenThree] = useState(false);
    // pageThree refersh reload
    const handleCloseFilterModThree = () => { setIsFilterOpenThree(false); };
    const handleClosePdfFilterModThree = () => { setIsPdfFilterOpenThree(false); };

    // second table
    const [isFilterOpenFour, setIsFilterOpenFour] = useState(false);
    const [isPdfFilterOpenFour, setIsPdfFilterOpenFour] = useState(false);
    // pageThree refersh reload
    const handleCloseFilterModFour = () => { setIsFilterOpenFour(false); };
    const handleClosePdfFilterModFour = () => { setIsPdfFilterOpenFour(false); };

    // Manage Columns
    const [searchQueryManageThree, setSearchQueryManageThree] = useState("");
    const [isManageColumnsOpenThree, setManageColumnsOpenThree] = useState(false);
    const [anchorElThree, setAnchorElThree] = useState(null);

    const handleOpenManageColumnsThree = (event) => {
        setAnchorElThree(event.currentTarget);
        setManageColumnsOpenThree(true);
    };
    const handleCloseManageColumnsThree = () => {
        setManageColumnsOpenThree(false);
        setSearchQueryManageThree("");
    };

    const openThree = Boolean(anchorElThree);
    const idThree = openThree ? "simple-popover" : undefined;

    // Manage Columns second Table
    const [searchQueryManageFour, setSearchQueryManageFour] = useState("");
    const [isManageColumnsOpenFour, setManageColumnsOpenFour] = useState(false);
    const [anchorElFour, setAnchorElFour] = useState(null);

    const handleOpenManageColumnsFour = (event) => {
        setAnchorElFour(event.currentTarget);
        setManageColumnsOpenFour(true);
    };
    const handleCloseManageColumnsFour = () => {
        setManageColumnsOpenFour(false);
        setSearchQueryManageFour("");
    };

    const openFour = Boolean(anchorElFour);
    const idFour = openFour ? "simple-popover" : undefined;

    const modeOption = [
        { label: "NaN", value: "NaN" },
        { label: "Approved", value: "Approved" },
        { label: "Reject", value: "Reject" },
    ]

    // Show All Columns & Manage Columns
    const initialColumnVisibilityThree = {
        serialNumber: true,
        level: true,
        vendor: true,
        branch: true,
        employeeid: true,
        employeename: true,
        loginid: true,
        date: true,
        category: true,
        subcategory: true,
        documentnumber: true,
        fieldname: true,
        line: true,
        errorvalue: true,
        correctvalue: true,
        clienterror: true,
        clientamount: true,
        percentage: true,
        amount: true,
        reason: true,
        forwardreason: true,
        actions: true,
        mode: true,
        actions2: true
    };
    const [columnVisibilityThree, setColumnVisibilityThree] = useState(initialColumnVisibilityThree);

    // Show All Columns & Manage Columns second Table
    const initialColumnVisibilityFour = {
        serialNumber: true,
        level: true,
        vendor: true,
        branch: true,
        employeeid: true,
        employeename: true,
        loginid: true,
        date: true,
        category: true,
        subcategory: true,
        documentnumber: true,
        fieldname: true,
        line: true,
        errorvalue: true,
        correctvalue: true,
        clienterror: true,
        clientamount: true,
        percentage: true,
        amount: true,
        requestreason: true,
        forwardreason: true,
        actions: true,
        mode: true,
        actions2: true
    };

    const [columnVisibilityFour, setColumnVisibilityFour] = useState(initialColumnVisibilityFour);

    // pageThree refersh reload code
    const handleBeforeUnload = (event) => {
        event.preventDefault();
        event.returnValue = ""; // This is required for Chrome support
    };

    useEffect(() => {
        const beforeUnloadHandler = (event) => handleBeforeUnload(event);
        window.addEventListener("beforeunload", beforeUnloadHandler);
        return () => {
            window.removeEventListener("beforeunload", beforeUnloadHandler);
        };
    }, []);

    const handleUpdateThree = async (rowId, mode) => {
        setBtnSubmitThree(true);
        try {
            let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                mode: mode
            });
            await fetchAllClient();
            setBtnSubmitThree(false);
            setPopupContent("Updated Successfully");
            setPopupSeverity("success");
            handleClickOpenPopup();
        } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
    };

    const handleActionThree = (value, rowId, sno) => {
        setRowModeThree((prevStatus) => ({
            ...prevStatus,
            [rowId]: {
                ...prevStatus[rowId],
                mode: value,
                btnShow: true,
            },
        }));
        setRowIndexThree(sno);
    };

    const handleUpdateFour = async (rowId, mode) => {
        setBtnSubmitFour(true);
        try {
            let res = await axios.put(`${SERVICE.PENALTYCLIENTERROR_SINGLE}/${rowId}`, {
                headers: {
                    Authorization: `Bearer ${auth.APIToken}`,
                },
                mode: mode
            });
            await fetchAllClient();
            setBtnSubmitFour(false);
            setPopupContent("Updated Successfully");
            setPopupSeverity("success");
            handleClickOpenPopup();
        } catch (err) { handleApiError(err, setPopupContentMalert, setPopupSeverityMalert, handleClickOpenPopupMalert); }
    };

    const handleActionFour = (value, rowId, sno) => {
        setRowModeFour((prevStatus) => ({
            ...prevStatus,
            [rowId]: {
                ...prevStatus[rowId],
                mode: value,
                btnShow: true,
            },
        }));
        setRowIndexFour(sno);
    };

    const addSerialNumberThree = (datas) => {
        setItemsThree(datas);
    };

    useEffect(() => {
        addSerialNumberThree(clientErrorsThree);
    }, [clientErrorsThree]);

    // second Table
    const addSerialNumberFour = (datas) => {
        setItemsFour(datas);
    };

    useEffect(() => {
        addSerialNumberFour(clientErrorsFour);
    }, [clientErrorsFour]);

    //Datatable
    const handlePageSizeChangeThree = (event) => {
        setPageSizeThree(Number(event.target.value));
        setSelectedRowsThree([]);
        setPageThree(1);
    };

    // Split the search query into individual terms
    const searchTermsThree = searchQueryThree.toLowerCase().split(" ");
    // Modify the filtering logic to check each term
    const filteredDatasThree = itemsThree?.filter((item) => {
        return searchTermsThree.every((term) =>
            Object.values(item).join(" ").toLowerCase().includes(term)
        );
    });
    const filteredDataThree = filteredDatasThree.slice((pageThree - 1) * pageSizeThree, pageThree * pageSizeThree);
    const totalPagesThree = Math.ceil(filteredDatasThree.length / pageSizeThree);
    const visiblePagesThree = Math.min(totalPagesThree, 3);
    const firstVisiblePageThree = Math.max(1, pageThree - 1);
    const lastVisiblePageThree = Math.min(firstVisiblePageThree + visiblePagesThree - 1, totalPagesThree);
    const pageNumbersThree = [];
    const indexOfLastItemThree = pageThree * pageSizeThree;
    const indexOfFirstItemThree = indexOfLastItemThree - pageSizeThree;
    for (let i = firstVisiblePageThree; i <= lastVisiblePageThree; i++) {
        pageNumbersThree.push(i);
    }

    //Datatable second Table
    const handlePageSizeChangeFour = (event) => {
        setPageSizeFour(Number(event.target.value));
        setSelectedRowsFour([]);
        setPageFour(1);
    };

    // Split the search query into individual terms
    const searchTermsFour = searchQueryFour.toLowerCase().split(" ");
    // Modify the filtering logic to check each term
    const filteredDatasFour = itemsFour?.filter((item) => {
        return searchTermsFour.every((term) =>
            Object.values(item).join(" ").toLowerCase().includes(term)
        );
    });
    const filteredDataFour = filteredDatasFour.slice((pageFour - 1) * pageSizeFour, pageFour * pageSizeFour);
    const totalPagesFour = Math.ceil(filteredDatasFour.length / pageSizeFour);
    const visiblePagesFour = Math.min(totalPagesFour, 3);
    const firstVisiblePageFour = Math.max(1, pageFour - 1);
    const lastVisiblePageFour = Math.min(firstVisiblePageFour + visiblePagesFour - 1, totalPagesFour);
    const pageNumbersFour = [];
    const indexOfLastItemFour = pageFour * pageSizeFour;
    const indexOfFirstItemFour = indexOfLastItemFour - pageSizeFour;
    for (let i = firstVisiblePageFour; i <= lastVisiblePageFour; i++) {
        pageNumbersFour.push(i);
    }

    const columnDataTableThree = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 75, hide: !columnVisibilityThree.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "level", headerName: "Level", flex: 0, width: 100, hide: !columnVisibilityThree.level, },
        { field: "vendor", headerName: "Vendor Name", flex: 0, width: 150, hide: !columnVisibilityThree.vendor, },
        { field: "branch", headerName: "Branch Name", flex: 0, width: 150, hide: !columnVisibilityThree.branch, headerClassName: "bold-header", },
        { field: "employeeid", headerName: "Employee Code", flex: 0, width: 150, hide: !columnVisibilityThree.employeeid, },
        { field: "employeename", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityThree.employeename, },
        { field: "loginid", headerName: "Login id", flex: 0, width: 120, hide: !columnVisibilityThree.loginid, },
        { field: "date", headerName: "Date", flex: 0, width: 120, hide: !columnVisibilityThree.date, headerClassName: "bold-header", },
        { field: "category", headerName: "Category", flex: 0, width: 250, hide: !columnVisibilityThree.category, },
        { field: "subcategory", headerName: "Subcategory", flex: 0, width: 250, hide: !columnVisibilityThree.subcategory, },
        { field: "documentnumber", headerName: "Document Number", flex: 0, width: 150, hide: !columnVisibilityThree.documentnumber, },
        { field: "fieldname", headerName: "Field Name", flex: 0, width: 150, hide: !columnVisibilityThree.fieldname, },
        { field: "line", headerName: "Line", flex: 0, width: 100, hide: !columnVisibilityThree.line, },
        { field: "errorvalue", headerName: "Error Value", flex: 0, width: 250, hide: !columnVisibilityThree.errorvalue, },
        { field: "correctvalue", headerName: "Correct Value", flex: 0, width: 250, hide: !columnVisibilityThree.correctvalue, },
        { field: "clienterror", headerName: "Client Error", flex: 0, width: 250, hide: !columnVisibilityThree.clienterror, },
        { field: "clientamount", headerName: "Client Amount", flex: 0, width: 100, hide: !columnVisibilityThree.clientamount, },
        { field: "percentage", headerName: "per%", flex: 0, width: 100, hide: !columnVisibilityThree.percentage, },
        { field: "amount", headerName: "Amount", flex: 0, width: 100, hide: !columnVisibilityThree.amount, },
        {
            field: "reason", headerName: "Request Reason", flex: 0, width: 250, hide: !columnVisibilityThree.reason, cellStyle: { whiteSpace: "pre-wrap", wordWrap: "break-word" },
            cellRenderer: (params) => {
                const reasons = params.data.reason ? params.data.reason.split('\n') : [];
                return (
                    <Grid container>
                        {reasons.map((line, index) => (
                            <Typography
                                key={index}
                                sx={{ color: index > 0 && index < reasons.length - 1 ? 'red' : 'inherit' }}
                            >
                                {line}
                            </Typography>
                        ))}
                    </Grid>
                );
            },
        },
        { field: "forwardreason", headerName: "Forward Reason", flex: 0, width: 250, hide: !columnVisibilityThree.forwardreason, cellStyle: { whiteSpace: "pre-wrap", wordWrap: "break-word" }, },
        {
            field: "actions", headerName: "Action", flex: 0, width: 350, hide: !columnVisibilityThree.actions, sortable: false, filter: false,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex', justifyContent: 'center' }}>
                    <RecheckReasonCellThree
                        rowId={params.data.id}
                        currentRecheckReasonThree={recheckReasonsThree[params.data.id] || ""}
                        onSave={(rejectreason) => {
                            setRecheckReasonsThree((prev) => ({
                                ...prev,
                                [params.data.id]: rejectreason,
                            }));
                        }}
                        setPopupContentMalert={setPopupContentMalert} setPopupSeverityMalert={setPopupSeverityMalert} handleClickOpenPopupMalert={handleClickOpenPopupMalert}
                        setPopupContent={setPopupContent}
                        setPopupSeverity={setPopupSeverity}
                        handleClickOpenPopup={handleClickOpenPopup}
                        auth={auth} fetchAllClient={fetchAllClient} rowData={params.data}
                    />
                </Grid>
            ),
        },
        {
            field: "mode", headerName: "Mode", flex: 0, width: 350, hide: !columnVisibilityThree.mode, sortable: false, filter: false,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex' }}>
                    <>
                        <Grid >
                            <FormControl size="small" fullWidth>
                                <Select size="small"
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    MenuProps={{
                                        PaperProps: {
                                            style: {
                                                maxHeight: 200,
                                                width: "auto",
                                            },
                                        },
                                    }}
                                    style={{ minWidth: 150, width: '230px' }}
                                    value={rowModeThree[params.data.id]?.mode ? rowModeThree[params.data.id]?.mode : params.data.mode}
                                    onChange={(e) => {
                                        handleActionThree(e.target.value, params.data.id, params.data.serialNumber);
                                    }}
                                    inputProps={{ "aria-label": "Without label" }}
                                >
                                    {modeOption?.map((d) => (
                                        <MenuItem key={d._id} value={d.value}>
                                            {d.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>&ensp;
                        {rowModeThree[params.data.id]?.btnShow &&
                            rowIndexThree === params.data.serialNumber ? (
                            <>
                                <LoadingButton size="small"
                                    sx={{ textTransform: 'capitalize' }}
                                    color='success'
                                    variant="contained"
                                    loading={btnSubmitThree}
                                    onClick={(e) =>
                                        handleUpdateThree(params.data.id, rowModeThree[params.data.id]?.mode,)
                                    }
                                >Apply</LoadingButton>
                            </>
                        ) : null}
                    </>
                </Grid>
            ),
        },
        {
            field: "actions", headerName: "Action", flex: 0, width: 350, hide: !columnVisibilityThree.actions,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex', justifyContent: 'center' }}>
                    <ForwardReasonCellThree
                        rowId={params.data.id}
                        currentForwardReasonThree={forwardReasonsThree[params.data.id] || ""}
                        onSave={(rejectreason2) => {
                            setForwardReasonsThree((prev) => ({
                                ...prev,
                                [params.data.id]: rejectreason2,
                            }));
                        }}
                        setPopupContentMalert={setPopupContentMalert} setPopupSeverityMalert={setPopupSeverityMalert} handleClickOpenPopupMalert={handleClickOpenPopupMalert}
                        setPopupContent={setPopupContent}
                        setPopupSeverity={setPopupSeverity}
                        handleClickOpenPopup={handleClickOpenPopup}
                        auth={auth} fetchAllClient={fetchAllClient} rowData={params.data}
                    />
                </Grid>
            ),
        },
    ];

    // second table
    const columnDataTableFour = [
        { field: "serialNumber", headerName: "SNo", flex: 0, width: 75, hide: !columnVisibilityFour.serialNumber, pinned: 'left', lockPinned: true, },
        { field: "level", headerName: "Level", flex: 0, width: 100, hide: !columnVisibilityFour.level, },
        { field: "vendor", headerName: "Vendor Name", flex: 0, width: 150, hide: !columnVisibilityFour.vendor, },
        { field: "branch", headerName: "Branch Name", flex: 0, width: 150, hide: !columnVisibilityFour.branch, headerClassName: "bold-header", },
        { field: "employeeid", headerName: "Employee Code", flex: 0, width: 150, hide: !columnVisibilityFour.employeeid, },
        { field: "employeename", headerName: "Employee Name", flex: 0, width: 250, hide: !columnVisibilityFour.employeename, },
        { field: "loginid", headerName: "Login id", flex: 0, width: 120, hide: !columnVisibilityFour.loginid, },
        { field: "date", headerName: "Date", flex: 0, width: 120, hide: !columnVisibilityFour.date, headerClassName: "bold-header", },
        { field: "category", headerName: "Category", flex: 0, width: 250, hide: !columnVisibilityFour.category, },
        { field: "subcategory", headerName: "Subcategory", flex: 0, width: 250, hide: !columnVisibilityFour.subcategory, },
        { field: "documentnumber", headerName: "Document Number", flex: 0, width: 150, hide: !columnVisibilityFour.documentnumber, },
        { field: "fieldname", headerName: "Field Name", flex: 0, width: 150, hide: !columnVisibilityFour.fieldname, },
        { field: "line", headerName: "Line", flex: 0, width: 100, hide: !columnVisibilityFour.line, },
        { field: "errorvalue", headerName: "Error Value", flex: 0, width: 250, hide: !columnVisibilityFour.errorvalue, },
        { field: "correctvalue", headerName: "Correct Value", flex: 0, width: 250, hide: !columnVisibilityFour.correctvalue, },
        { field: "clienterror", headerName: "Client Error", flex: 0, width: 250, hide: !columnVisibilityFour.clienterror, },
        { field: "clientamount", headerName: "Client Amount", flex: 0, width: 100, hide: !columnVisibilityFour.clientamount, },
        { field: "percentage", headerName: "per%", flex: 0, width: 100, hide: !columnVisibilityFour.percentage, },
        { field: "amount", headerName: "Amount", flex: 0, width: 100, hide: !columnVisibilityFour.amount, },
        { field: "requestreason", headerName: "Request Reason", flex: 0, width: 250, hide: !columnVisibilityFour.requestreason, cellStyle: { whiteSpace: "pre-wrap", wordWrap: "break-word" }, },
        { field: "forwardreason", headerName: "Forward Reason", flex: 0, width: 250, hide: !columnVisibilityFour.forwardreason, cellStyle: { whiteSpace: "pre-wrap", wordWrap: "break-word" }, },
        {
            field: "actions", headerName: "Action", flex: 0, width: 350, hide: !columnVisibilityFour.actions, sortable: false, filter: false,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex', justifyContent: 'center' }}>
                    <RecheckReasonCellFour
                        rowId={params.data.id}
                        currentRecheckReasonFour={recheckReasonsFour[params.data.id] || ""}
                        onSave={(rejectreason) => {
                            setRecheckReasonsFour((prev) => ({
                                ...prev,
                                [params.data.id]: rejectreason,
                            }));
                        }}
                        setPopupContentMalert={setPopupContentMalert} setPopupSeverityMalert={setPopupSeverityMalert} handleClickOpenPopupMalert={handleClickOpenPopupMalert}
                        setPopupContent={setPopupContent}
                        setPopupSeverity={setPopupSeverity}
                        handleClickOpenPopup={handleClickOpenPopup}
                        auth={auth} fetchAllClient={fetchAllClient} rowData={params.data}
                    />
                </Grid>
            ),
        },
        {
            field: "mode", headerName: "Mode", flex: 0, width: 350, hide: !columnVisibilityFour.mode, sortable: false, filter: false,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex' }}>
                    <>
                        <Grid >
                            <FormControl size="small" fullWidth>
                                <Select size="small"
                                    labelId="demo-select-small"
                                    id="demo-select-small"
                                    MenuProps={{
                                        PaperProps: {
                                            style: {
                                                maxHeight: 200,
                                                width: "auto",
                                            },
                                        },
                                    }}
                                    style={{ minWidth: 150, width: '230px' }}
                                    value={rowModeFour[params.data.id]?.mode ? rowModeFour[params.data.id]?.mode : params.data.mode}
                                    onChange={(e) => {
                                        handleActionFour(e.target.value, params.data.id, params.data.serialNumber);
                                    }}
                                    inputProps={{ "aria-label": "Without label" }}
                                >
                                    {modeOption?.map((d) => (
                                        <MenuItem key={d._id} value={d.value}>
                                            {d.label}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>
                        </Grid>&ensp;
                        {rowModeFour[params.data.id]?.btnShow &&
                            rowIndexFour === params.data.serialNumber ? (
                            <>
                                <LoadingButton size="small"
                                    sx={{ textTransform: 'capitalize' }}
                                    color='success'
                                    variant="contained"
                                    loading={btnSubmitFour}
                                    onClick={(e) =>
                                        handleUpdateFour(params.data.id, rowModeFour[params.data.id]?.mode,)
                                    }
                                >Apply</LoadingButton>
                            </>
                        ) : null}
                    </>
                </Grid>
            ),
        },
        {
            field: "actions", headerName: "Action", flex: 0, width: 350, hide: !columnVisibilityFour.actions,
            cellRenderer: (params) => (
                <Grid sx={{ display: 'flex', justifyContent: 'center' }}>
                    <ForwardReasonCellFour
                        rowId={params.data.id}
                        currentForwardReasonFour={forwardReasonsFour[params.data.id] || ""}
                        onSave={(rejectreason) => {
                            setForwardReasonsFour((prev) => ({
                                ...prev,
                                [params.data.id]: rejectreason,
                            }));
                        }}
                        setPopupContentMalert={setPopupContentMalert} setPopupSeverityMalert={setPopupSeverityMalert} handleClickOpenPopupMalert={handleClickOpenPopupMalert}
                        setPopupContent={setPopupContent}
                        setPopupSeverity={setPopupSeverity}
                        handleClickOpenPopup={handleClickOpenPopup}
                        auth={auth} fetchAllClient={fetchAllClient} rowData={params.data}
                    />
                </Grid>
            ),
        },
    ];

    const rowDataTableThree = filteredDataThree.map((item, index) => {
        return {
            ...item,
        };
    });
    // second Table
    const rowDataTableFour = filteredDataFour.map((item, index) => {
        return {
            ...item,
        };
    });

    // Show All Columns functionality
    const handleShowAllColumnsThree = () => {
        const updatedVisibility = { ...columnVisibilityThree };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityThree(updatedVisibility);
    };

    // Show All Columns functionality second Table
    const handleShowAllColumnsFour = () => {
        const updatedVisibility = { ...columnVisibilityFour };
        for (const columnKey in updatedVisibility) {
            updatedVisibility[columnKey] = true;
        }
        setColumnVisibilityFour(updatedVisibility);
    };

    // Function to filter columns based on search query
    const filteredColumnsThree = columnDataTableThree.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageThree.toLowerCase())
    );

    // Function to filter columns based on search query second Table
    const filteredColumnsFour = columnDataTableFour.filter((column) =>
        column.headerName.toLowerCase().includes(searchQueryManageFour.toLowerCase())
    );

    // Manage Columns functionality
    const toggleColumnVisibilityThree = (field) => {
        setColumnVisibilityThree((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    // Manage Columns functionality secondtable
    const toggleColumnVisibilityFour = (field) => {
        setColumnVisibilityFour((prevVisibility) => ({
            ...prevVisibility,
            [field]: !prevVisibility[field],
        }));
    };

    const [fileFormat, setFormat] = useState("");
    let exportColumnNamesThree = ['Level', 'Ventor Name', 'Branch Name', 'Unit', 'Team', 'Employee Code', 'Employee Name', 'Login id', 'Date', 'Category', 'SubCategory', 'Document Number', 'Field Name',
        'Line', 'Error Value', 'Correct Value', 'Client Error', 'Client Amount', 'per%', 'Amount', 'Request Reason', 'Forward Reason', 'Action', 'Mode', 'Action'];
    let exportRowValuesThree = ['level', 'ventorname', 'branchname', 'unit', 'team', 'employeecode', 'employeename', 'loginid', 'date', 'category', 'subcategory', 'documentnumber', 'fieldname',
        'line', 'errorvalue', 'correctvalue', 'clienterror', 'clientamount', 'per', 'amount', 'requestreason', 'forwardReason', 'action', 'mode', 'action'];

    let exportColumnNamesFour = ['Level', 'Ventor Name', 'Branch Name', 'Unit', 'Team', 'Employee Code', 'Employee Name', 'Login id', 'Date', 'Category', 'SubCategory', 'Document Number', 'Field Name',
        'Line', 'Error Value', 'Correct Value', 'Client Error', 'Client Amount', 'per%', 'Amount', 'Request Reason', 'Forward Reason'];
    let exportRowValuesFour = ['level', 'ventorname', 'branchname', 'unit', 'team', 'employeecode', 'employeename', 'loginid', 'date', 'category', 'subcategory', 'documentnumber', 'fieldname',
        'line', 'errorvalue', 'correctvalue', 'clienterror', 'clientamount', 'per', 'amount', 'requestreason', 'forwardReason'];

    //print...
    const componentRefThree = useRef();
    const handleprintThree = useReactToPrint({
        content: () => componentRefThree.current,
        documentTitle: "Resent Forward Employee Client Error Waiver Request List",
        pageStyle: "print",
    });

    //print...
    const componentRefFour = useRef();
    const handleprintFour = useReactToPrint({
        content: () => componentRefFour.current,
        documentTitle: "Recheck Employee Client Error Waiver Request List",
        pageStyle: "print",
    });

    //image
    const handleCaptureImageThree = () => {
        if (gridRefTableImgThree.current) {
            domtoimage.toBlob(gridRefTableImgThree.current)
                .then((blob) => {
                    saveAs(blob, "Resent Forward Employee Client Error Waiver Request List.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    //image second table
    const handleCaptureImageFour = () => {
        if (gridRefTableImgThree.current) {
            domtoimage.toBlob(gridRefTableImgThree.current)
                .then((blob) => {
                    saveAs(blob, "Recheck Employee Client Error Waiver Request List.png");
                })
                .catch((error) => {
                    console.error("dom-to-image error: ", error);
                });
        }
    };

    return (
        <Box>
            <Headtitle title={"Client Error Forward"} />
            {/* ****** Table Start ****** */}
            {isUserRoleCompare?.includes("lclienterrorforward") && (
                <>
                    <Box sx={userStyle.container}>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid item xs={8}>
                            <Typography sx={userStyle.importheadtext}>Resent Forward Employee Client Error Waiver Request List</Typography>
                        </Grid>
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSizeThree}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeThree}
                                        sx={{ width: "77px" }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={clientErrorsThree?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                <Box>
                                    {isUserRoleCompare?.includes("excelclienterrorforward") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenThree(true); setFormat("xl"); }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("csvclienterrorforward") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenThree(true); setFormat("csv"); }} sx={userStyle.buttongrp}><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("printclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintThree}>&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("pdfclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={() => { setIsPdfFilterOpenThree(true); }}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("imageclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImageThree}><ImageIcon sx={{ fontSize: "15px" }} />{" "} &ensp;Image&ensp;</Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <Box>
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTableThree}
                                        setItems={setItemsThree}
                                        addSerialNumber={addSerialNumberThree}
                                        setPage={setPageThree}
                                        maindatas={clientErrorsThree}
                                        setSearchedString={setSearchedStringThree}
                                        searchQuery={searchQueryThree}
                                        setSearchQuery={setSearchQueryThree}
                                        paginated={false}
                                        totalDatas={clientErrorsThree}
                                    />
                                </Box>
                            </Grid>
                        </Grid><br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsThree}>Show All Columns</Button>&ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsThree}>Manage Columns</Button><br /><br />
                        {loader ? (
                            <>
                                <Box sx={{ display: "flex", justifyContent: "center" }}>
                                    <ThreeDots
                                        height="80"
                                        width="80"
                                        radius="9"
                                        color="#1976d2"
                                        ariaLabel="three-dots-loading"
                                        wrapperStyle={{}}
                                        wrapperClassName=""
                                        visible={true}
                                    />
                                </Box>
                            </>
                        ) : (
                            <>
                                <AggridTable
                                    rowDataTable={rowDataTableThree}
                                    columnDataTable={columnDataTableThree}
                                    columnVisibility={columnVisibilityThree}
                                    page={pageThree}
                                    setPage={setPageThree}
                                    pageSize={pageSizeThree}
                                    totalPages={totalPagesThree}
                                    setColumnVisibility={setColumnVisibilityThree}
                                    isHandleChange={isHandleChangeThree}
                                    items={itemsThree}
                                    selectedRows={selectedRowsThree}
                                    setSelectedRows={setSelectedRowsThree}
                                    gridRefTable={gridRefTableThree}
                                    paginated={false}
                                    filteredDatas={filteredDatasThree}
                                    // totalDatas={totalDatas}
                                    searchQuery={searchedStringThree}
                                    handleShowAllColumns={handleShowAllColumnsThree}
                                    setFilteredRowData={setFilteredRowDataThree}
                                    filteredRowData={filteredRowDataThree}
                                    setFilteredChanges={setFilteredChangesThree}
                                    filteredChanges={filteredChangesThree}
                                    gridRefTableImg={gridRefTableImgThree}
                                    itemsList={clientErrorsThree}
                                    pagenamecheck={'Client Error Forward'}
                                />
                            </>
                        )}
                    </Box><br />
                    {/* Second Tabale  */}
                    <Box sx={userStyle.container}>
                        {/* ******************************************************EXPORT Buttons****************************************************** */}
                        <Grid item xs={8}>
                            <Typography sx={userStyle.importheadtext}>Recheck Employee Client Error Waiver Request List</Typography>
                        </Grid>
                        <Grid container spacing={2} style={userStyle.dataTablestyle}>
                            <Grid item md={2} xs={12} sm={12}>
                                <Box>
                                    <label>Show entries:</label>
                                    <Select
                                        id="pageSizeSelect"
                                        value={pageSizeFour}
                                        MenuProps={{
                                            PaperProps: {
                                                style: {
                                                    maxHeight: 180,
                                                    width: 80,
                                                },
                                            },
                                        }}
                                        onChange={handlePageSizeChangeFour}
                                        sx={{ width: "77px" }}
                                    >
                                        <MenuItem value={1}>1</MenuItem>
                                        <MenuItem value={5}>5</MenuItem>
                                        <MenuItem value={10}>10</MenuItem>
                                        <MenuItem value={25}>25</MenuItem>
                                        <MenuItem value={50}>50</MenuItem>
                                        <MenuItem value={100}>100</MenuItem>
                                        <MenuItem value={clientErrorsFour?.length}>All</MenuItem>
                                    </Select>
                                </Box>
                            </Grid>
                            <Grid item md={8} xs={12} sm={12} sx={{ display: "flex", justifyContent: "center", alignItems: "center", }}>
                                <Box>
                                    {isUserRoleCompare?.includes("excelclienterrorforward") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenFour(true); setFormat("xl"); }} sx={userStyle.buttongrp}><FaFileExcel />&ensp;Export to Excel&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("csvclienterrorforward") && (
                                        <>
                                            <Button onClick={(e) => { setIsFilterOpenFour(true); setFormat("csv"); }} sx={userStyle.buttongrp} ><FaFileCsv />&ensp;Export to CSV&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("printclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleprintFour} >&ensp;<FaPrint />&ensp;Print&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("pdfclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={() => { setIsPdfFilterOpenFour(true); }}><FaFilePdf />&ensp;Export to PDF&ensp;</Button>
                                        </>
                                    )}
                                    {isUserRoleCompare?.includes("imageclienterrorforward") && (
                                        <>
                                            <Button sx={userStyle.buttongrp} onClick={handleCaptureImageFour}><ImageIcon sx={{ fontSize: "15px" }} />{" "}&ensp;Image&ensp;</Button>
                                        </>
                                    )}
                                </Box>
                            </Grid>
                            <Grid item md={2} xs={6} sm={6}>
                                <Box>
                                    <AggregatedSearchBar
                                        columnDataTable={columnDataTableFour}
                                        setItems={setItemsFour}
                                        addSerialNumber={addSerialNumberFour}
                                        setPage={setPageFour}
                                        maindatas={clientErrorsFour}
                                        setSearchedString={setSearchedStringFour}
                                        searchQuery={searchQueryFour}
                                        setSearchQuery={setSearchQueryFour}
                                        paginated={false}
                                        totalDatas={clientErrorsFour}
                                    />
                                </Box>
                            </Grid>
                        </Grid><br />
                        <Button sx={userStyle.buttongrp} onClick={handleShowAllColumnsFour}>Show All Columns</Button>&ensp;
                        <Button sx={userStyle.buttongrp} onClick={handleOpenManageColumnsFour}>Manage Columns</Button><br /><br />
                        {loader ? (
                            <>
                                <Box sx={{ display: "flex", justifyContent: "center" }}>
                                    <ThreeDots
                                        height="80"
                                        width="80"
                                        radius="9"
                                        color="#1976d2"
                                        ariaLabel="three-dots-loading"
                                        wrapperStyle={{}}
                                        wrapperClassName=""
                                        visible={true}
                                    />
                                </Box>
                            </>
                        ) : (
                            <>
                                <AggridTable
                                    rowDataTable={rowDataTableFour}
                                    columnDataTable={columnDataTableFour}
                                    columnVisibility={columnVisibilityFour}
                                    page={pageFour}
                                    setPage={setPageFour}
                                    pageSize={pageSizeFour}
                                    totalPages={totalPagesFour}
                                    setColumnVisibility={setColumnVisibilityFour}
                                    isHandleChange={isHandleChangeFour}
                                    items={itemsFour}
                                    selectedRows={selectedRowsFour}
                                    setSelectedRows={setSelectedRowsFour}
                                    gridRefTable={gridRefTableFour}
                                    paginated={false}
                                    filteredDatas={filteredDatasFour}
                                    // totalDatas={totalDatas}
                                    searchQuery={searchedStringFour}
                                    handleShowAllColumns={handleShowAllColumnsFour}
                                    setFilteredRowData={setFilteredRowDataFour}
                                    filteredRowData={filteredRowDataFour}
                                    setFilteredChanges={setFilteredChangesFour}
                                    filteredChanges={filteredChangesFour}
                                    gridRefTableImg={gridRefTableImgFour}
                                    itemsList={clientErrorsFour}
                                    pagenamecheck={'Client Error Forward'}
                                />
                            </>
                        )}
                    </Box>
                </>
            )}

            {/* Manage Column */}
            <Popover
                id={idThree}
                open={isManageColumnsOpenThree}
                anchorEl={anchorElThree}
                onClose={handleCloseManageColumnsThree}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsThree}
                    searchQuery={searchQueryManageThree}
                    setSearchQuery={setSearchQueryManageThree}
                    filteredColumns={filteredColumnsThree}
                    columnVisibility={columnVisibilityThree}
                    toggleColumnVisibility={toggleColumnVisibilityThree}
                    setColumnVisibility={setColumnVisibilityThree}
                    initialColumnVisibility={initialColumnVisibilityThree}
                    columnDataTable={columnDataTableThree}
                />
            </Popover>

            {/* Manage Column */}
            <Popover
                id={idFour}
                open={isManageColumnsOpenFour}
                anchorEl={anchorElFour}
                onClose={handleCloseManageColumnsFour}
                anchorOrigin={{ vertical: "bottom", horizontal: "left", }}>
                <ManageColumnsContent
                    handleClose={handleCloseManageColumnsFour}
                    searchQuery={searchQueryManageFour}
                    setSearchQuery={setSearchQueryManageFour}
                    filteredColumns={filteredColumnsFour}
                    columnVisibility={initialColumnVisibilityFour}
                    toggleColumnVisibility={toggleColumnVisibilityFour}
                    setColumnVisibility={setColumnVisibilityFour}
                    initialColumnVisibility={initialColumnVisibilityFour}
                    columnDataTable={columnDataTableFour}
                />
            </Popover>

            {/* EXTERNAL COMPONENTS -------------- START */}
            {/* VALIDATION */}
            <MessageAlert
                openPopup={openPopupMalert}
                handleClosePopup={handleClosePopupMalert}
                popupContent={popupContentMalert}
                popupSeverity={popupSeverityMalert}
            />
            {/* SUCCESS */}
            <AlertDialog
                openPopup={openPopup}
                handleClosePopup={handleClosePopup}
                popupContent={popupContent}
                popupSeverity={popupSeverity}
            />
            {/* PRINT PDF EXCEL CSV */}
            <ExportData
                isFilterOpen={isFilterOpenThree}
                handleCloseFilterMod={handleCloseFilterModThree}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenThree}
                isPdfFilterOpen={isPdfFilterOpenThree}
                setIsPdfFilterOpen={setIsPdfFilterOpenThree}
                handleClosePdfFilterMod={handleClosePdfFilterModThree}
                filteredDataTwo={(filteredChangesThree !== null ? filteredRowDataThree : rowDataTableThree) ?? []}
                itemsTwo={clientErrorsThree ?? []}
                filename={"Resent Forward Employee Client Error Waiver Request List"}
                exportColumnNames={exportColumnNamesThree}
                exportRowValues={exportRowValuesThree}
                componentRef={componentRefThree}
            />
            {/* second Table */}
            <ExportData
                isFilterOpen={isFilterOpenFour}
                handleCloseFilterMod={handleCloseFilterModFour}
                fileFormat={fileFormat}
                setIsFilterOpen={setIsFilterOpenFour}
                isPdfFilterOpen={isPdfFilterOpenFour}
                setIsPdfFilterOpen={setIsPdfFilterOpenFour}
                handleClosePdfFilterMod={handleClosePdfFilterModFour}
                filteredDataTwo={(filteredChangesFour !== null ? filteredRowDataFour : rowDataTableFour) ?? []}
                itemsTwo={clientErrorsFour ?? []}
                filename={"Recheck Employee Client Error Waiver Request List"}
                exportColumnNames={exportColumnNamesFour}
                exportRowValues={exportRowValuesFour}
                componentRef={componentRefFour}
            />
            {/* EXTERNAL COMPONENTS -------------- END */}
        </Box>
    );
}

export default ResentForwardEmployee;