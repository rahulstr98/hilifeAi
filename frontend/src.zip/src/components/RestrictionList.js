export const RestrictionList = ["Team Login Allot", 'Task Hierarchy Reports', 'Invalid Error Entry', 'Valid Error Entry',
    'Team Long Absent Restriction List', 'Team Login Status',
    "Team Workstation", 'Team Attendance Status', 'Primary Hierarchy WorkOrder List',
    'Secondary Hierarchy WorkOrder List', 'Tertiary Hierarchy WorkOrder List',
    'Other Hierarchy WorkOrder List',
    'Consolidated(primary/secondary/tertiary) Hierarchy WorkOrder List',
    'Consolidated All Hierarchy WorkOrder List', 'Team Credentials', 'My Actionable Ticket',
    'Training Hierarchy Reports', 'Fix Salary Date', 'Fix Hold Salary Date',
    'Production Manual Entry Filter', "Error Upload Confirm", "Error Invalid Approval", "Error Valid Approval",
    "Waiver Employee Forward", "Approval Employee Waiver", "Client Error Forward", "Client Error Waiver Approval",
    "Hierarchy Remote Employee List", "Team Leave Verification", "Team Permission Verification" , "Hierarchy Approval Employee Documents"
];