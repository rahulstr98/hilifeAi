const Checklisttype = require('../../../model/modules/interview/checklisttype');
const ErrorHandler = require('../../../utils/errorhandler');
// const Task = require('../../../model/modules/project/task');
const catchAsyncErrors = require('../../../middleware/catchAsyncError');

//get All Checklisttype =>/api/Checklisttype
exports.getAllChecklisttype = catchAsyncErrors(async (req, res, next) => {
    let checklisttypes;
    try {
        checklisttypes = await Checklisttype.find({})
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!checklisttypes) {
        return next(new ErrorHandler('Checklisttype not found!', 404));
    }
    return res.status(200).json({
        checklisttypes
    });
})

exports.getAllChecklistByPagination = catchAsyncErrors(async (req, res, next) => {
    const { page, pageSize, allFilters, logicOperator, searchQuery } = req.body;

    let query = {};
    let conditions = [];


    // Advanced search filter
    if (allFilters && allFilters.length > 0) {
        allFilters.forEach(filter => {
            if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
                conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
            }
        });
    }

    if (searchQuery) {
        const searchTermsArray = searchQuery.split(" ");
        const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));

        const orConditions = regexTerms.map((regex) => ({
            $or: [
                { estimation: regex },
                { estimationtime: regex },
                { checklist: regex },
                { category: regex },

                { subcategory: regex },
                { details: regex },
                { information: regex },
                { module: regex },
                { submodule: regex },
                { mainpage: regex },
                { subpage: regex },
                { subsubpage: regex },
            ],
        }));

        query = {
            $and: [
                ...orConditions,
            ],
        };
    }

    // Apply logicOperator to combine conditions
    if (conditions.length > 0) {
        if (logicOperator === "AND") {
            query.$and = conditions;
        } else if (logicOperator === "OR") {
            query.$or = conditions;
        }
    }


    let checklisttypes;
    let totalDatas, paginatedData, isEmptyData, result, overallItems;

    try {
        const totalProjects = await Checklisttype.countDocuments(query);
        const overallitems = await Checklisttype.find({});
        const result = await Checklisttype.find(query)
            .select("")
            .lean()
            .skip((page - 1) * pageSize)
            .limit(parseInt(pageSize))
            .exec();

        res.status(200).json({
            totalProjects,
            result,
            currentPage: page,
            totalPages: Math.ceil(totalProjects / pageSize),
            overallitems
        });
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }

    if (!checklisttypes) {
        return next(new ErrorHandler("Checklists not found", 404));
    }
})



//create new Checklisttype => /api/Checklisttype/new
exports.addChecklisttype = catchAsyncErrors(async (req, res, next) => {
    // let checkmain = await Addexists.findOne({ name: req.body.name });
    // if (checkmain) {
    //     return next(new ErrorHandler('Name already exist!', 400));
    // }
    let aChecklisttype = await Checklisttype.create(req.body);
    return res.status(200).json({
        message: 'Successfully added!'
    });
})

// get Single Checklisttype => /api/Checklisttype/:id
exports.getSingleChecklisttype = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let schecklisttype = await Checklisttype.findById(id);
    if (!schecklisttype) {
        return next(new ErrorHandler('Checklisttype not found', 404));
    }
    return res.status(200).json({
        schecklisttype
    })
})

//update Checklisttype by id => /api/Checklisttype/:id
exports.updateChecklisttype = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let uchecklisttype = await Checklisttype.findByIdAndUpdate(id, req.body);
    if (!uchecklisttype) {
        return next(new ErrorHandler('Checklisttype not found', 404));
    }

    return res.status(200).json({ message: 'Updated successfully' });
})

//delete Checklisttype by id => /api/Checklisttype/:id
exports.deleteChecklisttype = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dchecklisttype = await Checklisttype.findByIdAndRemove(id);
    if (!dchecklisttype) {
        return next(new ErrorHandler('Checklisttype not found', 404));
    }

    return res.status(200).json({ message: 'Deleted successfully' });
})

exports.getAllChecklistNotAssignedByPagination = catchAsyncErrors(async (req, res, next) => {

    const { page, pageSize, allFilters, logicOperator, searchQuery } = req.body;

    let query = {};
    let conditions = [];


    // Advanced search filter
    if (allFilters && allFilters.length > 0) {
        allFilters.forEach(filter => {
            if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
                conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
            }
        });
    }

    if (searchQuery) {
        const searchTermsArray = searchQuery.split(" ");
        const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));

        const orConditions = regexTerms.map((regex) => ({
            $or: [
                { estimation: regex },
                { estimationtime: regex },
                { checklist: regex },
                { category: regex },

                { subcategory: regex },
                { details: regex },
                { information: regex },
                { module: regex },
                { submodule: regex },
                { mainpage: regex },
                { subpage: regex },
                { subsubpage: regex },
            ],
        }));

        query = {
            $and: [
                ...orConditions,
            ],
        };
    }

    // Apply logicOperator to combine conditions
    if (conditions.length > 0) {
        if (logicOperator === "AND") {
            query.$and = conditions;
        } else if (logicOperator === "OR") {
            query.$or = conditions;
        }
    }


    let checklisttypes;

    try {
        const totalProjectsData = await Checklisttype.aggregate([
            { $match: query }, // Apply the same query
            {
                $lookup: {
                    from: 'checklistverificationmasters',
                    let: {
                        currentCategory: "$category",
                        currentSubcategory: "$subcategory",
                        currentChecklist: "$details"
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$categoryname", "$$currentCategory"] },
                                        { $eq: ["$subcategoryname", "$$currentSubcategory"] },
                                        { $in: ["$$currentChecklist", "$checklisttype"] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'result'
                }
            },
            {
                $addFields: {
                    hasResult: { $gt: [{ $size: "$result" }, 0] } // Add 'hasResult' field
                }
            },
            {
                $match: {
                    hasResult: false // Filter for documents where result array is empty
                }
            },
            {
                $count: "total"
            }
        ]);
        const totalProjects = totalProjectsData.length > 0 ? totalProjectsData[0].total : 0;
        checklisttypes = await Checklisttype.aggregate([
            {
                $match: query // Use the dynamic query in the aggregation
            },
            {
                $lookup: {
                    from: 'checklistverificationmasters',
                    let: {
                        currentCategory: "$category",
                        currentSubcategory: "$subcategory",
                        currentChecklist: "$details"
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$categoryname", "$$currentCategory"] },
                                        { $eq: ["$subcategoryname", "$$currentSubcategory"] },
                                        { $in: ["$$currentChecklist", "$checklisttype"] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'result'
                }
            },
            {
                $addFields: {
                    hasResult: { $gt: [{ $size: "$result" }, 0] } // Add 'hasResult' field
                }
            },
            {
                $match: {
                    hasResult: false // Filter for documents where result array is empty
                }
            },
            {
                $skip: (page - 1) * pageSize // Implement pagination
            },
            {
                $limit: pageSize // Set page size
            }
        ]);


        let overallitems = await Checklisttype.aggregate([
            {
                $match: query // Use the dynamic query in the aggregation
            },
            {
                $lookup: {
                    from: 'checklistverificationmasters',
                    let: {
                        currentCategory: "$category",
                        currentSubcategory: "$subcategory",
                        currentChecklist: "$details"
                    },
                    pipeline: [
                        {
                            $match: {
                                $expr: {
                                    $and: [
                                        { $eq: ["$categoryname", "$$currentCategory"] },
                                        { $eq: ["$subcategoryname", "$$currentSubcategory"] },
                                        { $in: ["$$currentChecklist", "$checklisttype"] }
                                    ]
                                }
                            }
                        }
                    ],
                    as: 'result'
                }
            },
            {
                $addFields: {
                    hasResult: { $gt: [{ $size: "$result" }, 0] } // Add 'hasResult' field
                }
            },
            {
                $match: {
                    hasResult: false // Filter for documents where result array is empty
                }
            },
        ]);

        return res.status(200).json({
            result: checklisttypes,
            totalProjects,
            currentPage: page,
            totalPages: Math.ceil(totalProjects / pageSize),
            overallitems

        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }

    if (!checklisttypes) {
        return next(new ErrorHandler("Checklists not found", 404));
    }


})



// Helper function to create filter condition
function createFilterCondition(column, condition, value) {
    switch (condition) {
        case "Contains":
            return { [column]: new RegExp(value, 'i') };
        case "Does Not Contain":
            return { [column]: { $not: new RegExp(value, 'i') } };
        case "Equals":
            return { [column]: value };
        case "Does Not Equal":
            return { [column]: { $ne: value } };
        case "Begins With":
            return { [column]: new RegExp(`^${value}`, 'i') };
        case "Ends With":
            return { [column]: new RegExp(`${value}$`, 'i') };
        case "Blank":
            return { [column]: { $exists: false } };
        case "Not Blank":
            return { [column]: { $exists: true } };
        default:
            return {};
    }
}
