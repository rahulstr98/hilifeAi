const Manageothertask = require('../../../model/modules/othertask/othertask');
const QueueTypeMaster = require('../../../model/modules/production/queuetypemaster');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError');
const ClientUserid = require("../../../model/modules/production/ClientUserIDModel")
const ProductionIndividual = require("../../../model/modules/production/productionindividual")
const Users = require("../../../model/login/auth")

//get All Source =>/api/assignedby
exports.getAllManageothertask = catchAsyncErrors(async (req, res, next) => {
    let manageothertasks;
    try {
        manageothertasks = await Manageothertask.find()
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!manageothertasks) {
        return next(new ErrorHandler('Manageothertask not found!', 404));
    }
    return res.status(200).json({
        manageothertasks
    });
})

exports.getOverallOthertaskSort = catchAsyncErrors(async (req, res, next) => {
    let totalProjects, results, totalProjectsOverall;

    const { page, pageSize, project, category, allFilters, logicOperator, searchQuery, subcategory, assignedby, assignedmode, fromdate, todate, month, year } = req.body;

    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        if (Array.isArray(assignedby) && assignedby.length > 0) {
            query.assignedby = { $in: assignedby };
        }

        if (Array.isArray(assignedmode) && assignedmode.length > 0) {
            query.assignedmode = { $in: assignedmode };
        }
        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }

        // Month and Year filtering
        if ((Array.isArray(month) && month.length > 0) && (Array.isArray(year) && year.length > 0)) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });


            query.$expr = {
                $and: [
                    {
                        $in: [
                            { $month: { $dateFromString: { dateString: '$date' } } },
                            monthIndices
                        ]
                    },
                    {
                        $in: [
                            { $year: { $dateFromString: { dateString: '$date' } } },
                            year
                        ]
                    }
                ]
            }
        } else if (Array.isArray(month) && month.length > 0) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });
            query.$expr = {
                $in: [{ $month: { $dateFromString: { dateString: '$date' } } }, monthIndices]
            };
        } else if (Array.isArray(year) && year.length > 0) {

            query.$expr = {
                $in: [{ $year: { $dateFromString: { dateString: '$date' } } }, year]
            };
        }

        let conditions = [];

        // Advanced search filter
        if (allFilters && allFilters.length > 0) {
            allFilters.forEach(filter => {
                if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
                    conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
                }
            });
        }

        if (searchQuery && searchQuery !== undefined) {
            const searchTermsArray = searchQuery.split(" ");
            const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));

            const orConditions = regexTerms.map((regex) => ({
                $or: [
                    { project: regex },
                    { category: regex },
                    { subcategory: regex },
                    { total: regex },
                    { date: regex },
                    { time: regex },
                    { assignedby: regex },
                    { assignedmode: regex },
                    { ticket: regex },
                    { duedate: regex },
                    { duetime: regex },
                    { estimation: regex },
                    { estimationtime: regex },
                ],
            }));

            query = {
                $and: [
                    query,
                    // {
                    //     $or: assignbranch.map(item => ({
                    //         company: item.company,
                    //         branch: item.branch,
                    //     }))
                    // },
                    ...orConditions,
                ],
            };
        }

        // Apply logicOperator to combine conditions
        if (conditions.length > 0) {
            if (logicOperator === "AND") {
                query.$and = conditions;
            } else if (logicOperator === "OR") {
                query.$or = conditions;
            }
        }

        const isEmpty = Object.keys(query).length === 0;

        totalProjects = isEmpty ? 0 : await Manageothertask.find(query).countDocuments();
        totalProjectsOverall = isEmpty ? 0 : await Manageothertask.find(query)


        results = await Manageothertask.find(query)
            .skip((page - 1) * pageSize)
            .limit(parseInt(pageSize));

        const result = isEmpty ? [] : results;

        return res.status(200).json({
            totalProjects,
            totalProjectsOverall,
            result,
            currentPage: page,
            totalPages: Math.ceil(totalProjects / pageSize),
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
});

exports.getOverallOthertaskCompanySort = catchAsyncErrors(async (req, res, next) => {
    let totalProjects, results, totalProjectsOverall;

    const { page, pageSize, project, searchQuery, category, allFilters, logicOperator, subcategory, assignedby, assignedmode, fromdate, todate, month, year } = req.body;


    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        if (Array.isArray(assignedby) && assignedby.length > 0) {
            query.assignedby = { $in: assignedby };
        }

        if (Array.isArray(assignedmode) && assignedmode.length > 0) {
            query.assignedmode = { $in: assignedmode };
        }
        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }

        // Month and Year filtering
        if ((Array.isArray(month) && month.length > 0) && (Array.isArray(year) && year.length > 0)) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });


            query.$expr = {
                $and: [
                    {
                        $in: [
                            { $month: { $dateFromString: { dateString: '$date' } } },
                            monthIndices
                        ]
                    },
                    {
                        $in: [
                            { $year: { $dateFromString: { dateString: '$date' } } },
                            year
                        ]
                    }
                ]
            }
        } else if (Array.isArray(month) && month.length > 0) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });
            query.$expr = {
                $in: [{ $month: { $dateFromString: { dateString: '$date' } } }, monthIndices]
            };
        } else if (Array.isArray(year) && year.length > 0) {

            query.$expr = {
                $in: [{ $year: { $dateFromString: { dateString: '$date' } } }, year]
            };
        }

        let conditions = [];

        // Advanced search filter
        if (allFilters && allFilters.length > 0) {
            allFilters.forEach(filter => {
                if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
                    conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
                }
            });
        }

        if (searchQuery && searchQuery !== undefined) {
            const searchTermsArray = searchQuery.split(" ");
            const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));

            const orConditions = regexTerms.map((regex) => ({
                $or: [
                    { project: regex },
                    { category: regex },
                    { subcategory: regex },
                    { total: regex },
                    { date: regex },
                    { time: regex },
                    { assignedby: regex },
                    { assignedmode: regex },
                    { ticket: regex },
                    { duedate: regex },
                    { duetime: regex },
                    { estimation: regex },
                    { estimationtime: regex },
                ],
            }));

            query = {
                $and: [
                    query,
                    // {
                    //     $or: assignbranch.map(item => ({
                    //         company: item.company,
                    //         branch: item.branch,
                    //     }))
                    // },
                    ...orConditions,
                ],
            };
        }

        // Apply logicOperator to combine conditions
        if (conditions.length > 0) {
            if (logicOperator === "AND") {
                query.$and = conditions;
            } else if (logicOperator === "OR") {
                query.$or = conditions;
            }
        }

        const isEmpty = Object.keys(query).length === 0;

        totalProjects = isEmpty ? 0 : await Manageothertask.find(query).countDocuments();
        totalProjectsOverall = isEmpty ? 0 : await Manageothertask.find(query)


        results = await Manageothertask.find(query)
            .skip((page - 1) * pageSize)
            .limit(parseInt(pageSize));

        const result = isEmpty ? [] : results;

        return res.status(200).json({
            totalProjects,
            result,
            currentPage: page,
            totalProjectsOverall,
            totalPages: Math.ceil(totalProjects / pageSize),
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
});

exports.getOverallOthertaskEmployeeSort = catchAsyncErrors(async (req, res, next) => {
    let totalProjects, results, totalProjectsOverall;

    const { page, pageSize, project, category, searchQuery, allFilters, logicOperator, subcategory, assignedby, assignedmode, fromdate, todate, month, year } = req.body;

    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        if (Array.isArray(assignedby) && assignedby.length > 0) {
            query.assignedby = { $in: assignedby };
        }

        if (Array.isArray(assignedmode) && assignedmode.length > 0) {
            query.assignedmode = { $in: assignedmode };
        }

        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }

        // Month and Year filtering
        if ((Array.isArray(month) && month.length > 0) && (Array.isArray(year) && year.length > 0)) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });


            query.$expr = {
                $and: [
                    {
                        $in: [
                            { $month: { $dateFromString: { dateString: '$date' } } },
                            monthIndices
                        ]
                    },
                    {
                        $in: [
                            { $year: { $dateFromString: { dateString: '$date' } } },
                            year
                        ]
                    }
                ]
            }
        } else if (Array.isArray(month) && month.length > 0) {
            const monthIndices = month.map(m => {
                // Convert month name to its index
                const date = new Date(`${m} 01, 2000`);
                return date.getMonth() + 1; // Months are 0-indexed, so add 1
            });
            query.$expr = {
                $in: [{ $month: { $dateFromString: { dateString: '$date' } } }, monthIndices]
            };
        } else if (Array.isArray(year) && year.length > 0) {

            query.$expr = {
                $in: [{ $year: { $dateFromString: { dateString: '$date' } } }, year]
            };
        }

        let conditions = [];

        // Advanced search filter
        if (allFilters && allFilters.length > 0) {
            allFilters.forEach(filter => {
                if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
                    conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
                }
            });
        }

        if (searchQuery && searchQuery !== undefined) {
            const searchTermsArray = searchQuery.split(" ");
            const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));

            const orConditions = regexTerms.map((regex) => ({
                $or: [
                    { project: regex },
                    { category: regex },
                    { subcategory: regex },
                    { total: regex },
                    { date: regex },
                    { time: regex },
                    { assignedby: regex },
                    { assignedmode: regex },
                    { ticket: regex },
                    { duedate: regex },
                    { duetime: regex },
                    { estimation: regex },
                    { estimationtime: regex },
                ],
            }));

            query = {
                $and: [
                    query,
                    // {
                    //     $or: assignbranch.map(item => ({
                    //         company: item.company,
                    //         branch: item.branch,
                    //     }))
                    // },
                    ...orConditions,
                ],
            };
        }

        // Apply logicOperator to combine conditions
        if (conditions.length > 0) {
            if (logicOperator === "AND") {
                query.$and = conditions;
            } else if (logicOperator === "OR") {
                query.$or = conditions;
            }
        }

        const isEmpty = Object.keys(query).length === 0;

        totalProjects = isEmpty ? 0 : await Manageothertask.find(query).countDocuments();
        totalProjectsOverall = isEmpty ? 0 : await Manageothertask.find(query)


        results = await Manageothertask.find(query)
            .skip((page - 1) * pageSize)
            .limit(parseInt(pageSize));

        const result = isEmpty ? [] : results;

        return res.status(200).json({
            totalProjects,
            result,
            currentPage: page,
            totalProjectsOverall,
            totalPages: Math.ceil(totalProjects / pageSize),
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
});






//create new assignedby => /api/Manageothertask/new
exports.addManageothertask = catchAsyncErrors(async (req, res, next) => {


    let aManageothertask = await Manageothertask.create(req.body);
    return res.status(200).json({
        message: 'Successfully added!'
    });
})

// get Single Manageothertask => /api/Manageothertask/:id
exports.getSingleManageothertask = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let smanageothertask = await Manageothertask.findById(id);
    if (!smanageothertask) {
        return next(new ErrorHandler('Manageothertask not found', 404));
    }
    return res.status(200).json({
        smanageothertask
    })
})

//update Manageothertask by id => /api/Manageothertask/:id
exports.updateManageothertask = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let umanageothertask = await Manageothertask.findByIdAndUpdate(id, req.body);
    if (!umanageothertask) {
        return next(new ErrorHandler('Manageothertask not found', 404));
    }

    return res.status(200).json({ message: 'Updated successfully' });
})

//delete Manageothertask by id => /api/Manageothertask/:id
exports.deleteManageothertask = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dmanageothertask = await Manageothertask.findByIdAndRemove(id);
    if (!dmanageothertask) {
        return next(new ErrorHandler('Manageothertask not found', 404));
    }

    return res.status(200).json({ message: 'Deleted successfully' });
})

// get All result => /api/results
exports.getOverallOthertaskSortFlag = catchAsyncErrors(async (req, res, next) => {
    let result;
    const { project, category, subcategory, fromdate, todate } = req.body;
    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }

        const isEmpty = Object.keys(query).length === 0;

        let productionunmatched = await Manageothertask.find(query, { project: 1, category: 1, subcategory: 1, date: 1, total: 1 }).lean();

        const unitRates = await ProductionIndividual.find({}, { vendor: 1, fromdate: 1, time: 1, category: 1, filename: 1, flagcount: 1 }).lean();

        // const unitRateMap = new Map(unitRates.map((item) => [item.vendor.split('-')[0] + "-" + item.filename + "-" + item.category, item]));
        const unitRateMap = new Map();

        unitRates.forEach((item) => {
            const key = item.fromdate + "-" + item.vendor.split('-')[0] + "-" + item.filename + "-" + item.category;
            if (!unitRateMap.has(key)) {
                unitRateMap.set(key, []);
            }
            unitRateMap.get(key).push(item);
        });

        result = productionunmatched.reduce((acc, obj) => {
            const matchUnitrate = unitRateMap.get(obj.date + "-" + obj.project + "-" + obj.category + "-" + obj.subcategory);

            // If matchUnitrate is an array, sum up the flagcounts
            const manualflagcount = matchUnitrate
                ? Array.isArray(matchUnitrate)
                    ? matchUnitrate.reduce((sum, item) => sum + Number(item.flagcount), 0)
                    : Number(matchUnitrate.flagcount)
                : 0;

            const finalflagcount = obj.total ? Number(obj.total) : 0;
            const diffflagcount = finalflagcount - manualflagcount;

            let status = '';
            if (manualflagcount === finalflagcount) {
                status = 'Reached';
            }

            else if (manualflagcount < finalflagcount) {
                status = 'Not Reached';
            }
            
            else if (manualflagcount > finalflagcount) {
                status = 'Not Reached';
            }

            acc.push({
                _id: obj._id,
                project: obj.project,
                category: obj.category,
                subcategory: obj.subcategory,
                diffflagcount: diffflagcount,
                total: obj.total,
                date: obj.date,
                manualflagcount: manualflagcount,
                status: status,
            });

            return acc;
        }, []);

    } catch (err) {
        return next(new ErrorHandler("Data not found", 404));
    }

    return res.status(200).json({
        result,
    });
});


//view all
exports.getOverallOthertaskView = catchAsyncErrors(async (req, res, next) => {
    let productionupload, mergedData, mergedDataall;
    try {
        // producionIndividual = await ProducionIndividual.find({}, {});
        let loginids = await ClientUserid.find({ loginallotlog: { $exists: true, $ne: [] } }, { empname: 1, userid: 1, loginallotlog: 1 }).lean();
        let users = await Users.find({}, { companyname: 1, empcode: 1, company: 1, unit: 1, branch: 1, team: 1, username: 1, processlog: 1, shifttiming: 1, department: 1, doj: 1, assignExpLog: 1, shiftallot: 1, boardingLog: 1 });


        let query = {
            vendor: new RegExp("^" + req.body.project),
            filename: { $in: req.body.category },
            category: { $in: req.body.subcategory },
            fromdate: { $in: req.body.fromdate },
        }
        productionupload = await ProductionIndividual.find(query, {
            vendor: 1, fromdate: 1, category: 1, filename: 1, flagcount: 1,
            unitid: 1, user: 1, alllogin: 1, section: 1, approvalstatus: 1, lateentrystatus: 1, time: 1, createdAt: 1

        });


        let mergedDataallfirst = productionupload.map((upload) => {
            const loginInfo = loginids.find((login) => login.userid === upload.user);
            let loginallot = loginInfo && loginInfo.loginallotlog ? loginInfo.loginallotlog : [];
            let filteredDataDateTime = null;
            if (loginallot.length > 0) {
                const groupedByDateTime = {};

                // Group items by date and time
                loginallot.forEach((item) => {
                    const dateTime = item.date + " " + item.time; // Assuming item.updatetime contains time in HH:mm format
                    if (!groupedByDateTime[dateTime]) {
                        groupedByDateTime[dateTime] = [];
                    }
                    groupedByDateTime[dateTime].push(item);
                });
                // Extract the last item of each group
                const lastItemsForEachDateTime = Object.values(groupedByDateTime).map((group) => group[group.length - 1]);

                // Sort the last items by date and time
                lastItemsForEachDateTime.sort((a, b) => {
                    return new Date(a.date + " " + a.time) - new Date(b.date + " " + b.time);
                });
                // Find the first item in the sorted array that meets the criteria

                for (let i = 0; i < lastItemsForEachDateTime.length; i++) {
                    const dateTime = lastItemsForEachDateTime[i].date + " " + lastItemsForEachDateTime[i].time;
                    // let datevalsplit = upload.mode == "Manual" ? upload.fromdate : upload.dateval.split(" ");
                    let datevalsplitfinal = upload.fromdate + " " + upload.time + ":00"
                    
                    /////
                    const datevalsplitfinalFormatted = datevalsplitfinal.replace(" PM:00", " PM"); // Remove ":00"
                    const parsedDatevalsplitfinal = new Date(datevalsplitfinalFormatted);
                    // Parse `dateTime`
                    const parsedDateTime = new Date(dateTime);
                    /////
                    
                    if (parsedDateTime <= parsedDatevalsplitfinal) {
                        filteredDataDateTime = lastItemsForEachDateTime[i];
                    } else {
                        break; // Break the loop if we encounter an item with date and time greater than or equal to selectedDateTime
                    }
                }
            }
            // const userInfo = loginInfo ? users.find(user => user.companyname === loginInfo.empname) : "";


            let logininfoname = loginallot.length > 0 ? filteredDataDateTime.empname : loginInfo ? loginInfo.empname : "";
            const userInfo = loginInfo ? users.find((user) => user.companyname === logininfoname) : "";
            // const userArray = loginInfo ? users.filter((user) => user.companyname === logininfoname) : "";
            return {
                user: upload.user,
                fromdate: upload.fromdate,
                todate: upload.todate,
                vendor: upload.vendor,
                category: upload.category,
                // dateval: upload.mode === "Manual" ? `${upload.fromdate} ${upload.time}:00` : upload.dateval.split(" IST")[0],
                // dateval: upload.mode === "Manual" ? `${upload.fromdate} ${upload.time}:00` : upload.dateval.split(" IST")[0],
                // olddateval: upload.mode === "Manual" ? `${upload.fromdate}T${upload.time}:00` : `${upload.dateval.split(" IST")[0]}T${upload.dateval.split(" ")[1]}`,
                createdAt: upload.createdAt,
                time: upload.time,
                filename: upload.filename,
                empname: loginInfo && loginInfo.empname,
                empcode: userInfo && userInfo.empcode,
                company: userInfo && userInfo.company,
                unit: userInfo && userInfo.unit,
                branch: userInfo && userInfo.branch,
                team: userInfo && userInfo.team,

                username: userInfo && userInfo.username,
                _id: upload._id,

                section: upload.section,
                csection: upload.updatedsection ? upload.updatedsection : "",
                flagcount: upload.flagcount,
                cflagcount: upload.updatedflag ? upload.updatedflag : "",
                lateentrystatus: upload.lateentrystatus,
                approvalstatus: upload.approvalstatus,
                unitid: upload.unitid,
                filename: upload.filename,
                points: Number(upload.unitrate) * 8.333333333333333,
                cpoints: upload.updatedunitrate ? Number(upload.updatedunitrate) * 8.333333333333333 : "",
                unitrate: Number(upload.unitrate),
                cunitrate: upload.updatedunitrate ? Number(upload.updatedunitrate) : "",
            };

        });
        mergedDataall = mergedDataallfirst.map(curr => {
            return {
                vendor: curr.vendor, // Include section
                category: curr.category,
                filename: curr.filename,
                fromdate: curr.fromdate,
                flagcount: curr.flagcount,
                unitid: curr.unitid,
                user: curr.user,
                alllogin: curr.alllogin,
                section: curr.section,
                approvalstatus: curr.approvalstatus,
                lateentrystatus: curr.lateentrystatus,
                time: curr.time,
                empname: curr.empname,
                empcode: curr.empcode,
                company: curr.company,
                unit: curr.unit,
                branch: curr.branch,
                team: curr.team,
                unitrate: curr.unitrate,
                points: curr.points,
                points: curr.points,
                createdAt: curr.createdAt,
                _id: curr._id,
            };

        });

        mergedData = mergedDataall.filter(item => item != null)
    } catch (err) {
        return next(new ErrorHandler("Data not found", 404));
    }
    if (!productionupload) {
        return next(new ErrorHandler("Data not found!", 404));
    }
    return res.status(200).json({
        // count: products.length,
        mergedData,
    });
});

// Helper function to create filter condition
function createFilterCondition(column, condition, value) {
    switch (condition) {
        case "Contains":
            return { [column]: new RegExp(value, 'i') };
        case "Does Not Contain":
            return { [column]: { $not: new RegExp(value, 'i') } };
        case "Equals":
            return { [column]: value };
        case "Does Not Equal":
            return { [column]: { $ne: value } };
        case "Begins With":
            return { [column]: new RegExp(`^${value}`, 'i') };
        case "Ends With":
            return { [column]: new RegExp(`${value}$`, 'i') };
        case "Blank":
            return { [column]: { $exists: false } };
        case "Not Blank":
            return { [column]: { $exists: true } };
        default:
            return {};
    }
}


//othertaskconsolidatedreport
exports.getOverallOthertaskConsolidatedReport = catchAsyncErrors(async (req, res, next) => {
    let result, Queuetypemaster;
    const { project, category, subcategory, fromdate, todate } = req.body;
    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }


        // let productionunmatched = await Manageothertask.find(query, { project: 1, category: 1, subcategory: 1, date: 1, total: 1 }).lean();
        // let Queuetypemaster = await QueueTypeMaster.find({}, { category: 1, subcategory: 1, newrate: 1 }).lean();
        // const QueuetypeMap = new Map(Queuetypemaster.map((item) => [item.category + "-" + item.subcategory, item]));

        // result = productionunmatched.reduce((acc, current) => {
        //     const matchQueuetype = QueuetypeMap.get(current.category + "-" + current.subcategory);
        //     const newrateval = matchQueuetype ? Number(matchQueuetype.newrate) : 0;
        //     const existingItemIndex = acc.findIndex((d) => {
        //         // console.log(d.date, current.date, d.project, current.project, d.category, current.category, d.subcategory, current.subcategory, "condition");
        //         return (
        //             d.date === current.date &&
        //             d.project === current.project &&
        //             d.category === current.category &&
        //             d.subcategory === current.subcategory
        //         );
        //     });

        //     if (existingItemIndex !== -1) {
        //         // Update existing item
        //         const existingItem = acc[existingItemIndex];

        //         existingItem.total += Number(current.total);
        //         existingItem.newrate = newrateval;
        //     } else {
        //         // Add new item

        //         acc.push({
        //             _id: current._id,
        //             project: current.project,
        //             category: current.category,
        //             subcategory: current.subcategory,
        //             total: Number(current.total),
        //             newrate: newrateval,
        //             date: current.date,
        //         });
        //     }
        //     return acc;
        // }, []);

        let productionunmatched = await Manageothertask.find(query, { project: 1, category: 1, subcategory: 1, date: 1, total: 1 }).lean();
        let Queuetypemaster = await QueueTypeMaster.find({ type: "Other task queues" }, { category: 1, subcategory: 1, newrate: 1 }).lean();

        const QueuetypeMap = new Map(Queuetypemaster.map((item) => [item.category + "-" + item.subcategory, item]));

        result = productionunmatched.reduce((accumulator, currentEntry) => {
            const matchQueuetype = QueuetypeMap.get(`${currentEntry.category}-${currentEntry.subcategory}`);
            const newrateValue = matchQueuetype ? Number(matchQueuetype.newrate) : 0;

            const existingIndex = accumulator.findIndex((existingEntry) =>
                existingEntry.date === currentEntry.date &&
                existingEntry.project === currentEntry.project &&
                existingEntry.category === currentEntry.category &&
                existingEntry.subcategory === currentEntry.subcategory
            );

            if (existingIndex !== -1) {
                // Update existing entry
                accumulator[existingIndex].total += Number(currentEntry.total);
                accumulator[existingIndex].newrate = newrateValue;
                accumulator[existingIndex].totalnew += newrateValue * Number(currentEntry.total);
            } else {
                // Add new entry
                accumulator.push({
                    _id: currentEntry._id,
                    project: currentEntry.project,
                    category: currentEntry.category,
                    subcategory: currentEntry.subcategory,
                    total: Number(currentEntry.total),
                    newrate: newrateValue,
                    date: currentEntry.date,
                    totalnew: (newrateValue * Number(currentEntry.total))
                });
            }

            return accumulator;
        }, []);
        console.log(result[1], "asdrfe")


    } catch (err) {
        console.log(err.message);
    }

    return res.status(200).json({
        result,
    });
});


//individualconsolidatedreport
exports.getOverallOthertaskIndividualReport = catchAsyncErrors(async (req, res, next) => {
    let result, Queuetypemaster;
    const { project, category, subcategory, fromdate, todate } = req.body;
    try {
        let query = {};

        // Apply filters for other fields
        if (Array.isArray(project) && project.length > 0) {
            query.project = { $in: project };
        }

        if (Array.isArray(category) && category.length > 0) {
            query.category = { $in: category };
        }

        if (Array.isArray(subcategory) && subcategory.length > 0) {
            query.subcategory = { $in: subcategory };
        }

        // Date filtering
        if (fromdate && todate) {
            const fromDateObj = fromdate;
            const toDateObj = todate;

            query.date = {
                $gte: fromDateObj,
                $lte: toDateObj,
            };
        } else if (fromdate) {
            const fromDateObj = fromdate;
            query.date = {
                $gte: fromDateObj,
            };
        } else if (todate) {
            const toDateObj = todate;
            query.date = {
                $lte: toDateObj,
            };
        }


        let productionunmatched = await Manageothertask.find(query, { project: 1, category: 1, subcategory: 1, date: 1, total: 1 }).lean();
        let Queuetypemaster = await QueueTypeMaster.find({ type: "Other task queues" }, { category: 1, subcategory: 1, newrate: 1 }).lean();

        const QueuetypeMap = new Map(Queuetypemaster.map((item) => [item.category + "-" + item.subcategory, item]));

        result = productionunmatched.map((item, index) => {
            const matchQueuetype = QueuetypeMap.get(`${item.category}-${item.subcategory}`);
            const newrateValue = matchQueuetype ? Number(matchQueuetype.newrate) : 0;

            return {
                _id: item._id,
                project: item.project,
                category: item.category,
                subcategory: item.subcategory,
                total: Number(item.total),
                newrate: newrateValue,
                date: item.date,
                totalnew: (newrateValue * Number(item.total))
            }
        });


        console.log(result[1], "indivu")


    } catch (err) {
        console.log(err.message);
    }

    return res.status(200).json({
        result,
    });
});
