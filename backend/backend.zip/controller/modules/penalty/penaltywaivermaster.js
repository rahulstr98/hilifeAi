const Penaltywaivermaster = require("../../../model/modules/penalty/penaltywaivermaster");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");
const moment = require("moment");

// get All Penaltywaivermaster => /api/Penaltywaivermaster
exports.getAllPenaltywaivermaster = catchAsyncErrors(async (req, res, next) => {
    let penaltywaivermasters;
    try {
        penaltywaivermasters = await Penaltywaivermaster.find();
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!penaltywaivermasters) {
        return next(new ErrorHandler("Penaltywaivermaster not found!", 404));
    }
    return res.status(200).json({
        // count: products.length,
        penaltywaivermasters,
    });
});

// Create new Penaltywaivermaster=> /api/Penaltywaivermaster/new
exports.addPenaltywaivermaster = catchAsyncErrors(async (req, res, next) => {
    let aPenaltywaivermaster = await Penaltywaivermaster.create(req.body);

    return res.status(200).json({
        message: "Successfully added!",
    });
});

// get Signle Penaltywaivermaster => /api/Penaltywaivermaster/:id
exports.getSinglePenaltywaivermaster = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;

    let spenaltywaivermaster = await Penaltywaivermaster.findById(id);

    if (!spenaltywaivermaster) {
        return next(new ErrorHandler("Penaltywaivermaster not found!", 404));
    }
    return res.status(200).json({
        spenaltywaivermaster,
    });
});

// update Penaltywaivermaster by id => /api/Penaltywaivermaster/:id
exports.updatePenaltywaivermaster = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let upenaltywaivermaster = await Penaltywaivermaster.findByIdAndUpdate(id, req.body);
    if (!upenaltywaivermaster) {
        return next(new ErrorHandler("Penaltywaivermaster not found!", 404));
    }
    return res.status(200).json({ message: "Updated successfully" });
});

// delete Penaltywaivermaster by id => /api/Penaltywaivermaster/:id
exports.deletePenaltywaivermaster = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;

    let dpenaltywaivermaster = await Penaltywaivermaster.findByIdAndRemove(id);

    if (!dpenaltywaivermaster) {
        return next(new ErrorHandler("Penaltywaivermaster not found!", 404));
    }
    return res.status(200).json({ message: "Deleted successfully" });
});




