const PenaltyErrorUploadpoints = require("../../../model/modules/penalty/penaltyerrorupload");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");

// get All PenaltyErrorUploadpoints => /api/PenaltyErrorUploadpoints
exports.getAllPenaltyerroruploadpoints = catchAsyncErrors(async (req, res, next) => {
  let penaltyerroruploadpoints;
  try {
    penaltyerroruploadpoints = await PenaltyErrorUploadpoints.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!penaltyerroruploadpoints) {
    return next(new ErrorHandler("PenaltyErrorUploadpoints not found!", 404));
  }
  return res.status(200).json({
    // count: products.length,
    penaltyerroruploadpoints,
  });
});

// Create new PenaltyErrorUploadpoints=> /api/PenaltyErrorUploadpoints/new
exports.addPenaltyerroruploadpoints = catchAsyncErrors(async (req, res, next) => {
  let apenaltyerroruploadpoints = await PenaltyErrorUploadpoints.create(req.body);

  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Signle penaltyerroruploadpoints => /api/penaltyerroruploadpoints/:id
exports.getSinglePenaltyerroruploadpoints = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let spenaltyerroruploadpoints = await PenaltyErrorUploadpoints.findById(id);

  if (!spenaltyerroruploadpoints) {
    return next(new ErrorHandler("PenaltyErrorUploadpoints not found!", 404));
  }
  return res.status(200).json({
    spenaltyerroruploadpoints,
  });
});

// update penaltyerroruploadpoints by id => /api/penaltyerroruploadpoints/:id
exports.updatePenaltyerroruploadpoints = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let upenaltyerroruploadpoints = await PenaltyErrorUploadpoints.findByIdAndUpdate(id, req.body);
  if (!upenaltyerroruploadpoints) {
    return next(new ErrorHandler("PenaltyErrorUploadpoints not found!", 404));
  }
  return res.status(200).json({ message: "Updated successfully" });
});

// delete penaltyerroruploadpoints by id => /api/penaltyerroruploadpoints/:id
exports.deletePenaltyerroruploadpoints = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;

  let dpenaltyerroruploadpoints = await PenaltyErrorUploadpoints.findByIdAndRemove(id);

  if (!dpenaltyerroruploadpoints) {
    return next(new ErrorHandler("PenaltyErrorUploadpoints not found!", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});


exports.deleteMultiplePenaltyErrorUpload = catchAsyncErrors(
  async (req, res, next) => {
    const ids = req.body.ids;
    if (!Array.isArray(ids) || ids.length === 0) {
      return next(new ErrorHandler("Invalid IDs provided", 400));
    }

    // Define a batch size for deletion
    // const batchSize = Math.ceil(ids.length / 10);
    const batchSize = 10000;

    // Loop through IDs in batches
    for (let i = 0; i < ids.length; i += batchSize) {
      const batchIds = ids.slice(i, i + batchSize);

      // Delete records in the current batch
      await PenaltyErrorUploadpoints.deleteMany({ _id: { $in: batchIds } });
    }

    return res
      .status(200)
      .json({ message: "Deleted successfully", success: true });
  }
);

exports.getAllPenaltyerroruploadpointsDateFilter = catchAsyncErrors(async (req, res, next) => {
  const { fromdate, todate } = req.body;
  let penaltyerroruploadpoints;
  try {
    penaltyerroruploadpoints = await PenaltyErrorUploadpoints.find({ date: { $gte: fromdate, $lte: todate } });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!penaltyerroruploadpoints) {
    return next(new ErrorHandler("PenaltyErrorUploadpoints not found!", 404));
  }
  return res.status(200).json({
    penaltyerroruploadpoints,
  });
});

exports.getAllPenaltyerroruploadpointsProjectBasedFilter = catchAsyncErrors(async (req, res, next) => {
  let penaltyerroruploadpoints;
  try {
    const { projectvendor, process, loginid } = req.body;
    let query = {};

    if (projectvendor && projectvendor.length > 0) {
      query.projectvendor = { $in: projectvendor };
    }

    if (process && process.length > 0) {
      query.process = { $in: process };
    }

    if (loginid && loginid.length > 0) {
      query.loginid = { $in: loginid };
    }

    penaltyerroruploadpoints = await PenaltyErrorUploadpoints.find(query);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!penaltyerroruploadpoints) {
    return next(new ErrorHandler('Ebreadingdetails not found!', 404));
  }
  return res.status(200).json({
    penaltyerroruploadpoints
  });
})