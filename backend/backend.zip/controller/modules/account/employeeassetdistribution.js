const Employeeasset = require("../../../model/modules/account/employeeassetdistribution");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");


function createFilterCondition(column, condition, value) {
  switch (condition) {
    case "Contains":
      return { [column]: new RegExp(value, 'i') };
    case "Does Not Contain":
      return { [column]: { $not: new RegExp(value, 'i') } };
    case "Equals":
      return { [column]: value };
    case "Does Not Equal":
      return { [column]: { $ne: value } };
    case "Begins With":
      return { [column]: new RegExp(`^${value}`, 'i') };
    case "Ends With":
      return { [column]: new RegExp(`${value}$`, 'i') };
    case "Blank":
      return { [column]: { $exists: false } };
    case "Not Blank":
      return { [column]: { $exists: true } };
    default:
      return {};
  }
}

//get All Employeeasset =>/api/Employeeasset
exports.getAllEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  let employeeassets;
  try {
    employeeassets = await Employeeasset.find();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!employeeassets) {
    return next(new ErrorHandler("Employeeasset not found!", 404));
  }
  return res.status(200).json({
    employeeassets,
  });
});

// exports.getAllEmployeeassetAccess = catchAsyncErrors(async (req, res, next) => {
//   let employeeassets;
//   try {
//     const { assignbranch } = req.body;
//     let filterQuery = {};
//     // Construct the filter query based on the assignbranch array
//     const branchFilter = assignbranch.map((branchObj) => ({
//       branch: branchObj.branch,
//       company: branchObj.company,
//       unit: branchObj.unit,
//     }));
//     const branchFilterTo = assignbranch.map((branchObj) => ({
//       branchto: branchObj.branch,
//       companyto: branchObj.company,
//       unitto: branchObj.unit,
//     }));

//     if (branchFilter.length > 0 || branchFilterTo.length > 0) {
//       filterQuery = {
//         $or: [...branchFilter, ...branchFilterTo],
//       };
//     }
//     employeeassets = await Employeeasset.find(filterQuery);
//   } catch (err) {
//     return next(new ErrorHandler("Records not found!", 404));
//   }
//   if (!employeeassets) {
//     return next(new ErrorHandler("Employeeasset not found!", 404));
//   }
//   return res.status(200).json({
//     employeeassets,
//   });
// });


exports.getAllEmployeeassetAccess = catchAsyncErrors(async (req, res, next) => {
  const { page, pageSize, assignbranch, allFilters, logicOperator, searchQuery } = req.body;

  let query = {};
  // Construct the filter query based on the assignbranch array
  const branchFilter = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));
  const branchFilterTo = assignbranch.map((branchObj) => ({
    branchto: branchObj.branch,
    companyto: branchObj.company,
    unitto: branchObj.unit,
  }));

  query = { $or: [...branchFilter, ...branchFilterTo] };

  let queryoverall = {};
  // Construct the filter query based on the assignbranch array
  const branchFilterOverall = assignbranch.map((branchObj) => ({
    branch: branchObj.branch,
    company: branchObj.company,
    unit: branchObj.unit,
  }));
  const branchFilterToOverall = assignbranch.map((branchObj) => ({
    branchto: branchObj.branch,
    companyto: branchObj.company,
    unitto: branchObj.unit,
  }));

  queryoverall = { $or: [...branchFilterOverall, ...branchFilterToOverall] };

  let conditions = [];

  // Advanced search filter
  if (allFilters && allFilters.length > 0) {
    allFilters.forEach(filter => {
      console.log(filter, "filter")
      if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
        if (filter.column == "assigndate") {
          const [day, month, year] = filter.value.split("/")
          let formattedValue = `${year}-${month}-${day}`
          conditions.push(createFilterCondition(filter.column, filter.condition, formattedValue));
        }
        else {

          conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
        }
      }
    });
  }

  if (searchQuery && searchQuery !== undefined) {
    const searchTermsArray = searchQuery.split(" ");
    const regexTerms = searchTermsArray.map((term) => {

      // Check if the term is in the date format DD/MM/YYYY
      const dateRegex = /^\d{2}\/\d{2}\/\d{4}$/;
      if (dateRegex.test(term)) {
        // Convert DD/MM/YYYY to YYYY-MM-DD
        const [day, month, year] = term.split("/");
        const formattedDate = `${year}-${month}-${day}`;
        return new RegExp(formattedDate, "i");
      }
      return new RegExp(term, "i");
    });
    // console.log(regexTerms, "regexTerms")
    const orConditions = regexTerms.map((regex) => ({
      $or: [
        { company: regex },
        { branch: regex },
        { unit: regex },
        { floor: regex },
        { area: regex },
        { location: regex },
        { assetmaterial: regex },
        { subcomponents: regex },
        { assigntime: regex },
        { assigndate: regex },
        { companyto: regex },
        { branchto: regex },
        { unitto: regex },
        { teamto: regex },
        { employeenameto: regex },
      ],

    }));
    // console.log(searchQuery, "searchQuery")
    query = {
      $and: [

        { $or: [...branchFilterOverall, ...branchFilterToOverall] },

        ...orConditions,
      ],
    };
  }


  // console.log(query, "query")

  // Apply logicOperator to combine conditions
  if (conditions.length > 0) {
    if (logicOperator === "AND") {
      query.$and = conditions;
    } else if (logicOperator === "OR") {
      query.$or = conditions;
    }
  }
  // console.log(conditions, "conditions")
  try {

    const totalProjects = await Employeeasset.countDocuments(query);

    const totalProjectsData = await Employeeasset.find(queryoverall);

    const result = await Employeeasset.find(query)
      .select("")
      .lean()
      .skip((page - 1) * pageSize)
      .limit(parseInt(pageSize))
      .exec();
    // console.log(result.length, 'result')
    res.status(200).json({
      totalProjects,
      totalProjectsData,
      result,
      currentPage: page,
      totalPages: Math.ceil(totalProjects / pageSize),
    });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
});

//create new Employeeasset => /api/Employeeasset/new
exports.addEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  // let checkmain = await Addexists.findOne({ name: req.body.name });
  // if (checkmain) {
  //     return next(new ErrorHandler('Name already exist!', 400));
  // }
  let aEmployeeasset = await Employeeasset.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Single Employeeasset => /api/Employeeasset/:id
exports.getSingleEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let semployeeasset = await Employeeasset.findById(id);
  if (!semployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }
  return res.status(200).json({
    semployeeasset,
  });
});

//update Employeeasset by id => /api/Employeeasset/:id
exports.updateEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let uemployeeasset = await Employeeasset.findByIdAndUpdate(id, req.body);
  if (!uemployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }

  return res.status(200).json({ message: "Updated successfully" });
});

//delete Employeeasset by id => /api/Employeeasset/:id
exports.deleteEmployeeasset = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let demployeeasset = await Employeeasset.findByIdAndRemove(id);
  if (!demployeeasset) {
    return next(new ErrorHandler("Employeeasset not found", 404));
  }

  return res.status(200).json({ message: "Deleted successfully" });
});

exports.getAllEmployeeassetAccessHome = catchAsyncErrors(async (req, res, next) => {
  let employeeassets;
  try {


    employeeassets = await Employeeasset.countDocuments(
      // {status: {$nin: "recovered"}}
    );
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!employeeassets) {
    return next(new ErrorHandler("Employeeasset not found!", 404));
  }
  return res.status(200).json({
    employeeassets,
  });
});