const TaskAssignBoardList = require("../../../model/modules/project/taskassignboardlist");
const ErrorHandler = require("../../../utils/errorhandler");
const catchAsyncErrors = require("../../../middleware/catchAsyncError");
const User = require("../../../model/login/auth");

// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getAllTaskAssignBoardList = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList;
  try {
    taskAssignBoardList = await TaskAssignBoardList.find().lean();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!taskAssignBoardList) {
    return next(new ErrorHandler("task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    // count: Departments.length,
    taskAssignBoardList,
  });
});

// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getAllTaskAssignBoardListlimited = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList;
  try {
    taskAssignBoardList = await TaskAssignBoardList.find({}, { taskname: 1, taskid: 1, phase: 1, prevId: 1 }).lean();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!taskAssignBoardList) {
    return next(new ErrorHandler("task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    // count: Departments.length,
    taskAssignBoardList,
  });
});
// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getAllNotTaskAssignBoardListtabledata = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList;
  try {
    taskAssignBoardList = await TaskAssignBoardList.find({ allotedstatus: false }, { allotedstatus: 1, taskname: 1, phase: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1 }).lean();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!taskAssignBoardList) {
    return next(new ErrorHandler("task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    // count: Departments.length,
    taskAssignBoardList,
  });
});

// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getAllTaskAssignBoardListtabledata = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList, totalProjects, overallList;
  const { page, pageSize, allFilters, logicOperator, searchQuery
  } = req.body
  try {
    const taskDevName = req?.body?.companyname;
    let query = {};
    let queryParams = {};
    let queryOverall = {};
    Object.keys(req.body).forEach((key) => {
      if (key !== "headers" && !["page", 'pageSize', 'value', "companyname", "role"].includes(key)) {
        const value = req.body[key];
        if (value !== "" && value !== "ALL" && value?.length > 0) {
          query[key] = value;
        }
      }
    });

    const role = req?.body?.role?.map(data => data?.toLowerCase())?.includes("manager");
    const generateMongoQuery = (query) => {
      const mongoQuery = {};
      if (query?.project && query?.project?.length > 0) {
        mongoQuery.project = { $in: query?.project };
      }
      if (query?.subproject && query?.subproject.length > 0) {
        mongoQuery.subproject = { $in: query?.subproject };
      }
      if (query?.module && query?.module.length > 0) {
        mongoQuery.module = { $in: query?.module };
      }
      if (query?.submodule && query?.submodule.length > 0) {
        mongoQuery.submodule = { $in: query?.submodule };
      }
      if (query?.mainpage && query?.mainpage.length > 0) {
        mongoQuery.mainpage = { $in: query?.mainpage };
      }
      if (query?.subpage && query?.subpage?.length > 0) {
        mongoQuery.subpage = { $in: query?.subpage };
      }
      if (query?.subsubpage && query?.subsubpage?.length > 0) {
        mongoQuery.name = { $in: query?.subsubpage };
      }
      if (query?.phase && query?.phase?.length > 0) {
        mongoQuery.phase = { $in: query?.phase };
      }
      if (query?.allotedstatus === true || query?.allotedstatus === "true") {
        mongoQuery.allotedstatus = query?.allotedstatus;
      }
      return mongoQuery;
    }

    const mongoQuery = generateMongoQuery(query);

    let conditions = [];
    // Advanced search filter
    if (allFilters && allFilters.length > 0) {
      allFilters.forEach(filter => {
        if (filter.column && filter.condition && (filter.value || ["Blank", "Not Blank"].includes(filter.condition))) {
          conditions.push(createFilterCondition(filter.column, filter.condition, filter.value));
        }
      });
    }
    queryParams = {
      ...mongoQuery
    }
    queryOverall = {
      ...mongoQuery
    }

    if (searchQuery && searchQuery !== undefined) {
      const searchTermsArray = searchQuery.split(" ");
      const regexTerms = searchTermsArray.map((term) => new RegExp(term, "i"));
      const orConditions = regexTerms.map((regex) => ({
        $or: [
          { taskname: regex },
          { taskid: regex },
          { phase: regex },
          { project: regex },
          { subproject: regex },
          { module: regex },
          { submodule: regex },
          { mainpage: regex },
          { subpage: regex },

        ],
      }));
      const queryParamsMatch = {
        $match: {
          $and: searchQuery
            ? searchQuery.split(" ").map((term) => {
              const regex = new RegExp(term, "i");
              return {
                $or: [
                  { taskname: regex },
                  { taskid: regex },
                  { phase: regex },
                  { project: regex },
                  { subproject: regex },
                  { module: regex },
                  { submodule: regex },
                  { mainpage: regex },
                  { subpage: regex },
                ],
              };
            })
            : [],
        },
      };
      queryParams = {
        ...mongoQuery,
        $and: [
          ...orConditions,
        ]
      };
    }
    // Apply logicOperator to combine conditions
    if (conditions.length > 0) {
      if (logicOperator === "AND") {
        queryParams.$and = conditions;
      } else if (logicOperator === "OR") {
        queryParams.$or = conditions;
      }
    }


    const searchConditions = searchQuery
      ? searchQuery.split(" ").map((term) => {
        const regex = new RegExp(term, "i");
        return {
          $or: [
            { taskname: regex },
            { taskid: regex },
            { phase: regex },
            { project: regex },
            { subproject: regex },
            { module: regex },
            { submodule: regex },
            { mainpage: regex },
            { subpage: regex },
          ],
        };
      })
      : [];
    const pipeline = [
      { $match: { allotedstatus: true } },
      {
        $project: {
          allotedstatus: 1, taskname: 1, phase: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1,
          uidesign: {
            $filter: {
              input: "$uidesign", // Array to filter
              as: "item", // Variable name for the current item in the array
              cond: { $eq: ["$$item.taskdev", taskDevName] }, // Condition to match taskdev
            },
          },
          develop: {
            $filter: {
              input: "$develop",
              as: "item",
              cond: { $eq: ["$$item.taskdev", taskDevName] },
            },
          },
          testing: {
            $filter: {
              input: "$testing",
              as: "item",
              cond: { $eq: ["$$item.taskdev", taskDevName] },
            },
          },
          testinguidesign: {
            $filter: {
              input: "$testinguidesign",
              as: "item",
              cond: { $eq: ["$$item.taskdev", taskDevName] },
            },
          },
        },
      },
      {
        $match: {
          $expr: {
            $or: [
              { $gt: [{ $size: "$uidesign" }, 0] },
              { $gt: [{ $size: "$develop" }, 0] },
              { $gt: [{ $size: "$testing" }, 0] },
              { $gt: [{ $size: "$testinguidesign" }, 0] },
            ],
          },
        },
      },
    ];
    const pipeLineOverall = pipeline;
    // Add the search conditions only if there are terms to match
    if (searchConditions.length > 0) {
      pipeline.push({ $match: { $and: searchConditions } });
    }

    if (Object.keys(queryParams).length !== 0 || !role) {
      const individual = await TaskAssignBoardList.aggregate(pipeline)
      totalProjects = !role ? individual?.length : await TaskAssignBoardList.find(queryParams, { allotedstatus: 1, taskname: 1, phase: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1 }).countDocuments()
      overallList = !role ? await TaskAssignBoardList.aggregate(pipeLineOverall) : await TaskAssignBoardList.find(queryOverall, { allotedstatus: 1, taskname: 1, phase: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1 });
      taskAssignBoardList = !role ?
        await TaskAssignBoardList.aggregate(pipeline).skip((page - 1) * pageSize)
          .limit(parseInt(pageSize))
        : await TaskAssignBoardList.find(queryParams, { allotedstatus: 1, taskname: 1, phase: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1 }).skip((page - 1) * pageSize)
          .limit(parseInt(pageSize));
    }

  } catch (err) {
    console.log(err, 'err')
    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    totalProjects,
    overallList,
    taskAssignBoardList,
    currentPage: page,
    totalPages: Math.ceil(totalProjects / pageSize),
  });
});

// Helper function to create filter condition
function createFilterCondition(column, condition, value) {
  switch (condition) {
    case "Contains":
      return { [column]: new RegExp(value, 'i') };
    case "Does Not Contain":
      return { [column]: { $not: new RegExp(value, 'i') } };
    case "Equals":
      return { [column]: value };
    case "Does Not Equal":
      return { [column]: { $ne: value } };
    case "Begins With":
      return { [column]: new RegExp(`^${value}`, 'i') };
    case "Ends With":
      return { [column]: new RegExp(`${value}$`, 'i') };
    case "Blank":
      return { [column]: { $exists: false } };
    case "Not Blank":
      return { [column]: { $exists: true } };
    default:
      return {};
  }
}

// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getAllTaskAssignBoardListFilter = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList;
  const { project, subproject, module, submodule, mainpage, subpage, subsubpage } = req.body;
  try {
    const query = {};
    if (project && project.length > 0) {
      query.project = { $in: project };
    }
    if (subproject && subproject.length > 0) {
      query.subproject = { $in: subproject };
    }
    if (module && module.length > 0) {
      query.module = { $in: module };
    }
    if (submodule && submodule.length > 0) {
      query.submodule = { $in: submodule };
    }
    if (mainpage && mainpage.length > 0) {
      query.mainpage = { $in: mainpage };
    }
    if (subpage && subpage.length > 0) {
      query.subpage = { $in: subpage };
    }
    if (subsubpage && subsubpage.length > 0) {
      query.name = { $in: subsubpage };
    }

    taskAssignBoardList = await TaskAssignBoardList.find(query).lean();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!taskAssignBoardList) {
    return next(new ErrorHandler("task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    // count: Departments.length,
    taskAssignBoardList,
  });
});

//GET SINGLE USERTASK LIST
//get All Role =>/api/roles
exports.getParticularUsersTask = catchAsyncErrors(async (req, res, next) => {
  let tasks, taskUI, taskDev, taskTest, tasksDevelop, tasksTest, tasksIndCheck;
  try {
    const priorityOrder = ["URGENT", "Very High", "High", "Medium", "Low", "Very Low"];
    const pipelineUI = [
      {
        $match: {
          $and: [
            { allotedstatus: true }, // Condition for allotedstatus
            { phase: "UI" },         // Additional condition for phase
          ],
        },
      },
      {
        $project: {
          allotedstatus: 1,
          estimationtime: 1,
          priority: {
            $let: {
              vars: {
                priorities: {
                  $map: {
                    input: "$uidesign", // Map through all elements in the uidesign array
                    as: "item",
                    in: {
                      priority: "$$item.priority", // Extract the priority from each item
                      priorityIndex: {
                        $indexOfArray: [priorityOrder, "$$item.priority"], // Get the index of priority in the priorityOrder array
                      },
                    },
                  },
                },
              },
              in: {
                $arrayElemAt: [
                  {
                    $sortArray: {
                      input: "$$priorities", // Sort the array based on the priorityIndex
                      sortBy: { "priorityIndex": 1 }, // Sort in ascending order of priority index
                    },
                  },
                  0, // Select the highest priority (first element after sorting)
                ],
              },
            },
          },
          estimationtype: 1, taskname: 1, phase: 1, prevId: 1, taskid: 1, project: 1, subproject: 1, module: 1, submodule: 1, mainpage: 1, pagetype: 1, subpage: 1, name: 1,
          uidesign: {
            $filter: {
              input: "$uidesign", // Array to filter
              as: "item", // Variable name for the current item in the array
              cond: {
                $and: [
                  { $eq: ["$$item.taskdev", req.body.user] }, // Condition to match taskdev
                  { $ne: ["$$item.checkpointsstatus", "completed"] }, // Condition to exclude completed checkpoints
                ],
              },
            },
          },
          // develop: {
          //   $filter: {
          //     input: "$develop",
          //     as: "item",
          //     cond: { $eq: ["$$item.taskdev", taskDevName] },
          //   },
          // },
          // testing: {
          //   $filter: {
          //     input: "$testing",
          //     as: "item",
          //     cond: { $eq: ["$$item.taskdev", taskDevName] },
          //   },
          // },
          // testinguidesign: {
          //   $filter: {
          //     input: "$testinguidesign",
          //     as: "item",
          //     cond: { $eq: ["$$item.taskdev", taskDevName] },
          //   },
          // },
        },
      },
      {
        $match: {
          $expr: {
            $or: [
              { $gt: [{ $size: "$uidesign" }, 0] },
              // { $gt: [{ $size: "$develop" }, 0] },
              // { $gt: [{ $size: "$testing" }, 0] },
              // { $gt: [{ $size: "$testinguidesign" }, 0] },
            ],
          },
        },


      },
      {
        $sort: {
          priority: 1, // Sort by priority field (1 for ascending order based on priority index)
        },
      },
    ];


    // tasks = await TaskAssignBoardList.find();
    tasks = await TaskAssignBoardList.aggregate(pipelineUI);
    tasksDevelop = await TaskAssignBoardList.find().lean();
    tasksTest = await TaskAssignBoardList.find().lean();
    //filter task UI BASED ON USERLOGIN
    taskUI = tasks

    //filter task DEV BASED ON USERLOGIN
    taskDev = tasksDevelop.filter((task) => {
      // Check if the task meets the conditions for Development and allotedstatus
      if (task.phase === "Development" && task.allotedstatus === true && task.develop.some((item) => item.taskdev === req.body.user && item.checkpointsstatus !== "completed")) {
        // Find the corresponding UI phase task
        const uiPhaseTask = tasksDevelop.find((uiTask) => uiTask.taskid === task.taskid && uiTask.phase === "UI");

        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (uiPhaseTask && uiPhaseTask.uidesign.every((uiDesign) => uiDesign.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; // Exclude the task from the filtered result
    });
    //filter task TEST BASED ON USERLOGIN
    taskTest = tasksTest.filter((task) => {
      // Check if the task meets the conditions for Development and allotedstatus
      if ((task.phase === "Testing" && task.allotedstatus === true && task.testing.some((item) => item.taskdev === req.body.user && item.checkpointsstatus !== "completed")) || task.testinguidesign.some((item) => item.taskdev === req.body.user && item.checkpointsstatus !== "completed")) {
        // Find the corresponding UI phase task
        const devPhaseTask = tasksTest.find((devTask) => devTask.taskid === task.taskid && devTask.phase === "Development");
        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (devPhaseTask && devPhaseTask.develop.every((dev) => dev.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; // Exclude the task from the filtered result
    });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!TaskAssignBoardList) {
    return next(new ErrorHandler("Task not found!", 404));
  }
  return res.status(200).json({
    taskUI,
    taskDev,
    taskTest,
    tasksIndCheck
  });
});

exports.getAlltasksadminview = catchAsyncErrors(async (req, res, next) => {
  let tasks, taskUI, taskDev, taskTest, tasksDevelop, tasksTest;
  try {

    tasks = await TaskAssignBoardList.find().lean();
    tasksDevelop = await TaskAssignBoardList.find().lean();
    tasksTest = await TaskAssignBoardList.find().lean();
    //filter task UI BASED ON USERLOGIN
    taskUI = tasks
      .filter((task) => task.allotedstatus === true && task.phase == "UI")
      .map((task) => {
        task.uidesign = task.uidesign.filter((item) => {
          if (item.checkpointsstatus !== "completed") {
            return item;
          }
        });
        return task;
      })
      .filter((task) => task.uidesign.some((item) => item.checkpointsstatus !== "completed"));
    //filter task DEV BASED ON USERLOGIN
    taskDev = tasksDevelop.filter((task) => {
      // Check if the task meets the conditions for Development and allotedstatus
      if (task.phase === "Development" && task.allotedstatus === true && task.develop.some((item) => item.checkpointsstatus !== "completed")) {
        // Find the corresponding UI phase task
        const uiPhaseTask = tasksDevelop.find((uiTask) => uiTask.taskid === task.taskid && uiTask.phase === "UI");

        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (uiPhaseTask && uiPhaseTask.uidesign.every((uiDesign) => uiDesign.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; // Exclude the task from the filtered result
    });
    //filter task TEST BASED ON USERLOGIN
    taskTest = tasksTest.filter((task) => {
      // Check if the task meets the conditions for Development and allotedstatus
      if ((task.phase === "Testing" && task.allotedstatus === true && task.testing.some((item) => item.checkpointsstatus !== "completed")) || task.testinguidesign.some((item) => item.checkpointsstatus !== "completed")) {
        // Find the corresponding UI phase task
        const devPhaseTask = tasksTest.find((devTask) => devTask.taskid === task.taskid && devTask.phase === "Development");
        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (devPhaseTask && devPhaseTask.develop.every((dev) => dev.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; // Exclude the task from the filtered result
    });


  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!TaskAssignBoardList) {
    return next(new ErrorHandler("Task not found!", 404));
  }
  return res.status(200).json({
    taskUI,
    taskDev,
    taskTest,
  });
});

exports.updateTasksSubArrays = catchAsyncErrors(async (req, res, next) => {
  try {
    const { taskid, todos } = req.body;
    // Construct an array of update operations for each item in changecheckedlabel
    const updateOperations = todos.map((todo) => ({
      updateOne: {
        filter: {
          "develop._id": taskid,
        },
        update: {
          $set: {
            "develop.$.state": "Re-Printed",
          },
        },
      },
    }));
    // Bulk write the update operations
    const result = await TaskAssignBoardList.bulkWrite(updateOperations);
    if (result.modifiedCount === 0) {
      return next(new ErrorHandler("Task not found!", 404));
    }
    return res.status(200).json({ message: "Task updated successfully" });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
    return next(new ErrorHandler("Error updating Task!", 500));
  }
});

// Create new TaskAssignBoardList => /api/taskAssignBoardList/new
exports.addTaskAssignBoardList = catchAsyncErrors(async (req, res, next) => {
  let ataskAssignBoardList = await TaskAssignBoardList.create(req.body);
  return res.status(200).json({
    message: "Successfully added!",
  });
});

// get Signle TaskAssignBoardList => /api/taskAssignBoardList/:id
exports.getSingleTaskAssignBoardList = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let staskAssignBoardList = await TaskAssignBoardList.findById(id);
  if (!staskAssignBoardList) {
    return next(new ErrorHandler("Task Assign Board List not found", 404));
  }
  return res.status(200).json({
    staskAssignBoardList,
  });
});
// get Single TaskAssignBoardList => /api/taskAssignBoardList/:id
exports.getSingleTaskAssignBoardListNew = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  const user = req.body.user;
  let staskAssignBoardList, staskAssignBoardListnew, staskAssignBoardListnewDev, staskAssignBoardListnewTest, staskAssignBoardListnewTestui; // Assuming user is coming from the request body

  try {
    staskAssignBoardList = await TaskAssignBoardList.findById(id);
    // Filter the uidesign array to include only elements where taskdev matches user
    staskAssignBoardListnew = staskAssignBoardList.uidesign.filter((elem) => elem.taskdev === user);

    staskAssignBoardListnewDev = staskAssignBoardList.develop.filter((elem) => elem.taskdev === user);
    staskAssignBoardListnewTest = staskAssignBoardList.testing.filter((elem) => elem.taskdev === user);
    staskAssignBoardListnewTestui = staskAssignBoardList.testinguidesign.filter((elem) => elem.taskdev === user);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!staskAssignBoardList) {
    return next(new ErrorHandler("Task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    staskAssignBoardList,
    staskAssignBoardListnew,
    staskAssignBoardListnewDev,
    staskAssignBoardListnewTest,
    staskAssignBoardListnewTestui,
  });
});

exports.taskassignchecktimer = catchAsyncErrors(async (req, res, next) => {
  let tasks, taskallcheck, prioritycheck, prioritycheckUI, prioritycheckDEV, prioritycheckTest;
  try {
    tasks = await TaskAssignBoardList.find({}, { taskname: 1, taskid: 1, phase: 1, allotedstatus: 1, uidesign: 1, develop: 1, testing: 1, testinguidesign: 1 }).lean();
    taskallcheck = tasks.filter((task) => {
      return (task.uidesign && task.uidesign.some((item) => item.taskdev === req.body.user && item.state === "running")) || (task.develop && task.develop.some((item) => item.taskdev === req.body.user && item.state === "running")) || (task.testing && task.testing.some((item) => item.taskdev === req.body.user && item.state === "running")) || (task.testinguidesign && task.testinguidesign.some((item) => item.taskdev === req.body.user && item.state === "running"));
    });
    prioritycheckUI = tasks
      .filter((task) => task.allotedstatus === true && task.phase == "UI")
      .map((task) => {
        task.uidesign = task.uidesign.filter((item) => {
          if (item.taskdev === req.body.user && item.checkpointsstatus !== "completed") {
            return item;
          }
        });
        return task;
      })
      .filter((task) => task.uidesign.some((item) => item.checkpointsstatus !== "completed" && (item.priority.toLowerCase() == "high" || item.priority.toLowerCase() == "veryhigh" || item.priority.toLowerCase() == "very high")));
    prioritycheckDEV = tasks.filter((task) => {
      // Check if the phase is "Development" and there is a matching condition in the develop array
      if (task.phase === "Development" && task.allotedstatus === true && task.develop.some((dev) => dev.taskdev === req.body.user && (dev.priority.toLowerCase() == "high" || dev.priority.toLowerCase() == "veryhigh" || dev.priority.toLowerCase() == "very high") && dev.checkpointsstatus !== "completed")) {
        const uiPhaseTask = tasks.find((uiTask) => uiTask.taskid === task.taskid && uiTask.phase === "UI");

        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (uiPhaseTask && uiPhaseTask.uidesign.every((uiDesign) => uiDesign.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; //
    });
    prioritycheckTest = tasks.filter((task) => {
      // Check if the phase is "Development" and there is a matching condition in the develop array
      if (task.phase === "Testing" && task.allotedstatus === true && (task.testing.some((test) => test.tasktest === req.body.user && (test.priority.toLowerCase() == "high" || test.priority.toLowerCase() == "veryhigh" || test.priority.toLowerCase() == "very high") && test.checkpointsstatus !== "complete") || task.testinguidesign.some((test) => test.tasktest === req.body.user && (test.priority.toLowerCase() == "high" || test.priority.toLowerCase() == "veryhigh" || test.priority.toLowerCase() == "very high") && test.checkpointsstatus !== "complete"))) {
        const devPhaseTask = tasks.find((uiTask) => uiTask.taskid === task.taskid && uiTask.phase === "UI");
        // Check if the UI phase task exists and if all uidesign checkpoints are completed
        if (devPhaseTask && devPhaseTask.develop.every((dev) => dev.checkpointsstatus === "completed")) {
          return true; // Include the task in the filtered result
        }
      }
      return false; //
    });
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!tasks) {
    return next(new ErrorHandler("Task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    taskallcheck,
    prioritycheckUI,
    prioritycheckDEV,
    prioritycheckTest,
  });
});

// get All getTaskidstoUpdateRequirements Details => /api/taskAssignBoardList
exports.getTaskidstoUpdateRequirements = catchAsyncErrors(async (req, res, next) => {
  let taskUIid, taskDevid, taskTestid;
  try {
    taskUIid = await TaskAssignBoardList.find({ prevId: req.body.id, phase: "UI" }, { _id: 1 }).lean();
    taskDevid = await TaskAssignBoardList.find({ prevId: req.body.id, phase: "Development" }, { _id: 1 }).lean();
    taskTestid = await TaskAssignBoardList.find({ prevId: req.body.id, phase: "Testing" }, { _id: 1 }).lean();
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!taskUIid) {
    return next(new ErrorHandler("task Assign Board List details not found", 404));
  }
  return res.status(200).json({
    // count: Departments.length,
    taskUIid,
    taskDevid,
    taskTestid,
  });
});

exports.getAllcompletedtask = catchAsyncErrors(async (req, res, next) => {
  let task, completedtask, filter;
  try {
    task = await TaskAssignBoardList.find().lean();
    //filter task UI BASED ON USERLOGIN
    //filter task TEST BASED ON USERLOGIN
    filter = task.filter(
      (task) =>
        // Check if the task meets the conditions for Development and allotedstatus
        task.phase === "Testing" && task.allotedstatus === true && task.testing.every((item) => item.checkpointsstatus == "completed") && task.testinguidesign.every((item) => item.checkpointsstatus == "completed")
    );
    completedtask = filter.map((item) => item.taskname);
  } catch (err) {
    return next(new ErrorHandler("Records not found!", 404));
  }
  if (!TaskAssignBoardList) {
    return next(new ErrorHandler("Task not found!", 404));
  }
  return res.status(200).json({
    completedtask,
  });
});

// get All TaskAssignBoardList Details => /api/taskAssignBoardList
exports.getTaskboardviewlistFilter = catchAsyncErrors(async (req, res, next) => {
  let taskAssignBoardList;
  let tasks, taskUI, taskDev, taskTest, tasksDevelop, tasksTest, tasksDeveloptesting, tasksTestTesting;
  const { project, subproject, module, submodule, mainpage, subpage, subsubpage, access, accessdrop, company, branch, unit, team, designation, department, employeenames } = req.body;

  try {
    const fields = {
      project,
      subproject,
      module,
      submodule,
      mainpage,
      subpage,
      name: subsubpage,
    };
    const Userfields = {
      company,
      branch,
      unit,
      team,
      designation,
      department,
      companyname: employeenames,
    };

    const query = Object.entries(fields).reduce((acc, [key, value]) => {
      if (value && value.length > 0) {
        acc[key] = { $in: value };
      }
      return acc;
    }, {});
    const queryUser = Object.entries(Userfields).reduce((acc, [key, value]) => {
      if (value && value.length > 0) {
        acc[key] = { $in: value };
      }
      return acc;
    }, {});

    const length = Object.keys(queryUser).length;
    let userDetailsCompanyName = length > 0 ? await User.find(queryUser, { companyname: 1 }) : [];
    const companyNameFromUser = userDetailsCompanyName?.length > 0 ? userDetailsCompanyName?.map(Data => Data?.companyname) : [];
    const userNamesParamaters = companyNameFromUser?.length > 0 ? companyNameFromUser : [];

    const priorityOrder = ["URGENT", "VERY HIGH", "HIGH", "MEDIUM", "LOW", "VERY LOW"];
    const buildPipeline = (phase, isManager = false, user = null, fromDate = null, toDate = null, query = {}) => {

      const arrayField = (() => {
        switch (phase) {
          case "UI":
            return "uidesign";
          case "Development":
            return "develop";
          case "Testing":
            return "testing";
          default:
            throw new Error(`Unknown phase: ${phase}`);
        }
      })();

      const baseMatchStage = {
        $match: {
          $and: [
            { allotedstatus: true },
            { phase },
            query
          ],
        },
      };

      const baseProjectStage = {
        $project: {
          allotedstatus: 1,
          priority: {
            $let: {
              vars: {
                priorities: {
                  $map: {
                    input: `$${arrayField}`,
                    as: "item",
                    in: {
                      priority: { $toUpper: "$$item.priority" },
                      priorityIndex: {
                        $cond: {
                          if: { $ne: [{ $toUpper: "$$item.priority" }, null] },
                          then: {
                            $indexOfArray: [priorityOrder, { $toUpper: "$$item.priority" }],
                          },
                          else: -1,
                        },
                      },
                    },
                  },
                },
              },
              in: {
                $arrayElemAt: [
                  {
                    $sortArray: {
                      input: "$$priorities",
                      sortBy: { priorityIndex: 1 },
                    },
                  },
                  0,
                ],
              },
            },
          },
          estimationtime: 1,
          estimationtype: 1,
          taskname: 1,
          phase: 1,
          prevId: 1,
          taskid: 1,
          project: 1,
          subproject: 1,
          module: 1,
          submodule: 1,
          mainpage: 1,
          pagetype: 1,
          subpage: 1,
          name: 1,
          uidesign: 1,
          develop: 1,
          testing: 1,
          [arrayField]: {
            $filter: {
              input: `$${arrayField}`,
              as: "item",
              cond: {
                $and: [
                  ...(user && user.length > 0 ? [{ $in: ["$$item.taskdev", user] }] : []),
                  { $ne: ["$$item.checkpointsstatus", "completed"] },
                  ...(fromDate ? [{ $gte: ["$$item.assigndate", fromDate] }] : []),
                  ...(toDate ? [{ $lte: ["$$item.assigndate", toDate] }] : []),
                ],
              },
            },
          },
        },
      };

      const postFilterStage = {
        $match: {
          $expr: {
            $gt: [{ $size: `$${arrayField}` }, 0],
          },
        },
      };

      const sortStage = {
        $sort: {
          priority: 1,
        },
      };

      return [baseMatchStage, baseProjectStage, postFilterStage, sortStage];
    };

    const processTasks = (tasksArray, priorityOrder) => {
      if (!tasksArray) return [];

      return tasksArray.sort((a, b) => {
        const priorityIndexA = Number(priorityOrder.indexOf(a.priority.priority));
        const priorityIndexB = Number(priorityOrder.indexOf(b.priority.priority));
        console.log('A:', a.priority.priority, 'IndexA:', priorityIndexA);
        console.log('B:', b.priority.priority, 'IndexB:', priorityIndexB);
        if (priorityIndexA === -1 || priorityIndexB === -1) {
          return 0; // Default behavior when priority isn't found
        }
        // Sort by priority index
        return priorityIndexA - priorityIndexB;
      });
    };

    //identifySame TaskId and Phase 
    const sameTaskIdPhase = async (taskid, phase) => {
      return await TaskAssignBoardList.find({ taskid, phase }).lean();
    };
    // Determine the appropriate pipeline based on access level
    const isManager = access.includes("Manager") && accessdrop === "all";
    const isManager2 = !access.includes("Manager") || (access.includes("Manager") && accessdrop === "Teammember");

    // Utility function to build and execute the pipelines
    const executePipeline = async (phase, isManager, user, fromDate, toDate, query) => {
      const pipeline = buildPipeline(phase, isManager, (isManager && companyNameFromUser?.length < 1) ? null : user, fromDate, toDate, query);
      return TaskAssignBoardList.aggregate(pipeline);
    };

    // Utility function to filter tasks based on the phase and status
    const filterTasksByPhase = async (tasks, phase, statusKey) => {
      return await Promise.all(
        tasks.map(async (task) => {
          const firstTask = await sameTaskIdPhase(task?.taskid, phase);
          const phaseTask = firstTask[0];
          if (phaseTask && phaseTask[statusKey].every((uiDesign) => uiDesign.checkpointsstatus === "completed")) {
            return task; // Include the task in the result
          }
          return null; // Exclude the task from the result
        })
      );
    };

    // Common logic for both isManager and isManager2
    const processTasksByRole = async (isManagerFlag, companynames) => {
      // Build pipelines for each phase
      const answerTasksUI = await executePipeline("UI", isManagerFlag, companynames, req.body.fromdate, req.body.todate, query);
      const answerTaskDevelopment = await executePipeline("Development", isManagerFlag, companynames, req.body.fromdate, req.body.todate, query);
      const answerTaskTesting = await executePipeline("Testing", isManagerFlag, companynames, req.body.fromdate, req.body.todate, query);

      // Process tasks
      let tasks = processTasks(answerTasksUI, priorityOrder);
      let tasksDeveloptesting = processTasks(answerTaskDevelopment, priorityOrder);
      let tasksTestTesting = processTasks(answerTaskTesting, priorityOrder);

      // Filter tasks based on phases and status

      let taskUI = tasks;
      let taskDev = (await filterTasksByPhase(tasksDeveloptesting, "UI", "uidesign")).filter(task => task !== null);
      let taskTest = (await filterTasksByPhase(tasksTestTesting, "Development", "develop")).filter(task => task !== null);

      return { taskUI, taskDev, taskTest };
    };


    if (isManager) {
      // Manager 
      ({ taskUI, taskDev, taskTest } = await processTasksByRole(true, userNamesParamaters));
    }

    if (isManager2) {
      // Non-manager or Teammember logic
      ({ taskUI, taskDev, taskTest } = await processTasksByRole(false, [req.body.user]));
    }
    // taskAssignBoardList = await TaskAssignBoardList.find(query);
  } catch (err) {
    console.log(err, 'err')
    return next(new ErrorHandler("Records not found!", 404));
  }

  return res.status(200).json({
    // count: Departments.length,
    // taskAssignBoardList,
    taskUI,
    taskDev,
    taskTest,
  });
});

// update taskAssignBoardList by id => /api/taskAssignBoardList/:id
exports.updateTaskAssignBoardList = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let uptaskAssignBoardList = await TaskAssignBoardList.findByIdAndUpdate(id, req.body);
  if (!uptaskAssignBoardList) {
    return next(new ErrorHandler("TaskAssignBoardList Details not found", 404));
  }
  return res.status(200).json({ message: "Updates successfully" });
});

// delete Task Assign Board List by id => /api/taskAssignBoardList/:id
exports.deleteTaskAssignBoardList = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  let dtaskAssignBoardList = await TaskAssignBoardList.findByIdAndRemove(id);
  if (!dtaskAssignBoardList) {
    return next(new ErrorHandler("task Assign Board List  Details not found", 404));
  }
  return res.status(200).json({ message: "Deleted successfully" });
});

// delete workorder only
exports.deleteWorkOrders = catchAsyncErrors(async (req, res, next) => {
  const id = req.params.id;
  try {
    const updatedDocument = await TaskAssignBoardList.findOneAndUpdate(
      { _id: id },
      {
        $unset: { assignby: 1, assignmode: 1, assigndate: 1, team: 1, calculatedtime: 1, workorders: 1 },
        $set: { taskassignboardliststatus: "Yet to assign" },
      },
      { new: true, returnOriginal: false } // Return the updated document
    );
    if (!updatedDocument) {
      // Handle the case where no document was found (possibly due to incorrect ID)
      return res.status(404).json({ message: "Task not found" });
    }
    res.status(200).json({ message: "Workorders deleted successfully" });
  } catch (err) {
    console.error(err.message, 'err');
    res.status(500).json({ message: "Internal Server Error" });
  }
});