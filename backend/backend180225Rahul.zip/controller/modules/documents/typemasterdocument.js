const Typemasterdocument = require('../../../model/modules/documents/typemasterdocument');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError'); 

//get All Typemasterdocument =>/api/Typemasterdocument
exports.getAllTypemasterdocument = catchAsyncErrors(async (req, res, next) => {
    let typemasterdouments;
    try {
        typemasterdouments = await Typemasterdocument.find() 
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!typemasterdouments) {
        return next(new ErrorHandler('Typemasterdocument not found!', 404));
    }
    return res.status(200).json({
        typemasterdouments
    });
})


//create new Typemasterdocument => /api/Typemasterdocument/new
exports.addTypemasterdocument = catchAsyncErrors(async (req, res, next) => {

    let aTypemasterdocument = await Typemasterdocument.create(req.body);
    return res.status(200).json({
        message: 'Successfully added!'
    });
})

// get Single Typemasterdocument => /api/Typemasterdocument/:id
exports.getSingleTypemasterdocument = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let stypemasterdocument = await Typemasterdocument.findById(id);
    if (!stypemasterdocument) {
        return next(new ErrorHandler('Typemasterdocument not found', 404));
    }
    return res.status(200).json({
        stypemasterdocument
    })
})

//update Typemasterdocument by id => /api/Typemasterdocument/:id
exports.updateTypemasterdocument = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let utypemasterdocument = await Typemasterdocument.findByIdAndUpdate(id, req.body);
    if (!utypemasterdocument) {
        return next(new ErrorHandler('Typemasterdocument not found', 404));
    }

    return res.status(200).json({ message: 'Updated successfully' });
})

//delete Typemasterdocument by id => /api/Typemasterdocument/:id
exports.deleteTypemasterdocument = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dtypemasterdocument = await Typemasterdocument.findByIdAndRemove(id);
    if (!dtypemasterdocument) {
        return next(new ErrorHandler('Typemasterdocument not found', 404));
    }

    return res.status(200).json({ message: 'Deleted successfully' });
})