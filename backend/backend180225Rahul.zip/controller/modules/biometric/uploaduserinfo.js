const Biouploaduserinfo = require('../../../model/modules/biometric/uploaduserinfo');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError'); 

exports.getAllUploadUserInfo = catchAsyncErrors(async (req, res, next) => {
    let alluploaduserinfo;
    try {
        alluploaduserinfo = await Biouploaduserinfo.find();

        return res.status(200).json({
            alluploaduserinfo
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})


exports.addUploadUserInfo = catchAsyncErrors(async (req, res, next) => {
    
  try{
    let auploaduserinfo = await Biouploaduserinfo.create(req.body);
    return res.status(200).json({
        returnStatus : true,
        returnMessage:"Successfully Updated!!",
        returnValue:""
    });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})


 exports.getDownloadUserinfo = catchAsyncErrors(async (req, res, next) => {
    
    try{
      return res.status(200).json({
          returnStatus : true,
          returnMessage:"Successfully Updated!!",
          returnValue:req.body
      });
  
      } catch (err) {
          return next(new ErrorHandler("Records not found!", 500));
      }
  })