const Biometricattlog = require('../../../model/modules/biometric/biometricattalog');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError'); 

exports.getAllattLog = catchAsyncErrors(async (req, res, next) => {
    let allattlog;
    try {
        allattlog = await Biometricattlog.find();

        return res.status(200).json({
            allattlog
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})


exports.addAttLog = catchAsyncErrors(async (req, res, next) => {
    
  try{
    let addattalog = await Biometricattlog.create(req.body);
    return res.status(200).json({
        returnStatus : true,
        returnMessage:"Successfully added!!",
        returnValue:""
    });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})
