const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError');
const Biocommandcomplete = require('../../../model/modules/biometric/biocommandcomplete');
const Biometriconlinestatus = require('../../../model/modules/biometric/biometriconlinestatus');
const Biometricattlog = require('../../../model/modules/biometric/biometricattalog');
const Biouploaduserinfo = require('../../../model/modules/biometric/uploaduserinfo');
const Biouploadtemplateinfo = require('../../../model/modules/biometric/uploadusertemplateinfo');

exports.getSendCommand = catchAsyncErrors(async (req, res, next) => {
    try {
        const deviceCommand = req?.body?.deviceCommandN ? req?.body?.deviceCommandN : "8";
        let allbiocmdcpl = await Biocommandcomplete.find({
            CloudIDC: req?.body?.CloudIDC,
            StatusC: { $in: ["New"] }
        }).sort({ createdAt: -1 });
        if (allbiocmdcpl?.length > 0) {
            let lastCmd = allbiocmdcpl[0];
            if (lastCmd.StatusC === "New") {
                let updateResult = await Biocommandcomplete.updateOne(
                    { _id: lastCmd._id },
                    { $set: { StatusC: "Sent", updatedAt: new Date() } }
                );
            }
        } else {
            if (req?.body?.CloudIDC !== null) {
                let aallbiocmdcpl = await Biocommandcomplete.create({
                    deviceCommandN: deviceCommand,
                    CloudIDC: req.body.CloudIDC,
                    StatusC: "New",
                    description: req.body.description ? req.body.description : "",
                    param1C: "",
                    param2C: "",
                });

                const string = JSON.stringify({
                    "deviceCommandN": deviceCommand,
                    "CloudIDC": req.body.CloudIDC,
                    "biometricUserIDC": "",
                    "param1C": "",
                    "param2C": ""
                });
                return res.status(200).json({
                    returnStatus: true,
                    returnMessage: "Successfully updated",
                    returnValue: string
                });
            }

        }
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});


// exports.getSendCommand = catchAsyncErrors(async (req, res, next) => {
//     try {
//         const deviceCommand = req?.body?.deviceCommandN || "5";

//         // Find the latest command that is still "New"
//         let lastCmd = await Biocommandcomplete.findOne({
//             CloudIDC: req?.body?.CloudIDC,
//             StatusC: "New"
//         }).sort({ createdAt: -1 });

//         if (lastCmd) {
//             // If there's an existing "New" command, do not create a new one
//             return res.status(400).json({
//                 returnStatus: false,
//                 returnMessage: "A command is already in progress. Please wait.",
//                 returnValue: ""
//             });
//         } else {
//             // If no "New" command exists, create a new one
//             if (req?.body?.CloudIDC !== null) {
//                 let newCommand = await Biocommandcomplete.create({
//                     deviceCommandN: deviceCommand,
//                     CloudIDC: req.body.CloudIDC,
//                     StatusC: "New",
//                     description: req.body.description || "",
//                     param1C: "",
//                     param2C: "",
//                 });

//                 return res.status(200).json({
//                     returnStatus: true,
//                     returnMessage: "Successfully updated",
//                     returnValue: JSON.stringify({
//                         "deviceCommandN": newCommand.deviceCommandN,
//                         "CloudIDC": newCommand.CloudIDC,
//                         "biometricUserIDC": "",
//                         "param1C": "",
//                         "param2C": ""
//                     })
//                 });
//             }
//         }
//     } catch (err) {
//         return next(new ErrorHandler("Records not found!", 500));
//     }
// });



// exports.getSendCommand = catchAsyncErrors(async (req, res, next) => {
//     try {
//         const { CloudIDC, description } = req.body;
//         if (!CloudIDC) {
//             return res.status(400).json({ returnStatus: false, returnMessage: "CloudIDC is required" });
//         }

//         let existingRecord = await Biocommandcomplete.findOne({ CloudIDC });

//         if (existingRecord) {
//             if (existingRecord.StatusC === "Sent") {
//                 return res.status(200).json({ returnStatus: false, returnMessage: "Waiting for completion" });
//             }

//             if (existingRecord.StatusC === "Complete") {
//                 await Biocommandcomplete.updateOne(
//                     { _id: existingRecord._id },
//                     { $set: { StatusC: "New", updatedAt: new Date() } }
//                 );
//             }
//         } else {
//             existingRecord = await Biocommandcomplete.create({
//                 deviceCommandN: req.body.deviceCommandN || "5",
//                 CloudIDC,
//                 StatusC: "New",
//                 description: description || "",
//                 param1C: "",
//                 param2C: "",
//             });
//         }

//         await Biocommandcomplete.updateOne(
//             { _id: existingRecord._id },
//             { $set: { StatusC: "Sent", updatedAt: new Date() } }
//         );

//         const responsePayload = JSON.stringify({
//             deviceCommandN: existingRecord.deviceCommandN,
//             CloudIDC,
//             biometricUserIDC: "",
//             param1C: "",
//             param2C: "",
//         });

//         return res.status(200).json({
//             returnStatus: true,
//             returnMessage: "Successfully updated",
//             returnValue: responsePayload,
//         });
//     } catch (err) {
//         return next(new ErrorHandler("Records not found!", 500));
//     }
// });



// exports.getSendCommand = catchAsyncErrors(async (req, res, next) => {
//     try {
//         const deviceCommand = req?.body?.deviceCommandN || "5";

//         // Fetch the latest command for the given CloudIDC
//         let lastCmd = await Biocommandcomplete.findOne({
//             CloudIDC: req?.body?.CloudIDC
//         }).sort({ createdAt: -1 });

//         if (lastCmd) {
//             if (lastCmd.StatusC === "New" || lastCmd.StatusC === "Sent") {
//                 // If "New" or "Sent" exists, update "New" to "Sent"
//                 if (lastCmd.StatusC === "New") {
//                     await Biocommandcomplete.updateOne(
//                         { _id: lastCmd._id },
//                         { $set: { StatusC: "Sent", updatedAt: new Date() } }
//                     );
//                 }
//                 return res.status(200).json({
//                     returnStatus: true,
//                     returnMessage: "Command already in process",
//                     returnValue: JSON.stringify({
//                         "deviceCommandN": lastCmd.deviceCommandN,
//                         "CloudIDC": lastCmd.CloudIDC,
//                         "biometricUserIDC": "",
//                         "param1C": "",
//                         "param2C": ""
//                     })
//                 });
//             }
//         }

//         // If no previous command or last command was "Complete", create a new one
//         if (req?.body?.CloudIDC) {
//             let newCmd = await Biocommandcomplete.create({
//                 deviceCommandN: deviceCommand,
//                 CloudIDC: req.body.CloudIDC,
//                 StatusC: "New",
//                 description: req.body.description || "",
//                 param1C: "",
//                 param2C: "",
//             });

//             return res.status(200).json({
//                 returnStatus: true,
//                 returnMessage: "Successfully created new command",
//                 returnValue: JSON.stringify({
//                     "deviceCommandN": deviceCommand,
//                     "CloudIDC": req.body.CloudIDC,
//                     "biometricUserIDC": "",
//                     "param1C": "",
//                     "param2C": ""
//                 })
//             });
//         }

//         return next(new ErrorHandler("Invalid CloudIDC", 400));

//     } catch (err) {
//         return next(new ErrorHandler("Records not found!", 500));
//     }
// });



exports.getCompleteCommand = catchAsyncErrors(async (req, res, next) => {

    try {
        let { cloudIDC } = req?.body;
        let allbiocmdcpl = await Biocommandcomplete.find({ CloudIDC: cloudIDC, StatusC: "Sent" }).sort({ createdAt: -1 });
        if (allbiocmdcpl?.length > 0) {
            let updatePromises = allbiocmdcpl.map(async (cmd) => {
                return Biocommandcomplete.updateMany(
                    { CloudIDC: cloudIDC },
                    { $set: { StatusC: "Complete", deviceCommandN: 0, updatedAt: new Date() } }  // Update fields
                );
            });
            // Wait for all updates to complete
            await Promise.all(updatePromises);
            return res.status(200).json({
                returnStatus: true,
                returnMessage: "Successfully updated",
                returnValue: ""
            });
        } else {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        }
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});
exports.getDeviceInfoCommand = catchAsyncErrors(async (req, res, next) => {
    try {
        const { CloudIDC, totalManagerN, totalUserN, totalFaceN, totalFPN, totalCardN, totalPWDN } = req?.body;
        console.log(req.body, 'Device Info Command- command 2')
        let allbiocmdcpl = await Biocommandcomplete.find({ CloudIDC, totalManagerN, totalUserN, totalFaceN, totalFPN, totalCardN, totalPWDN }).sort({ createdAt: -1 });
        return res.status(200).json({
            returnStatus: true,
            returnMessage: "Successfully updated",
            returnValue: ""
        });
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})
exports.getUploadUserTemplateInfo = catchAsyncErrors(async (req, res, next) => {
    try {
        console.log(req.body, 'getUploadUserTemplateInfo- command 5')

        const userInfo = req?.body;
        const uploadUserTemplateInfo = await Biouploaduserinfo.findOneAndUpdate(
            { cloudIDC: userInfo.cloudIDC, biometricUserIDC: userInfo.biometricUserIDC },
            { $setOnInsert: userInfo }, // Insert only if it doesn’t exist
            { upsert: true, new: true }
        );


        return res.status(200).json({
            returnStatus: true,
            returnMessage: "Successfully updated",
            returnValue: ""
        });
    } catch (err) {
        // console.log(err, 'err')
        return next(new ErrorHandler("Records not found!", 500));
    }
});
exports.getBioDownlodUser = catchAsyncErrors(async (req, res, next) => {
    try {
        console.log(req.body, 'getBioDownlodUser - 5 req.body');



        const idsFilter = await Biouploaduserinfo.find({ cloudIDC: req.body.cloudIDC }, { biometricUserIDC: 1 }).lean();
        const ids = idsFilter?.map(data => data?.biometricUserIDC);
        const newData = await Biouploaduserinfo.findOne({ cloudIDC: req.body.cloudIDC, biometricUserIDC: "1" }, {
            _id: 0,
            addedby: 0,
            updatedby: 0, createdAt: 0, __v: 0
        })
        console.log(newData, 'newData');
        if (newData) {
            const string = JSON.stringify(newData)
            return res.status(200).json({
                returnStatus: true,
                returnMessage: "Successfully updated",
                returnValue: string
            });
        }
        else {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        }
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});
exports.getBioDownloadUserTemplate = catchAsyncErrors(async (req, res, next) => {
    try {
        console.log(req.body, 'getBioDownloadUserTemplate - command 5')
        const newData = await Biouploadtemplateinfo.findOne({ cloudIDC: req.body.cloudIDC, biometricUserIDC: "1" }, {
            _id: 0,
            addedby: 0,
            updatedby: 0, createdAt: 0, __v: 0
        })

        console.log(newData, 'newData 2')
        if (newData) {
            const string = JSON.stringify(newData)
            return res.status(200).json({
                returnStatus: true,
                returnMessage: "Successfully updated",
                returnValue: string
            });
        }
        else {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        }

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});
//---------------------------------------------------------------------------------------------//
// exports.getBioUploadUserTemplate = catchAsyncErrors(async (req, res, next) => {

//     try {
//         const matchingTemplatesCount = await Biouploadtemplateinfo.countDocuments({
//             cloudIDC: req?.body.cloudIDC,
//             biometricUserIDC: req?.body?.biometricUserIDC,
//             templateTypeC: req?.body?.templateTypeC
//         });

//         const uploadUserInfoTemplate = await Biouploadtemplateinfo.findOneAndUpdate(
//             {
//                 cloudIDC: req?.body.cloudIDC,
//                 biometricUserIDC: req?.body?.biometricUserIDC,
//                 templateTypeC: req?.body?.templateTypeC
//             },
//             { $setOnInsert: req?.body }, // Insert only if it doesn’t exist
//             { upsert: true, new: true }
//         );

//         if (uploadUserInfoTemplate) {
//             let incrementField = null;
//             if (req.body?.templateTypeC === "FINGER") {
//                 incrementField = 'downloadedFingerTemplateN';
//             }
//             if (req.body?.templateTypeC === "FACE") {
//                 incrementField = 'downloadedFaceTemplateN';
//             }
//             // console.log(incrementField, 'incrementField')
//             if (incrementField) {
//                 const existingUploadUserInfo = await Biouploaduserinfo.findOne({
//                     cloudIDC: req.body.cloudIDC,
//                     biometricUserIDC: req.body.biometricUserIDC
//                 });
//                 // console.log(existingUploadUserInfo, 'existingUploadUserInfo')
//                 if (existingUploadUserInfo) {

//                     for (let i = 0; i < matchingTemplatesCount; i++) {
//                         await Biouploaduserinfo.findOneAndUpdate(
//                             {
//                                 cloudIDC: req.body.cloudIDC,
//                                 biometricUserIDC: req.body.biometricUserIDC
//                             },
//                             {
//                                 $inc: { [incrementField]: 1 }
//                             },
//                             { new: true }
//                         );
//                     }
//                 }
//             }
//             return res.status(200).json({
//                 returnStatus: true,
//                 returnMessage: "Successfully updated",
//                 returnValue: ""
//             });
//         }
//         else {
//             return res.status(200).json({
//                 returnStatus: false,
//                 returnMessage: "",
//                 returnValue: ""
//             });
//         }


//     } catch (err) {
//         return next(new ErrorHandler("Records not found!", 500));
//     }
// });

exports.getBioUploadUserTemplate = catchAsyncErrors(async (req, res, next) => {
    try {
        const { cloudIDC, biometricUserIDC, templateTypeC } = req.body;

        // Get count of matching documents
        const matchingTemplatesCount = await Biouploadtemplateinfo.countDocuments({
            cloudIDC,
            biometricUserIDC,
            templateTypeC
        });

        // Upsert Biouploadtemplateinfo
        const uploadUserInfoTemplate = await Biouploadtemplateinfo.findOneAndUpdate(
            { cloudIDC, biometricUserIDC, templateTypeC },
            { $setOnInsert: req.body }, // Insert only if it doesn’t exist
            { upsert: true, new: true }
        );

        if (uploadUserInfoTemplate) {
            let incrementField = null;
            if (templateTypeC === "FINGER") {
                incrementField = "downloadedFingerTemplateN";
            } else if (templateTypeC === "FACE") {
                incrementField = "downloadedFaceTemplateN";
            }

            if (incrementField) {
                const existingUploadUserInfo = await Biouploaduserinfo.findOne({ cloudIDC, biometricUserIDC });

                if (existingUploadUserInfo) {
                    let incrementValue = 0;

                    if (templateTypeC === "FINGER") {
                        const newValue = existingUploadUserInfo.downloadedFingerTemplateN + matchingTemplatesCount;
                        incrementValue = newValue <= existingUploadUserInfo.fingerCount ? matchingTemplatesCount : Math.max(0, existingUploadUserInfo.fingerCount - existingUploadUserInfo.downloadedFingerTemplateN);
                    }

                    if (templateTypeC === "FACE") {
                        incrementValue = existingUploadUserInfo.downloadedFaceTemplateN < 1 ? 1 : 0;
                    }

                    if (incrementValue > 0) {
                        await Biouploaduserinfo.findOneAndUpdate(
                            { cloudIDC, biometricUserIDC },
                            { $inc: { [incrementField]: incrementValue } },
                            { new: true }
                        );
                    }
                }
            }

            return res.status(200).json({
                returnStatus: true,
                returnMessage: "Successfully updated",
                returnValue: ""
            });
        } else {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        }
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});
//---------------------------------------------------------------------------------------------//
exports.getBioPendingUserTemplate = catchAsyncErrors(async (req, res, next) => {

    try {

        const checkOne = await Biouploaduserinfo.find(
            { cloudIDC: req?.body?.cloudIDC, biometricUserIDC: req?.body?.biometricUserIDC },
            { cloudIDC: 1, biometricUserIDC: 1 }
        );

        let bioData = null;

        if (checkOne?.length > 0) {
            const remaining = checkOne?.map((data) => data?.biometricUserIDC);
            bioData = await Biouploaduserinfo.findOne({
                cloudIDC: req.body.CloudIDC,
                biometricUserIDC: { $ne: { $in: remaining } },
                $or: [
                    { $expr: { $lt: ["$downloadedFingerTemplateN", "$fingerCountN"] } },
                    {
                        $and: [
                            { isFaceEnrolledC: "Yes" },
                            { downloadedFaceTemplateN: 0 }
                        ]
                    }
                ]
            }, { addedby: 0, updatedby: 0, _id: 0 }).sort({ createdAt: -1 });
        } else {
            // Fetch bioData when checkOne is empty
            bioData = await Biouploaduserinfo.findOne({
                cloudIDC: req.body.CloudIDC,
                $or: [
                    { $expr: { $lt: ["$downloadedFingerTemplateN", "$fingerCountN"] } },
                    {
                        $and: [
                            { isFaceEnrolledC: "Yes" },
                            { downloadedFaceTemplateN: 0 }
                        ]
                    }
                ]
            }, { addedby: 0, updatedby: 0, _id: 0 }).sort({ createdAt: -1 });
        }
        // console.log(bioData, 'bioData')
        if (!bioData) {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        } else {
            const bioDataString = JSON.stringify(bioData);
            return res.status(200).json({
                returnStatus: true,
                returnMessage: "Successfully updated",
                returnValue: bioDataString
            });
        }


    } catch (err) {
        console.log(err, 'err')
        return next(new ErrorHandler("Records not found!", 500));
    }
});
exports.getCompleteListCommand = catchAsyncErrors(async (req, res, next) => {
    // console.log(req.body, 'getsendcmd')
    try {
        let { CloudIDC } = req?.body;
        let allbiocmdcpl = await Biocommandcomplete.find({ CloudIDC, StatusC: "Sent" }).sort({ createdAt: -1 });
        if (allbiocmdcpl?.length > 0) {
            const string = JSON.stringify({
                "deviceCommandN": 0,
                "CloudIDC": req.body.CloudIDC,
                "biometricUserIDC": "",
                "param1C": "",
                "param2C": ""
            })
            return res.status(200).json({
                returnStatus: true,
                returnMessage: "",
                returnValue: string
            });
        } else {
            return res.status(200).json({
                returnStatus: false,
                returnMessage: "",
                returnValue: ""
            });
        }
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
});
exports.getSendCommandList = catchAsyncErrors(async (req, res, next) => {
    try {

        return res.status(200).json({
            returnStatus: true,
            returnMessage: "",
            returnValue: req.body
        });
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})