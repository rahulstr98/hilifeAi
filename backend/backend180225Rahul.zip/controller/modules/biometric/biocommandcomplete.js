const Biocommandcomplete = require('../../../model/modules/biometric/biocommandcomplete');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError');

exports.getAllBiocommandcomplete = catchAsyncErrors(async (req, res, next) => {
    let allbiocmdcpl;
    try {
        allbiocmdcpl = await Biocommandcomplete.find();
        return res.status(200).json({
            allbiocmdcpl
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})

exports.getAllBiocommandcompleteCheck = catchAsyncErrors(async (req, res, next) => {
    let command;
    const { cloudIDC } = req.body;
    try {
        command = await Biocommandcomplete.findOne({ cloudIDC });
        if (!command) {
            return res.json({
                returnStatus: "false",
                returnMessage: "No commands available",
                returnValue: "",
            });
        }

        // Update command status to "sent"
        command.status = "Send";
        await command.save();




        return res.status(200).json({
            returnStatus: "true",
            returnMessage: "",
            returnValue: {
                deviceCommandN: command.deviceCommandN,
                cloudIDC: command.cloudIDC,
                biometricUserIDC: command.biometricUserIDC,
                param1C: command.param1C,
                param2C: command.param2C,
            },
        });

    } catch (err) {
        console.log(err , 'err')
        return next(new ErrorHandler("Records not found!", 500));
    }
})



exports.getClounStatuscommandcomplete = catchAsyncErrors(async (req, res, next) => {
    let allbiocmdcpl;
    try {
        allbiocmdcpl = await Biocommandcomplete.find({ deviceCommandN: req.body.deviceCommandN }).sort({ createdAt: -1 });
        return res.status(200).json({
            allbiocmdcpl
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})

exports.addCommandComplete = catchAsyncErrors(async (req, res, next) => {

    try {
        let aallbiocmdcpl = await Biocommandcomplete.create(req.body);

        if (aallbiocmdcpl) {
            aallbiocmdcpl.status = "Completed"
            await aallbiocmdcpl.save()
        }

        return res.status(200).json({
            returnStatus: true,
            returnMessage: "Successfully Updated!!",
            returnValue: aallbiocmdcpl,
            status: aallbiocmdcpl.status
        });
    } catch (err) {
        console.log(err)
        return next(new ErrorHandler("Records not found!", 500));
    }
})
