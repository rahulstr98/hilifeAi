const Biometriconlinestatus = require('../../../model/modules/biometric/biometriconlinestatus');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError'); 

exports.getAllOnlineStatus = catchAsyncErrors(async (req, res, next) => {
    let allonlinestatus;
    try {
        allonlinestatus = await Biometriconlinestatus.find();
        return res.status(200).json({
            allonlinestatus
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})

exports.addOnlineStatus = catchAsyncErrors(async (req, res, next) => {
    
   try{
    let aonlinestatus = await Biometriconlinestatus.create(req.body);
    return res.status(200).json({
        returnStatus : true,
        returnMessage:"Successfully Updated!!",
         returnValue:""
    });
} catch (err) {
    return next(new ErrorHandler("Records not found!", 500));
}
})
