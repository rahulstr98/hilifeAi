const Biogetdeviceinfo = require('../../../model/modules/biometric/getdeviceinfo');
const ErrorHandler = require('../../../utils/errorhandler');
const catchAsyncErrors = require('../../../middleware/catchAsyncError'); 

exports.getAllDeviceinfo = catchAsyncErrors(async (req, res, next) => {
    let alldeviceinfo;
    try {
        alldeviceinfo = await Biogetdeviceinfo.find();

        return res.status(200).json({
            alldeviceinfo
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})


exports.addDeviceinfo = catchAsyncErrors(async (req, res, next) => {
    
  try{
    let addattalog = await Biogetdeviceinfo.create(req.body);
    return res.status(200).json({
        returnStatus : true,
        returnMessage:"Successfully Updated!!",
        returnValue:""
    });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 500));
    }
})
