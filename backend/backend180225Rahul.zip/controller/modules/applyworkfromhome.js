const Applyworkfromhome = require('../../model/modules/applyworkfromhome');
const ErrorHandler = require('../../utils/errorhandler');
const User = require("../../model/login/auth");
const catchAsyncErrors = require('../../middleware/catchAsyncError');
const Leavetype = require('../../model/modules/leave/leavetype');
const LeaveVerification = require("../../model/modules/leave/leaveverification");



//get All Applyworkfromhome =>/api/Applyworkfromhome
exports.getAllApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes;
    try {
        applyworkfromhomes = await Applyworkfromhome.find()
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler('Applyworkfromhome not found!', 404));
    }
    return res.status(200).json({
        applyworkfromhomes
    });
})
exports.getActiveApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes;
    let users;
    try {
        users = await User.find(
            {

                resonablestatus: {
                    $in: ["Not Joined", "Postponed", "Rejected", "Closed", "Releave Employee", "Absconded", "Hold", "Terminate"],
                },
            },
            {

                companyname: 1,
            }
        );

        let companyname = users.map(d => d.companyname)
        applyworkfromhomes = await Applyworkfromhome.find({ employeename: { $nin: companyname }, status: "Applied" }, {});
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler('Data not found!', 404));
    }
    return res.status(200).json({
        applyworkfromhomes
    });
})
//get All Applyworkfromhome =>/api/applyworkfromhomefilter
exports.getAllApplyworkfromhomeFilter = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes;
    try {
        applyworkfromhomes = await Applyworkfromhome.find(
            {},
            {
                company: 1,
                branch: 1,
                unit: 1,
                team: 1,
                department: 1,
                date: 1,
                status: 1,
                employeename: 1,
                employeeid: 1,
                leavetype: 1,
                reasonforleave: 1,
                reasonforworkfromhome: 1,
                rejectedreason: 1,
                numberofdays: 1,
            }
        );
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler("Applyworkfromhome not found!", 404));
    }
    return res.status(200).json({
        applyworkfromhomes,
    });
});

//create new Applyworkfromhome => /api/Applyworkfromhome/new
exports.addApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {

    let aApplyworkfromhome = await Applyworkfromhome.create(req.body);
    return res.status(200).json({
        message: 'Successfully added!'
    });
})

// get Single Applyworkfromhome => /api/Applyworkfromhome/:id
exports.getSingleApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let sapplyworkfromhome = await Applyworkfromhome.findById(id);
    if (!sapplyworkfromhome) {
        return next(new ErrorHandler('Applyworkfromhome not found', 404));
    }
    return res.status(200).json({
        sapplyworkfromhome
    })
})

//update Applyworkfromhome by id => /api/Applyworkfromhome/:id
exports.updateApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let uapplyworkfromhome = await Applyworkfromhome.findByIdAndUpdate(id, req.body);
    if (!uapplyworkfromhome) {
        return next(new ErrorHandler('Applyworkfromhome not found', 404));
    }

    return res.status(200).json({ message: 'Updated successfully' });
})

//delete Applyworkfromhome by id => /api/Applyworkfromhome/:id
exports.deleteApplyworkfromhome = catchAsyncErrors(async (req, res, next) => {
    const id = req.params.id;
    let dapplyworkfromhome = await Applyworkfromhome.findByIdAndRemove(id);
    if (!dapplyworkfromhome) {
        return next(new ErrorHandler('Applyworkfromhome not found', 404));
    }

    return res.status(200).json({ message: 'Deleted successfully' });
})

exports.getAllApplyworkfromhomeApprovedForUserShiftRoaster = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhome;
    let leavetype;
    let applyworkfromhomes = [];
    try {
        applyworkfromhome = await Applyworkfromhome.find({}, { status: req.body.status, usershifts: 1, leavetype: 1, employeeid: 1 },);
        leavetype = await Leavetype.find();

        leavetype?.map((type) => {
            applyworkfromhome?.forEach((d) => {
                if (type.leavetype === d.leavetype) {
                    d.usershifts.forEach((shift) => {
                        applyworkfromhomes.push({
                            date: shift.formattedDate,
                            leavetype: d.leavetype,
                            status: d.status,
                            code: type.code,
                            tookleavecheckstatus: shift.tookleavecheckstatus,
                            leavestatus: shift.leavestatus,
                            shiftcount: shift.shiftcount,
                            empcode: d.employeeid,
                        });
                    });
                }
            });
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler('Applyworkfromhome not found!', 404));
    }
    return res.status(200).json({
        applyworkfromhomes
    });
})
exports.getAllApprovedLeave = catchAsyncErrors(async (req, res, next) => {
    let approvedleaves;
    try {
        approvedleaves = await Applyworkfromhome.find({ status: 'Approved' })
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!approvedleaves) {
        return res.json({});
    }
    return res.status(200).json({
        approvedleaves
    });
});
exports.getAllApplyworkfromhomeApprovedForUserShiftRoasterAssignbranch = catchAsyncErrors(async (req, res, next) => {
    const { assignbranch } = req.body;


    const query = {}
    if (assignbranch.length > 0) {
        query.$or = assignbranch.map(item => ({
            company: item.company,
            branch: item.branch,
            unit: item.unit

        }))
    };

    let applyworkfromhome;
    let leavetype;
    let applyworkfromhomes = [];
    try {
        applyworkfromhome = await Applyworkfromhome.find(query, { status: req.body.status, usershifts: 1, leavetype: 1, employeeid: 1 },);
        leavetype = await Leavetype.find(query);

        leavetype?.map((type) => {
            applyworkfromhome?.forEach((d) => {
                if (type.leavetype === d.leavetype) {
                    d.usershifts.forEach((shift) => {
                        applyworkfromhomes.push({
                            date: shift.formattedDate,
                            leavetype: d.leavetype,
                            status: d.status,
                            code: type.code,
                            tookleavecheckstatus: shift.tookleavecheckstatus,
                            leavestatus: shift.leavestatus,
                            shiftcount: shift.shiftcount,
                            empcode: d.employeeid,
                        });
                    });
                }
            });
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler('Applyworkfromhome not found!', 404));
    }
    return res.status(200).json({
        applyworkfromhomes
    });
})

exports.getAllApplyworkfromhomeHome = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes;
    try {
        const currentDate = new Date();
        const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()}`;
        applyworkfromhomes = await Applyworkfromhome.countDocuments({ status: "Approved", date: { $in: formattedDate } }, { date: 1 })
    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }

    return res.status(200).json({
        applyworkfromhomes
    });
})



exports.getAllApplyworkfromhomeHomeList = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes;
    try {
        const currentDate = new Date();
        const formattedDate = `${currentDate.getDate().toString().padStart(2, '0')}/${(currentDate.getMonth() + 1).toString().padStart(2, '0')}/${currentDate.getFullYear()}`;
        applyworkfromhomes = await Applyworkfromhome.find({ status: "Approved", date: { $in: formattedDate } }, {})

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler('Applyworkfromhome not found!', 404));
    }
    return res.status(200).json({
        applyworkfromhomes
    });
})

exports.getAllApplyworkfromhomeFilterHome = catchAsyncErrors(async (req, res, next) => {
    let applyworkfromhomes, leaveverification;
    try {
        // console.log(req.body, "request")
        if (!req.body.role.includes("Manager")) {
            leaveverification = await LeaveVerification.find({ employeenameto: { $in: req.body.username } }, { employeenamefrom: 1, _id: 0 })
            // console.log(leaveverification.map(d => d.employeenamefrom).flat(), "leaveveri")
            applyworkfromhomes = await Applyworkfromhome.countDocuments(
                {
                    status: "Applied",
                    employeename: { $in: leaveverification.map(d => d.employeenamefrom).flat() }
                },
                {
                    company: 1,
                    branch: 1,
                    unit: 1,
                    team: 1,
                    department: 1,
                    date: 1,
                    status: 1,
                    employeename: 1,
                    employeeid: 1,
                    leavetype: 1,
                    reasonforleave: 1,
                    reasonforworkfromhome: 1,
                    rejectedreason: 1,
                    numberofdays: 1,
                }
            );

        } else {

            applyworkfromhomes = await Applyworkfromhome.countDocuments(
                { status: "Applied", },
                {
                    company: 1,
                    branch: 1,
                    unit: 1,
                    team: 1,
                    department: 1,
                    date: 1,
                    status: 1,
                    employeename: 1,
                    employeeid: 1,
                    leavetype: 1,
                    reasonforleave: 1,
                    reasonforworkfromhome: 1,
                    rejectedreason: 1,
                    numberofdays: 1,
                }
            );


        }


    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    if (!applyworkfromhomes) {
        return next(new ErrorHandler("Applyworkfromhome not found!", 404));
    }
    return res.status(200).json({
        applyworkfromhomes,
    });
});


exports.getAllApplyworkfromhomeApprovedForUserShiftRoasterAssignbranchHome = catchAsyncErrors(async (req, res, next) => {


    let applyworkfromhome;
    let leavetype;
    let applyworkfromhomes = [];
    try {
        applyworkfromhome = await Applyworkfromhome.find({ status: "Approved" }, { status: 1, usershifts: 1, leavetype: 1, employeeid: 1 },);
        leavetype = await Leavetype.find();

        leavetype?.map((type) => {
            applyworkfromhome?.forEach((d) => {
                if (type.leavetype === d.leavetype) {
                    d.usershifts.forEach((shift) => {
                        applyworkfromhomes.push({
                            date: shift.formattedDate,
                            leavetype: d.leavetype,
                            status: d.status,
                            code: type.code,
                            tookleavecheckstatus: shift.tookleavecheckstatus,
                            leavestatus: shift.leavestatus,
                            shiftcount: shift.shiftcount,
                            empcode: d.employeeid,
                        });
                    });
                }
            });
        });

    } catch (err) {
        return next(new ErrorHandler("Records not found!", 404));
    }
    // if (!applyworkfromhomes) {
    //     return next(new ErrorHandler('Applyworkfromhome not found!', 404));
    // }
    return res.status(200).json({
        applyworkfromhomes
    });
})